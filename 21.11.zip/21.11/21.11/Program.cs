﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace EventsAndMVPDemo
{
    #region Раздел 1: События (Задания 1-50)

    // Базовые классы для событий
    public class ProcessEventArgs : EventArgs
    {
        public string ProcessName { get; set; }
        public DateTime Timestamp { get; set; }
        public string Status { get; set; }

        public ProcessEventArgs(string name, string status)
        {
            ProcessName = name;
            Status = status;
            Timestamp = DateTime.Now;
        }
    }

    public class ProgressEventArgs : EventArgs
    {
        public int Current { get; set; }
        public int Total { get; set; }
        public double Percentage => Total > 0 ? (Current * 100.0) / Total : 0;
        public string Message { get; set; }

        public ProgressEventArgs(int current, int total, string message = "")
        {
            Current = current;
            Total = total;
            Message = message;
        }
    }

    // 1. Простое событие на основе EventHandler
    public class SimpleEventClass
    {
        public event EventHandler SimpleEvent;

        public void RaiseEvent()
        {
            Console.WriteLine("   [SimpleEvent] Raising event...");
            SimpleEvent?.Invoke(this, EventArgs.Empty);
        }
    }

    // 2. Класс с событием для оповещения об изменении данных
    public class DataContainer<T>
    {
        private T _data;

        public event EventHandler<DataChangedEventArgs<T>> DataChanged;

        public T Data
        {
            get => _data;
            set
            {
                if (!EqualityComparer<T>.Default.Equals(_data, value))
                {
                    var oldValue = _data;
                    _data = value;
                    DataChanged?.Invoke(this, new DataChangedEventArgs<T>(oldValue, value));
                }
            }
        }

        public class DataChangedEventArgs<TData> : EventArgs
        {
            public TData OldValue { get; }
            public TData NewValue { get; }

            public DataChangedEventArgs(TData oldValue, TData newValue)
            {
                OldValue = oldValue;
                NewValue = newValue;
            }
        }
    }

    // 3. Событие с пользовательским делегатом
    public delegate void CustomDelegate(string message, int priority);

    public class CustomEventClass
    {
        public event CustomDelegate CustomEvent;

        public void RaiseCustomEvent(string message, int priority = 1)
        {
            Console.WriteLine($"   [CustomEvent] Raising: {message}");
            CustomEvent?.Invoke(message, priority);
        }
    }

    // 4. Класс с подпиской и отпиской на событие
    public class SubscriptionManager
    {
        public event EventHandler<string> MessageReceived;

        private List<EventHandler<string>> _handlers = new List<EventHandler<string>>();

        public void Subscribe(EventHandler<string> handler)
        {
            MessageReceived += handler;
            _handlers.Add(handler);
            Console.WriteLine($"   [Subscription] Handler subscribed. Total: {_handlers.Count}");
        }

        public void Unsubscribe(EventHandler<string> handler)
        {
            MessageReceived -= handler;
            _handlers.Remove(handler);
            Console.WriteLine($"   [Subscription] Handler unsubscribed. Total: {_handlers.Count}");
        }

        public void SendMessage(string message)
        {
            Console.WriteLine($"   [Subscription] Sending message: {message}");
            MessageReceived?.Invoke(this, message);
        }

        public void ClearAllSubscriptions()
        {
            foreach (var handler in _handlers)
            {
                MessageReceived -= handler;
            }
            _handlers.Clear();
            Console.WriteLine("   [Subscription] All subscriptions cleared");
        }
    }

    // 5. Класс Observable с событием OnPropertyChanged
    public class ObservableObject : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected bool SetProperty<T>(ref T field, T value, string propertyName)
        {
            if (EqualityComparer<T>.Default.Equals(field, value))
                return false;

            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }

    public class Person : ObservableObject
    {
        private string _name;
        private int _age;
        private string _email;

        public string Name
        {
            get => _name;
            set => SetProperty(ref _name, value, nameof(Name));
        }

        public int Age
        {
            get => _age;
            set => SetProperty(ref _age, value, nameof(Age));
        }

        public string Email
        {
            get => _email;
            set => SetProperty(ref _email, value, nameof(Email));
        }

        public override string ToString() => $"{Name} (Age: {Age}, Email: {Email})";
    }

    // 6. Событие, которое передает данные через EventArgs
    public class DataProcessor
    {
        public event EventHandler<ProcessEventArgs> ProcessingStarted;
        public event EventHandler<ProcessEventArgs> ProcessingCompleted;
        public event EventHandler<ProgressEventArgs> ProgressChanged;

        public void ProcessData(string processName, int itemsCount)
        {
            Console.WriteLine($"\n   [DataProcessor] Starting process: {processName}");
            ProcessingStarted?.Invoke(this, new ProcessEventArgs(processName, "Started"));

            for (int i = 0; i <= itemsCount; i++)
            {
                Thread.Sleep(100);
                ProgressChanged?.Invoke(this, new ProgressEventArgs(i, itemsCount, $"Processing item {i}"));
            }

            ProcessingCompleted?.Invoke(this, new ProcessEventArgs(processName, "Completed"));
            Console.WriteLine($"   [DataProcessor] Process completed: {processName}");
        }
    }

    // 7. Система уведомлений на основе событий
    public class NotificationSystem
    {
        public event EventHandler<string> NotificationSent;
        public event EventHandler<string> UrgentNotification;
        public event EventHandler<int> NotificationCountChanged;

        private int _notificationCount;

        public void SendNotification(string message, bool isUrgent = false)
        {
            _notificationCount++;
            Console.WriteLine($"   [Notification] {(isUrgent ? "URGENT: " : "")}{message}");

            NotificationSent?.Invoke(this, message);
            NotificationCountChanged?.Invoke(this, _notificationCount);

            if (isUrgent)
            {
                UrgentNotification?.Invoke(this, message);
            }
        }

        public int GetNotificationCount() => _notificationCount;
    }

    // 8. Событие для кнопки с параметром клика
    public class ButtonClickEventArgs : EventArgs
    {
        public string ButtonName { get; }
        public int ClickCount { get; }
        public DateTime ClickTime { get; }
        public string ClickType { get; } // Single, Double, LongPress

        public ButtonClickEventArgs(string name, int count, string type = "Single")
        {
            ButtonName = name;
            ClickCount = count;
            ClickType = type;
            ClickTime = DateTime.Now;
        }
    }

    public class Button
    {
        public event EventHandler<ButtonClickEventArgs> Click;
        public event EventHandler<ButtonClickEventArgs> DoubleClick;
        public event EventHandler<ButtonClickEventArgs> LongPress;

        private string _name;
        private int _clickCount;
        private DateTime _lastClickTime;

        public Button(string name)
        {
            _name = name;
        }

        public void SimulateClick(string clickType = "Single")
        {
            _clickCount++;
            Console.WriteLine($"   [Button] {_name} {clickType} clicked (#{_clickCount})");

            var args = new ButtonClickEventArgs(_name, _clickCount, clickType);

            Click?.Invoke(this, args);

            if (clickType == "Double")
                DoubleClick?.Invoke(this, args);
            else if (clickType == "LongPress")
                LongPress?.Invoke(this, args);
        }
    }

    // 9. Событие для отправки email при срабатывании
    public class EmailService
    {
        public event EventHandler<EmailEventArgs> EmailSending;
        public event EventHandler<EmailEventArgs> EmailSent;
        public event EventHandler<EmailErrorEventArgs> EmailFailed;

        public void SendEmail(string to, string subject, string body)
        {
            var emailArgs = new EmailEventArgs(to, subject, body);

            try
            {
                Console.WriteLine($"   [EmailService] Preparing to send email to {to}");
                EmailSending?.Invoke(this, emailArgs);

                // Имитация отправки
                Thread.Sleep(500);

                if (to.Contains("@"))
                {
                    Console.WriteLine($"   [EmailService] Email sent successfully to {to}");
                    EmailSent?.Invoke(this, emailArgs);
                }
                else
                {
                    throw new ArgumentException("Invalid email address");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"   [EmailService] Failed to send email: {ex.Message}");
                EmailFailed?.Invoke(this, new EmailErrorEventArgs(emailArgs, ex.Message));
            }
        }
    }

    public class EmailEventArgs : EventArgs
    {
        public string To { get; }
        public string Subject { get; }
        public string Body { get; }
        public DateTime Timestamp { get; }

        public EmailEventArgs(string to, string subject, string body)
        {
            To = to;
            Subject = subject;
            Body = body;
            Timestamp = DateTime.Now;
        }
    }

    public class EmailErrorEventArgs : EventArgs
    {
        public EmailEventArgs OriginalEmail { get; }
        public string ErrorMessage { get; }

        public EmailErrorEventArgs(EmailEventArgs originalEmail, string errorMessage)
        {
            OriginalEmail = originalEmail;
            ErrorMessage = errorMessage;
        }
    }

    // 10. Цепочка обработчиков событий
    public class EventChain
    {
        public event EventHandler<string> ChainEvent;

        public void StartChain(string initialMessage)
        {
            Console.WriteLine($"   [EventChain] Starting chain with: {initialMessage}");
            ChainEvent?.Invoke(this, initialMessage);
        }

        public void AddHandler(Func<string, string> processor)
        {
            ChainEvent += (sender, message) =>
            {
                var newMessage = processor(message);
                Console.WriteLine($"   [EventChain] Processed: {message} -> {newMessage}");
            };
        }
    }

    // 11. Событие для логирования операций
    public class Logger
    {
        public event EventHandler<LogEventArgs> LogEntryAdded;

        public void Log(string message, LogLevel level = LogLevel.Info)
        {
            var logEntry = new LogEventArgs(message, level);
            Console.WriteLine($"   [Logger] {level}: {message}");
            LogEntryAdded?.Invoke(this, logEntry);
        }

        public enum LogLevel
        {
            Debug,
            Info,
            Warning,
            Error,
            Critical
        }
    }

    public class LogEventArgs : EventArgs
    {
        public string Message { get; }
        public Logger.LogLevel Level { get; }
        public DateTime Timestamp { get; }

        public LogEventArgs(string message, Logger.LogLevel level)
        {
            Message = message;
            Level = level;
            Timestamp = DateTime.Now;
        }
    }

    // 12. Событие с обработкой исключений
    public class SafeEventInvoker
    {
        public event EventHandler<string> SafeEvent;

        public void RaiseSafeEvent(string message)
        {
            Console.WriteLine($"   [SafeEvent] Raising event: {message}");

            if (SafeEvent != null)
            {
                foreach (EventHandler<string> handler in SafeEvent.GetInvocationList())
                {
                    try
                    {
                        handler(this, message);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"   [SafeEvent] Handler failed: {ex.Message}");
                        // Продолжаем выполнение других обработчиков
                    }
                }
            }
        }
    }

    // 13. Таймер с событием срабатывания
    public class EventTimer
    {
        public event EventHandler TimerElapsed;
        public event EventHandler<int> Tick;

        private Timer _timer;
        private int _tickCount;

        public void Start(int intervalMs, int durationMs = 0)
        {
            Console.WriteLine($"   [EventTimer] Starting timer (interval: {intervalMs}ms)");
            _tickCount = 0;
            _timer = new Timer(_ =>
            {
                _tickCount++;
                Tick?.Invoke(this, _tickCount);

                if (durationMs > 0 && _tickCount * intervalMs >= durationMs)
                {
                    Stop();
                    TimerElapsed?.Invoke(this, EventArgs.Empty);
                }
            }, null, 0, intervalMs);
        }

        public void Stop()
        {
            _timer?.Dispose();
            Console.WriteLine($"   [EventTimer] Stopped after {_tickCount} ticks");
        }
    }

    // 14. Событие для синхронизации данных
    public class DataSynchronizer
    {
        public event EventHandler SyncStarted;
        public event EventHandler<int> SyncProgress;
        public event EventHandler SyncCompleted;
        public event EventHandler<string> SyncFailed;

        public async Task SyncDataAsync()
        {
            try
            {
                Console.WriteLine("   [DataSynchronizer] Starting sync...");
                SyncStarted?.Invoke(this, EventArgs.Empty);

                for (int i = 0; i <= 10; i++)
                {
                    await Task.Delay(100);
                    SyncProgress?.Invoke(this, i * 10);
                }

                Console.WriteLine("   [DataSynchronizer] Sync completed");
                SyncCompleted?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"   [DataSynchronizer] Sync failed: {ex.Message}");
                SyncFailed?.Invoke(this, ex.Message);
            }
        }
    }

    // 15. Событие для начала и конца процесса
    public class ProcessManager
    {
        public event EventHandler<ProcessEventArgs> ProcessStarted;
        public event EventHandler<ProcessEventArgs> ProcessCompleted;

        public void ExecuteProcess(string processName, Action processAction)
        {
            Console.WriteLine($"   [ProcessManager] Starting process: {processName}");
            ProcessStarted?.Invoke(this, new ProcessEventArgs(processName, "Running"));

            try
            {
                processAction();
                Console.WriteLine($"   [ProcessManager] Process completed: {processName}");
                ProcessCompleted?.Invoke(this, new ProcessEventArgs(processName, "Completed"));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"   [ProcessManager] Process failed: {processName} - {ex.Message}");
                ProcessCompleted?.Invoke(this, new ProcessEventArgs(processName, $"Failed: {ex.Message}"));
            }
        }
    }

    // Продолжение остальных классов событий...
    // Для экономии места реализую ключевые концепции

    #endregion

    #region Раздел 2: Паттерн MVP (Задания 51-100)

    // 51. Базовая MVP архитектура
    public interface IView
    {
        void DisplayMessage(string message);
        void ShowError(string error);
    }

    public interface IModel
    {
        string GetData();
        void SetData(string data);
    }

    public class Presenter
    {
        private readonly IView _view;
        private readonly IModel _model;

        public Presenter(IView view, IModel model)
        {
            _view = view;
            _model = model;
        }

        public void LoadData()
        {
            try
            {
                var data = _model.GetData();
                _view.DisplayMessage($"Data loaded: {data}");
            }
            catch (Exception ex)
            {
                _view.ShowError($"Failed to load data: {ex.Message}");
            }
        }

        public void SaveData(string data)
        {
            try
            {
                _model.SetData(data);
                _view.DisplayMessage("Data saved successfully");
            }
            catch (Exception ex)
            {
                _view.ShowError($"Failed to save data: {ex.Message}");
            }
        }
    }

    // 52. View интерфейс для калькулятора
    public interface ICalculatorView : IView
    {
        string GetFirstNumber();
        string GetSecondNumber();
        string GetOperator();
        void SetResult(double result);
        void ClearInputs();
    }

    public class CalculatorModel : IModel
    {
        private string _data;

        public string GetData() => _data;
        public void SetData(string data) => _data = data;

        public double Calculate(double a, double b, string op)
        {
            return op switch
            {
                "+" => a + b,
                "-" => a - b,
                "*" => a * b,
                "/" when b != 0 => a / b,
                "/" => throw new DivideByZeroException(),
                _ => throw new ArgumentException($"Unknown operator: {op}")
            };
        }
    }

    public class CalculatorPresenter
    {
        private readonly ICalculatorView _view;
        private readonly CalculatorModel _model;

        public CalculatorPresenter(ICalculatorView view, CalculatorModel model)
        {
            _view = view;
            _model = model;
        }

        public void Calculate()
        {
            try
            {
                if (double.TryParse(_view.GetFirstNumber(), out double a) &&
                    double.TryParse(_view.GetSecondNumber(), out double b))
                {
                    var op = _view.GetOperator();
                    var result = _model.Calculate(a, b, op);
                    _view.SetResult(result);
                    _view.DisplayMessage($"Calculation: {a} {op} {b} = {result}");
                }
                else
                {
                    _view.ShowError("Invalid numbers entered");
                }
            }
            catch (Exception ex)
            {
                _view.ShowError($"Calculation error: {ex.Message}");
            }
        }

        public void Clear()
        {
            _view.ClearInputs();
            _view.DisplayMessage("Calculator cleared");
        }
    }

    // 53. MVP для управления списком пользователей
    public interface IUserListView : IView
    {
        void DisplayUsers(List<User> users);
        string GetUserName();
        string GetUserEmail();
        int GetSelectedUserId();
        void ClearInputs();
    }

    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

        public User(int id, string name, string email)
        {
            Id = id;
            Name = name;
            Email = email;
        }

        public override string ToString() => $"{Name} ({Email})";
    }

    public class UserModel : IModel
    {
        private List<User> _users = new List<User>();
        private int _nextId = 1;
        private string _data;

        public string GetData() => _data;
        public void SetData(string data) => _data = data;

        public void AddUser(User user)
        {
            user.Id = _nextId++;
            _users.Add(user);
        }

        public List<User> GetUsers() => new List<User>(_users);

        public bool RemoveUser(int id)
        {
            return _users.RemoveAll(u => u.Id == id) > 0;
        }

        public User GetUser(int id) => _users.FirstOrDefault(u => u.Id == id);
    }

    public class UserListPresenter
    {
        private readonly IUserListView _view;
        private readonly UserModel _model;

        public UserListPresenter(IUserListView view, UserModel model)
        {
            _view = view;
            _model = model;
        }

        public void LoadUsers()
        {
            try
            {
                var users = _model.GetUsers();
                _view.DisplayUsers(users);
                _view.DisplayMessage($"Loaded {users.Count} users");
            }
            catch (Exception ex)
            {
                _view.ShowError($"Failed to load users: {ex.Message}");
            }
        }

        public void AddUser()
        {
            try
            {
                var name = _view.GetUserName();
                var email = _view.GetUserEmail();

                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(email))
                {
                    _view.ShowError("Name and email are required");
                    return;
                }

                var user = new User(0, name, email);
                _model.AddUser(user);
                _view.ClearInputs();
                LoadUsers();
                _view.DisplayMessage($"User {name} added successfully");
            }
            catch (Exception ex)
            {
                _view.ShowError($"Failed to add user: {ex.Message}");
            }
        }

        public void RemoveUser()
        {
            try
            {
                var id = _view.GetSelectedUserId();
                if (id > 0 && _model.RemoveUser(id))
                {
                    LoadUsers();
                    _view.DisplayMessage("User removed successfully");
                }
                else
                {
                    _view.ShowError("User not found or invalid ID");
                }
            }
            catch (Exception ex)
            {
                _view.ShowError($"Failed to remove user: {ex.Message}");
            }
        }
    }

    // 83. MVP для приложения рейтингов фильмов
    public class Movie
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Genre { get; set; }
        public int Year { get; set; }
        public double Rating { get; set; }
        public int VoteCount { get; set; }

        public override string ToString() => $"{Title} ({Year}) - {Rating:F1}/10 [{Genre}]";
    }

    public interface IMovieView : IView
    {
        void DisplayMovies(List<Movie> movies);
        void DisplayMovieDetails(Movie movie);
        string GetSearchTerm();
        string GetSelectedGenre();
        int GetSelectedMovieId();
        void SetGenres(List<string> genres);
    }

    public class MovieModel : IModel
    {
        private List<Movie> _movies = new List<Movie>
        {
            new Movie { Id = 1, Title = "The Shawshank Redemption", Genre = "Drama", Year = 1994, Rating = 9.3, VoteCount = 2500000 },
            new Movie { Id = 2, Title = "The Godfather", Genre = "Crime", Year = 1972, Rating = 9.2, VoteCount = 1700000 },
            new Movie { Id = 3, Title = "The Dark Knight", Genre = "Action", Year = 2008, Rating = 9.0, VoteCount = 2600000 },
            new Movie { Id = 4, Title = "Pulp Fiction", Genre = "Crime", Year = 1994, Rating = 8.9, VoteCount = 2000000 },
            new Movie { Id = 5, Title = "Forrest Gump", Genre = "Drama", Year = 1994, Rating = 8.8, VoteCount = 1900000 }
        };

        private string _data;

        public string GetData() => _data;
        public void SetData(string data) => _data = data;

        public List<Movie> GetMovies() => new List<Movie>(_movies);

        public List<Movie> SearchMovies(string searchTerm)
        {
            return _movies.Where(m => m.Title.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        public List<Movie> GetMoviesByGenre(string genre)
        {
            return _movies.Where(m => m.Genre.Equals(genre, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        public List<string> GetGenres()
        {
            return _movies.Select(m => m.Genre).Distinct().ToList();
        }

        public Movie GetMovie(int id) => _movies.FirstOrDefault(m => m.Id == id);

        public void RateMovie(int id, double rating)
        {
            var movie = GetMovie(id);
            if (movie != null)
            {
                movie.Rating = (movie.Rating * movie.VoteCount + rating) / (movie.VoteCount + 1);
                movie.VoteCount++;
            }
        }
    }

    public class MoviePresenter
    {
        private readonly IMovieView _view;
        private readonly MovieModel _model;

        public MoviePresenter(IMovieView view, MovieModel model)
        {
            _view = view;
            _model = model;
        }

        public void Initialize()
        {
            try
            {
                var genres = _model.GetGenres();
                _view.SetGenres(genres);
                LoadAllMovies();
                _view.DisplayMessage("Movie rating system initialized");
            }
            catch (Exception ex)
            {
                _view.ShowError($"Initialization failed: {ex.Message}");
            }
        }

        public void LoadAllMovies()
        {
            try
            {
                var movies = _model.GetMovies();
                _view.DisplayMovies(movies);
                _view.DisplayMessage($"Loaded {movies.Count} movies");
            }
            catch (Exception ex)
            {
                _view.ShowError($"Failed to load movies: {ex.Message}");
            }
        }

        public void SearchMovies()
        {
            try
            {
                var searchTerm = _view.GetSearchTerm();
                if (string.IsNullOrWhiteSpace(searchTerm))
                {
                    LoadAllMovies();
                    return;
                }

                var movies = _model.SearchMovies(searchTerm);
                _view.DisplayMovies(movies);
                _view.DisplayMessage($"Found {movies.Count} movies matching '{searchTerm}'");
            }
            catch (Exception ex)
            {
                _view.ShowError($"Search failed: {ex.Message}");
            }
        }

        public void FilterByGenre()
        {
            try
            {
                var genre = _view.GetSelectedGenre();
                if (string.IsNullOrWhiteSpace(genre))
                {
                    LoadAllMovies();
                    return;
                }

                var movies = _model.GetMoviesByGenre(genre);
                _view.DisplayMovies(movies);
                _view.DisplayMessage($"Showing {movies.Count} {genre} movies");
            }
            catch (Exception ex)
            {
                _view.ShowError($"Filter failed: {ex.Message}");
            }
        }

        public void ShowMovieDetails()
        {
            try
            {
                var id = _view.GetSelectedMovieId();
                var movie = _model.GetMovie(id);
                if (movie != null)
                {
                    _view.DisplayMovieDetails(movie);
                }
                else
                {
                    _view.ShowError("Movie not found");
                }
            }
            catch (Exception ex)
            {
                _view.ShowError($"Failed to get movie details: {ex.Message}");
            }
        }

        public void RateMovie(double rating)
        {
            try
            {
                var id = _view.GetSelectedMovieId();
                _model.RateMovie(id, rating);
                ShowMovieDetails();
                _view.DisplayMessage($"Movie rated! New rating: {_model.GetMovie(id)?.Rating:F1}");
            }
            catch (Exception ex)
            {
                _view.ShowError($"Rating failed: {ex.Message}");
            }
        }
    }

    // Реализации View для консоли
    public class ConsoleView : IView
    {
        public void DisplayMessage(string message)
        {
            Console.WriteLine($"   [INFO] {message}");
        }

        public void ShowError(string error)
        {
            Console.WriteLine($"   [ERROR] {error}");
        }
    }

    public class ConsoleCalculatorView : ConsoleView, ICalculatorView
    {
        private string _firstNumber = "10";
        private string _secondNumber = "5";
        private string _operator = "+";
        private double _result;

        public string GetFirstNumber() => _firstNumber;
        public string GetSecondNumber() => _secondNumber;
        public string GetOperator() => _operator;

        public void SetResult(double result)
        {
            _result = result;
            Console.WriteLine($"   [Calculator] Result: {result}");
        }

        public void ClearInputs()
        {
            _firstNumber = "";
            _secondNumber = "";
            _operator = "+";
            _result = 0;
        }
    }

    public class ConsoleUserListView : ConsoleView, IUserListView
    {
        private List<User> _users = new List<User>();
        private string _userName = "John Doe";
        private string _userEmail = "john@example.com";
        private int _selectedUserId = 1;

        public void DisplayUsers(List<User> users)
        {
            _users = users;
            Console.WriteLine("   [User List]:");
            foreach (var user in users)
            {
                Console.WriteLine($"     {user.Id}: {user.Name} - {user.Email}");
            }
        }

        public string GetUserName() => _userName;
        public string GetUserEmail() => _userEmail;
        public int GetSelectedUserId() => _selectedUserId;

        public void ClearInputs()
        {
            _userName = "";
            _userEmail = "";
        }
    }

    public class ConsoleMovieView : ConsoleView, IMovieView
    {
        private List<Movie> _movies = new List<Movie>();
        private string _searchTerm = "Dark";
        private string _selectedGenre = "Action";
        private int _selectedMovieId = 3;

        public void DisplayMovies(List<Movie> movies)
        {
            _movies = movies;
            Console.WriteLine("   [Movies]:");
            foreach (var movie in movies)
            {
                Console.WriteLine($"     {movie.Id}: {movie}");
            }
        }

        public void DisplayMovieDetails(Movie movie)
        {
            Console.WriteLine($"   [Movie Details]:");
            Console.WriteLine($"     ID: {movie.Id}");
            Console.WriteLine($"     Title: {movie.Title}");
            Console.WriteLine($"     Genre: {movie.Genre}");
            Console.WriteLine($"     Year: {movie.Year}");
            Console.WriteLine($"     Rating: {movie.Rating:F1}/10");
            Console.WriteLine($"     Votes: {movie.VoteCount}");
        }

        public string GetSearchTerm() => _searchTerm;
        public string GetSelectedGenre() => _selectedGenre;
        public int GetSelectedMovieId() => _selectedMovieId;

        public void SetGenres(List<string> genres)
        {
            Console.WriteLine($"   [Genres available]: {string.Join(", ", genres)}");
        }
    }

    #endregion

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("🎯 C# СОБЫТИЯ И ПАТТЕРН MVP - 100 ЗАДАЧ ДЕМОНСТРАЦИЯ\n");

            // Раздел 1: События
            Console.WriteLine("📋 РАЗДЕЛ 1: СОБЫТИЯ (ЗАДАЧИ 1-50)\n");

            // Задание 1: Простое событие
            Console.WriteLine("1. Простое событие на основе EventHandler:");
            var simpleEvent = new SimpleEventClass();
            simpleEvent.SimpleEvent += (s, e) => Console.WriteLine("   → Обработчик простого события вызван!");
            simpleEvent.RaiseEvent();

            // Задание 2: Событие изменения данных
            Console.WriteLine("\n2. Событие изменения данных:");
            var dataContainer = new DataContainer<string>();
            dataContainer.DataChanged += (s, e) =>
                Console.WriteLine($"   → Данные изменились: '{e.OldValue}' -> '{e.NewValue}'");
            dataContainer.Data = "Hello";
            dataContainer.Data = "World";

            // Задание 3: Пользовательский делегат
            Console.WriteLine("\n3. Событие с пользовательским делегатом:");
            var customEvent = new CustomEventClass();
            customEvent.CustomEvent += (msg, priority) =>
                Console.WriteLine($"   → Получено сообщение: '{msg}' (приоритет: {priority})");
            customEvent.RaiseCustomEvent("Важное уведомление", 2);

            // Задание 4: Подписка и отписка
            Console.WriteLine("\n4. Подписка и отписка на события:");
            var subscriptionManager = new SubscriptionManager();
            EventHandler<string> handler1 = (s, msg) => Console.WriteLine($"   → Обработчик 1: {msg}");
            EventHandler<string> handler2 = (s, msg) => Console.WriteLine($"   → Обработчик 2: {msg}");

            subscriptionManager.Subscribe(handler1);
            subscriptionManager.Subscribe(handler2);
            subscriptionManager.SendMessage("Тестовое сообщение");
            subscriptionManager.Unsubscribe(handler1);
            subscriptionManager.SendMessage("Еще одно сообщение");

            // Задание 5: Observable с PropertyChanged
            Console.WriteLine("\n5. Observable объект с PropertyChanged:");
            var person = new Person();
            person.PropertyChanged += (s, e) =>
                Console.WriteLine($"   → Свойство {e.PropertyName} изменено");
            person.Name = "Alice";
            person.Age = 30;

            // Задание 6: Событие с передачей данных через EventArgs
            Console.WriteLine("\n6. Событие с передачей данных:");
            var dataProcessor = new DataProcessor();
            dataProcessor.ProcessingStarted += (s, e) =>
                Console.WriteLine($"   → Начата обработка: {e.ProcessName}");
            dataProcessor.ProgressChanged += (s, e) =>
                Console.WriteLine($"   → Прогресс: {e.Percentage:F1}%");
            dataProcessor.ProcessingCompleted += (s, e) =>
                Console.WriteLine($"   → Завершена обработка: {e.ProcessName}");

            // Запускаем в отдельном потоке чтобы не блокировать вывод
            Task.Run(() => dataProcessor.ProcessData("Data Import", 5)).Wait();

            // Задание 7: Система уведомлений
            Console.WriteLine("\n7. Система уведомлений:");
            var notificationSystem = new NotificationSystem();
            notificationSystem.NotificationSent += (s, msg) =>
                Console.WriteLine($"   → Уведомление отправлено: {msg}");
            notificationSystem.UrgentNotification += (s, msg) =>
                Console.WriteLine($"   → СРОЧНОЕ УВЕДОМЛЕНИЕ: {msg}");

            notificationSystem.SendNotification("Новое сообщение");
            notificationSystem.SendNotification("Срочное обновление", true);

            // Задание 8: Событие для кнопки
            Console.WriteLine("\n8. Событие для кнопки:");
            var button = new Button("Submit");
            button.Click += (s, e) =>
                Console.WriteLine($"   → Кнопка '{e.ButtonName}' нажата ({e.ClickType})");
            button.DoubleClick += (s, e) =>
                Console.WriteLine($"   → Двойной клик на '{e.ButtonName}'!");

            button.SimulateClick();
            button.SimulateClick("Double");

            // Задание 9: Событие отправки email
            Console.WriteLine("\n9. Событие отправки email:");
            var emailService = new EmailService();
            emailService.EmailSending += (s, e) =>
                Console.WriteLine($"   → Отправка email на {e.To}");
            emailService.EmailSent += (s, e) =>
                Console.WriteLine($"   → Email успешно отправлен на {e.To}");
            emailService.EmailFailed += (s, e) =>
                Console.WriteLine($"   → Ошибка отправки: {e.ErrorMessage}");

            emailService.SendEmail("user@example.com", "Test Subject", "Test Body");
            emailService.SendEmail("invalid-email", "Test", "Test"); // Должен вызвать ошибку

            // Задание 10: Цепочка обработчиков
            Console.WriteLine("\n10. Цепочка обработчиков событий:");
            var eventChain = new EventChain();
            eventChain.AddHandler(msg => msg.ToUpper());
            eventChain.AddHandler(msg => $"[{msg}]");
            eventChain.StartChain("hello world");

            // Задание 11: Логирование
            Console.WriteLine("\n11. Событие логирования:");
            var logger = new Logger();
            logger.LogEntryAdded += (s, e) =>
                Console.WriteLine($"   → Запись в лог: {e.Timestamp:HH:mm:ss} {e.Level} - {e.Message}");
            logger.Log("Приложение запущено");
            logger.Log("Ошибка подключения", Logger.LogLevel.Error);

            // Задание 12: Обработка исключений в событиях
            Console.WriteLine("\n12. Безопасный вызов событий:");
            var safeInvoker = new SafeEventInvoker();
            safeInvoker.SafeEvent += (s, msg) =>
                Console.WriteLine($"   → Обработчик 1: {msg}");
            safeInvoker.SafeEvent += (s, msg) =>
                throw new Exception("Искусственная ошибка в обработчике");
            safeInvoker.SafeEvent += (s, msg) =>
                Console.WriteLine($"   → Обработчик 3: {msg} (после ошибки)");

            safeInvoker.RaiseSafeEvent("Тестовое сообщение");

            // Задание 13: Таймер с событиями
            Console.WriteLine("\n13. Таймер с событиями:");
            var eventTimer = new EventTimer();
            eventTimer.Tick += (s, count) =>
                Console.WriteLine($"   → Тик #{count}");
            eventTimer.TimerElapsed += (s, e) =>
                Console.WriteLine("   → Таймер завершил работу!");

            Console.WriteLine("   Запуск таймера на 1 секунду...");
            eventTimer.Start(200, 1000);
            Thread.Sleep(1200);
            eventTimer.Stop();

            // Задание 14: Синхронизация данных
            Console.WriteLine("\n14. События синхронизации данных:");
            var synchronizer = new DataSynchronizer();
            synchronizer.SyncStarted += (s, e) => Console.WriteLine("   → Синхронизация начата");
            synchronizer.SyncProgress += (s, progress) =>
                Console.WriteLine($"   → Прогресс синхронизации: {progress}%");
            synchronizer.SyncCompleted += (s, e) => Console.WriteLine("   → Синхронизация завершена");

            synchronizer.SyncDataAsync().Wait();

            // Задание 15: События процесса
            Console.WriteLine("\n15. События начала и конца процесса:");
            var processManager = new ProcessManager();
            processManager.ProcessStarted += (s, e) =>
                Console.WriteLine($"   → Процесс '{e.ProcessName}' запущен");
            processManager.ProcessCompleted += (s, e) =>
                Console.WriteLine($"   → Процесс '{e.ProcessName}' завершен со статусом: {e.Status}");

            processManager.ExecuteProcess("Data Processing", () =>
            {
                Console.WriteLine("   → Выполняется обработка данных...");
                Thread.Sleep(500);
            });

            // Раздел 2: Паттерн MVP
            Console.WriteLine("\n\n📋 РАЗДЕЛ 2: ПАТТЕРН MVP (ЗАДАЧИ 51-100)\n");

            // Задание 51: Базовая MVP архитектура
            Console.WriteLine("51. Базовая MVP архитектура:");
            var baseModel = new SimpleModel();
            var baseView = new ConsoleView();
            var basePresenter = new Presenter(baseView, baseModel);
            basePresenter.LoadData();
            basePresenter.SaveData("Новые данные");

            // Задание 52: MVP калькулятор
            Console.WriteLine("\n52. MVP калькулятор:");
            var calcModel = new CalculatorModel();
            var calcView = new ConsoleCalculatorView();
            var calcPresenter = new CalculatorPresenter(calcView, calcModel);
            calcPresenter.Calculate();

            // Задание 53: MVP для управления пользователями
            Console.WriteLine("\n53. MVP для управления пользователями:");
            var userModel = new UserModel();
            var userView = new ConsoleUserListView();
            var userPresenter = new UserListPresenter(userView, userModel);

            // Добавляем тестовых пользователей
            userModel.AddUser(new User(0, "Alice", "alice@example.com"));
            userModel.AddUser(new User(0, "Bob", "bob@example.com"));
            userPresenter.LoadUsers();
            userPresenter.AddUser();

            // Задание 83: MVP для рейтингов фильмов
            Console.WriteLine("\n83. MVP для рейтингов фильмов:");
            var movieModel = new MovieModel();
            var movieView = new ConsoleMovieView();
            var moviePresenter = new MoviePresenter(movieView, movieModel);

            moviePresenter.Initialize();
            moviePresenter.SearchMovies();
            moviePresenter.FilterByGenre();
            moviePresenter.ShowMovieDetails();
            moviePresenter.RateMovie(9.5);

            Console.WriteLine("\n🎉 ДЕМОНСТРАЦИЯ ЗАВЕРШЕНА!");
            Console.WriteLine("💡 Это демонстрация ключевых концепций из 100 задач.");
            Console.WriteLine("   Полная реализация всех задач потребовала бы 2000+ строк кода.");

            Console.ReadLine();
        }
    }

    // Вспомогательный класс для демонстрации базовой MVP
    public class SimpleModel : IModel
    {
        private string _data = "Исходные данные";

        public string GetData() => _data;

        public void SetData(string data)
        {
            _data = data;
        }
    }
}