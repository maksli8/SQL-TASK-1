﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADONET_Practice
{
    class Program
    {
        // Имитация базы данных в памяти
        private static DataSet _schoolDatabase = new DataSet("SchoolDB");
        private static DataSet _businessDatabase = new DataSet("BusinessDB");

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== ПРАКТИЧЕСКИЕ ЗАДАНИЯ ПО ADO.NET ===");
                Console.WriteLine("Выберите задание для выполнения (1-10):");
                Console.WriteLine("1. Отслеживание изменений состояния строк (RowState)");
                Console.WriteLine("2. Работа с версиями данных (DataRowVersion)");
                Console.WriteLine("3. Фильтрация и поиск с DataView");
                Console.WriteLine("4. Создание TableAdapter (имитация)");
                Console.WriteLine("5. Методы получения данных TableAdapter");
                Console.WriteLine("6. Информация о структуре БД");
                Console.WriteLine("7. Сопоставление таблиц (DataTableMapping)");
                Console.WriteLine("8. Сопоставление колонок (DataColumnMapping)");
                Console.WriteLine("9. Комплексная работа со всеми концепциями");
                Console.WriteLine("10. Оптимизация больших объемов данных");
                Console.WriteLine("0. Выход");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    switch (choice)
                    {
                        case 1: Task1_RowStateTracking(); break;
                        case 2: Task2_DataRowVersion(); break;
                        case 3: Task3_DataViewFiltering(); break;
                        case 4: Task4_TableAdapterCreation(); break;
                        case 5: Task5_TableAdapterMethods(); break;
                        case 6: Task6_DatabaseStructure(); break;
                        case 8: Task8_ColumnMapping(); break;
                        case 9: Task9_ComplexWork(); break;
                        case 10: Task10_DataOptimization(); break;
                        case 0: return;
                        default: Console.WriteLine("Неверный выбор!"); break;
                    }
                }

                Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                Console.ReadKey();
            }
        }

        #region Задание 1: Отслеживание изменений состояния строк
        static void Task1_RowStateTracking()
        {
            Console.Clear();
            Console.WriteLine("=== ЗАДАНИЕ 1: Отслеживание изменений состояния строк ===");

            // Создаем таблицу учащихся
            DataTable studentsTable = CreateStudentsTable();

            // Добавляем начальные данные
            AddInitialStudents(studentsTable);
            Console.WriteLine("Исходные данные:");
            PrintStudentsTable(studentsTable);

            // 1. Добавляем 3 новых учащихся
            Console.WriteLine("\n1. Добавление 3 новых учащихся:");
            DataRow newStudent1 = studentsTable.NewRow();
            newStudent1["ID"] = 4;
            newStudent1["ФИО"] = "Иванов Иван Иванович";
            newStudent1["Email"] = "ivanov@school.ru";
            newStudent1["Класс"] = "10Б";
            newStudent1["СредняяОценка"] = 4.2;
            studentsTable.Rows.Add(newStudent1);

            DataRow newStudent2 = studentsTable.NewRow();
            newStudent2["ID"] = 5;
            newStudent2["ФИО"] = "Петрова Анна Сергеевна";
            newStudent2["Email"] = "petrova@school.ru";
            newStudent2["Класс"] = "11А";
            newStudent2["СредняяОценка"] = 4.8;
            studentsTable.Rows.Add(newStudent2);

            DataRow newStudent3 = studentsTable.NewRow();
            newStudent3["ID"] = 6;
            newStudent3["ФИО"] = "Сидоров Петр Васильевич";
            newStudent3["Email"] = "sidorov@school.ru";
            newStudent3["Класс"] = "9В";
            newStudent3["СредняяОценка"] = 3.9;
            studentsTable.Rows.Add(newStudent3);

            PrintRowStates(studentsTable);

            // 2. Редактируем 2 существующих учащихся
            Console.WriteLine("\n2. Редактирование 2 существующих учащихся:");
            studentsTable.Rows[0]["Email"] = "novikov.new@school.ru";
            studentsTable.Rows[0]["СредняяОценка"] = 4.7;

            studentsTable.Rows[1]["Email"] = "smirnova.new@school.ru";
            studentsTable.Rows[1]["СредняяОценка"] = 4.4;

            PrintRowStates(studentsTable);

            // 3. Удаляем 1 учащегося
            Console.WriteLine("\n3. Удаление 1 учащегося:");
            studentsTable.Rows[2].Delete();

            PrintRowStates(studentsTable);

            // 4. Подробный отчет о всех строках
            Console.WriteLine("\n4. Подробный отчет о всех строках:");
            PrintDetailedReport(studentsTable);

            // 5. Получаем только измененные строки
            Console.WriteLine("\n5. Только измененные строки (GetChanges):");
            DataTable changedTable = studentsTable.GetChanges();
            if (changedTable != null)
            {
                PrintDetailedReport(changedTable);
            }
        }

        static DataTable CreateStudentsTable()
        {
            DataTable table = new DataTable("Учащиеся");

            table.Columns.Add("ID", typeof(int));
            table.Columns.Add("ФИО", typeof(string));
            table.Columns.Add("Email", typeof(string));
            table.Columns.Add("Класс", typeof(string));
            table.Columns.Add("СредняяОценка", typeof(double));

            table.PrimaryKey = new DataColumn[] { table.Columns["ID"] };

            return table;
        }

        static void AddInitialStudents(DataTable table)
        {
            DataRow row1 = table.NewRow();
            row1["ID"] = 1;
            row1["ФИО"] = "Новиков Алексей Петрович";
            row1["Email"] = "novikov@school.ru";
            row1["Класс"] = "11А";
            row1["СредняяОценка"] = 4.5;
            table.Rows.Add(row1);

            DataRow row2 = table.NewRow();
            row2["ID"] = 2;
            row2["ФИО"] = "Смирнова Ольга Игоревна";
            row2["Email"] = "smirnova@school.ru";
            row2["Класс"] = "10Б";
            row2["СредняяОценка"] = 4.3;
            table.Rows.Add(row2);

            DataRow row3 = table.NewRow();
            row3["ID"] = 3;
            row3["ФИО"] = "Козлов Дмитрий Сергеевич";
            row3["Email"] = "kozlov@school.ru";
            row3["Класс"] = "9А";
            row3["СредняяОценка"] = 3.8;
            table.Rows.Add(row3);

            table.AcceptChanges(); // Принимаем изменения, чтобы начальные строки имели состояние Unchanged
        }

        static void PrintStudentsTable(DataTable table)
        {
            Console.WriteLine($"Таблица: {table.TableName}");
            Console.WriteLine(new string('-', 80));
            Console.WriteLine("| {0,3} | {1,25} | {2,20} | {3,5} | {4,5} |",
                "ID", "ФИО", "Email", "Класс", "Оценка");
            Console.WriteLine(new string('-', 80));

            foreach (DataRow row in table.Rows)
            {
                if (row.RowState != DataRowState.Deleted)
                {
                    Console.WriteLine("| {0,3} | {1,25} | {2,20} | {3,5} | {4,5:F1} |",
                        row["ID"], row["ФИО"], row["Email"], row["Класс"], row["СредняяОценка"]);
                }
            }
            Console.WriteLine(new string('-', 80));
        }

        static void PrintRowStates(DataTable table)
        {
            Console.WriteLine("Состояния строк:");
            Console.WriteLine(new string('-', 80));
            Console.WriteLine("| {0,3} | {1,25} | {2,15} |", "ID", "ФИО", "RowState");
            Console.WriteLine(new string('-', 80));

            foreach (DataRow row in table.Rows)
            {
                string fio = row.RowState == DataRowState.Deleted ? "УДАЛЕНО" : row["ФИО"].ToString();
                Console.WriteLine("| {0,3} | {1,25} | {2,15} |",
                    row["ID", DataRowVersion.Original], fio, row.RowState);
            }
            Console.WriteLine(new string('-', 80));
        }

        static void PrintDetailedReport(DataTable table)
        {
            Console.WriteLine("Подробный отчет:");
            Console.WriteLine(new string('-', 100));

            foreach (DataRow row in table.Rows)
            {
                Console.WriteLine($"Строка ID={row["ID", DataRowVersion.Original]}");
                Console.WriteLine($"  Состояние: {row.RowState}");

                if (row.RowState == DataRowState.Modified)
                {
                    Console.WriteLine("  Измененные поля:");
                    foreach (DataColumn column in table.Columns)
                    {
                        if (row[column.ColumnName, DataRowVersion.Original].ToString() !=
                            row[column.ColumnName, DataRowVersion.Current].ToString())
                        {
                            Console.WriteLine($"    {column.ColumnName}: {row[column.ColumnName, DataRowVersion.Original]} -> {row[column.ColumnName, DataRowVersion.Current]}");
                        }
                    }
                }
                else if (row.RowState == DataRowState.Added)
                {
                    Console.WriteLine("  Все поля (новая строка):");
                    foreach (DataColumn column in table.Columns)
                    {
                        Console.WriteLine($"    {column.ColumnName}: {row[column.ColumnName]}");
                    }
                }
                else if (row.RowState == DataRowState.Deleted)
                {
                    Console.WriteLine("  Удаленная строка (оригинальные значения):");
                    foreach (DataColumn column in table.Columns)
                    {
                        Console.WriteLine($"    {column.ColumnName}: {row[column.ColumnName, DataRowVersion.Original]}");
                    }
                }
                Console.WriteLine(new string('-', 100));
            }
        }
        #endregion

        #region Задание 2: Работа с DataRowVersion
        static void Task2_DataRowVersion()
        {
            Console.Clear();
            Console.WriteLine("=== ЗАДАНИЕ 2: Работа с DataRowVersion ===");

            // Создаем таблицу товаров
            DataTable productsTable = CreateProductsTable();
            AddInitialProducts(productsTable);

            Console.WriteLine("Исходные данные товаров:");
            PrintProductsTable(productsTable);

            // Изменяем несколько товаров
            Console.WriteLine("\nИзменение товаров:");

            // Изменяем цену первого товара
            productsTable.Rows[0]["Цена"] = 12999.99m;
            productsTable.Rows[0]["КоличествоНаСкладе"] = 8;

            // Изменяем второй товар
            productsTable.Rows[1]["Цена"] = 23999.99m;
            productsTable.Rows[1]["СтатусДоступности"] = false;

            // Добавляем новый товар
            DataRow newProduct = productsTable.NewRow();
            newProduct["ID"] = 4;
            newProduct["Название"] = "Планшет Samsung";
            newProduct["Цена"] = 15999.99m;
            newProduct["КоличествоНаСкладе"] = 15;
            newProduct["СтатусДоступности"] = true;
            productsTable.Rows.Add(newProduct);

            // Выводим отчет с версиями
            PrintVersionReport(productsTable);

            // Отчет только по измененным товарам
            Console.WriteLine("\nОтчет только по товарам с измененной ценой:");
            PrintPriceChangeReport(productsTable);

            // Вывод всех версий для строки
            Console.WriteLine("\nВсе версии данных для первой строки:");
            PrintAllRowVersions(productsTable.Rows[0]);
        }

        static DataTable CreateProductsTable()
        {
            DataTable table = new DataTable("Товары");

            table.Columns.Add("ID", typeof(int));
            table.Columns.Add("Название", typeof(string));
            table.Columns.Add("Цена", typeof(decimal));
            table.Columns.Add("КоличествоНаСкладе", typeof(int));
            table.Columns.Add("СтатусДоступности", typeof(bool));

            table.PrimaryKey = new DataColumn[] { table.Columns["ID"] };

            return table;
        }

        static void AddInitialProducts(DataTable table)
        {
            DataRow row1 = table.NewRow();
            row1["ID"] = 1;
            row1["Название"] = "Ноутбук HP";
            row1["Цена"] = 11999.99m;
            row1["КоличествоНаСкладе"] = 10;
            row1["СтатусДоступности"] = true;
            table.Rows.Add(row1);

            DataRow row2 = table.NewRow();
            row2["ID"] = 2;
            row2["Название"] = "Смартфон Xiaomi";
            row2["Цена"] = 22999.99m;
            row2["КоличествоНаСкладе"] = 25;
            row2["СтатусДоступности"] = true;
            table.Rows.Add(row2);

            DataRow row3 = table.NewRow();
            row3["ID"] = 3;
            row3["Название"] = "Наушники Sony";
            row3["Цена"] = 5999.99m;
            row3["КоличествоНаСкладе"] = 0;
            row3["СтатусДоступности"] = false;
            table.Rows.Add(row3);

            table.AcceptChanges();
        }

        static void PrintProductsTable(DataTable table)
        {
            Console.WriteLine(new string('-', 90));
            Console.WriteLine("| {0,3} | {1,20} | {2,10} | {3,8} | {4,8} |",
                "ID", "Название", "Цена", "Склад", "Доступен");
            Console.WriteLine(new string('-', 90));

            foreach (DataRow row in table.Rows)
            {
                if (row.RowState != DataRowState.Deleted)
                {
                    Console.WriteLine("| {0,3} | {1,20} | {2,10:C2} | {3,8} | {4,8} |",
                        row["ID"], row["Название"], row["Цена"],
                        row["КоличествоНаСкладе"], row["СтатусДоступности"]);
                }
            }
            Console.WriteLine(new string('-', 90));
        }

        static void PrintVersionReport(DataTable table)
        {
            Console.WriteLine("\nОтчет по версиям данных:");
            Console.WriteLine(new string('-', 100));
            Console.WriteLine("| {0,3} | {1,15} | {2,15} | {3,10} | {4,10} |",
                "ID", "Оригинальная цена", "Текущая цена", "Разница", "Изменение %");
            Console.WriteLine(new string('-', 100));

            foreach (DataRow row in table.Rows)
            {
                if (row.RowState == DataRowState.Modified || row.RowState == DataRowState.Unchanged)
                {
                    try
                    {
                        decimal originalPrice = (decimal)row["Цена", DataRowVersion.Original];
                        decimal currentPrice = (decimal)row["Цена", DataRowVersion.Current];
                        decimal difference = currentPrice - originalPrice;
                        decimal percentChange = originalPrice != 0 ? (difference / originalPrice) * 100 : 0;

                        Console.WriteLine("| {0,3} | {1,15:C2} | {2,15:C2} | {3,10:C2} | {4,10:F2}% |",
                            row["ID"], originalPrice, currentPrice, difference, percentChange);
                    }
                    catch (VersionNotFoundException)
                    {
                        // Для новых строк Original версия недоступна
                        Console.WriteLine("| {0,3} | {1,15} | {2,15:C2} | {3,10} | {4,10} |",
                            row["ID"], "НОВЫЙ", row["Цена"], "Н/Д", "Н/Д");
                    }
                }
            }
            Console.WriteLine(new string('-', 100));
        }

        static void PrintPriceChangeReport(DataTable table)
        {
            var changedRows = table.Select("", "", DataViewRowState.ModifiedCurrent | DataViewRowState.ModifiedOriginal);

            foreach (DataRow row in changedRows)
            {
                try
                {
                    decimal originalPrice = (decimal)row["Цена", DataRowVersion.Original];
                    decimal currentPrice = (decimal)row["Цена", DataRowVersion.Current];

                    if (originalPrice != currentPrice)
                    {
                        Console.WriteLine($"Товар ID={row["ID"]}: {row["Название"]}");
                        Console.WriteLine($"  Цена изменена: {originalPrice:C2} -> {currentPrice:C2}");
                        Console.WriteLine($"  Изменение: {(currentPrice - originalPrice):C2} ({((currentPrice - originalPrice) / originalPrice * 100):F2}%)");
                    }
                }
                catch (VersionNotFoundException) { }
            }
        }

        static void PrintAllRowVersions(DataRow row)
        {
            Console.WriteLine($"Строка ID={row["ID"]}, Название: {row["Название"]}");

            // Original версия (если доступна)
            try
            {
                Console.WriteLine("\nOriginal версия:");
                Console.WriteLine($"  Цена: {row["Цена", DataRowVersion.Original]}");
                Console.WriteLine($"  Количество: {row["КоличествоНаСкладе", DataRowVersion.Original]}");
                Console.WriteLine($"  Доступность: {row["СтатусДоступности", DataRowVersion.Original]}");
            }
            catch (VersionNotFoundException)
            {
                Console.WriteLine("  Original версия недоступна");
            }

            // Current версия
            Console.WriteLine("\nCurrent версия:");
            Console.WriteLine($"  Цена: {row["Цена", DataRowVersion.Current]}");
            Console.WriteLine($"  Количество: {row["КоличествоНаСкладе", DataRowVersion.Current]}");
            Console.WriteLine($"  Доступность: {row["СтатусДоступности", DataRowVersion.Current]}");

            // Proposed версия (если есть)
            try
            {
                Console.WriteLine("\nProposed версия:");
                Console.WriteLine($"  Цена: {row["Цена", DataRowVersion.Proposed]}");
                Console.WriteLine($"  Количество: {row["КоличествоНаСкладе", DataRowVersion.Proposed]}");
                Console.WriteLine($"  Доступность: {row["СтатусДоступности", DataRowVersion.Proposed]}");
            }
            catch (VersionNotFoundException)
            {
                Console.WriteLine("  Proposed версия недоступна");
            }
        }
        #endregion

        #region Задание 3: Фильтрация и поиск с DataView
        static void Task3_DataViewFiltering()
        {
            Console.Clear();
            Console.WriteLine("=== ЗАДАНИЕ 3: Фильтрация и поиск с DataView ===");

            // Создаем и заполняем таблицы
            DataTable employeesTable = CreateEmployeesTable();
            DataTable projectsTable = CreateProjectsTable();

            AddInitialEmployees(employeesTable);
            AddInitialProjects(projectsTable);

            Console.WriteLine("Исходные данные сотрудников:");
            PrintEmployeesTable(employeesTable);

            Console.WriteLine("\nИсходные данные проектов:");
            PrintProjectsTable(projectsTable);

            // 1. Поиск сотрудников по фамилии
            Console.WriteLine("\n1. Поиск сотрудников по фамилии (частичный):");
            string searchLastName = "ов";
            DataRow[] foundRows = employeesTable.Select($"ФИО LIKE '%{searchLastName}%'");
            Console.WriteLine($"Результаты поиска по '{searchLastName}':");
            foreach (DataRow row in foundRows)
            {
                Console.WriteLine($"  {row["ID"]}: {row["ФИО"]} - {row["Отдел"]}");
            }

            // 2. Фильтрация по отделу с использованием DataView
            Console.WriteLine("\n2. Фильтрация сотрудников по отделу (IT):");
            DataView itEmployeesView = new DataView(employeesTable);
            itEmployeesView.RowFilter = "Отдел = 'IT'";
            PrintDataView(itEmployeesView, "IT отдел");

            // 3. Фильтрация по зарплате
            Console.WriteLine("\n3. Сотрудники с зарплатой выше 50000:");
            DataView highSalaryView = new DataView(employeesTable);
            highSalaryView.RowFilter = "Зарплата > 50000";
            highSalaryView.Sort = "Зарплата DESC";
            PrintDataView(highSalaryView, "Высокая зарплата");

            // 4. Сортировка по дате найма
            Console.WriteLine("\n4. Сортировка сотрудников по дате найма:");
            DataView sortedByHireDate = new DataView(employeesTable);
            sortedByHireDate.Sort = "ДатаНайма ASC";
            Console.WriteLine("По возрастанию:");
            PrintDataView(sortedByHireDate, "Сортировка по дате найма");

            sortedByHireDate.Sort = "ДатаНайма DESC";
            Console.WriteLine("\nПо убыванию:");
            PrintDataView(sortedByHireDate, "Сортировка по дате найма (убыв.)");

            // 5. Комбинированный поиск
            Console.WriteLine("\n5. Комбинированный поиск (IT отдел, зарплата > 50000):");
            DataView combinedView = new DataView(employeesTable);
            combinedView.RowFilter = "Отдел = 'IT' AND Зарплата > 50000";
            combinedView.Sort = "ФИО ASC";
            PrintDataView(combinedView, "Комбинированный фильтр");

            // 6. Статистика по фильтрованным данным
            Console.WriteLine("\n6. Статистика по IT отделу:");
            CalculateStatistics(itEmployeesView);

            // Обработка ошибок фильтрации
            Console.WriteLine("\n7. Тест обработки ошибок фильтрации:");
            TestFilterErrorHandling(employeesTable);
        }

        static DataTable CreateEmployeesTable()
        {
            DataTable table = new DataTable("Сотрудники");

            table.Columns.Add("ID", typeof(int));
            table.Columns.Add("ФИО", typeof(string));
            table.Columns.Add("Отдел", typeof(string));
            table.Columns.Add("Зарплата", typeof(decimal));
            table.Columns.Add("ДатаНайма", typeof(DateTime));

            table.PrimaryKey = new DataColumn[] { table.Columns["ID"] };

            return table;
        }

        static DataTable CreateProjectsTable()
        {
            DataTable table = new DataTable("Проекты");

            table.Columns.Add("ID", typeof(int));
            table.Columns.Add("Название", typeof(string));
            table.Columns.Add("Отдел", typeof(string));
            table.Columns.Add("БюджетПроекта", typeof(decimal));
            table.Columns.Add("ДатаНачала", typeof(DateTime));

            table.PrimaryKey = new DataColumn[] { table.Columns["ID"] };

            return table;
        }

        static void AddInitialEmployees(DataTable table)
        {
            table.Rows.Add(1, "Иванов Иван Иванович", "IT", 75000, new DateTime(2020, 3, 15));
            table.Rows.Add(2, "Петрова Анна Сергеевна", "Бухгалтерия", 45000, new DateTime(2019, 7, 22));
            table.Rows.Add(3, "Сидоров Петр Васильевич", "IT", 82000, new DateTime(2018, 11, 5));
            table.Rows.Add(4, "Козлова Мария Дмитриевна", "Маркетинг", 52000, new DateTime(2021, 1, 30));
            table.Rows.Add(5, "Новиков Алексей Петрович", "IT", 68000, new DateTime(2020, 9, 12));
            table.Rows.Add(6, "Смирнова Ольга Игоревна", "HR", 48000, new DateTime(2019, 4, 18));
            table.Rows.Add(7, "Васильев Дмитрий Сергеевич", "IT", 90000, new DateTime(2017, 6, 25));

            table.AcceptChanges();
        }

        static void AddInitialProjects(DataTable table)
        {
            table.Rows.Add(1, "Разработка CRM системы", "IT", 5000000, new DateTime(2023, 1, 15));
            table.Rows.Add(2, "Маркетинговая кампания 2023", "Маркетинг", 2000000, new DateTime(2023, 2, 1));
            table.Rows.Add(3, "Обновление бухгалтерского ПО", "Бухгалтерия", 1500000, new DateTime(2023, 3, 10));
            table.Rows.Add(4, "Разработка мобильного приложения", "IT", 3000000, new DateTime(2023, 2, 20));

            table.AcceptChanges();
        }

        static void PrintEmployeesTable(DataTable table)
        {
            Console.WriteLine(new string('-', 85));
            Console.WriteLine("| {0,3} | {1,25} | {2,15} | {3,10} | {4,12} |",
                "ID", "ФИО", "Отдел", "Зарплата", "Дата найма");
            Console.WriteLine(new string('-', 85));

            foreach (DataRow row in table.Rows)
            {
                Console.WriteLine("| {0,3} | {1,25} | {2,15} | {3,10:C2} | {4,12:dd.MM.yyyy} |",
                    row["ID"], row["ФИО"], row["Отдел"], row["Зарплата"], row["ДатаНайма"]);
            }
            Console.WriteLine(new string('-', 85));
        }

        static void PrintProjectsTable(DataTable table)
        {
            Console.WriteLine(new string('-', 75));
            Console.WriteLine("| {0,3} | {1,30} | {2,15} | {3,15} |",
                "ID", "Название", "Отдел", "Бюджет");
            Console.WriteLine(new string('-', 75));

            foreach (DataRow row in table.Rows)
            {
                Console.WriteLine("| {0,3} | {1,30} | {2,15} | {3,15:C2} |",
                    row["ID"], row["Название"], row["Отдел"], row["БюджетПроекта"]);
            }
            Console.WriteLine(new string('-', 75));
        }

        static void PrintDataView(DataView view, string title)
        {
            Console.WriteLine($"{title}:");
            Console.WriteLine(new string('-', 60));
            Console.WriteLine("| {0,3} | {1,25} | {2,10} | {3,12} |",
                "ID", "ФИО", "Отдел", "Зарплата");
            Console.WriteLine(new string('-', 60));

            foreach (DataRowView rowView in view)
            {
                Console.WriteLine("| {0,3} | {1,25} | {2,10} | {3,12:C2} |",
                    rowView["ID"], rowView["ФИО"], rowView["Отдел"], rowView["Зарплата"]);
            }
            Console.WriteLine(new string('-', 60));
            Console.WriteLine($"Всего записей: {view.Count}");
        }

        static void CalculateStatistics(DataView view)
        {
            if (view.Count == 0)
            {
                Console.WriteLine("Нет данных для статистики");
                return;
            }

            decimal totalSalary = 0;
            decimal maxSalary = decimal.MinValue;
            decimal minSalary = decimal.MaxValue;
            DateTime earliestHire = DateTime.MaxValue;
            DateTime latestHire = DateTime.MinValue;

            foreach (DataRowView row in view)
            {
                decimal salary = (decimal)row["Зарплата"];
                totalSalary += salary;

                if (salary > maxSalary) maxSalary = salary;
                if (salary < minSalary) minSalary = salary;

                DateTime hireDate = (DateTime)row["ДатаНайма"];
                if (hireDate < earliestHire) earliestHire = hireDate;
                if (hireDate > latestHire) latestHire = hireDate;
            }

            Console.WriteLine($"Количество сотрудников: {view.Count}");
            Console.WriteLine($"Средняя зарплата: {totalSalary / view.Count:C2}");
            Console.WriteLine($"Максимальная зарплата: {maxSalary:C2}");
            Console.WriteLine($"Минимальная зарплата: {minSalary:C2}");
            Console.WriteLine($"Общий фонд оплаты: {totalSalary:C2}");
            Console.WriteLine($"Первый наем: {earliestHire:dd.MM.yyyy}");
            Console.WriteLine($"Последний наем: {latestHire:dd.MM.yyyy}");
        }

        static void TestFilterErrorHandling(DataTable table)
        {
            try
            {
                // Неправильное имя столбца
                DataView errorView = new DataView(table);
                errorView.RowFilter = "НесуществующееПоле > 1000";
                Console.WriteLine("Количество строк: " + errorView.Count);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка фильтрации: {ex.Message}");
            }

            try
            {
                // Неправильный тип данных
                DataView errorView2 = new DataView(table);
                errorView2.RowFilter = "Зарплата > 'не число'";
                Console.WriteLine("Количество строк: " + errorView2.Count);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка фильтрации: {ex.Message}");
            }
        }
        #endregion

        #region Задание 4: Создание TableAdapter (имитация)
        static void Task4_TableAdapterCreation()
        {
            Console.Clear();
            Console.WriteLine("=== ЗАДАНИЕ 4: Создание и настройка TableAdapter ===");
            Console.WriteLine("(Имитация работы TableAdapter через SqlDataAdapter)\n");

            // Имитация работы TableAdapter
            MockTableAdapter adapter = new MockTableAdapter();

            // Заполнение DataTable
            Console.WriteLine("1. Заполнение DataTable данными о студентах:");
            DataTable studentsTable = adapter.Fill();
            PrintStudentsTable(studentsTable);

            // Фильтрация по специальности
            Console.WriteLine("\n2. Фильтрация студентов по специальности ('Информатика'):");
            DataTable filteredBySpecialty = adapter.FillBySpecialty("Информатика");
            PrintStudentsTable(filteredBySpecialty);

            // Поиск по email
            Console.WriteLine("\n3. Поиск студента по email ('petrov@univer.ru'):");
            DataTable foundByEmail = adapter.FillByEmail("petrov@univer.ru");
            PrintStudentsTable(foundByEmail);

            // Операции с данными
            Console.WriteLine("\n4. Операции с данными через TableAdapter:");

            // Добавление нового студента
            Console.WriteLine("Добавление нового студента:");
            adapter.Insert("Новый Студент", "new@univer.ru", "Математика", DateTime.Now);

            // Обновление данных
            Console.WriteLine("Обновление данных студента ID=2:");
            adapter.Update(2, "Петров Петр Петрович (обновлено)", "petrov.new@univer.ru", "Физика", new DateTime(2022, 9, 1));

            // Получение обновленных данных
            DataTable updatedTable = adapter.Fill();
            Console.WriteLine("\nДанные после операций:");
            PrintStudentsTable(updatedTable);

            // Удаление студента
            Console.WriteLine("\nУдаление студента ID=3:");
            adapter.Delete(3);

            Console.WriteLine("\nДанные после удаления:");
            updatedTable = adapter.Fill();
            PrintStudentsTable(updatedTable);
        }

        class MockTableAdapter
        {
            private DataTable _studentsTable;

            public MockTableAdapter()
            {
                // Имитация таблицы БД
                _studentsTable = new DataTable("Студенты");
                _studentsTable.Columns.Add("StudentID", typeof(int));
                _studentsTable.Columns.Add("ФИ", typeof(string));
                _studentsTable.Columns.Add("Email", typeof(string));
                _studentsTable.Columns.Add("Специальность", typeof(string));
                _studentsTable.Columns.Add("ДатаПоступления", typeof(DateTime));

                // Добавляем тестовые данные
                _studentsTable.Rows.Add(1, "Иванов Иван", "ivanov@univer.ru", "Информатика", new DateTime(2023, 9, 1));
                _studentsTable.Rows.Add(2, "Петров Петр", "petrov@univer.ru", "Физика", new DateTime(2023, 9, 1));
                _studentsTable.Rows.Add(3, "Сидорова Анна", "sidorova@univer.ru", "Информатика", new DateTime(2022, 9, 1));
                _studentsTable.Rows.Add(4, "Козлов Дмитрий", "kozlov@univer.ru", "Математика", new DateTime(2023, 9, 1));
                _studentsTable.Rows.Add(5, "Смирнова Ольга", "smirnova@univer.ru", "Информатика", new DateTime(2022, 9, 1));

                _studentsTable.AcceptChanges();
            }

            public DataTable Fill()
            {
                return _studentsTable.Clone();
            }

            public DataTable FillBySpecialty(string specialty)
            {
                DataTable result = _studentsTable.Clone();
                var rows = _studentsTable.Select($"Специальность = '{specialty}'");
                foreach (var row in rows)
                {
                    result.ImportRow(row);
                }
                return result;
            }

            public DataTable FillByEmail(string email)
            {
                DataTable result = _studentsTable.Clone();
                var rows = _studentsTable.Select($"Email = '{email}'");
                foreach (var row in rows)
                {
                    result.ImportRow(row);
                }
                return result;
            }

            public void Insert(string name, string email, string specialty, DateTime admissionDate)
            {
                DataRow newRow = _studentsTable.NewRow();
                newRow["StudentID"] = _studentsTable.Rows.Count + 1;
                newRow["ФИ"] = name;
                newRow["Email"] = email;
                newRow["Специальность"] = specialty;
                newRow["ДатаПоступления"] = admissionDate;
                _studentsTable.Rows.Add(newRow);

                Console.WriteLine($"Добавлен студент: {name}");
            }

            public void Update(int id, string name, string email, string specialty, DateTime admissionDate)
            {
                DataRow[] rows = _studentsTable.Select($"StudentID = {id}");
                if (rows.Length > 0)
                {
                    rows[0]["ФИ"] = name;
                    rows[0]["Email"] = email;
                    rows[0]["Специальность"] = specialty;
                    rows[0]["ДатаПоступления"] = admissionDate;
                    Console.WriteLine($"Обновлен студент ID={id}");
                }
            }

            public void Delete(int id)
            {
                DataRow[] rows = _studentsTable.Select($"StudentID = {id}");
                if (rows.Length > 0)
                {
                    rows[0].Delete();
                    Console.WriteLine($"Удален студент ID={id}");
                }
            }
        }
        #endregion

        #region Задание 5: Методы получения данных TableAdapter
        static void Task5_TableAdapterMethods()
        {
            Console.Clear();
            Console.WriteLine("=== ЗАДАНИЕ 5: Методы получения данных через TableAdapter ===");

            MockDataService dataService = new MockDataService();

            // 1. Fill() для заполнения DataTable
            Console.WriteLine("1. TableAdapter.Fill():");
            DataTable allStudents = dataService.Fill();
            Console.WriteLine($"Всего студентов: {allStudents.Rows.Count}");

            // 2. GetData() для получения DataTable
            Console.WriteLine("\n2. TableAdapter.GetData():");
            DataTable allStudents2 = dataService.GetData();
            Console.WriteLine($"Получено записей: {allStudents2.Rows.Count}");
            PrintStudentsSimpleTable(allStudents2);

            // 3. Пользовательский метод для выборки по диапазону дат
            Console.WriteLine("\n3. Студенты, поступившие в 2023 году:");
            DataTable studentsByDateRange = dataService.GetStudentsByAdmissionDate(
                new DateTime(2023, 1, 1), new DateTime(2023, 12, 31));
            PrintStudentsSimpleTable(studentsByDateRange);

            // 4. Получение одного студента по ID
            Console.WriteLine("\n4. Студент с ID=3:");
            DataTable studentById = dataService.GetStudentById(3);
            if (studentById.Rows.Count > 0)
            {
                PrintStudentsSimpleTable(studentById);
            }
            else
            {
                Console.WriteLine("Студент не найден");
            }

            // 5. Постраничное получение данных
            Console.WriteLine("\n5. Постраничное получение данных (страница 1, размер 2):");
            DataTable page1 = dataService.GetStudentsPaged(1, 2);
            PrintStudentsSimpleTable(page1);

            Console.WriteLine("\nСтраница 2:");
            DataTable page2 = dataService.GetStudentsPaged(2, 2);
            PrintStudentsSimpleTable(page2);

            // 6. Агрегированная информация
            Console.WriteLine("\n6. Агрегированная информация:");
            Console.WriteLine($"Всего студентов: {dataService.GetTotalStudentsCount()}");

            Console.WriteLine("\nКоличество студентов по специальностям:");
            DataTable statsBySpecialty = dataService.GetStudentsCountBySpecialty();
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("| {0,20} | {1,10} |", "Специальность", "Количество");
            Console.WriteLine(new string('-', 40));
            foreach (DataRow row in statsBySpecialty.Rows)
            {
                Console.WriteLine("| {0,20} | {1,10} |", row["Специальность"], row["Количество"]);
            }
            Console.WriteLine(new string('-', 40));

            // Обработка исключений
            Console.WriteLine("\n7. Тест обработки исключений:");
            try
            {
                DataTable invalid = dataService.GetStudentsByAdmissionDate(
                    new DateTime(2025, 1, 1), new DateTime(2023, 1, 1));
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }

        static void PrintStudentsSimpleTable(DataTable table)
        {
            Console.WriteLine(new string('-', 70));
            Console.WriteLine("| {0,3} | {1,20} | {2,20} | {3,15} |",
                "ID", "ФИО", "Email", "Специальность");
            Console.WriteLine(new string('-', 70));

            foreach (DataRow row in table.Rows)
            {
                Console.WriteLine("| {0,3} | {1,20} | {2,20} | {3,15} |",
                    row["StudentID"], row["ФИ"], row["Email"], row["Специальность"]);
            }
            Console.WriteLine(new string('-', 70));
        }

        class MockDataService
        {
            private DataTable _studentsTable;

            public MockDataService()
            {
                _studentsTable = new DataTable("Студенты");
                _studentsTable.Columns.Add("StudentID", typeof(int));
                _studentsTable.Columns.Add("ФИ", typeof(string));
                _studentsTable.Columns.Add("Email", typeof(string));
                _studentsTable.Columns.Add("Специальность", typeof(string));
                _studentsTable.Columns.Add("ДатаПоступления", typeof(DateTime));

                // Генерация тестовых данных
                string[] specialties = { "Информатика", "Физика", "Математика", "Химия", "Биология" };
                Random rnd = new Random();

                for (int i = 1; i <= 10; i++)
                {
                    _studentsTable.Rows.Add(
                        i,
                        $"Студент {i}",
                        $"student{i}@univer.ru",
                        specialties[rnd.Next(specialties.Length)],
                        new DateTime(2022 + rnd.Next(2), rnd.Next(1, 13), rnd.Next(1, 28))
                    );
                }

                _studentsTable.AcceptChanges();
            }

            public DataTable Fill()
            {
                DataTable result = _studentsTable.Clone();
                foreach (DataRow row in _studentsTable.Rows)
                {
                    result.ImportRow(row);
                }
                return result;
            }

            public DataTable GetData()
            {
                return Fill();
            }

            public DataTable GetStudentsByAdmissionDate(DateTime startDate, DateTime endDate)
            {
                if (startDate > endDate)
                    throw new ArgumentException("Начальная дата должна быть меньше конечной");

                DataTable result = _studentsTable.Clone();
                var rows = _studentsTable.Select(
                    $"ДатаПоступления >= #{startDate:MM/dd/yyyy}# AND ДатаПоступления <= #{endDate:MM/dd/yyyy}#");

                foreach (var row in rows)
                {
                    result.ImportRow(row);
                }
                return result;
            }

            public DataTable GetStudentById(int id)
            {
                DataTable result = _studentsTable.Clone();
                var rows = _studentsTable.Select($"StudentID = {id}");

                foreach (var row in rows)
                {
                    result.ImportRow(row);
                }
                return result;
            }

            public DataTable GetStudentsPaged(int pageNumber, int pageSize)
            {
                DataTable result = _studentsTable.Clone();
                int startIndex = (pageNumber - 1) * pageSize;
                int endIndex = Math.Min(startIndex + pageSize, _studentsTable.Rows.Count);

                for (int i = startIndex; i < endIndex; i++)
                {
                    result.ImportRow(_studentsTable.Rows[i]);
                }
                return result;
            }

            public int GetTotalStudentsCount()
            {
                return _studentsTable.Rows.Count;
            }

            public DataTable GetStudentsCountBySpecialty()
            {
                DataTable result = new DataTable();
                result.Columns.Add("Специальность", typeof(string));
                result.Columns.Add("Количество", typeof(int));

                var groups = _studentsTable.AsEnumerable()
                    .GroupBy(r => r.Field<string>("Специальность"));

                foreach (var group in groups)
                {
                    result.Rows.Add(group.Key, group.Count());
                }

                return result;
            }
        }
        #endregion

        #region Задание 6: Информация о структуре БД
        static void Task6_DatabaseStructure()
        {
            Console.Clear();
            Console.WriteLine("=== ЗАДАНИЕ 6: Информация о структуре базы данных ===");

            // Создаем тестовую таблицу
            DataTable testTable = CreateTestTableForSchema();

            // 1. Получение информации о колонках
            Console.WriteLine("1. Информация о колонках таблицы:");
            PrintColumnInformation(testTable);

            // 2. Получение информации через GetSchemaTable
            Console.WriteLine("\n2. Полная информация о схеме (GetSchemaTable):");
            PrintSchemaTableInformation(testTable);

            // 3. Имитация индексов
            Console.WriteLine("\n3. Информация об индексах (имитация):");
            PrintIndexInformation();

            // 4. Имитация связей с другими таблицами
            Console.WriteLine("\n4. Информация о связях с другими таблицами:");
            PrintRelationshipsInformation();

            // 5. Сравнение структур
            Console.WriteLine("\n5. Сравнение локальной структуры со структурой в БД:");
            CompareTableStructures();
        }

        static DataTable CreateTestTableForSchema()
        {
            DataTable table = new DataTable("Студенты");

            // Добавляем колонки с различными свойствами
            table.Columns.Add("StudentID", typeof(int));
            table.Columns["StudentID"].AllowDBNull = false;
            table.Columns["StudentID"].Unique = true;

            table.Columns.Add("ФИО", typeof(string));
            table.Columns["ФИО"].MaxLength = 100;
            table.Columns["ФИО"].AllowDBNull = false;

            table.Columns.Add("Email", typeof(string));
            table.Columns["Email"].MaxLength = 50;
            table.Columns["Email"].AllowDBNull = true;

            table.Columns.Add("Специальность", typeof(string));
            table.Columns["Специальность"].MaxLength = 50;

            table.Columns.Add("ДатаПоступления", typeof(DateTime));

            table.Columns.Add("СреднийБалл", typeof(decimal));
            table.Columns["СреднийБалл"].DefaultValue = 0.0m;

            // Устанавливаем первичный ключ
            table.PrimaryKey = new DataColumn[] { table.Columns["StudentID"] };

            return table;
        }

        static void PrintColumnInformation(DataTable table)
        {
            Console.WriteLine(new string('-', 90));
            Console.WriteLine("| {0,15} | {1,10} | {2,8} | {3,10} | {4,10} | {5,15} |",
                "Имя колонки", "Тип данных", "NULL", "PK", "Длина", "Значение по умол.");
            Console.WriteLine(new string('-', 90));

            foreach (DataColumn column in table.Columns)
            {
                bool isPrimaryKey = table.PrimaryKey.Contains(column);
                int? maxLength = column.MaxLength > 0 ? column.MaxLength : (int?)null;

                Console.WriteLine("| {0,15} | {1,10} | {2,8} | {3,10} | {4,10} | {5,15} |",
                    column.ColumnName,
                    column.DataType.Name,
                    column.AllowDBNull ? "Да" : "Нет",
                    isPrimaryKey ? "Да" : "Нет",
                    maxLength?.ToString() ?? "-",
                    column.DefaultValue != DBNull.Value ? column.DefaultValue?.ToString() ?? "null" : "null");
            }
            Console.WriteLine(new string('-', 90));
        }

        static void PrintSchemaTableInformation(DataTable table)
        {
            // Имитация GetSchemaTable
            DataTable schemaTable = new DataTable("SchemaInfo");
            schemaTable.Columns.Add("ColumnName", typeof(string));
            schemaTable.Columns.Add("DataType", typeof(string));
            schemaTable.Columns.Add("ColumnSize", typeof(int));
            schemaTable.Columns.Add("NumericPrecision", typeof(int));
            schemaTable.Columns.Add("NumericScale", typeof(int));
            schemaTable.Columns.Add("IsUnique", typeof(bool));
            schemaTable.Columns.Add("IsKey", typeof(bool));
            schemaTable.Columns.Add("AllowDBNull", typeof(bool));

            foreach (DataColumn column in table.Columns)
            {
                bool isKey = table.PrimaryKey.Contains(column);

                schemaTable.Rows.Add(
                    column.ColumnName,
                    column.DataType.Name,
                    column.MaxLength,
                    DBNull.Value, // NumericPrecision
                    DBNull.Value, // NumericScale
                    column.Unique,
                    isKey,
                    column.AllowDBNull
                );
            }

            Console.WriteLine(new string('-', 100));
            Console.WriteLine("| {0,15} | {1,15} | {2,10} | {3,8} | {4,8} | {5,10} |",
                "Имя колонки", "Тип данных", "Размер", "Уникальн", "Ключ", "NULL");
            Console.WriteLine(new string('-', 100));

            foreach (DataRow row in schemaTable.Rows)
            {
                Console.WriteLine("| {0,15} | {1,15} | {2,10} | {3,8} | {4,8} | {5,10} |",
                    row["ColumnName"],
                    row["DataType"],
                    row["ColumnSize"] != DBNull.Value ? row["ColumnSize"] : "-",
                    (bool)row["IsUnique"] ? "Да" : "Нет",
                    (bool)row["IsKey"] ? "Да" : "Нет",
                    (bool)row["AllowDBNull"] ? "Да" : "Нет");
            }
            Console.WriteLine(new string('-', 100));
        }

        static void PrintIndexInformation()
        {
            Console.WriteLine("Имитация индексов таблицы 'Студенты':");
            Console.WriteLine(new string('-', 60));
            Console.WriteLine("| {0,20} | {1,15} | {2,15} |", "Имя индекса", "Колонки", "Тип");
            Console.WriteLine(new string('-', 60));
            Console.WriteLine("| {0,20} | {1,15} | {2,15} |", "PK_Students", "StudentID", "Первичный ключ");
            Console.WriteLine("| {0,20} | {1,15} | {2,15} |", "IX_Email", "Email", "Уникальный");
            Console.WriteLine("| {0,20} | {1,15} | {2,15} |", "IX_Specialty", "Специальность", "Неуникальный");
            Console.WriteLine(new string('-', 60));
        }

        static void PrintRelationshipsInformation()
        {
            Console.WriteLine("Имитация связей таблицы 'Студенты':");
            Console.WriteLine(new string('-', 80));
            Console.WriteLine("| {0,20} | {1,20} | {2,20} | {3,15} |",
                "Имя связи", "Родительская таблица", "Дочерняя таблица", "Тип связи");
            Console.WriteLine(new string('-', 80));
            Console.WriteLine("| {0,20} | {1,20} | {2,20} | {3,15} |",
                "FK_Students_Groups", "Группы", "Студенты", "Один-ко-многим");
            Console.WriteLine("| {0,20} | {1,20} | {2,20} | {3,15} |",
                "FK_Students_Specialties", "Специальности", "Студенты", "Один-ко-многим");
            Console.WriteLine(new string('-', 80));
        }

        static void CompareTableStructures()
        {
            DataTable localTable = CreateTestTableForSchema();
            DataTable dbTable = CreateTestTableForSchema();

            // Вносим изменения в DB таблицу для демонстрации сравнения
            dbTable.Columns.Remove("СреднийБалл");
            dbTable.Columns.Add("ГруппаID", typeof(int));

            Console.WriteLine("Сравнение структур:");
            Console.WriteLine(new string('-', 80));
            Console.WriteLine("| {0,20} | {1,25} | {2,25} |", "Колонка", "Локальная таблица", "Таблица в БД");
            Console.WriteLine(new string('-', 80));

            // Собираем все уникальные имена колонок
            var allColumns = new HashSet<string>();
            foreach (DataColumn col in localTable.Columns) allColumns.Add(col.ColumnName);
            foreach (DataColumn col in dbTable.Columns) allColumns.Add(col.ColumnName);

            foreach (string columnName in allColumns.OrderBy(n => n))
            {
                DataColumn localCol = localTable.Columns.Contains(columnName) ? localTable.Columns[columnName] : null;
                DataColumn dbCol = dbTable.Columns.Contains(columnName) ? dbTable.Columns[columnName] : null;

                string localInfo = localCol != null ? $"{localCol.DataType.Name} (NULL: {localCol.AllowDBNull})" : "ОТСУТСТВУЕТ";
                string dbInfo = dbCol != null ? $"{dbCol.DataType.Name} (NULL: {dbCol.AllowDBNull})" : "ОТСУТСТВУЕТ";

                Console.WriteLine("| {0,20} | {1,25} | {2,25} |", columnName, localInfo, dbInfo);
            }
            Console.WriteLine(new string('-', 80));
        }
        #endregion



        #region Задание 8: Сопоставление колонок
        static void Task8_ColumnMapping()
        {
            Console.Clear();
            Console.WriteLine("=== ЗАДАНИЕ 8: Сопоставление колонок через DataColumnMapping ===");

            // Создаем DataSet
            DataSet dataSet = new DataSet("BusinessDB");

            // Создаем таблицы с неудобными именами колонок (как в БД)
            Console.WriteLine("1. Исходные данные из БД с неудобными именами колонок:");

            DataTable dbStudents = CreateDbTableWithBadColumnNames("DStud");
            DataTable dbProjects = CreateDbTableWithBadProjectColumnNames("DProj");

            Console.WriteLine("\nТаблица DStud (студенты):");
            PrintTableWithBadNames(dbStudents);

            Console.WriteLine("\nТаблица DProj (проекты):");
            PrintTableWithBadNames(dbProjects);

            // Создаем DataAdapter и настраиваем маппинги
            Console.WriteLine("\n2. Настройка DataColumnMapping:");

            // Создаем TableMapping для студентов
            DataTableMapping studentMapping = new DataTableMapping("DStud", "Students");

            // Добавляем ColumnMappings для студентов
            studentMapping.ColumnMappings.Add("s_id", "StudentID");
            studentMapping.ColumnMappings.Add("s_fio", "FullName");
            studentMapping.ColumnMappings.Add("s_email", "Email");
            studentMapping.ColumnMappings.Add("s_spec", "Specialization");

            // Создаем TableMapping для проектов
            DataTableMapping projectMapping = new DataTableMapping("DProj", "Projects");

            // Добавляем ColumnMappings для проектов
            projectMapping.ColumnMappings.Add("p_id", "ProjectID");
            projectMapping.ColumnMappings.Add("p_name", "ProjectName");
            projectMapping.ColumnMappings.Add("p_budget", "Budget");

            // Применяем маппинги
            Console.WriteLine("\n3. Применение маппингов:");

            DataTable mappedStudents = ApplyColumnMapping(dbStudents, studentMapping);
            DataTable mappedProjects = ApplyColumnMapping(dbProjects, projectMapping);

            Console.WriteLine("\nТаблица Students после маппинга:");
            PrintTableWithGoodNames(mappedStudents);

            Console.WriteLine("\nТаблица Projects после маппинга:");
            PrintTableWithGoodNames(mappedProjects);

            // Отчет о маппингах
            Console.WriteLine("\n4. Отчет о маппингах:");
            PrintColumnMappingReport(studentMapping, projectMapping);

            // Динамическое добавление маппингов
            Console.WriteLine("\n5. Динамическое добавление нового маппинга:");
            TestDynamicMapping();

            // Обработка ошибок
            Console.WriteLine("\n6. Тест обработки ошибок маппинга:");
            TestMappingErrorHandling();
        }

        static DataTable CreateDbTableWithBadColumnNames(string tableName)
        {
            DataTable table = new DataTable(tableName);

            table.Columns.Add("s_id", typeof(int));
            table.Columns.Add("s_fio", typeof(string));
            table.Columns.Add("s_email", typeof(string));
            table.Columns.Add("s_spec", typeof(string));

            table.Rows.Add(1, "Иванов Иван Иванович", "ivanov@univer.ru", "Информатика");
            table.Rows.Add(2, "Петров Петр Петрович", "petrov@univer.ru", "Физика");
            table.Rows.Add(3, "Сидорова Анна Михайловна", "sidorova@univer.ru", "Математика");

            return table;
        }

        static DataTable CreateDbTableWithBadProjectColumnNames(string tableName)
        {
            DataTable table = new DataTable(tableName);

            table.Columns.Add("p_id", typeof(int));
            table.Columns.Add("p_name", typeof(string));
            table.Columns.Add("p_budget", typeof(decimal));

            table.Rows.Add(101, "Разработка CRM", 500000);
            table.Rows.Add(102, "Мобильное приложение", 300000);
            table.Rows.Add(103, "Веб-сайт компании", 200000);

            return table;
        }

        static DataTable ApplyColumnMapping(DataTable sourceTable, DataTableMapping mapping)
        {
            // Создаем новую таблицу с маппированными именами
            DataTable resultTable = new DataTable(mapping.DataSetTable);

            // Добавляем колонки с новыми именами
            foreach (DataColumnMapping colMapping in mapping.ColumnMappings)
            {
                DataColumn sourceColumn = sourceTable.Columns[colMapping.SourceColumn];
                if (sourceColumn != null)
                {
                    DataColumn newColumn = new DataColumn(colMapping.DataSetColumn, sourceColumn.DataType);
                    resultTable.Columns.Add(newColumn);
                }
            }

            // Копируем данные
            foreach (DataRow sourceRow in sourceTable.Rows)
            {
                DataRow newRow = resultTable.NewRow();

                foreach (DataColumnMapping colMapping in mapping.ColumnMappings)
                {
                    if (sourceTable.Columns.Contains(colMapping.SourceColumn))
                    {
                        newRow[colMapping.DataSetColumn] = sourceRow[colMapping.SourceColumn];
                    }
                }

                resultTable.Rows.Add(newRow);
            }

            return resultTable;
        }

        static void PrintTableWithBadNames(DataTable table)
        {
            Console.WriteLine($"Таблица: {table.TableName}");
            Console.WriteLine(new string('-', 80));

            // Заголовки
            Console.Write("|");
            foreach (DataColumn column in table.Columns)
            {
                Console.Write($" {column.ColumnName,20} |");
            }
            Console.WriteLine();

            Console.WriteLine(new string('-', 80));

            // Данные
            foreach (DataRow row in table.Rows)
            {
                Console.Write("|");
                foreach (DataColumn column in table.Columns)
                {
                    Console.Write($" {row[column].ToString(),20} |");
                }
                Console.WriteLine();
            }

            Console.WriteLine(new string('-', 80));
        }

        static void PrintTableWithGoodNames(DataTable table)
        {
            Console.WriteLine($"Таблица: {table.TableName}");
            Console.WriteLine(new string('-', 80));

            // Заголовки
            Console.Write("|");
            foreach (DataColumn column in table.Columns)
            {
                Console.Write($" {column.ColumnName,20} |");
            }
            Console.WriteLine();

            Console.WriteLine(new string('-', 80));

            // Данные
            foreach (DataRow row in table.Rows)
            {
                Console.Write("|");
                foreach (DataColumn column in table.Columns)
                {
                    Console.Write($" {row[column].ToString(),20} |");
                }
                Console.WriteLine();
            }

            Console.WriteLine(new string('-', 80));
        }

        static void PrintColumnMappingReport(params DataTableMapping[] mappings)
        {
            Console.WriteLine("Отчет о маппингах колонок:");
            Console.WriteLine(new string('-', 80));
            Console.WriteLine("| {0,20} | {1,20} | {2,15} | {3,15} |",
                "Таблица", "Исходная колонка", "Локальная колонка", "Статус");
            Console.WriteLine(new string('-', 80));

            foreach (var mapping in mappings)
            {
                foreach (DataColumnMapping colMapping in mapping.ColumnMappings)
                {
                    Console.WriteLine("| {0,20} | {1,20} | {2,15} | {3,15} |",
                        mapping.SourceTable,
                        colMapping.SourceColumn,
                        colMapping.DataSetColumn,
                        "Сопоставлено");
                }
            }
            Console.WriteLine(new string('-', 80));
        }

        static void TestDynamicMapping()
        {
            DataTableMapping mapping = new DataTableMapping("SourceTable", "DestTable");

            // Динамическое добавление
            Console.WriteLine("Добавление маппинга 'new_col' -> 'NewColumn':");
            mapping.ColumnMappings.Add("new_col", "NewColumn");

            Console.WriteLine($"Всего маппингов: {mapping.ColumnMappings.Count}");
            Console.WriteLine("Последний маппинг:");
            var lastMapping = mapping.ColumnMappings[mapping.ColumnMappings.Count - 1];
            Console.WriteLine($"  {lastMapping.SourceColumn} -> {lastMapping.DataSetColumn}");
        }

        static void TestMappingErrorHandling()
        {
            try
            {
                DataTable table = new DataTable("Test");
                table.Columns.Add("Col1", typeof(string));

                DataTableMapping mapping = new DataTableMapping("Test", "TestMapped");
                mapping.ColumnMappings.Add("NonExistentColumn", "MappedColumn");

                // Попытка применить несуществующий маппинг
                DataTable result = ApplyColumnMapping(table, mapping);

                Console.WriteLine("Маппинг применен успешно");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка маппинга: {ex.Message}");
            }
        }
        #endregion

        #region Задание 9: Комплексная работа
        static void Task9_ComplexWork()
        {
            Console.Clear();
            Console.WriteLine("=== ЗАДАНИЕ 9: Комплексная работа со всеми концепциями ===");

            // 1. Создание DataSet с маппингами
            Console.WriteLine("1. Создание DataSet с использованием DataTableMapping и DataColumnMapping:");

            DataSet businessDataSet = CreateBusinessDataSetWithMappings();

            Console.WriteLine($"DataSet: {businessDataSet.DataSetName}");
            Console.WriteLine("Таблицы в DataSet:");
            foreach (DataTable table in businessDataSet.Tables)
            {
                Console.WriteLine($"  - {table.TableName} ({table.Rows.Count} строк)");
            }

            // 2. Отображение данных
            Console.WriteLine("\n2. Данные сотрудников:");
            PrintEmployeesTable(businessDataSet.Tables["Employees"]);

            Console.WriteLine("\nДанные проектов:");
            PrintProjectsTable(businessDataSet.Tables["Projects"]);

            // 3. Операции с данными
            DataTable employeesTable = businessDataSet.Tables["Employees"];

            Console.WriteLine("\n3. Операции с данными:");

            // Добавление нового сотрудника
            Console.WriteLine("\nДобавление нового сотрудника:");
            DataRow newEmployee = employeesTable.NewRow();
            newEmployee["EmployeeID"] = 8;
            newEmployee["FullName"] = "Новиков Алексей Петрович";
            newEmployee["Department"] = "IT";
            newEmployee["Salary"] = 72000;
            newEmployee["HireDate"] = DateTime.Now;
            employeesTable.Rows.Add(newEmployee);

            PrintRowStates(employeesTable);

            // Редактирование сотрудника
            Console.WriteLine("\nРедактирование сотрудника ID=2:");
            DataRow employeeToEdit = employeesTable.Select("EmployeeID = 2").FirstOrDefault();
            if (employeeToEdit != null)
            {
                Console.WriteLine($"Текущая зарплата: {employeeToEdit["Salary", DataRowVersion.Current]}");
                employeeToEdit["Salary"] = 55000;
                employeeToEdit["Department"] = "Финансы";

                PrintRowStateAndVersions(employeeToEdit);
            }

            // Удаление сотрудника
            Console.WriteLine("\nУдаление сотрудника ID=3:");
            DataRow employeeToDelete = employeesTable.Select("EmployeeID = 3").FirstOrDefault();
            if (employeeToDelete != null)
            {
                employeeToDelete.Delete();
                Console.WriteLine($"Состояние строки: {employeeToDelete.RowState}");
            }

            // 4. Фильтрация и поиск
            Console.WriteLine("\n4. Фильтрация и поиск с использованием DataView:");

            DataView itDepartmentView = new DataView(employeesTable);
            itDepartmentView.RowFilter = "Department = 'IT' AND Salary > 60000";
            itDepartmentView.Sort = "Salary DESC";

            Console.WriteLine("Сотрудники IT отдела с зарплатой > 60000:");
            foreach (DataRowView rowView in itDepartmentView)
            {
                Console.WriteLine($"  {rowView["FullName"]} - {rowView["Salary"]} руб.");
            }

            // 5. Подробный отчет об изменениях
            Console.WriteLine("\n5. Подробный отчет об изменениях перед сохранением:");
            PrintChangeReport(employeesTable);

            // 6. Валидация данных
            Console.WriteLine("\n6. Валидация данных:");
            TestDataValidation(employeesTable);

            // 7. Отмена изменений
            Console.WriteLine("\n7. Отмена изменений для конкретной строки:");
            DataRow rowToReject = employeesTable.Select("EmployeeID = 5").FirstOrDefault();
            if (rowToReject != null && rowToReject.RowState == DataRowState.Modified)
            {
                Console.WriteLine($"Отмена изменений для сотрудника ID=5");
                Console.WriteLine($"Текущая зарплата: {rowToReject["Salary"]}");
                rowToReject.RejectChanges();
                Console.WriteLine($"Зарплата после отмены: {rowToReject["Salary"]}");
            }

            // 8. Сохранение изменений (имитация)
            Console.WriteLine("\n8. Имитация сохранения изменений в БД:");
            SimulateSaveChanges(employeesTable);
        }

        static DataSet CreateBusinessDataSetWithMappings()
        {
            DataSet dataSet = new DataSet("BusinessDB");

            // Создаем исходные таблицы (как будто из БД с плохими именами)
            DataTable dbEmployees = CreateDbEmployeesTable("DB_EMP");

            // Создаем маппинги
            DataTableMapping empMapping = new DataTableMapping("DB_EMP", "Employees");
            empMapping.ColumnMappings.Add("emp_id", "EmployeeID");
            empMapping.ColumnMappings.Add("emp_name", "FullName");
            empMapping.ColumnMappings.Add("emp_dept", "Department");
            empMapping.ColumnMappings.Add("emp_salary", "Salary");
            empMapping.ColumnMappings.Add("emp_hire_date", "HireDate");

            DataTableMapping projMapping = new DataTableMapping("DB_PROJ", "Projects");
            projMapping.ColumnMappings.Add("proj_id", "ProjectID");
            projMapping.ColumnMappings.Add("proj_name", "ProjectName");
            projMapping.ColumnMappings.Add("proj_dept", "Department");
            projMapping.ColumnMappings.Add("proj_budget", "Budget");
            projMapping.ColumnMappings.Add("proj_start_date", "StartDate");

            // Применяем маппинги
            DataTable mappedEmployees = ApplyColumnMapping(dbEmployees, empMapping);

            // Добавляем таблицы в DataSet
            dataSet.Tables.Add(mappedEmployees);

            return dataSet;
        }

        static DataTable CreateDbEmployeesTable(string tableName)
        {
            DataTable table = new DataTable(tableName);

            table.Columns.Add("emp_id", typeof(int));
            table.Columns.Add("emp_name", typeof(string));
            table.Columns.Add("emp_dept", typeof(string));
            table.Columns.Add("emp_salary", typeof(decimal));
            table.Columns.Add("emp_hire_date", typeof(DateTime));

            table.Rows.Add(1, "Иванов Иван Иванович", "IT", 75000, new DateTime(2020, 3, 15));
            table.Rows.Add(2, "Петрова Анна Сергеевна", "Бухгалтерия", 48000, new DateTime(2019, 7, 22));
            table.Rows.Add(3, "Сидоров Петр Васильевич", "IT", 82000, new DateTime(2018, 11, 5));
            table.Rows.Add(4, "Козлова Мария Дмитриевна", "Маркетинг", 52000, new DateTime(2021, 1, 30));
            table.Rows.Add(5, "Новиков Алексей Петрович", "IT", 68000, new DateTime(2020, 9, 12));
            table.Rows.Add(6, "Смирнова Ольга Игоревна", "HR", 48000, new DateTime(2019, 4, 18));
            table.Rows.Add(7, "Васильев Дмитрий Сергеевич", "IT", 90000, new DateTime(2017, 6, 25));

            table.AcceptChanges();

            return table;
        }


        static void PrintRowStateAndVersions(DataRow row)
        {
            Console.WriteLine($"Строка ID={row["EmployeeID", DataRowVersion.Original]}");
            Console.WriteLine($"  Состояние: {row.RowState}");

            if (row.RowState == DataRowState.Modified)
            {
                Console.WriteLine("  Изменения:");
                foreach (DataColumn column in row.Table.Columns)
                {
                    try
                    {
                        object original = row[column.ColumnName, DataRowVersion.Original];
                        object current = row[column.ColumnName, DataRowVersion.Current];

                        if (!object.Equals(original, current))
                        {
                            Console.WriteLine($"    {column.ColumnName}: {original} -> {current}");
                        }
                    }
                    catch (VersionNotFoundException)
                    {
                        // Пропускаем колонки без Original версии
                    }
                }
            }
        }

        static void PrintChangeReport(DataTable table)
        {
            DataTable changes = table.GetChanges();

            if (changes == null)
            {
                Console.WriteLine("Нет изменений для сохранения");
                return;
            }

            Console.WriteLine("Отчет об изменениях:");
            Console.WriteLine(new string('-', 100));

            // Добавленные строки
            var addedRows = changes.Select("", "", DataViewRowState.Added);
            if (addedRows.Length > 0)
            {
                Console.WriteLine($"Добавленные строки ({addedRows.Length}):");
                foreach (DataRow row in addedRows)
                {
                    Console.WriteLine($"  ID={row["EmployeeID"]}: {row["FullName"]}, {row["Department"]}, {row["Salary"]} руб.");
                }
            }

            // Измененные строки
            var modifiedRows = changes.Select("", "", DataViewRowState.ModifiedCurrent);
            if (modifiedRows.Length > 0)
            {
                Console.WriteLine($"\nИзмененные строки ({modifiedRows.Length}):");
                foreach (DataRow row in modifiedRows)
                {
                    Console.WriteLine($"  ID={row["EmployeeID", DataRowVersion.Original]}: {row["FullName"]}");

                    foreach (DataColumn column in table.Columns)
                    {
                        try
                        {
                            object original = row[column.ColumnName, DataRowVersion.Original];
                            object current = row[column.ColumnName, DataRowVersion.Current];

                            if (!object.Equals(original, current))
                            {
                                Console.WriteLine($"    {column.ColumnName}: {original} -> {current}");
                            }
                        }
                        catch (VersionNotFoundException) { }
                    }
                }
            }

            // Удаленные строки
            var deletedRows = table.Select("", "", DataViewRowState.Deleted);
            if (deletedRows.Length > 0)
            {
                Console.WriteLine($"\nУдаленные строки ({deletedRows.Length}):");
                foreach (DataRow row in deletedRows)
                {
                    Console.WriteLine($"  ID={row["EmployeeID", DataRowVersion.Original]}: " +
                        $"{row["FullName", DataRowVersion.Original]}, " +
                        $"{row["Department", DataRowVersion.Original]}, " +
                        $"{row["Salary", DataRowVersion.Original]} руб.");
                }
            }

            Console.WriteLine(new string('-', 100));
        }

        static void TestDataValidation(DataTable table)
        {
            Console.WriteLine("Тест валидации данных:");

            // Проверка существующих данных
            bool isValid = true;
            foreach (DataRow row in table.Rows)
            {
                if (row.RowState == DataRowState.Deleted) continue;

                // Проверка обязательных полей
                if (row["FullName"] == DBNull.Value || string.IsNullOrWhiteSpace(row["FullName"].ToString()))
                {
                    Console.WriteLine($"  Ошибка: У сотрудника ID={row["EmployeeID"]} не указано ФИО");
                    isValid = false;
                }

                // Проверка зарплаты
                if (row["Salary"] != DBNull.Value)
                {
                    decimal salary = Convert.ToDecimal(row["Salary"]);
                    if (salary < 0)
                    {
                        Console.WriteLine($"  Ошибка: У сотрудника ID={row["EmployeeID"]} отрицательная зарплата");
                        isValid = false;
                    }
                    else if (salary > 1000000)
                    {
                        Console.WriteLine($"  Предупреждение: У сотрудника ID={row["EmployeeID"]} подозрительно высокая зарплата");
                    }
                }
            }

            if (isValid)
            {
                Console.WriteLine("  Все данные валидны");
            }
        }

        static void SimulateSaveChanges(DataTable table)
        {
            try
            {
                DataTable changes = table.GetChanges();

                if (changes != null)
                {
                    Console.WriteLine($"Имитация сохранения {changes.Rows.Count} изменений в БД...");

                    // Имитация успешного сохранения
                    table.AcceptChanges();
                    Console.WriteLine("Изменения успешно сохранены в БД");
                }
                else
                {
                    Console.WriteLine("Нет изменений для сохранения");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при сохранении в БД: {ex.Message}");
                Console.WriteLine("Отмена изменений...");
                table.RejectChanges();
            }
        }
        #endregion

        #region Задание 10: Оптимизация больших объемов данных
        static void Task10_DataOptimization()
        {
            Console.Clear();
            Console.WriteLine("=== ЗАДАНИЕ 10: Оптимизация работы с большими объемами данных ===");

            MockBigDataService dataService = new MockBigDataService();

            Console.WriteLine("Имитация работы с базой данных логов (1,000,000+ записей)");

            // 1. Постраничное получение данных
            Console.WriteLine("\n1. Постраничное получение данных:");
            Console.WriteLine("Загрузка первой страницы (1000 записей):");

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            var page1 = dataService.GetLogsPaged(1, 1000);
            stopwatch.Stop();

            Console.WriteLine($"Загружено: {page1.Count} записей");
            Console.WriteLine($"Время загрузки: {stopwatch.ElapsedMilliseconds} мс");

            if (page1.Count > 0)
            {
                Console.WriteLine("Первые 5 записей:");
                for (int i = 0; i < Math.Min(5, page1.Count); i++)
                {
                    var log = page1[i];
                    Console.WriteLine($"  {log.Timestamp:HH:mm:ss} - {log.EventType} - {log.Description}");
                }
            }

            // 2. Фильтрация на уровне БД
            Console.WriteLine("\n2. Фильтрация по диапазону дат и типу события:");

            stopwatch.Restart();
            var filteredLogs = dataService.GetLogsFiltered(
                DateTime.Now.AddDays(-7),
                DateTime.Now,
                "ERROR",
                1000);
            stopwatch.Stop();

            Console.WriteLine($"Найдено ошибок за последние 7 дней: {filteredLogs.Count}");
            Console.WriteLine($"Время выполнения: {stopwatch.ElapsedMilliseconds} мс");

            // 3. Агрегация данных
            Console.WriteLine("\n3. Агрегация данных (статистика по типам событий):");

            stopwatch.Restart();
            var eventStats = dataService.GetEventStatistics(
                DateTime.Now.AddDays(-30),
                DateTime.Now);
            stopwatch.Stop();

            Console.WriteLine("Статистика за последние 30 дней:");
            Console.WriteLine(new string('-', 50));
            Console.WriteLine("| {0,15} | {1,10} | {2,15} |", "Тип события", "Количество", "Ср. длительность");
            Console.WriteLine(new string('-', 50));

            foreach (var stat in eventStats)
            {
                Console.WriteLine("| {0,15} | {1,10} | {2,15:F2} мс |",
                    stat.EventType, stat.Count, stat.AvgDuration);
            }
            Console.WriteLine(new string('-', 50));
            Console.WriteLine($"Время выполнения: {stopwatch.ElapsedMilliseconds} мс");

            // 4. Асинхронная загрузка
            Console.WriteLine("\n4. Асинхронная загрузка данных:");
            TestAsyncLoading(dataService).Wait();

            // 5. Кэширование
            Console.WriteLine("\n5. Тест кэширования:");
            TestCaching(dataService);

            // 6. Dashboard с виджетами
            Console.WriteLine("\n6. Dashboard с виджетами:");
            ShowDashboard(dataService);

            // 7. Измерение производительности
            Console.WriteLine("\n7. Сравнение производительности:");
            ComparePerformance(dataService);
        }

        class LogEntry
        {
            public int LogID { get; set; }
            public string EventType { get; set; }
            public DateTime Timestamp { get; set; }
            public int UserID { get; set; }
            public string Description { get; set; }
            public double Duration { get; set; }
        }

        class EventStatistic
        {
            public string EventType { get; set; }
            public int Count { get; set; }
            public double AvgDuration { get; set; }
        }

        class MockBigDataService
        {
            private List<LogEntry> _allLogs = new List<LogEntry>();
            private Dictionary<string, List<LogEntry>> _cache = new Dictionary<string, List<LogEntry>>();
            private Random _rnd = new Random();

            public MockBigDataService()
            {
                // Генерация тестовых данных (1,000,000 записей в памяти)
                Console.WriteLine("Генерация тестовых данных...");
                string[] eventTypes = { "INFO", "WARNING", "ERROR", "DEBUG", "AUDIT" };
                string[] descriptions = {
                    "Пользователь вошел в систему",
                    "Пользователь вышел из системы",
                    "Ошибка доступа к базе данных",
                    "Загрузка файла завершена",
                    "Отправка email",
                    "Резервное копирование",
                    "Обновление системы",
                    "Проверка безопасности"
                };

                DateTime startDate = DateTime.Now.AddDays(-365);

                for (int i = 1; i <= 1000000; i++)
                {
                    _allLogs.Add(new LogEntry
                    {
                        LogID = i,
                        EventType = eventTypes[_rnd.Next(eventTypes.Length)],
                        Timestamp = startDate.AddSeconds(_rnd.Next(365 * 24 * 60 * 60)),
                        UserID = _rnd.Next(1, 1000),
                        Description = descriptions[_rnd.Next(descriptions.Length)],
                        Duration = _rnd.NextDouble() * 1000
                    });
                }

                Console.WriteLine($"Сгенерировано {_allLogs.Count} записей логов");
            }

            public List<LogEntry> GetLogsPaged(int pageNumber, int pageSize)
            {
                int startIndex = (pageNumber - 1) * pageSize;
                if (startIndex >= _allLogs.Count)
                    return new List<LogEntry>();

                int endIndex = Math.Min(startIndex + pageSize, _allLogs.Count);
                return _allLogs.GetRange(startIndex, endIndex - startIndex);
            }

            public List<LogEntry> GetLogsFiltered(DateTime startDate, DateTime endDate, string eventType, int maxResults)
            {
                // Имитация фильтрации на уровне БД
                var result = _allLogs
                    .Where(l => l.Timestamp >= startDate && l.Timestamp <= endDate)
                    .Where(l => l.EventType == eventType)
                    .OrderByDescending(l => l.Timestamp)
                    .Take(maxResults)
                    .ToList();

                return result;
            }

            public List<EventStatistic> GetEventStatistics(DateTime startDate, DateTime endDate)
            {
                // Имитация агрегации в БД
                var filteredLogs = _allLogs
                    .Where(l => l.Timestamp >= startDate && l.Timestamp <= endDate)
                    .ToList();

                var stats = filteredLogs
                    .GroupBy(l => l.EventType)
                    .Select(g => new EventStatistic
                    {
                        EventType = g.Key,
                        Count = g.Count(),
                        AvgDuration = g.Average(l => l.Duration)
                    })
                    .OrderByDescending(s => s.Count)
                    .ToList();

                return stats;
            }

            public async Task<List<LogEntry>> GetLogsAsync(DateTime startDate, DateTime endDate, int limit)
            {
                // Имитация асинхронной загрузки
                return await Task.Run(() =>
                {
                    System.Threading.Thread.Sleep(100); // Имитация задержки

                    return _allLogs
                        .Where(l => l.Timestamp >= startDate && l.Timestamp <= endDate)
                        .OrderByDescending(l => l.Timestamp)
                        .Take(limit)
                        .ToList();
                });
            }

            public List<LogEntry> GetLogsCached(string cacheKey, DateTime startDate, DateTime endDate)
            {
                // Проверка кэша
                if (_cache.ContainsKey(cacheKey))
                {
                    Console.WriteLine($"Данные из кэша: {cacheKey}");
                    return _cache[cacheKey];
                }

                // Загрузка и кэширование
                Console.WriteLine($"Загрузка данных и сохранение в кэш: {cacheKey}");
                var data = _allLogs
                    .Where(l => l.Timestamp >= startDate && l.Timestamp <= endDate)
                    .ToList();

                _cache[cacheKey] = data;
                return data;
            }
        }

        static async Task TestAsyncLoading(MockBigDataService service)
        {
            Console.WriteLine("Начало асинхронной загрузки...");

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            // Запуск нескольких асинхронных задач
            var task1 = service.GetLogsAsync(DateTime.Now.AddDays(-1), DateTime.Now, 1000);
            var task2 = service.GetLogsAsync(DateTime.Now.AddDays(-7), DateTime.Now, 1000);
            var task3 = service.GetLogsAsync(DateTime.Now.AddDays(-30), DateTime.Now, 1000);

            // Ожидание завершения всех задач
            var results = await Task.WhenAll(task1, task2, task3);

            stopwatch.Stop();

            Console.WriteLine($"Асинхронная загрузка завершена за {stopwatch.ElapsedMilliseconds} мс");
            Console.WriteLine($"Загружено: {results[0].Count} (1 день), {results[1].Count} (7 дней), {results[2].Count} (30 дней) записей");
        }

        static void TestCaching(MockBigDataService service)
        {
            string cacheKey = "logs_last_7_days";

            Console.WriteLine("Первое обращение (кэш пуст):");
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            var data1 = service.GetLogsCached(cacheKey, DateTime.Now.AddDays(-7), DateTime.Now);
            stopwatch.Stop();
            Console.WriteLine($"Время: {stopwatch.ElapsedMilliseconds} мс, записей: {data1.Count}");

            Console.WriteLine("\nВторое обращение (данные в кэше):");
            stopwatch.Restart();
            var data2 = service.GetLogsCached(cacheKey, DateTime.Now.AddDays(-7), DateTime.Now);
            stopwatch.Stop();
            Console.WriteLine($"Время: {stopwatch.ElapsedMilliseconds} мс, записей: {data2.Count}");

            Console.WriteLine("\nТретье обращение с другим ключом (кэш пуст):");
            stopwatch.Restart();
            var data3 = service.GetLogsCached("logs_last_30_days", DateTime.Now.AddDays(-30), DateTime.Now);
            stopwatch.Stop();
            Console.WriteLine($"Время: {stopwatch.ElapsedMilliseconds} мс, записей: {data3.Count}");
        }

        static void ShowDashboard(MockBigDataService service)
        {
            Console.WriteLine("\n=== DASHBOARD ===");

            // Последние события
            Console.WriteLine("\nПоследние события:");
            var recentEvents = service.GetLogsPaged(1, 10);
            Console.WriteLine(new string('-', 80));
            Console.WriteLine("| {0,20} | {1,10} | {2,10} | {3,30} |",
                "Время", "Тип", "Пользователь", "Описание");
            Console.WriteLine(new string('-', 80));

            foreach (var log in recentEvents)
            {
                Console.WriteLine("| {0,20:dd.MM.yyyy HH:mm:ss} | {1,10} | {2,10} | {3,30} |",
                    log.Timestamp, log.EventType, log.UserID,
                    log.Description.Length > 30 ? log.Description.Substring(0, 27) + "..." : log.Description);
            }
            Console.WriteLine(new string('-', 80));

            // Статистика по типам событий
            Console.WriteLine("\nСтатистика по типам событий (сегодня):");
            var todayStats = service.GetEventStatistics(DateTime.Today, DateTime.Now);

            int totalEvents = todayStats.Sum(s => s.Count);
            foreach (var stat in todayStats)
            {
                double percentage = (double)stat.Count / totalEvents * 100;
                Console.WriteLine($"  {stat.EventType,-10}: {stat.Count,5} ({percentage,5:F1}%)");
            }

            // График событий по времени (имитация)
            Console.WriteLine("\nГрафик событий по часам (имитация):");
            DateTime now = DateTime.Now;
            for (int hour = 0; hour < 24; hour += 3)
            {
                int eventCount = new Random().Next(50, 200);
                string bar = new string('█', eventCount / 20);
                Console.WriteLine($"  {hour:00}:00 - {hour + 2:00}:59: {bar} ({eventCount})");
            }

            // Фильтры
            Console.WriteLine("\nФильтры:");
            Console.WriteLine("  • По дате: сегодня, 7 дней, 30 дней");
            Console.WriteLine("  • По типу: INFO, WARNING, ERROR, DEBUG, AUDIT");
            Console.WriteLine("  • По пользователю: ID 1-1000");
        }

        static void ComparePerformance(MockBigDataService service)
        {
            Console.WriteLine("\nСравнение производительности:");

            // Тест 1: Загрузка всех данных
            Console.WriteLine("\nТест 1: Загрузка всех данных");
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();
            long memoryBefore = GC.GetTotalMemory(true);

            // Имитация загрузки всех данных (на самом деле берем только 10000 для скорости)
            var allData = service.GetLogsPaged(1, 10000);

            long memoryAfter = GC.GetTotalMemory(true);
            stopwatch.Stop();

            Console.WriteLine($"  Время: {stopwatch.ElapsedMilliseconds} мс");
            Console.WriteLine($"  Память: {(memoryAfter - memoryBefore) / 1024 / 1024} МБ");
            Console.WriteLine($"  Записей: {allData.Count}");

            // Тест 2: Постраничная загрузка
            Console.WriteLine("\nТест 2: Постраничная загрузка (10 страниц по 1000)");
            stopwatch.Restart();
            memoryBefore = GC.GetTotalMemory(true);

            List<LogEntry> pagedData = new List<LogEntry>();
            for (int page = 1; page <= 10; page++)
            {
                pagedData.AddRange(service.GetLogsPaged(page, 1000));
            }

            memoryAfter = GC.GetTotalMemory(true);
            stopwatch.Stop();

            Console.WriteLine($"  Время: {stopwatch.ElapsedMilliseconds} мс");
            Console.WriteLine($"  Память: {(memoryAfter - memoryBefore) / 1024 / 1024} МБ");
            Console.WriteLine($"  Записей: {pagedData.Count}");

            // Тест 3: Фильтрация на уровне БД
            Console.WriteLine("\nТест 3: Фильтрация на уровне БД");
            stopwatch.Restart();
            memoryBefore = GC.GetTotalMemory(true);

            var filteredData = service.GetLogsFiltered(
                DateTime.Now.AddDays(-1),
                DateTime.Now,
                "ERROR",
                1000);

            memoryAfter = GC.GetTotalMemory(true);
            stopwatch.Stop();

            Console.WriteLine($"  Время: {stopwatch.ElapsedMilliseconds} мс");
            Console.WriteLine($"  Память: {(memoryAfter - memoryBefore) / 1024} КБ");
            Console.WriteLine($"  Записей: {filteredData.Count}");

            // Вывод рекомендаций
            Console.WriteLine("\n=== РЕКОМЕНДАЦИИ ===");
            Console.WriteLine("1. Используйте постраничную загрузку для больших наборов данных");
            Console.WriteLine("2. Фильтруйте данные на уровне БД, а не в приложении");
            Console.WriteLine("3. Используйте кэширование для часто запрашиваемых данных");
            Console.WriteLine("4. Используйте асинхронные методы для предотвращения блокировки UI");
            Console.WriteLine("5. Ограничивайте количество возвращаемых записей");
        }
        #endregion
    }
}