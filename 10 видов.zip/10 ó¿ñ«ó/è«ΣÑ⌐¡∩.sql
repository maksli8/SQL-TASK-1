IF NOT EXISTS(SELECT * FROM sys.databases WHERE name='CoffeeShopExample')
    CREATE DATABASE CoffeeShopExample;
GO
USE CoffeeShopExample;
GO

-- �������
IF OBJECT_ID('Drinks','U') IS NOT NULL DROP TABLE Drinks;
IF OBJECT_ID('Ingredients','U') IS NOT NULL DROP TABLE Ingredients;
IF OBJECT_ID('Orders','U') IS NOT NULL DROP TABLE Orders;
IF OBJECT_ID('Baristas','U') IS NOT NULL DROP TABLE Baristas;
IF OBJECT_ID('DrinkIngredients','U') IS NOT NULL DROP TABLE DrinkIngredients;

CREATE TABLE Drinks(
    DrinkID INT IDENTITY PRIMARY KEY,
    DrinkName NVARCHAR(100),
    Type NVARCHAR(50),
    Size NVARCHAR(1) CHECK(Size IN ('S','M','L')),
    Price DECIMAL(10,2)
);

CREATE TABLE Ingredients(
    IngredientID INT IDENTITY PRIMARY KEY,
    IngredientName NVARCHAR(100),
    Unit NVARCHAR(20),
    Quantity DECIMAL(10,2)
);

CREATE TABLE Baristas(
    BaristaID INT IDENTITY PRIMARY KEY,
    Name NVARCHAR(50),
    Shift NVARCHAR(20),
    Rating INT
);

CREATE TABLE Orders(
    OrderID INT IDENTITY PRIMARY KEY,
    BaristaID INT NOT NULL,
    OrderDate DATE,
    FOREIGN KEY(BaristaID) REFERENCES Baristas(BaristaID)
);

CREATE TABLE DrinkIngredients(
    DrinkIngredientID INT IDENTITY PRIMARY KEY,
    DrinkID INT NOT NULL,
    IngredientID INT NOT NULL,
    Quantity DECIMAL(10,2),
    FOREIGN KEY(DrinkID) REFERENCES Drinks(DrinkID),
    FOREIGN KEY(IngredientID) REFERENCES Ingredients(IngredientID)
);

-- ������
INSERT INTO Drinks(DrinkName, Type, Size, Price) VALUES
('�����','����','M',250),
('��������','����','S',150);

INSERT INTO Ingredients(IngredientName, Unit, Quantity) VALUES
('������','��',1000),
('����','�',500);

INSERT INTO Baristas(Name, Shift, Rating) VALUES
('����','����',5),
('����','�����',4);

INSERT INTO Orders(BaristaID, OrderDate) VALUES
(1,'2023-09-20'),
(2,'2023-09-21');

INSERT INTO DrinkIngredients(DrinkID, IngredientID, Quantity) VALUES
(1,1,200),(1,2,20),
(2,2,15);

-- ������� ��������
-- 1. ��� ������ � �������
SELECT o.OrderID, b.Name AS Barista
FROM Orders o
JOIN Baristas b ON o.BaristaID=b.BaristaID;

-- 2. ������ �������
SELECT d.DrinkName, i.IngredientName, di.Quantity, i.Unit
FROM DrinkIngredients di
JOIN Drinks d ON di.DrinkID=d.DrinkID
JOIN Ingredients i ON di.IngredientID=i.IngredientID;
