﻿// ТЕМА 1: ПОНИМАТЬ РАБОТУ МЕТОДОВ (100 задач)

// Задача 1: Напишите метод, возвращающий квадрат числа
static int Square(int n)
{
    return n * n;
}

// Пример использования:
// int result = Square(5); // result = 25

// Задача 2: Напишите метод, вычисляющий сумму двух целых чисел
static int Sum(int a, int b)
{
    return a + b;
}

// Пример использования:
// int result = Sum(10, 20); // result = 30

// Задача 3: Реализуйте метод, возвращающий длину строки
static int GetStringLength(string str)
{
    if (str == null)
        return 0;
    return str.Length;
}

// Пример использования:
// int length = GetStringLength("Hello"); // length = 5

// Задача 4: Создайте метод для вычисления НОД двух чисел
static int GCD(int a, int b)
{
    while (b != 0)
    {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// Пример использования:
// int gcd = GCD(48, 18); // gcd = 6

// Задача 5: Создайте метод для вычисления НОД двух чисел
static int GCD_Recursive(int a, int b)
{
    if (b == 0)
        return a;
    return GCD_Recursive(b, a % b);
}

// Пример использования:
// int gcd = GCD_Recursive(56, 98); // gcd = 14

// Задача 6: Создайте метод, выводящий таблицу умножения числа
static void PrintMultiplicationTable(int n)
{
    for (int i = 1; i <= 10; i++)
    {
        Console.WriteLine($"{n} x {i} = {n * i}");
    }
}

// Пример использования:
// PrintMultiplicationTable(5);
// Вывод: 5 x 1 = 5, 5 x 2 = 10, ... 5 x 10 = 50

// Задача 7: Напишите метод, возвращающий квадрат числа
static double Square(double n)
{
    return n * n;
}

// Пример использования:
// double result = Square(3.5); // result = 12.25

// Задача 8: Реализуйте метод для реверса строки
static string ReverseString(string str)
{
    if (string.IsNullOrEmpty(str))
        return str;

    char[] chars = str.ToCharArray();
    Array.Reverse(chars);
    return new string(chars);
}

// Пример использования:
// string reversed = ReverseString("Hello"); // reversed = "olleH"

// Задача 9: Реализуйте метод для нахождения максимума из трех чисел
static int MaxOfThree(int a, int b, int c)
{
    int max = a;
    if (b > max) max = b;
    if (c > max) max = c;
    return max;
}

// Пример использования:
// int maximum = MaxOfThree(15, 42, 28); // maximum = 42

// Задача 10: Напишите метод для вычисления суммы элементов массива
static int SumArray(int[] array)
{
    if (array == null || array.Length == 0)
        return 0;

    int sum = 0;
    foreach (int num in array)
    {
        sum += num;
    }
    return sum;
}

// Пример использования:
// int[] numbers = {1, 2, 3, 4, 5};
// int total = SumArray(numbers); // total = 15

// Задача 11: Создайте метод, находящий минимум в массиве
static int FindMin(int[] array)
{
    if (array == null || array.Length == 0)
        throw new ArgumentException("Массив не может быть пустым");

    int min = array[0];
    for (int i = 1; i < array.Length; i++)
    {
        if (array[i] < min)
            min = array[i];
    }
    return min;
}

// Пример использования:
// int min = FindMin(new int[] {3, 1, 4, 1, 5}); // min = 1

// Задача 12: Создайте метод, определяющий, является ли число четным
static bool IsEven(int number)
{
    return number % 2 == 0;
}

// Пример использования:
// bool result = IsEven(4); // result = true

// Задача 13: Напишите метод, вычисляющий сумму двух целых чисел
static int SumWithCheck(int a, int b)
{
    long result = (long)a + b;
    if (result > int.MaxValue || result < int.MinValue)
        throw new OverflowException("Результат выходит за пределы int");
    return a + b;
}

// Пример использования:
// int result = SumWithCheck(1000000000, 2000000000); // Без ошибки

// Задача 14: Реализуйте метод для нахождения максимума из трех чисел
static double MaxOfThree(double a, double b, double c)
{
    return Math.Max(a, Math.Max(b, c));
}

// Пример использования:
// double max = MaxOfThree(1.5, 2.7, 1.8); // max = 2.7

// Задача 15: Напишите метод, проверяющий, является ли число простым
static bool IsPrime(int number)
{
    if (number <= 1) return false;
    if (number == 2) return true;
    if (number % 2 == 0) return false;

    for (int i = 3; i <= Math.Sqrt(number); i += 2)
    {
        if (number % i == 0)
            return false;
    }
    return true;
}

// Пример использования:
// bool prime = IsPrime(17); // prime = true

// Задача 16: Создайте метод для вычисления НОД двух чисел
static int GCD_Abs(int a, int b)
{
    a = Math.Abs(a);
    b = Math.Abs(b);

    while (b != 0)
    {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// Пример использования:
// int gcd = GCD_Abs(-48, 18); // gcd = 6

// Задача 17: Создайте метод, проверяющий, содержится ли элемент в массиве
static bool ContainsElement(int[] array, int element)
{
    if (array == null) return false;

    foreach (int item in array)
    {
        if (item == element)
            return true;
    }
    return false;
}

// Пример использования:
// bool contains = ContainsElement(new int[] {1, 2, 3}, 2); // contains = true

// Задача 18: Создайте метод, возвращающий абсолютное значение числа
static int AbsoluteValue(int number)
{
    return number < 0 ? -number : number;
}

// Пример использования:
// int abs = AbsoluteValue(-10); // abs = 10

// Задача 19: Напишите метод, вычисляющий сумму двух целых чисел
static int SumWithLog(int a, int b)
{
    int result = a + b;
    Console.WriteLine($"Сумма {a} + {b} = {result}");
    return result;
}

// Пример использования:
// int result = SumWithLog(5, 3); // Вывод: Сумма 5 + 3 = 8

// Задача 20: Реализуйте метод для реверса строки
static string ReverseStringSB(string str)
{
    if (string.IsNullOrEmpty(str))
        return str;

    StringBuilder sb = new StringBuilder();
    for (int i = str.Length - 1; i >= 0; i--)
    {
        sb.Append(str[i]);
    }
    return sb.ToString();
}

// Пример использования:
// string reversed = ReverseStringSB("Hello"); // reversed = "olleH"

// Задача 21: Напишите метод, проверяющий, является ли число простым
static bool IsPrimeOptimized(int number)
{
    if (number <= 1) return false;
    if (number == 2 || number == 3) return true;
    if (number % 2 == 0 || number % 3 == 0) return false;

    for (int i = 5; i * i <= number; i += 6)
    {
        if (number % i == 0 || number % (i + 2) == 0)
            return false;
    }
    return true;
}

// Пример использования:
// bool prime = IsPrimeOptimized(29); // prime = true

// Задача 22: Реализуйте метод для реверса строки
static string ReverseStringLinq(string str)
{
    if (string.IsNullOrEmpty(str))
        return str;
    return new string(str.Reverse().ToArray());
}

// Пример использования:
// string reversed = ReverseStringLinq("World"); // reversed = "dlroW"

// Задача 23: Создайте метод, находящий минимум в массиве
static double FindMin(double[] array)
{
    if (array == null || array.Length == 0)
        throw new ArgumentException("Массив не может быть пустым");

    double min = array[0];
    for (int i = 1; i < array.Length; i++)
    {
        if (array[i] < min)
            min = array[i];
    }
    return min;
}

// Пример использования:
// double min = FindMin(new double[] {1.1, 2.2, 0.5}); // min = 0.5

// Задача 24: Создайте метод для вычисления НОД двух чисел
static int LCM(int a, int b)
{
    return Math.Abs(a * b) / GCD(a, b);
}

// Пример использования:
// int lcm = LCM(12, 18); // lcm = 36

// Задача 25: Реализуйте метод для сортировки массива по возрастанию
static int[] SortArray(int[] array)
{
    if (array == null) return null;
    int[] sorted = (int[])array.Clone();
    Array.Sort(sorted);
    return sorted;
}

// Пример использования:
// int[] sorted = SortArray(new int[] {3, 1, 4, 2}); // [1, 2, 3, 4]

// Задача 26: Напишите метод для вычисления суммы элементов массива
static double SumArray(double[] array)
{
    if (array == null) return 0;

    double sum = 0;
    foreach (double num in array)
    {
        sum += num;
    }
    return sum;
}

// Пример использования:
// double sum = SumArray(new double[] {1.5, 2.5, 3.5}); // sum = 7.5

// Задача 27: Реализуйте метод, возвращающий длину строки
static int SafeStringLength(string str)
{
    return str?.Length ?? 0;
}

// Пример использования:
// int length = SafeStringLength(null); // length = 0

// Задача 28: Напишите метод, вычисляющий сумму двух целых чисел
static int SumThree(int a, int b, int c)
{
    return a + b + c;
}

// Пример использования:
// int result = SumThree(1, 2, 3); // result = 6

// Задача 29: Реализуйте метод для конкатенации двух строк
static string Concatenate(string str1, string str2)
{
    return str1 + str2;
}

// Пример использования:
// string result = Concatenate("Hello", "World"); // "HelloWorld"

// Задача 30: Создайте метод, находящий минимум в массиве
static decimal FindMin(decimal[] array)
{
    if (array == null || array.Length == 0)
        throw new ArgumentException("Массив не может быть пустым");

    decimal min = array[0];
    for (int i = 1; i < array.Length; i++)
    {
        if (array[i] < min)
            min = array[i];
    }
    return min;
}

// Пример использования:
// decimal min = FindMin(new decimal[] {1.5m, 0.5m, 2.5m}); // min = 0.5

// Задача 31: Создайте метод для вычисления площади прямоугольника
static double RectangleArea(double width, double height)
{
    return width * height;
}

// Пример использования:
// double area = RectangleArea(5, 10); // area = 50

// Задача 32: Реализуйте метод, возвращающий длину строки
static int ArrayLength(int[] array)
{
    return array?.Length ?? 0;
}

// Пример использования:
// int length = ArrayLength(new int[] {1, 2, 3}); // length = 3

// Задача 33: Создайте метод, выводящий таблицу умножения числа
static void PrintMultiplicationTableRange(int n, int start, int end)
{
    for (int i = start; i <= end; i++)
    {
        Console.WriteLine($"{n} x {i} = {n * i}");
    }
}

// Пример использования:
// PrintMultiplicationTableRange(3, 5, 8); // Таблица от 5 до 8

// Задача 34: Напишите метод, проверяющий, является ли число простым
static bool CheckPrime(int number)
{
    return IsPrime(number);
}

// Пример использования:
// bool isPrime = CheckPrime(13); // true

// Задача 35: Создайте метод для вычисления площади прямоугольника
static double SquareArea(double side)
{
    return side * side;
}

// Пример использования:
// double area = SquareArea(4); // area = 16

// Задача 36: Напишите метод, возвращающий квадрат числа
static int Cube(int n)
{
    return n * n * n;
}

// Пример использования:
// int result = Cube(3); // result = 27

// Задача 37: Реализуйте метод для нахождения максимума из трех чисел
static int MinOfThree(int a, int b, int c)
{
    int min = a;
    if (b < min) min = b;
    if (c < min) min = c;
    return min;
}

// Пример использования:
// int min = MinOfThree(5, 2, 8); // min = 2

// Задача 38: Напишите метод для подсчета количества гласных в строке
static int CountVowels(string str)
{
    if (string.IsNullOrEmpty(str)) return 0;

    char[] vowels = { 'a', 'e', 'i', 'o', 'u', 'а', 'е', 'ё', 'и', 'о', 'у', 'ы', 'э', 'ю', 'я' };
    int count = 0;
    foreach (char c in str.ToLower())
    {
        if (vowels.Contains(c))
            count++;
    }
    return count;
}

// Пример использования:
// int count = CountVowels("Hello"); // count = 2

// Задача 39: Напишите метод, возвращающий квадрат числа
static decimal Square(decimal n)
{
    return n * n;
}

// Пример использования:
// decimal result = Square(2.5m); // result = 6.25

// Задача 40: Реализуйте метод, определяющий, является ли строка палиндромом
static bool IsPalindrome(string str)
{
    if (string.IsNullOrEmpty(str)) return true;

    string clean = new string(str.ToLower().Where(char.IsLetterOrDigit).ToArray());
    string reversed = new string(clean.Reverse().ToArray());
    return clean == reversed;
}

// Пример использования:
// bool palindrome = IsPalindrome("А роза упала на лапу Азора"); // true

// Задача 41: Реализуйте метод, определяющий, является ли строка палиндромом
static bool IsPalindromeIgnoreCase(string str)
{
    if (string.IsNullOrEmpty(str)) return true;

    string clean = new string(str.Where(char.IsLetterOrDigit).ToArray());
    return clean.Equals(new string(clean.Reverse().ToArray()), StringComparison.OrdinalIgnoreCase);
}

// Пример использования:
// bool result = IsPalindromeIgnoreCase("Racecar"); // true

// Задача 42: Создайте метод, возвращающий абсолютное значение числа
static double AbsoluteValue(double number)
{
    return Math.Abs(number);
}

// Пример использования:
// double abs = AbsoluteValue(-3.14); // abs = 3.14

// Задача 43: Реализуйте метод, возвращающий длину строки
static int StringArrayLength(string[] array)
{
    return array?.Length ?? 0;
}

// Пример использования:
// int length = StringArrayLength(new string[] {"a", "b", "c"}); // length = 3

// Задача 44: Создайте метод, определяющий, является ли число четным
static bool IsOdd(int number)
{
    return number % 2 != 0;
}

// Пример использования:
// bool odd = IsOdd(7); // odd = true

// Задача 45: Реализуйте метод для сортировки массива по возрастанию
static string[] SortStringArray(string[] array)
{
    if (array == null) return null;
    string[] sorted = (string[])array.Clone();
    Array.Sort(sorted);
    return sorted;
}

// Пример использования:
// string[] sorted = SortStringArray(new string[] {"z", "a", "m"}); // ["a", "m", "z"]

// Задача 46: Реализуйте метод для реверса строки
static int[] ReverseArray(int[] array)
{
    if (array == null) return null;

    int[] reversed = new int[array.Length];
    for (int i = 0; i < array.Length; i++)
    {
        reversed[i] = array[array.Length - 1 - i];
    }
    return reversed;
}

// Пример использования:
// int[] reversed = ReverseArray(new int[] {1, 2, 3}); // [3, 2, 1]

// Задача 47: Напишите метод, возвращающий квадрат числа
static double Power(double baseNum, int exponent)
{
    return Math.Pow(baseNum, exponent);
}

// Пример использования:
// double result = Power(2, 3); // result = 8

// Задача 48: Напишите метод для подсчета количества гласных в строке
static int CountConsonants(string str)
{
    if (string.IsNullOrEmpty(str)) return 0;

    char[] vowels = { 'a', 'e', 'i', 'o', 'u', 'а', 'е', 'ё', 'и', 'о', 'у', 'ы', 'э', 'ю', 'я' };
    int count = 0;
    foreach (char c in str.ToLower().Where(char.IsLetter))
    {
        if (!vowels.Contains(c))
            count++;
    }
    return count;
}

// Пример использования:
// int count = CountConsonants("Hello"); // count = 3

// Задача 49: Реализуйте метод для нахождения максимума из трех чисел
static double AverageOfThree(int a, int b, int c)
{
    return (a + b + c) / 3.0;
}

// Пример использования:
// double avg = AverageOfThree(1, 2, 3); // avg = 2.0

// Задача 50: Реализуйте метод для реверса строки
static string ReverseStringManual(string str)
{
    if (string.IsNullOrEmpty(str)) return str;

    char[] result = new char[str.Length];
    for (int i = 0; i < str.Length; i++)
    {
        result[i] = str[str.Length - 1 - i];
    }
    return new string(result);
}

// Пример использования:
// string reversed = ReverseStringManual("Test"); // "tseT"

// Продолжение следующих 50 задач из темы 1...

// Задача 51: Напишите метод для преобразования градусов Цельсия в Фаренгейт
static double CelsiusToFahrenheit(double celsius)
{
    return (celsius * 9 / 5) + 32;
}

// Пример использования:
// double fahrenheit = CelsiusToFahrenheit(25); // 77

// Задача 52: Создайте метод, возвращающий абсолютное значение числа
static decimal AbsoluteValue(decimal number)
{
    return number < 0 ? -number : number;
}

// Пример использования:
// decimal abs = AbsoluteValue(-5.5m); // 5.5

// Задача 53: Реализуйте метод, определяющий, является ли строка палиндромом
static bool IsPalindromeSimple(string str)
{
    if (string.IsNullOrEmpty(str)) return true;

    int left = 0;
    int right = str.Length - 1;

    while (left < right)
    {
        if (str[left] != str[right])
            return false;
        left++;
        right--;
    }
    return true;
}

// Пример использования:
// bool result = IsPalindromeSimple("radar"); // true

// Задача 54: Напишите метод для вычисления суммы элементов массива
static decimal SumArray(decimal[] array)
{
    if (array == null) return 0;

    decimal sum = 0;
    foreach (decimal num in array)
    {
        sum += num;
    }
    return sum;
}

// Пример использования:
// decimal sum = SumArray(new decimal[] {1.1m, 2.2m, 3.3m}); // 6.6

// Задача 55: Напишите метод, проверяющий, является ли число простым
static bool IsPrimeSieve(int number)
{
    if (number <= 1) return false;
    if (number == 2) return true;
    if (number % 2 == 0) return false;

    for (int i = 3; i * i <= number; i += 2)
    {
        if (number % i == 0)
            return false;
    }
    return true;
}

// Пример использования:
// bool prime = IsPrimeSieve(19); // true

// Задача 56: Реализуйте метод для нахождения максимума из трех чисел
static int MaxOfThreeParams(params int[] numbers)
{
    if (numbers == null || numbers.Length == 0)
        throw new ArgumentException("Массив не может быть пустым");

    int max = numbers[0];
    for (int i = 1; i < numbers.Length; i++)
    {
        if (numbers[i] > max)
            max = numbers[i];
    }
    return max;
}

// Пример использования:
// int max = MaxOfThreeParams(10, 20, 15); // 20

// Задача 57: Создайте метод, определяющий, является ли число четным
static bool IsEvenLong(long number)
{
    return number % 2 == 0;
}

// Пример использования:
// bool even = IsEvenLong(10000000000L); // true

// Задача 58: Создайте метод для вычисления НОД двух чисел
static int GCDExtended(int a, int b)
{
    a = Math.Abs(a);
    b = Math.Abs(b);

    while (b != 0)
    {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// Пример использования:
// int gcd = GCDExtended(54, 24); // 6

// Задача 59: Напишите метод для преобразования градусов Цельсия в Фаренгейт
static double FahrenheitToCelsius(double fahrenheit)
{
    return (fahrenheit - 32) * 5 / 9;
}

// Пример использования:
// double celsius = FahrenheitToCelsius(77); // 25

// Задача 60: Реализуйте метод для нахождения максимума из трех чисел
static decimal MaxOfThree(decimal a, decimal b, decimal c)
{
    decimal max = a;
    if (b > max) max = b;
    if (c > max) max = c;
    return max;
}

// Пример использования:
// decimal max = MaxOfThree(1.5m, 2.7m, 1.8m); // 2.7

// Задача 61: Создайте метод для вычисления НОД двух чисел
static int GCDThree(int a, int b, int c)
{
    return GCD(GCD(a, b), c);
}

// Пример использования:
// int gcd = GCDThree(12, 18, 24); // 6

// Задача 62: Напишите метод, возвращающий квадрат числа
static long Square(long n)
{
    return n * n;
}

// Пример использования:
// long result = Square(1000000L); // 1000000000000

// Задача 63: Напишите метод для подсчета количества гласных в строке
static int CountVowelsEnglish(string str)
{
    if (string.IsNullOrEmpty(str)) return 0;

    char[] vowels = { 'a', 'e', 'i', 'o', 'u' };
    int count = 0;
    foreach (char c in str.ToLower())
    {
        if (vowels.Contains(c))
            count++;
    }
    return count;
}

// Пример использования:
// int count = CountVowelsEnglish("Programming"); // 3

// Задача 64: Реализуйте метод, возвращающий длину строки
static long GetStringLengthLong(string str)
{
    return str?.Length ?? 0;
}

// Пример использования:
// long length = GetStringLengthLong("Hello World"); // 11

// Задача 65: Реализуйте метод для сортировки массива по возрастанию
static double[] SortArray(double[] array)
{
    if (array == null) return null;
    double[] sorted = (double[])array.Clone();
    Array.Sort(sorted);
    return sorted;
}

// Пример использования:
// double[] sorted = SortArray(new double[] {3.1, 1.2, 2.3}); // [1.2, 2.3, 3.1]

// Задача 66: Реализуйте метод, определяющий, является ли строка палиндромом
static bool IsPalindromeNumber(int number)
{
    string str = number.ToString();
    return IsPalindrome(str);
}

// Пример использования:
// bool result = IsPalindromeNumber(12321); // true

// Задача 67: Реализуйте метод для конкатенации двух строк
static string ConcatenateWithSpace(string str1, string str2)
{
    return $"{str1} {str2}";
}

// Пример использования:
// string result = ConcatenateWithSpace("Hello", "World"); // "Hello World"

// Задача 68: Реализуйте метод, определяющий, является ли строка палиндромом
static bool IsPalindromeWithSpaces(string str)
{
    if (string.IsNullOrEmpty(str)) return true;

    string clean = new string(str.ToLower().Where(char.IsLetter).ToArray());
    return clean == new string(clean.Reverse().ToArray());
}

// Пример использования:
// bool result = IsPalindromeWithSpaces("A man a plan a canal Panama"); // true

// Задача 69: Реализуйте метод, определяющий, является ли строка палиндромом
static bool IsPalindromePhrase(string str)
{
    if (string.IsNullOrEmpty(str)) return true;

    string clean = new string(str.ToLower().Where(char.IsLetterOrDigit).ToArray());
    return IsPalindrome(clean);
}

// Пример использования:
// bool result = IsPalindromePhrase("Madam, I'm Adam"); // true

// Задача 70: Напишите метод, проверяющий, является ли число простым
static bool IsPrimeBig(int number)
{
    if (number <= 1) return false;
    if (number == 2) return true;
    if (number % 2 == 0) return false;

    int boundary = (int)Math.Sqrt(number);
    for (int i = 3; i <= boundary; i += 2)
    {
        if (number % i == 0)
            return false;
    }
    return true;
}

// Пример использования:
// bool prime = IsPrimeBig(97); // true

// Задача 71: Реализуйте метод, возвращающий длину строки
static int GetStringLengthSafe(string str)
{
    return str == null ? 0 : str.Length;
}

// Пример использования:
// int length = GetStringLengthSafe(null); // 0

// Задача 72: Реализуйте метод для нахождения максимума из трех чисел
static float MaxOfThree(float a, float b, float c)
{
    return Math.Max(a, Math.Max(b, c));
}

// Пример использования:
// float max = MaxOfThree(1.1f, 2.2f, 1.5f); // 2.2

// Задача 73: Создайте метод, возвращающий абсолютное значение числа
static float AbsoluteValue(float number)
{
    return Math.Abs(number);
}

// Пример использования:
// float abs = AbsoluteValue(-3.14f); // 3.14

// Задача 74: Реализуйте метод для конкатенации двух строк
static string ConcatenateThree(string str1, string str2, string str3)
{
    return str1 + str2 + str3;
}

// Пример использования:
// string result = ConcatenateThree("C#", " is", " great"); // "C# is great"

// Задача 75: Реализуйте метод для реверса строки
static string ReverseWords(string str)
{
    if (string.IsNullOrEmpty(str)) return str;

    string[] words = str.Split(' ');
    Array.Reverse(words);
    return string.Join(" ", words);
}

// Пример использования:
// string reversed = ReverseWords("Hello World C#"); // "C# World Hello"

// Задача 76: Создайте метод для вычисления НОД двух чисел
static int GCDLoop(int a, int b)
{
    a = Math.Abs(a);
    b = Math.Abs(b);

    while (a != b)
    {
        if (a > b)
            a -= b;
        else
            b -= a;
    }
    return a;
}

// Пример использования:
// int gcd = GCDLoop(48, 18); // 6

// Задача 77: Реализуйте метод для конкатенации двух строк
static string ConcatenateWithSeparator(string str1, string str2, string separator)
{
    return $"{str1}{separator}{str2}";
}

// Пример использования:
// string result = ConcatenateWithSeparator("Hello", "World", ", "); // "Hello, World"

// Задача 78: Реализуйте метод для сортировки массива по возрастанию
static string[] SortStringArrayDesc(string[] array)
{
    if (array == null) return null;
    string[] sorted = (string[])array.Clone();
    Array.Sort(sorted);
    Array.Reverse(sorted);
    return sorted;
}

// Пример использования:
// string[] sorted = SortStringArrayDesc(new string[] {"a", "c", "b"}); // ["c", "b", "a"]

// Задача 79: Напишите метод для подсчета количества гласных в строке
static int CountVowelsRussian(string str)
{
    if (string.IsNullOrEmpty(str)) return 0;

    char[] vowels = { 'а', 'е', 'ё', 'и', 'о', 'у', 'ы', 'э', 'ю', 'я' };
    int count = 0;
    foreach (char c in str.ToLower())
    {
        if (vowels.Contains(c))
            count++;
    }
    return count;
}

// Пример использования:
// int count = CountVowelsRussian("Программирование"); // 6

// Задача 80: Реализуйте метод, возвращающий длину строки
static int GetStringLengthUnicode(string str)
{
    return str?.Length ?? 0;
}

// Пример использования:
// int length = GetStringLengthUnicode("Привет"); // 6

// Задача 81: Реализуйте метод для реверса строки
static string ReverseSubstring(string str, int start, int length)
{
    if (string.IsNullOrEmpty(str)) return str;
    if (start < 0 || start >= str.Length || length <= 0) return str;

    string substring = str.Substring(start, Math.Min(length, str.Length - start));
    return ReverseString(substring);
}

// Пример использования:
// string reversed = ReverseSubstring("Hello World", 6, 5); // "dlroW"

// Задача 82: Создайте метод для вычисления НОД двух чисел
static int GCDBinary(int a, int b)
{
    a = Math.Abs(a);
    b = Math.Abs(b);

    if (a == 0) return b;
    if (b == 0) return a;

    int shift;
    for (shift = 0; ((a | b) & 1) == 0; shift++)
    {
        a >>= 1;
        b >>= 1;
    }

    while ((a & 1) == 0)
        a >>= 1;

    do
    {
        while ((b & 1) == 0)
            b >>= 1;

        if (a > b)
        {
            int temp = a;
            a = b;
            b = temp;
        }
        b -= a;
    } while (b != 0);

    return a << shift;
}

// Пример использования:
// int gcd = GCDBinary(48, 18); // 6

// Задача 83: Создайте метод для вычисления площади прямоугольника
static double RectangleAreaPerimeter(double width, double height, out double perimeter)
{
    perimeter = 2 * (width + height);
    return width * height;
}

// Пример использования:
// double area = RectangleAreaPerimeter(5, 10, out double perimeter); // area=50, perimeter=30

// Задача 84: Создайте метод, определяющий, является ли число четным
static string EvenOddString(int number)
{
    return number % 2 == 0 ? "Even" : "Odd";
}

// Пример использования:
// string result = EvenOddString(7); // "Odd"

// Задача 85: Создайте метод для вычисления НОД двух чисел
static int GCDArray(params int[] numbers)
{
    if (numbers == null || numbers.Length == 0)
        throw new ArgumentException("Массив не может быть пустым");

    int result = numbers[0];
    for (int i = 1; i < numbers.Length; i++)
    {
        result = GCD(result, numbers[i]);
    }
    return result;
}

// Пример использования:
// int gcd = GCDArray(12, 18, 24); // 6

// Задача 86: Создайте метод, определяющий, является ли число четным
static void CheckEvenOdd(int number)
{
    if (number % 2 == 0)
        Console.WriteLine($"{number} is even");
    else
        Console.WriteLine($"{number} is odd");
}

// Пример использования:
// CheckEvenOdd(10); // "10 is even"

// Задача 87: Создайте метод для вычисления площади прямоугольника
static double TriangleArea(double baseLength, double height)
{
    return 0.5 * baseLength * height;
}

// Пример использования:
// double area = TriangleArea(10, 5); // 25

// Задача 88: Напишите метод для подсчета количества гласных в строке
static int CountVowelsBoth(string str)
{
    if (string.IsNullOrEmpty(str)) return 0;

    char[] vowels = { 'a', 'e', 'i', 'o', 'u', 'а', 'е', 'ё', 'и', 'о', 'у', 'ы', 'э', 'ю', 'я' };
    int count = 0;
    foreach (char c in str.ToLower())
    {
        if (vowels.Contains(c))
            count++;
    }
    return count;
}

// Пример использования:
// int count = CountVowelsBoth("Hello Привет"); // 4

// Задача 89: Реализуйте метод, возвращающий длину строки
static int GetStringLengthTrimmed(string str)
{
    return str?.Trim().Length ?? 0;
}

// Пример использования:
// int length = GetStringLengthTrimmed("  Hello  "); // 5

// Задача 90: Реализуйте метод для нахождения максимума из трех чисел
static int MaxOfThreeWithLog(int a, int b, int c)
{
    int max = MaxOfThree(a, b, c);
    Console.WriteLine($"Maximum of {a}, {b}, {c} is {max}");
    return max;
}

// Пример использования:
// int max = MaxOfThreeWithLog(1, 5, 3); // Вывод: Maximum of 1, 5, 3 is 5

// Задача 91: Напишите метод, проверяющий, является ли число простым
static string PrimeStatus(int number)
{
    return IsPrime(number) ? "Prime" : "Not Prime";
}

// Пример использования:
// string status = PrimeStatus(17); // "Prime"

// Задача 92: Напишите метод для вычисления суммы элементов массива
static long SumArrayLong(long[] array)
{
    if (array == null) return 0;

    long sum = 0;
    foreach (long num in array)
    {
        sum += num;
    }
    return sum;
}

// Пример использования:
// long sum = SumArrayLong(new long[] {1000000L, 2000000L}); // 3000000

// Задача 93: Создайте метод для вычисления площади прямоугольника
static double CircleArea(double radius)
{
    return Math.PI * radius * radius;
}

// Пример использования:
// double area = CircleArea(5); // ~78.54

// Задача 94: Напишите метод, проверяющий, является ли число простым
static bool IsPrimeWithMessage(int number)
{
    bool isPrime = IsPrime(number);
    Console.WriteLine($"{number} is {(isPrime ? "prime" : "not prime")}");
    return isPrime;
}

// Пример использования:
// bool result = IsPrimeWithMessage(29); // Вывод: 29 is prime

// Задача 95: Напишите метод для вычисления среднего арифметического массива
static double ArrayAverage(int[] array)
{
    if (array == null || array.Length == 0)
        throw new ArgumentException("Массив не может быть пустым");

    return (double)SumArray(array) / array.Length;
}

// Пример использования:
// double avg = ArrayAverage(new int[] {1, 2, 3, 4, 5}); // 3.0

// Задача 96: Напишите метод для подсчета количества гласных в строке
static Dictionary<char, int> CountVowelsDetailed(string str)
{
    var result = new Dictionary<char, int>();
    char[] vowels = { 'a', 'e', 'i', 'o', 'u' };

    foreach (char vowel in vowels)
    {
        result[vowel] = 0;
    }

    if (!string.IsNullOrEmpty(str))
    {
        foreach (char c in str.ToLower())
        {
            if (vowels.Contains(c))
            {
                result[c]++;
            }
        }
    }

    return result;
}

// Пример использования:
// var counts = CountVowelsDetailed("hello world"); // a:0, e:1, i:0, o:2, u:0

// Задача 97: Реализуйте метод для сортировки массива по возрастанию
static void SortArrayInPlace(int[] array)
{
    if (array != null)
        Array.Sort(array);
}

// Пример использования:
// int[] arr = {3, 1, 2};
// SortArrayInPlace(arr); // arr становится [1, 2, 3]

// Задача 98: Создайте метод, выводящий таблицу умножения числа
static void PrintMultiplicationTableVertical(int n)
{
    Console.WriteLine($"Vertical multiplication table for {n}:");
    for (int i = 1; i <= 10; i++)
    {
        Console.WriteLine($"{n} × {i} = {n * i}");
    }
}

// Пример использования:
// PrintMultiplicationTableVertical(8);

// Задача 99: Реализуйте метод, возвращающий длину строки
static int GetStringLengthWithoutSpaces(string str)
{
    return str?.Replace(" ", "").Length ?? 0;
}

// Пример использования:
// int length = GetStringLengthWithoutSpaces("Hello World"); // 10

// Задача 100: Создайте метод, выводящий таблицу умножения числа
static void PrintFullMultiplicationTable()
{
    for (int i = 1; i <= 10; i++)
    {
        for (int j = 1; j <= 10; j++)
        {
            Console.Write($"{i * j,4}");
        }
        Console.WriteLine();
    }
}

// Пример использования:
// PrintFullMultiplicationTable(); // Полная таблица умножения

// Задача 101: Создайте рекурсивную функцию для проверки, является ли строка палиндромом
static bool IsPalindromeRecursive(string str)
{
    if (str == null) return false;
    if (str.Length <= 1) return true;

    if (char.ToLower(str[0]) != char.ToLower(str[str.Length - 1]))
        return false;

    return IsPalindromeRecursive(str.Substring(1, str.Length - 2));
}

// Пример использования:
// bool result = IsPalindromeRecursive("radar"); // true

// Задача 102: Напишите рекурсивную функцию для генерации всех подмножеств множества
static List<List<int>> GenerateSubsets(int[] nums)
{
    var result = new List<List<int>>();
    GenerateSubsetsHelper(nums, 0, new List<int>(), result);
    return result;
}

static void GenerateSubsetsHelper(int[] nums, int index, List<int> current, List<List<int>> result)
{
    if (index == nums.Length)
    {
        result.Add(new List<int>(current));
        return;
    }

    // Не включаем текущий элемент
    GenerateSubsetsHelper(nums, index + 1, current, result);

    // Включаем текущий элемент
    current.Add(nums[index]);
    GenerateSubsetsHelper(nums, index + 1, current, result);
    current.RemoveAt(current.Count - 1);
}

// Пример использования:
// var subsets = GenerateSubsets(new int[] {1, 2, 3});

// Задача 103: Напишите рекурсивную функцию для генерации всех подмножеств множества
static List<string> GenerateSubsetsString(string str)
{
    var result = new List<string>();
    GenerateSubsetsStringHelper(str, 0, "", result);
    return result;
}

static void GenerateSubsetsStringHelper(string str, int index, string current, List<string> result)
{
    if (index == str.Length)
    {
        result.Add(current);
        return;
    }

    // Не включаем текущий символ
    GenerateSubsetsStringHelper(str, index + 1, current, result);

    // Включаем текущий символ
    GenerateSubsetsStringHelper(str, index + 1, current + str[index], result);
}

// Пример использования:
// var subsets = GenerateSubsetsString("abc");

// Задача 104: Напишите рекурсивный метод для вычисления суммы цифр числа
static int SumDigits(int number)
{
    if (number == 0) return 0;
    return number % 10 + SumDigits(number / 10);
}

// Пример использования:
// int sum = SumDigits(123); // 6

// Задача 105: Реализуйте рекурсивный метод для вычисления биномиального коэффициента
static int BinomialCoefficient(int n, int k)
{
    if (k == 0 || k == n) return 1;
    return BinomialCoefficient(n - 1, k - 1) + BinomialCoefficient(n - 1, k);
}

// Пример использования:
// int coefficient = BinomialCoefficient(5, 2); // 10

// Задача 106: Создайте рекурсивную функцию для вычисления произведения элементов массива
static int ProductArray(int[] array)
{
    return ProductArrayHelper(array, 0);
}

static int ProductArrayHelper(int[] array, int index)
{
    if (index >= array.Length) return 1;
    return array[index] * ProductArrayHelper(array, index + 1);
}

// Пример использования:
// int product = ProductArray(new int[] {2, 3, 4}); // 24

// Задача 107: Реализуйте рекурсивный метод для вычисления биномиального коэффициента
static int BinomialCoefficientMemo(int n, int k, Dictionary<string, int> memo = null)
{
    memo = memo ?? new Dictionary<string, int>();
    string key = $"{n},{k}";

    if (memo.ContainsKey(key)) return memo[key];
    if (k == 0 || k == n) return 1;

    int result = BinomialCoefficientMemo(n - 1, k - 1, memo) + BinomialCoefficientMemo(n - 1, k, memo);
    memo[key] = result;
    return result;
}

// Пример использования:
// int coefficient = BinomialCoefficientMemo(6, 3); // 20

// Задача 108: Реализуйте рекурсивный метод для проверки отсортированности массива
static bool IsSorted(int[] array)
{
    return IsSortedHelper(array, 0);
}

static bool IsSortedHelper(int[] array, int index)
{
    if (index >= array.Length - 1) return true;
    if (array[index] > array[index + 1]) return false;
    return IsSortedHelper(array, index + 1);
}

// Пример использования:
// bool sorted = IsSorted(new int[] {1, 2, 3, 4}); // true

// Задача 109: Напишите рекурсивную функцию для поиска максимума в массиве
static int FindMaxRecursive(int[] array)
{
    return FindMaxRecursiveHelper(array, 0, int.MinValue);
}

static int FindMaxRecursiveHelper(int[] array, int index, int currentMax)
{
    if (index >= array.Length) return currentMax;
    return FindMaxRecursiveHelper(array, index + 1, Math.Max(currentMax, array[index]));
}

// Пример использования:
// int max = FindMaxRecursive(new int[] {3, 1, 4, 1, 5}); // 5

// Задача 110: Создайте рекурсивную функцию для проверки, является ли строка палиндромом
static bool IsPalindromeRecursiveSimple(string str)
{
    return IsPalindromeRecursiveSimpleHelper(str, 0, str.Length - 1);
}

static bool IsPalindromeRecursiveSimpleHelper(string str, int left, int right)
{
    if (left >= right) return true;
    if (char.ToLower(str[left]) != char.ToLower(str[right])) return false;
    return IsPalindromeRecursiveSimpleHelper(str, left + 1, right - 1);
}

// Пример использования:
// bool result = IsPalindromeRecursiveSimple("racecar"); // true

// Задача 111: Создайте рекурсивный метод для нахождения НОД двух чисел
static int GCDRecursive(int a, int b)
{
    if (b == 0) return Math.Abs(a);
    return GCDRecursive(b, a % b);
}

// Пример использования:
// int gcd = GCDRecursive(48, 18); // 6

// Задача 112: Создайте рекурсивный метод для решения задачи Ханойской башни
static void TowerOfHanoi(int n, char fromRod, char toRod, char auxRod)
{
    if (n == 1)
    {
        Console.WriteLine($"Move disk 1 from rod {fromRod} to rod {toRod}");
        return;
    }

    TowerOfHanoi(n - 1, fromRod, auxRod, toRod);
    Console.WriteLine($"Move disk {n} from rod {fromRod} to rod {toRod}");
    TowerOfHanoi(n - 1, auxRod, toRod, fromRod);
}

// Пример использования:
// TowerOfHanoi(3, 'A', 'C', 'B');

// Задача 113: Реализуйте рекурсивную функцию для вычисления треугольника Паскаля
static int PascalTriangle(int row, int col)
{
    if (col == 0 || col == row) return 1;
    return PascalTriangle(row - 1, col - 1) + PascalTriangle(row - 1, col);
}

// Пример использования:
// int value = PascalTriangle(4, 2); // 6

// Задача 114: Напишите рекурсивный метод для вычисления суммы чисел от 1 до N
static int SumToN(int n)
{
    if (n <= 0) return 0;
    return n + SumToN(n - 1);
}

// Пример использования:
// int sum = SumToN(5); // 15

// Задача 115: Создайте рекурсивную функцию для вычисления чисел Фибоначчи
static int Fibonacci(int n)
{
    if (n <= 1) return n;
    return Fibonacci(n - 1) + Fibonacci(n - 2);
}

// Пример использования:
// int fib = Fibonacci(6); // 8

// Задача 116: Реализуйте рекурсивную функцию для вычисления степени числа
static double PowerRecursive(double baseNum, int exponent)
{
    if (exponent == 0) return 1;
    if (exponent < 0) return 1 / PowerRecursive(baseNum, -exponent);
    return baseNum * PowerRecursive(baseNum, exponent - 1);
}

// Пример использования:
// double result = PowerRecursive(2, 3); // 8

// Задача 117: Создайте рекурсивный метод для нахождения НОД двух чисел
static int GCDRecursiveSimple(int a, int b)
{
    return b == 0 ? a : GCDRecursiveSimple(b, a % b);
}

// Пример использования:
// int gcd = GCDRecursiveSimple(54, 24); // 6

// Задача 118: Напишите рекурсивную функцию для реверса строки
static string ReverseStringRecursive(string str)
{
    if (string.IsNullOrEmpty(str) || str.Length == 1) return str;
    return ReverseStringRecursive(str.Substring(1)) + str[0];
}

// Пример использования:
// string reversed = ReverseStringRecursive("hello"); // "olleh"

// Задача 119: Создайте рекурсивную функцию для вычисления произведения элементов массива
static long ProductArrayLong(long[] array)
{
    return ProductArrayLongHelper(array, 0);
}

static long ProductArrayLongHelper(long[] array, int index)
{
    if (index >= array.Length) return 1;
    return array[index] * ProductArrayLongHelper(array, index + 1);
}

// Пример использования:
// long product = ProductArrayLong(new long[] {10, 20, 30}); // 6000

// Задача 120: Создайте рекурсивную функцию для проверки вхождения подстроки в строку
static bool ContainsSubstring(string str, string substring)
{
    if (substring.Length > str.Length) return false;
    if (str.StartsWith(substring)) return true;
    return ContainsSubstring(str.Substring(1), substring);
}

// Пример использования:
// bool contains = ContainsSubstring("hello world", "world"); // true

// Задача 121: Напишите рекурсивный метод для вычисления суммы чисел от 1 до N
static int SumToNTailRecursive(int n, int accumulator = 0)
{
    if (n == 0) return accumulator;
    return SumToNTailRecursive(n - 1, accumulator + n);
}

// Пример использования:
// int sum = SumToNTailRecursive(10); // 55

// Задача 122: Реализуйте рекурсивный метод для проверки отсортированности массива
static bool IsSortedDescending(int[] array)
{
    return IsSortedDescendingHelper(array, 0);
}

static bool IsSortedDescendingHelper(int[] array, int index)
{
    if (index >= array.Length - 1) return true;
    if (array[index] < array[index + 1]) return false;
    return IsSortedDescendingHelper(array, index + 1);
}

// Пример использования:
// bool sorted = IsSortedDescending(new int[] {5, 4, 3, 2}); // true

// Задача 123: Реализуйте рекурсивный метод для проверки отсортированности массива
static bool IsSortedGeneric(int[] array, bool ascending = true)
{
    return IsSortedGenericHelper(array, 0, ascending);
}

static bool IsSortedGenericHelper(int[] array, int index, bool ascending)
{
    if (index >= array.Length - 1) return true;

    if (ascending && array[index] > array[index + 1]) return false;
    if (!ascending && array[index] < array[index + 1]) return false;

    return IsSortedGenericHelper(array, index + 1, ascending);
}

// Пример использования:
// bool sorted = IsSortedGeneric(new int[] {1, 2, 3}, true); // true

// Задача 124: Создайте рекурсивную функцию для проверки вхождения подстроки в строку
static int IndexOfSubstring(string str, string substring, int index = 0)
{
    if (index + substring.Length > str.Length) return -1;
    if (str.Substring(index, substring.Length) == substring) return index;
    return IndexOfSubstring(str, substring, index + 1);
}

// Пример использования:
// int index = IndexOfSubstring("hello world", "world"); // 6

// Задача 125: Напишите рекурсивный метод для преобразования числа в двоичную систему
static string DecimalToBinary(int number)
{
    if (number == 0) return "0";
    if (number == 1) return "1";
    return DecimalToBinary(number / 2) + (number % 2).ToString();
}

// Пример использования:
// string binary = DecimalToBinary(10); // "1010"

// Задача 126: Создайте рекурсивный метод для решения задачи Ханойской башни
static void TowerOfHanoiWithCount(int n, char from, char to, char aux, ref int moveCount)
{
    if (n == 1)
    {
        Console.WriteLine($"Move disk 1 from {from} to {to}");
        moveCount++;
        return;
    }

    TowerOfHanoiWithCount(n - 1, from, aux, to, ref moveCount);
    Console.WriteLine($"Move disk {n} from {from} to {to}");
    moveCount++;
    TowerOfHanoiWithCount(n - 1, aux, to, from, ref moveCount);
}

// Пример использования:
// int count = 0;
// TowerOfHanoiWithCount(3, 'A', 'C', 'B', ref count);

// Задача 127: Напишите рекурсивный метод для вычисления суммы цифр числа
static int SumDigitsTailRecursive(int number, int sum = 0)
{
    if (number == 0) return sum;
    return SumDigitsTailRecursive(number / 10, sum + number % 10);
}

// Пример использования:
// int sum = SumDigitsTailRecursive(1234); // 10

// Задача 128: Напишите рекурсивную функцию для генерации всех подмножеств множества
static List<List<char>> GenerateSubsetsChar(char[] chars)
{
    var result = new List<List<char>>();
    GenerateSubsetsCharHelper(chars, 0, new List<char>(), result);
    return result;
}

static void GenerateSubsetsCharHelper(char[] chars, int index, List<char> current, List<List<char>> result)
{
    if (index == chars.Length)
    {
        result.Add(new List<char>(current));
        return;
    }

    GenerateSubsetsCharHelper(chars, index + 1, current, result);
    current.Add(chars[index]);
    GenerateSubsetsCharHelper(chars, index + 1, current, result);
    current.RemoveAt(current.Count - 1);
}

// Пример использования:
// var subsets = GenerateSubsetsChar(new char[] {'a', 'b', 'c'});

// Задача 129: Реализуйте рекурсивный метод для вычисления факториала числа
static long Factorial(int n)
{
    if (n < 0) throw new ArgumentException("Факториал отрицательного числа не определен");
    if (n == 0 || n == 1) return 1;
    return n * Factorial(n - 1);
}

// Пример использования:
// long fact = Factorial(5); // 120

// Задача 130: Реализуйте рекурсивную функцию для вычисления степени числа
static double PowerRecursiveFast(double baseNum, int exponent)
{
    if (exponent == 0) return 1;
    if (exponent < 0) return 1 / PowerRecursiveFast(baseNum, -exponent);

    double half = PowerRecursiveFast(baseNum, exponent / 2);
    if (exponent % 2 == 0)
        return half * half;
    else
        return baseNum * half * half;
}

// Пример использования:
// double result = PowerRecursiveFast(2, 10); // 1024

// Задача 131: Напишите рекурсивную функцию для генерации всех подмножеств множества
static List<string> GenerateAllSubsets(string elements)
{
    var result = new List<string>();
    GenerateAllSubsetsHelper(elements, 0, "", result);
    return result;
}

static void GenerateAllSubsetsHelper(string elements, int index, string current, List<string> result)
{
    if (index == elements.Length)
    {
        result.Add(current);
        return;
    }

    GenerateAllSubsetsHelper(elements, index + 1, current, result);
    GenerateAllSubsetsHelper(elements, index + 1, current + elements[index], result);
}

// Пример использования:
// var allSubsets = GenerateAllSubsets("123");

// Задача 132: Напишите рекурсивный метод для вычисления суммы цифр числа
static int SumDigitsSingleLine(int number)
{
    return number == 0 ? 0 : number % 10 + SumDigitsSingleLine(number / 10);
}

// Пример использования:
// int sum = SumDigitsSingleLine(456); // 15

// Задача 133: Создайте рекурсивный метод для обхода массива и вывода его элементов
static void PrintArrayRecursive(int[] array, int index = 0)
{
    if (index >= array.Length) return;
    Console.WriteLine(array[index]);
    PrintArrayRecursive(array, index + 1);
}

// Пример использования:
// PrintArrayRecursive(new int[] {1, 2, 3, 4, 5});

// Задача 134: Реализуйте рекурсивную функцию для вычисления степени числа
static int PowerIntRecursive(int baseNum, int exponent)
{
    if (exponent == 0) return 1;
    if (exponent < 0) throw new ArgumentException("Отрицательная степень не поддерживается");
    return baseNum * PowerIntRecursive(baseNum, exponent - 1);
}

// Пример использования:
// int result = PowerIntRecursive(3, 4); // 81

// Задача 135: Реализуйте рекурсивную функцию Аккермана
static int Ackermann(int m, int n)
{
    if (m == 0) return n + 1;
    if (n == 0) return Ackermann(m - 1, 1);
    return Ackermann(m - 1, Ackermann(m, n - 1));
}

// Пример использования:
// int result = Ackermann(2, 3); // 9

// Задача 136: Создайте рекурсивную функцию для вычисления произведения элементов массива
static double ProductArrayDouble(double[] array)
{
    return ProductArrayDoubleHelper(array, 0);
}

static double ProductArrayDoubleHelper(double[] array, int index)
{
    if (index >= array.Length) return 1.0;
    return array[index] * ProductArrayDoubleHelper(array, index + 1);
}

// Пример использования:
// double product = ProductArrayDouble(new double[] {1.5, 2.0, 3.0}); // 9.0

// Задача 137: Напишите рекурсивную функцию для реверса строки
static string ReverseStringRecursiveTail(string str, string reversed = "")
{
    if (string.IsNullOrEmpty(str)) return reversed;
    return ReverseStringRecursiveTail(str.Substring(0, str.Length - 1), reversed + str[str.Length - 1]);
}

// Пример использования:
// string reversed = ReverseStringRecursiveTail("hello"); // "olleh"

// Задача 138: Напишите рекурсивный метод для преобразования числа в двоичную систему
static string DecimalToBinaryOptimized(int number)
{
    if (number < 0) return "-" + DecimalToBinaryOptimized(-number);
    if (number == 0) return "0";
    if (number == 1) return "1";

    return DecimalToBinaryOptimized(number >> 1) + (number & 1);
}

// Пример использования:
// string binary = DecimalToBinaryOptimized(15); // "1111"

// Задача 139: Реализуйте рекурсивный метод для вычисления факториала числа
static long FactorialTailRecursive(int n, long accumulator = 1)
{
    if (n < 0) throw new ArgumentException("Факториал отрицательного числа не определен");
    if (n == 0) return accumulator;
    return FactorialTailRecursive(n - 1, accumulator * n);
}

// Пример использования:
// long fact = FactorialTailRecursive(6); // 720

// Задача 140: Напишите рекурсивный метод для вычисления суммы цифр числа
static int SumDigitsWithValidation(int number)
{
    if (number < 0) return SumDigitsWithValidation(-number);
    if (number < 10) return number;
    return number % 10 + SumDigitsWithValidation(number / 10);
}

// Пример использования:
// int sum = SumDigitsWithValidation(-123); // 6

// Задача 141: Создайте рекурсивный метод для решения задачи Ханойской башни
static List<string> TowerOfHanoiList(int n, char from, char to, char aux)
{
    var moves = new List<string>();
    TowerOfHanoiListHelper(n, from, to, aux, moves);
    return moves;
}

static void TowerOfHanoiListHelper(int n, char from, char to, char aux, List<string> moves)
{
    if (n == 1)
    {
        moves.Add($"Move disk 1 from {from} to {to}");
        return;
    }

    TowerOfHanoiListHelper(n - 1, from, aux, to, moves);
    moves.Add($"Move disk {n} from {from} to {to}");
    TowerOfHanoiListHelper(n - 1, aux, to, from, moves);
}

// Пример использования:
// var moves = TowerOfHanoiList(3, 'A', 'C', 'B');

// Задача 142: Напишите рекурсивную функцию для реверса строки
static string ReverseStringRecursiveIndex(string str, int index = 0)
{
    if (index >= str.Length) return "";
    return ReverseStringRecursiveIndex(str, index + 1) + str[index];
}

// Пример использования:
// string reversed = ReverseStringRecursiveIndex("world"); // "dlrow"

// Задача 143: Создайте рекурсивный метод для решения задачи Ханойской башни
static void TowerOfHanoiWithValidation(int n, char from, char to, char aux)
{
    if (n <= 0) throw new ArgumentException("Количество дисков должно быть положительным");
    if (n == 1)
    {
        Console.WriteLine($"Move disk 1 from {from} to {to}");
        return;
    }

    TowerOfHanoiWithValidation(n - 1, from, aux, to);
    Console.WriteLine($"Move disk {n} from {from} to {to}");
    TowerOfHanoiWithValidation(n - 1, aux, to, from);
}

// Пример использования:
// TowerOfHanoiWithValidation(2, 'A', 'C', 'B');

// Задача 144: Реализуйте рекурсивную функцию для вычисления степени числа
static decimal PowerDecimalRecursive(decimal baseNum, int exponent)
{
    if (exponent == 0) return 1;
    if (exponent < 0) return 1 / PowerDecimalRecursive(baseNum, -exponent);
    return baseNum * PowerDecimalRecursive(baseNum, exponent - 1);
}

// Пример использования:
// decimal result = PowerDecimalRecursive(2.5m, 3); // 15.625

// Задача 145: Реализуйте рекурсивную функцию Аккермана
static long AckermannLong(long m, long n)
{
    if (m == 0) return n + 1;
    if (n == 0) return AckermannLong(m - 1, 1);
    return AckermannLong(m - 1, AckermannLong(m, n - 1));
}

// Пример использования:
// long result = AckermannLong(3, 1); // 13

// Задача 146: Создайте рекурсивный метод для решения задачи Ханойской башни
static int TowerOfHanoiMoveCount(int n)
{
    if (n <= 0) return 0;
    if (n == 1) return 1;
    return 2 * TowerOfHanoiMoveCount(n - 1) + 1;
}

// Пример использования:
// int moves = TowerOfHanoiMoveCount(4); // 15

// Задача 147: Создайте рекурсивную функцию для проверки вхождения подстроки в строку
static bool ContainsSubstringRecursive(string str, string substring, int startIndex = 0)
{
    if (startIndex + substring.Length > str.Length) return false;
    if (str.Substring(startIndex, substring.Length) == substring) return true;
    return ContainsSubstringRecursive(str, substring, startIndex + 1);
}

// Пример использования:
// bool contains = ContainsSubstringRecursive("programming", "gram"); // true

// Задача 148: Реализуйте рекурсивный метод для подсчета количества цифр в числе
static int CountDigits(int number)
{
    if (number < 0) return CountDigits(-number);
    if (number < 10) return 1;
    return 1 + CountDigits(number / 10);
}

// Пример использования:
// int digits = CountDigits(12345); // 5

// Задача 149: Создайте рекурсивный метод для нахождения НОД двух чисел
static int GCDRecursiveWithValidation(int a, int b)
{
    if (b == 0) return Math.Abs(a);
    return GCDRecursiveWithValidation(b, a % b);
}

// Пример использования:
// int gcd = GCDRecursiveWithValidation(0, 5); // 5

// Задача 150: Напишите рекурсивную функцию для поиска максимума в массиве
static int FindMaxRecursiveSimple(int[] array, int index = 0)
{
    if (index == array.Length - 1) return array[index];
    return Math.Max(array[index], FindMaxRecursiveSimple(array, index + 1));
}

// Пример использования:
// int max = FindMaxRecursiveSimple(new int[] {3, 7, 2, 9, 1}); // 9


// Задача 151: Напишите рекурсивную функцию для реверса строки
static string ReverseStringRecursiveMiddle(string str)
{
    if (string.IsNullOrEmpty(str) || str.Length == 1) return str;

    int mid = str.Length / 2;
    string left = str.Substring(0, mid);
    string right = str.Substring(mid);

    return ReverseStringRecursiveMiddle(right) + ReverseStringRecursiveMiddle(left);
}

// Пример использования:
// string reversed = ReverseStringRecursiveMiddle("hello"); // "olleh"

// Задача 152: Напишите рекурсивную функцию для генерации всех подмножеств множества
static List<List<int>> GenerateSubsetsWithSum(int[] nums, int targetSum)
{
    var result = new List<List<int>>();
    GenerateSubsetsWithSumHelper(nums, 0, new List<int>(), 0, targetSum, result);
    return result;
}

static void GenerateSubsetsWithSumHelper(int[] nums, int index, List<int> current, int currentSum, int targetSum, List<List<int>> result)
{
    if (index == nums.Length)
    {
        if (currentSum == targetSum && current.Count > 0)
            result.Add(new List<int>(current));
        return;
    }

    // Не включаем текущий элемент
    GenerateSubsetsWithSumHelper(nums, index + 1, current, currentSum, targetSum, result);

    // Включаем текущий элемент
    current.Add(nums[index]);
    GenerateSubsetsWithSumHelper(nums, index + 1, current, currentSum + nums[index], targetSum, result);
    current.RemoveAt(current.Count - 1);
}

// Пример использования:
// var subsets = GenerateSubsetsWithSum(new int[] {2, 3, 5, 7}, 10);

// Задача 153: Создайте рекурсивный метод для решения задачи Ханойской башни
static void TowerOfHanoiWithSteps(int n, string from, string to, string aux, int step = 1)
{
    if (n == 1)
    {
        Console.WriteLine($"Шаг {step}: Переместить диск 1 с {from} на {to}");
        return;
    }

    TowerOfHanoiWithSteps(n - 1, from, aux, to, step);
    Console.WriteLine($"Шаг {step + (1 << (n - 1)) - 1}: Переместить диск {n} с {from} на {to}");
    TowerOfHanoiWithSteps(n - 1, aux, to, from, step + (1 << (n - 1)));
}

// Пример использования:
// TowerOfHanoiWithSteps(3, "Стержень A", "Стержень C", "Стержень B");

// Задача 154: Реализуйте рекурсивный метод для вычисления факториала числа
static BigInteger FactorialBig(int n)
{
    if (n < 0) throw new ArgumentException("Факториал отрицательного числа не определен");
    if (n == 0 || n == 1) return 1;
    return n * FactorialBig(n - 1);
}

// Пример использования:
// BigInteger fact = FactorialBig(20); // 2432902008176640000

// Задача 155: Создайте рекурсивную функцию для проверки вхождения подстроки в строку
static int CountSubstringOccurrences(string str, string substring, int startIndex = 0)
{
    if (startIndex + substring.Length > str.Length) return 0;

    int count = 0;
    if (str.Substring(startIndex, substring.Length) == substring)
        count = 1;

    return count + CountSubstringOccurrences(str, substring, startIndex + 1);
}

// Пример использования:
// int count = CountSubstringOccurrences("ababab", "ab"); // 3

// Задача 156: Создайте рекурсивный метод для обхода массива и вывода его элементов
static void PrintArrayReverseRecursive(int[] array, int index = 0)
{
    if (index >= array.Length) return;
    PrintArrayReverseRecursive(array, index + 1);
    Console.WriteLine(array[index]);
}

// Пример использования:
// PrintArrayReverseRecursive(new int[] {1, 2, 3, 4});

// Задача 157: Реализуйте рекурсивную функцию для вычисления треугольника Паскаля
static void PrintPascalTriangle(int rows, int currentRow = 0)
{
    if (currentRow >= rows) return;

    for (int i = 0; i <= currentRow; i++)
    {
        Console.Write(PascalTriangle(currentRow, i) + " ");
    }
    Console.WriteLine();

    PrintPascalTriangle(rows, currentRow + 1);
}

// Пример использования:
// PrintPascalTriangle(5);

// Задача 158: Реализуйте рекурсивный метод для вычисления факториала числа
static double FactorialDouble(int n)
{
    if (n < 0) throw new ArgumentException("Факториал отрицательного числа не определен");
    if (n == 0 || n == 1) return 1.0;
    return n * FactorialDouble(n - 1);
}

// Пример использования:
// double fact = FactorialDouble(10); // 3628800.0

// Задача 159: Реализуйте рекурсивную функцию для вычисления степени числа
static long PowerLongRecursive(long baseNum, int exponent)
{
    if (exponent == 0) return 1;
    if (exponent < 0) throw new ArgumentException("Отрицательная степень не поддерживается");
    return baseNum * PowerLongRecursive(baseNum, exponent - 1);
}

// Пример использования:
// long result = PowerLongRecursive(2, 10); // 1024

// Задача 160: Напишите рекурсивную функцию для поиска максимума в массиве
static double FindMaxRecursive(double[] array, int index = 0)
{
    if (index == array.Length - 1) return array[index];
    return Math.Max(array[index], FindMaxRecursive(array, index + 1));
}

// Пример использования:
// double max = FindMaxRecursive(new double[] {1.5, 3.2, 2.7, 4.1}); // 4.1

// Задача 161: Реализуйте рекурсивную функцию Аккермана
static int AckermannWithMemo(int m, int n, Dictionary<string, int> memo = null)
{
    memo = memo ?? new Dictionary<string, int>();
    string key = $"{m},{n}";

    if (memo.ContainsKey(key)) return memo[key];

    int result;
    if (m == 0)
        result = n + 1;
    else if (n == 0)
        result = AckermannWithMemo(m - 1, 1, memo);
    else
        result = AckermannWithMemo(m - 1, AckermannWithMemo(m, n - 1, memo), memo);

    memo[key] = result;
    return result;
}

// Пример использования:
// int result = AckermannWithMemo(3, 2); // 29

// Задача 162: Создайте рекурсивную функцию для проверки, является ли строка палиндромом
static bool IsPalindromeRecursiveWithSpaces(string str)
{
    return IsPalindromeRecursiveWithSpacesHelper(str, 0, str.Length - 1);
}

static bool IsPalindromeRecursiveWithSpacesHelper(string str, int left, int right)
{
    while (left < right && !char.IsLetterOrDigit(str[left])) left++;
    while (left < right && !char.IsLetterOrDigit(str[right])) right--;

    if (left >= right) return true;
    if (char.ToLower(str[left]) != char.ToLower(str[right])) return false;

    return IsPalindromeRecursiveWithSpacesHelper(str, left + 1, right - 1);
}

// Пример использования:
// bool result = IsPalindromeRecursiveWithSpaces("A man, a plan, a canal: Panama"); // true

// Задача 163: Создайте рекурсивную функцию для вычисления чисел Фибоначчи
static long FibonacciMemo(int n, Dictionary<int, long> memo = null)
{
    memo = memo ?? new Dictionary<int, long>();
    if (memo.ContainsKey(n)) return memo[n];

    if (n <= 1) return n;

    long result = FibonacciMemo(n - 1, memo) + FibonacciMemo(n - 2, memo);
    memo[n] = result;
    return result;
}

// Пример использования:
// long fib = FibonacciMemo(50); // 12586269025

// Задача 164: Создайте рекурсивную функцию для проверки, является ли строка палиндромом
static bool IsPalindromeNumberRecursive(int number)
{
    return IsPalindromeNumberRecursiveHelper(number.ToString(), 0, number.ToString().Length - 1);
}

static bool IsPalindromeNumberRecursiveHelper(string str, int left, int right)
{
    if (left >= right) return true;
    if (str[left] != str[right]) return false;
    return IsPalindromeNumberRecursiveHelper(str, left + 1, right - 1);
}

// Пример использования:
// bool result = IsPalindromeNumberRecursive(12321); // true

// Задача 165: Реализуйте рекурсивный метод для вычисления биномиального коэффициента
static long BinomialCoefficientLong(int n, int k)
{
    if (k == 0 || k == n) return 1;
    return BinomialCoefficientLong(n - 1, k - 1) + BinomialCoefficientLong(n - 1, k);
}

// Пример использования:
// long coefficient = BinomialCoefficientLong(10, 3); // 120

// Задача 166: Напишите рекурсивный метод для вычисления суммы чисел от 1 до N
static decimal SumToNDecimal(int n)
{
    if (n <= 0) return 0;
    return n + SumToNDecimal(n - 1);
}

// Пример использования:
// decimal sum = SumToNDecimal(100); // 5050

// Задача 167: Напишите рекурсивный метод для вычисления суммы чисел от 1 до N
static int SumRange(int start, int end)
{
    if (start > end) return 0;
    if (start == end) return start;
    return start + SumRange(start + 1, end);
}

// Пример использования:
// int sum = SumRange(5, 10); // 45

// Задача 168: Реализуйте рекурсивную функцию для вычисления треугольника Паскаля
static int[] PascalTriangleRow(int row)
{
    if (row == 0) return new int[] { 1 };
    if (row == 1) return new int[] { 1, 1 };

    int[] previousRow = PascalTriangleRow(row - 1);
    int[] currentRow = new int[row + 1];
    currentRow[0] = 1;
    currentRow[row] = 1;

    for (int i = 1; i < row; i++)
    {
        currentRow[i] = previousRow[i - 1] + previousRow[i];
    }

    return currentRow;
}

// Пример использования:
// int[] row = PascalTriangleRow(4); // [1, 4, 6, 4, 1]

// Задача 169: Напишите рекурсивный метод для вычисления суммы чисел от 1 до N
static int SumToNWithValidation(int n)
{
    if (n < 0) throw new ArgumentException("Число должно быть неотрицательным");
    if (n == 0) return 0;
    return n + SumToNWithValidation(n - 1);
}

// Пример использования:
// int sum = SumToNWithValidation(7); // 28

// Задача 170: Напишите рекурсивную функцию для генерации всех подмножеств множества
static List<List<T>> GenerateSubsetsGeneric<T>(T[] elements)
{
    var result = new List<List<T>>();
    GenerateSubsetsGenericHelper(elements, 0, new List<T>(), result);
    return result;
}

static void GenerateSubsetsGenericHelper<T>(T[] elements, int index, List<T> current, List<List<T>> result)
{
    if (index == elements.Length)
    {
        result.Add(new List<T>(current));
        return;
    }

    GenerateSubsetsGenericHelper(elements, index + 1, current, result);
    current.Add(elements[index]);
    GenerateSubsetsGenericHelper(elements, index + 1, current, result);
    current.RemoveAt(current.Count - 1);
}

// Пример использования:
// var subsets = GenerateSubsetsGeneric(new string[] {"x", "y", "z"});

// Задача 171: Создайте рекурсивный метод для нахождения НОД двух чисел
static int GCDRecursiveThree(int a, int b, int c)
{
    return GCDRecursive(GCDRecursive(a, b), c);
}

// Пример использования:
// int gcd = GCDRecursiveThree(12, 18, 24); // 6

// Задача 172: Создайте рекурсивный метод для нахождения НОД двух чисел
static int LCMRecursive(int a, int b)
{
    return Math.Abs(a * b) / GCDRecursive(a, b);
}

// Пример использования:
// int lcm = LCMRecursive(12, 18); // 36

// Задача 173: Реализуйте рекурсивную функцию для вычисления треугольника Паскаля
static void PrintPascalTriangleFormatted(int rows, int currentRow = 0)
{
    if (currentRow >= rows) return;

    // Отступ для центрирования
    Console.Write(new string(' ', (rows - currentRow - 1) * 2));

    for (int i = 0; i <= currentRow; i++)
    {
        Console.Write($"{PascalTriangle(currentRow, i),4}");
    }
    Console.WriteLine();

    PrintPascalTriangleFormatted(rows, currentRow + 1);
}

// Пример использования:
// PrintPascalTriangleFormatted(6);

// Задача 174: Напишите рекурсивную функцию для генерации всех подмножеств множества
static List<List<int>> GenerateSubsetsWithLength(int[] nums, int length)
{
    var result = new List<List<int>>();
    GenerateSubsetsWithLengthHelper(nums, 0, new List<int>(), length, result);
    return result;
}

static void GenerateSubsetsWithLengthHelper(int[] nums, int index, List<int> current, int length, List<List<int>> result)
{
    if (current.Count == length)
    {
        result.Add(new List<int>(current));
        return;
    }

    if (index >= nums.Length) return;

    // Включаем текущий элемент
    current.Add(nums[index]);
    GenerateSubsetsWithLengthHelper(nums, index + 1, current, length, result);
    current.RemoveAt(current.Count - 1);

    // Не включаем текущий элемент
    GenerateSubsetsWithLengthHelper(nums, index + 1, current, length, result);
}

// Пример использования:
// var subsets = GenerateSubsetsWithLength(new int[] {1, 2, 3, 4}, 2);

// Задача 175: Напишите рекурсивную функцию для реверса строки
static string ReverseStringRecursiveSplit(string str)
{
    if (string.IsNullOrEmpty(str) || str.Length == 1) return str;

    int mid = str.Length / 2;
    string firstHalf = str.Substring(0, mid);
    string secondHalf = str.Substring(mid);

    return ReverseStringRecursiveSplit(secondHalf) + ReverseStringRecursiveSplit(firstHalf);
}

// Пример использования:
// string reversed = ReverseStringRecursiveSplit("abcdef"); // "fedcba"

// Задача 176: Напишите рекурсивный метод для вычисления суммы цифр числа
static int SumDigitsRecursive(long number)
{
    if (number < 0) return SumDigitsRecursive(-number);
    if (number < 10) return (int)number;
    return (int)(number % 10) + SumDigitsRecursive(number / 10);
}

// Пример использования:
// int sum = SumDigitsRecursive(123456789L); // 45

// Задача 177: Создайте рекурсивный метод для решения задачи Ханойской башни
static int TowerOfHanoiMinimumMoves(int n)
{
    if (n <= 0) return 0;
    if (n == 1) return 1;
    return 2 * TowerOfHanoiMinimumMoves(n - 1) + 1;
}

// Пример использования:
// int moves = TowerOfHanoiMinimumMoves(5); // 31

// Задача 178: Создайте рекурсивную функцию для проверки вхождения подстроки в строку
static bool StartsWithRecursive(string str, string prefix, int index = 0)
{
    if (index >= prefix.Length) return true;
    if (index >= str.Length) return false;
    if (str[index] != prefix[index]) return false;
    return StartsWithRecursive(str, prefix, index + 1);
}

// Пример использования:
// bool startsWith = StartsWithRecursive("hello world", "hello"); // true

// Задача 179: Создайте рекурсивную функцию для вычисления произведения элементов массива
static decimal ProductArrayDecimal(decimal[] array, int index = 0)
{
    if (index >= array.Length) return 1;
    return array[index] * ProductArrayDecimal(array, index + 1);
}

// Пример использования:
// decimal product = ProductArrayDecimal(new decimal[] {1.1m, 2.2m, 3.3m}); // 7.986

// Задача 180: Реализуйте рекурсивный метод для подсчета количества цифр в числе
static int CountDigitsLong(long number)
{
    if (number < 0) return CountDigitsLong(-number);
    if (number < 10) return 1;
    return 1 + CountDigitsLong(number / 10);
}

// Пример использования:
// int digits = CountDigitsLong(123456789012345L); // 15

// Задача 181: Напишите рекурсивную функцию для генерации всех подмножеств множества
static List<List<int>> GenerateSubsetsNonEmpty(int[] nums)
{
    var result = new List<List<int>>();
    GenerateSubsetsNonEmptyHelper(nums, 0, new List<int>(), result);
    return result.Where(subset => subset.Count > 0).ToList();
}

static void GenerateSubsetsNonEmptyHelper(int[] nums, int index, List<int> current, List<List<int>> result)
{
    if (index == nums.Length)
    {
        result.Add(new List<int>(current));
        return;
    }

    GenerateSubsetsNonEmptyHelper(nums, index + 1, current, result);
    current.Add(nums[index]);
    GenerateSubsetsNonEmptyHelper(nums, index + 1, current, result);
    current.RemoveAt(current.Count - 1);
}

// Пример использования:
// var subsets = GenerateSubsetsNonEmpty(new int[] {1, 2, 3});

// Задача 182: Реализуйте рекурсивный метод для подсчета количества цифр в числе
static int CountDigitsBinary(int number)
{
    if (number < 0) return CountDigitsBinary(-number);
    if (number == 0) return 1;
    if (number == 1) return 1;
    return 1 + CountDigitsBinary(number >> 1);
}

// Пример использования:
// int digits = CountDigitsBinary(15); // 4 (1111 в двоичной)

// Задача 183: Реализуйте рекурсивную функцию Аккермана
static void PrintAckermannValues(int maxM, int maxN)
{
    for (int m = 0; m <= maxM; m++)
    {
        for (int n = 0; n <= maxN; n++)
        {
            try
            {
                int value = Ackermann(m, n);
                Console.WriteLine($"A({m},{n}) = {value}");
            }
            catch (StackOverflowException)
            {
                Console.WriteLine($"A({m},{n}) = слишком большое значение");
            }
        }
    }
}

// Пример использования:
// PrintAckermannValues(3, 3);

// Задача 184: Реализуйте рекурсивный метод для проверки отсортированности массива
static bool IsSortedStrictlyIncreasing(int[] array, int index = 0)
{
    if (index >= array.Length - 1) return true;
    if (array[index] >= array[index + 1]) return false;
    return IsSortedStrictlyIncreasing(array, index + 1);
}

// Пример использования:
// bool sorted = IsSortedStrictlyIncreasing(new int[] {1, 2, 3, 4}); // true

// Задача 185: Напишите рекурсивную функцию для поиска максимума в массиве
static int FindMaxRecursiveParams(params int[] numbers)
{
    return FindMaxRecursiveParamsHelper(numbers, 0);
}

static int FindMaxRecursiveParamsHelper(int[] numbers, int index)
{
    if (index == numbers.Length - 1) return numbers[index];
    return Math.Max(numbers[index], FindMaxRecursiveParamsHelper(numbers, index + 1));
}

// Пример использования:
// int max = FindMaxRecursiveParams(3, 7, 2, 9, 1, 8); // 9

// Задача 186: Напишите рекурсивный метод для преобразования числа в двоичную систему
static string DecimalToHexadecimal(int number)
{
    if (number < 0) return "-" + DecimalToHexadecimal(-number);
    if (number < 10) return number.ToString();
    if (number < 16) return ((char)('A' + number - 10)).ToString();

    int remainder = number % 16;
    string digit = remainder < 10 ? remainder.ToString() : ((char)('A' + remainder - 10)).ToString();
    return DecimalToHexadecimal(number / 16) + digit;
}

// Пример использования:
// string hex = DecimalToHexadecimal(255); // "FF"

// Задача 187: Создайте рекурсивный метод для решения задачи Ханойской башни
static void TowerOfHanoiInteractive(int n, string from, string to, string aux)
{
    if (n == 1)
    {
        Console.WriteLine($"Переместите диск 1 с {from} на {to}");
        Console.ReadLine();
        return;
    }

    TowerOfHanoiInteractive(n - 1, from, aux, to);
    Console.WriteLine($"Переместите диск {n} с {from} на {to}");
    Console.ReadLine();
    TowerOfHanoiInteractive(n - 1, aux, to, from);
}

// Пример использования:
// TowerOfHanoiInteractive(3, "A", "C", "B");

// Задача 188: Напишите рекурсивный метод для преобразования числа в двоичную систему
static string DecimalToOctal(int number)
{
    if (number < 0) return "-" + DecimalToOctal(-number);
    if (number < 8) return number.ToString();
    return DecimalToOctal(number / 8) + (number % 8).ToString();
}

// Пример использования:
// string octal = DecimalToOctal(100); // "144"

// Задача 189: Реализуйте рекурсивную функцию для вычисления степени числа
static double PowerRecursiveWithPrecision(double baseNum, int exponent, double precision = 1e-10)
{
    if (exponent == 0) return 1;
    if (Math.Abs(baseNum) < precision) return 0;
    if (exponent < 0) return 1 / PowerRecursiveWithPrecision(baseNum, -exponent, precision);
    return baseNum * PowerRecursiveWithPrecision(baseNum, exponent - 1, precision);
}

// Пример использования:
// double result = PowerRecursiveWithPrecision(2.5, 3); // 15.625

// Задача 190: Создайте рекурсивную функцию для проверки, является ли строка палиндромом
static bool IsPalindromeRecursiveIgnoreCase(string str)
{
    return IsPalindromeRecursiveIgnoreCaseHelper(str, 0, str.Length - 1);
}

static bool IsPalindromeRecursiveIgnoreCaseHelper(string str, int left, int right)
{
    if (left >= right) return true;
    if (char.ToLower(str[left]) != char.ToLower(str[right])) return false;
    return IsPalindromeRecursiveIgnoreCaseHelper(str, left + 1, right - 1);
}

// Пример использования:
// bool result = IsPalindromeRecursiveIgnoreCase("RaceCar"); // true

// Задача 191: Создайте рекурсивную функцию для проверки, является ли строка палиндромом
static bool IsPalindromeRecursiveWords(string sentence)
{
    string clean = new string(sentence.ToLower().Where(char.IsLetter).ToArray());
    return IsPalindromeRecursive(clean);
}

// Пример использования:
// bool result = IsPalindromeRecursiveWords("A man a plan a canal Panama"); // true

// Задача 192: Напишите рекурсивный метод для вычисления суммы чисел от 1 до N
static double SumToNDouble(double n)
{
    if (n <= 0) return 0;
    return n + SumToNDouble(n - 1);
}

// Пример использования:
// double sum = SumToNDouble(5.5); // 16.5

// Задача 193: Создайте рекурсивный метод для обхода массива и вывода его элементов
static void PrintArrayRecursiveWithIndex(int[] array, int index = 0)
{
    if (index >= array.Length) return;
    Console.WriteLine($"array[{index}] = {array[index]}");
    PrintArrayRecursiveWithIndex(array, index + 1);
}

// Пример использования:
// PrintArrayRecursiveWithIndex(new int[] {10, 20, 30, 40});

// Задача 194: Реализуйте рекурсивный метод для вычисления факториала числа
static int FactorialInt(int n)
{
    if (n < 0) throw new ArgumentException("Факториал отрицательного числа не определен");
    if (n == 0 || n == 1) return 1;
    return n * FactorialInt(n - 1);
}

// Пример использования:
// int fact = FactorialInt(7); // 5040

// Задача 195: Реализуйте рекурсивный метод для вычисления биномиального коэффициента
static decimal BinomialCoefficientDecimal(int n, int k)
{
    if (k == 0 || k == n) return 1;
    return BinomialCoefficientDecimal(n - 1, k - 1) + BinomialCoefficientDecimal(n - 1, k);
}

// Пример использования:
// decimal coefficient = BinomialCoefficientDecimal(8, 4); // 70

// Задача 196: Напишите рекурсивную функцию для генерации всех подмножеств множества
static List<string> GenerateBinaryStrings(int length)
{
    var result = new List<string>();
    GenerateBinaryStringsHelper(length, "", result);
    return result;
}

static void GenerateBinaryStringsHelper(int length, string current, List<string> result)
{
    if (current.Length == length)
    {
        result.Add(current);
        return;
    }

    GenerateBinaryStringsHelper(length, current + "0", result);
    GenerateBinaryStringsHelper(length, current + "1", result);
}

// Пример использования:
// var binaryStrings = GenerateBinaryStrings(3); // ["000", "001", "010", ...]

// Задача 197: Создайте рекурсивную функцию для проверки, является ли строка палиндромом
static bool IsPalindromeRecursiveWithNumbers(string str)
{
    string clean = new string(str.ToLower().Where(char.IsLetterOrDigit).ToArray());
    return IsPalindromeRecursive(clean);
}

// Пример использования:
// bool result = IsPalindromeRecursiveWithNumbers("A1b2b1a"); // true

// Задача 198: Реализуйте рекурсивный метод для вычисления биномиального коэффициента
static double BinomialCoefficientDouble(int n, int k)
{
    if (k == 0 || k == n) return 1;
    return BinomialCoefficientDouble(n - 1, k - 1) + BinomialCoefficientDouble(n - 1, k);
}

// Пример использования:
// double coefficient = BinomialCoefficientDouble(7, 3); // 35

// Задача 199: Создайте рекурсивную функцию для проверки, является ли строка палиндромом
static bool IsPalindromeRecursiveSentence(string sentence)
{
    string clean = new string(sentence.Where(char.IsLetterOrDigit).ToArray()).ToLower();
    return IsPalindromeRecursive(clean);
}

// Пример использования:
// bool result = IsPalindromeRecursiveSentence("Madam, I'm Adam"); // true

// Задача 200: Реализуйте рекурсивный метод для вычисления факториала числа
static ulong FactorialUlong(int n)
{
    if (n < 0) throw new ArgumentException("Факториал отрицательного числа не определен");
    if (n == 0 || n == 1) return 1;
    return (ulong)n * FactorialUlong(n - 1);
}

// Пример использования:
// ulong fact = FactorialUlong(10); // 3628800

// Задача 201: Напишите перегруженные методы для вывода информации разных типов
static void PrintInfo(int value)
{
    Console.WriteLine($"Целое число: {value}");
}

static void PrintInfo(double value)
{
    Console.WriteLine($"Дробное число: {value}");
}

static void PrintInfo(string value)
{
    Console.WriteLine($"Строка: {value}");
}

static void PrintInfo(bool value)
{
    Console.WriteLine($"Логическое значение: {value}");
}

// Пример использования:
// PrintInfo(10);
// PrintInfo(3.14);
// PrintInfo("Hello");
// PrintInfo(true);

// Задача 202: Реализуйте перегрузку метода для вычисления площади (круг, прямоугольник)
static double CalculateArea(double radius)
{
    return Math.PI * radius * radius;
}

static double CalculateArea(double width, double height)
{
    return width * height;
}

static double CalculateArea(double baseLength, double height, string shape)
{
    if (shape.ToLower() == "triangle")
        return 0.5 * baseLength * height;
    throw new ArgumentException("Неизвестная фигура");
}

// Пример использования:
// double circleArea = CalculateArea(5.0);
// double rectangleArea = CalculateArea(4.0, 6.0);
// double triangleArea = CalculateArea(4.0, 6.0, "triangle");

// Задача 203: Реализуйте перегрузку метода для умножения (int, double, decimal)
static int Multiply(int a, int b)
{
    return a * b;
}

static double Multiply(double a, double b)
{
    return a * b;
}

static decimal Multiply(decimal a, decimal b)
{
    return a * b;
}

static double Multiply(int a, double b)
{
    return a * b;
}

static double Multiply(double a, int b)
{
    return a * b;
}

// Пример использования:
// int result1 = Multiply(3, 4);
// double result2 = Multiply(2.5, 3.0);
// decimal result3 = Multiply(1.5m, 2.0m);

// Задача 204: Напишите перегруженные методы для вывода информации разных типов
static void Display(int number)
{
    Console.WriteLine($"Число: {number}");
}

static void Display(string text)
{
    Console.WriteLine($"Текст: {text}");
}

static void Display(int[] array)
{
    Console.WriteLine($"Массив: [{string.Join(", ", array)}]");
}

static void Display(char symbol, int count)
{
    Console.WriteLine(new string(symbol, count));
}

// Пример использования:
// Display(42);
// Display("Hello World");
// Display(new int[] {1, 2, 3});
// Display('*', 10);

// Задача 205: Реализуйте перегрузку метода для вычисления площади (круг, прямоугольник)
static double GetArea(double side)
{
    return side * side; // квадрат
}

static double GetArea(double length, double width)
{
    return length * width; // прямоугольник
}

static double GetArea(double radius, string circle)
{
    if (circle.ToLower() == "circle")
        return Math.PI * radius * radius;
    throw new ArgumentException("Неизвестная фигура");
}

// Пример использования:
// double squareArea = GetArea(5.0);
// double rectangleArea = GetArea(4.0, 6.0);
// double circleArea = GetArea(3.0, "circle");

// Задача 206: Реализуйте перегруженные методы для вычисления расстояния (2D, 3D точки)
static double CalculateDistance(double x1, double y1, double x2, double y2)
{
    return Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
}

static double CalculateDistance(double x1, double y1, double z1, double x2, double y2, double z2)
{
    return Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2) + Math.Pow(z2 - z1, 2));
}

// Пример использования:
// double distance2D = CalculateDistance(0, 0, 3, 4);
// double distance3D = CalculateDistance(0, 0, 0, 3, 4, 5);

// Задача 207: Напишите перегруженные методы для вывода информации разных типов
static void Show(object value)
{
    Console.WriteLine($"Объект: {value} (тип: {value.GetType()})");
}

static void Show(int value)
{
    Console.WriteLine($"Целое число: {value}");
}

static void Show(double value)
{
    Console.WriteLine($"Дробное число: {value:F2}");
}

static void Show(string value, bool uppercase = false)
{
    if (uppercase)
        Console.WriteLine($"Строка: {value.ToUpper()}");
    else
        Console.WriteLine($"Строка: {value}");
}

// Пример использования:
// Show(123);
// Show(45.6789);
// Show("hello");
// Show("hello", true);

// Задача 208: Реализуйте перегруженные методы для работы с коллекциями (добавление элементов)
static void AddToList(List<int> list, int value)
{
    list.Add(value);
}

static void AddToList(List<int> list, params int[] values)
{
    list.AddRange(values);
}

static void AddToList(List<string> list, string value)
{
    list.Add(value);
}

static void AddToList(List<string> list, params string[] values)
{
    list.AddRange(values);
}

// Пример использования:
// List<int> numbers = new List<int>();
// AddToList(numbers, 1);
// AddToList(numbers, 2, 3, 4, 5);

// Задача 209: Реализуйте перегрузку метода для умножения (int, double, decimal)
static int Multiply(params int[] numbers)
{
    int result = 1;
    foreach (int num in numbers)
        result *= num;
    return result;
}

static double Multiply(params double[] numbers)
{
    double result = 1.0;
    foreach (double num in numbers)
        result *= num;
    return result;
}

// Пример использования:
// int product1 = Multiply(2, 3, 4);
// double product2 = Multiply(1.5, 2.0, 3.0);

// Задача 210: Напишите перегруженные методы для форматирования даты разными способами
static string FormatDate(DateTime date)
{
    return date.ToString("yyyy-MM-dd");
}

static string FormatDate(DateTime date, string format)
{
    return date.ToString(format);
}

static string FormatDate(int year, int month, int day)
{
    return new DateTime(year, month, day).ToString("yyyy-MM-dd");
}

static string FormatDate(int year, int month, int day, string format)
{
    return new DateTime(year, month, day).ToString(format);
}

// Пример использования:
// string date1 = FormatDate(DateTime.Now);
// string date2 = FormatDate(DateTime.Now, "dd/MM/yyyy");
// string date3 = FormatDate(2024, 12, 25);
// string date4 = FormatDate(2024, 12, 25, "MMMM dd, yyyy");

// Задача 211: Создайте перегрузку метода для вычисления скидки (процент, фиксированная сумма)
static decimal CalculateDiscount(decimal price, decimal discountPercentage)
{
    return price * (1 - discountPercentage / 100);
}

static decimal CalculateDiscount(decimal price, decimal discountAmount, bool isFixed)
{
    if (isFixed)
        return price - discountAmount;
    throw new ArgumentException("Для процентной скидки используйте другую перегрузку");
}

// Пример использования:
// decimal price1 = CalculateDiscount(1000, 10); // 10% скидка
// decimal price2 = CalculateDiscount(1000, 100, true); // фиксированная скидка 100

// Задача 212: Создайте перегруженные методы для работы с массивами разных типов
static void PrintArray(int[] array)
{
    Console.WriteLine($"int[]: [{string.Join(", ", array)}]");
}

static void PrintArray(double[] array)
{
    Console.WriteLine($"double[]: [{string.Join(", ", array)}]");
}

static void PrintArray(string[] array)
{
    Console.WriteLine($"string[]: [{string.Join(", ", array)}]");
}

static void PrintArray(char[] array)
{
    Console.WriteLine($"char[]: [{string.Join(", ", array)}]");
}

// Пример использования:
// PrintArray(new int[] {1, 2, 3});
// PrintArray(new double[] {1.1, 2.2, 3.3});
// PrintArray(new string[] {"a", "b", "c"});
// PrintArray(new char[] {'x', 'y', 'z'});

// Задача 213: Напишите перегрузку метода для валидации данных (email, телефон, URL)
static bool Validate(string email)
{
    return email.Contains("@") && email.Contains(".");
}

static bool Validate(string phone, bool isPhone)
{
    if (isPhone)
        return phone.Length >= 10 && phone.All(char.IsDigit);
    return false;
}

static bool Validate(string url, string type)
{
    if (type.ToLower() == "url")
        return url.StartsWith("http://") || url.StartsWith("https://");
    return false;
}

// Пример использования:
// bool validEmail = Validate("test@example.com");
// bool validPhone = Validate("1234567890", true);
// bool validUrl = Validate("https://example.com", "url");

// Задача 214: Реализуйте перегруженные методы для конкатенации строк (2, 3, 4 строки)
static string Concatenate(string str1, string str2)
{
    return str1 + str2;
}

static string Concatenate(string str1, string str2, string str3)
{
    return str1 + str2 + str3;
}

static string Concatenate(string str1, string str2, string str3, string str4)
{
    return str1 + str2 + str3 + str4;
}

static string Concatenate(params string[] strings)
{
    return string.Concat(strings);
}

// Пример использования:
// string result1 = Concatenate("Hello", "World");
// string result2 = Concatenate("C#", " ", "Programming");
// string result3 = Concatenate("a", "b", "c", "d");
// string result4 = Concatenate("1", "2", "3", "4", "5");

// Задача 215: Создайте перегруженные методы для шифрования текста разными алгоритмами
static string Encrypt(string text)
{
    // Простой шифр Цезаря
    char[] chars = text.ToCharArray();
    for (int i = 0; i < chars.Length; i++)
    {
        if (char.IsLetter(chars[i]))
        {
            char offset = char.IsUpper(chars[i]) ? 'A' : 'a';
            chars[i] = (char)(((chars[i] - offset + 3) % 26) + offset);
        }
    }
    return new string(chars);
}

static string Encrypt(string text, int shift)
{
    // Шифр Цезаря с заданным сдвигом
    char[] chars = text.ToCharArray();
    for (int i = 0; i < chars.Length; i++)
    {
        if (char.IsLetter(chars[i]))
        {
            char offset = char.IsUpper(chars[i]) ? 'A' : 'a';
            chars[i] = (char)(((chars[i] - offset + shift) % 26) + offset);
        }
    }
    return new string(chars);
}

static string Encrypt(string text, string algorithm)
{
    if (algorithm.ToLower() == "reverse")
        return new string(text.Reverse().ToArray());
    else if (algorithm.ToLower() == "uppercase")
        return text.ToUpper();
    return text;
}

// Пример использования:
// string encrypted1 = Encrypt("hello");
// string encrypted2 = Encrypt("hello", 5);
// string encrypted3 = Encrypt("hello", "reverse");

// Задача 216: Создайте перегруженные методы для шифрования текста разными алгоритмами
static string Decrypt(string text)
{
    return Encrypt(text, -3); // обратный сдвиг для Caesar
}

static string Decrypt(string text, int shift)
{
    return Encrypt(text, -shift); // обратный сдвиг
}

static string Decrypt(string text, string algorithm)
{
    if (algorithm.ToLower() == "reverse")
        return new string(text.Reverse().ToArray());
    else if (algorithm.ToLower() == "uppercase")
        return text.ToLower();
    return text;
}

// Пример использования:
// string decrypted1 = Decrypt("khoor");
// string decrypted2 = Decrypt("mjqqt", 5);
// string decrypted3 = Decrypt("olleh", "reverse");

// Задача 217: Создайте перегрузку метода для вычисления скидки (процент, фиксированная сумма)
static decimal ApplyDiscount(decimal price, int discountPercent)
{
    return price * (100 - discountPercent) / 100;
}

static decimal ApplyDiscount(decimal price, decimal discountAmount)
{
    return Math.Max(0, price - discountAmount);
}

static decimal ApplyDiscount(decimal price, string couponCode)
{
    var couponDiscounts = new Dictionary<string, decimal>
    {
        {"SAVE10", 10},
        {"SAVE20", 20},
        {"HALF", 50}
    };

    if (couponDiscounts.ContainsKey(couponCode.ToUpper()))
        return price * (100 - couponDiscounts[couponCode.ToUpper()]) / 100;

    return price;
}

// Пример использования:
// decimal price1 = ApplyDiscount(100, 10);
// decimal price2 = ApplyDiscount(100, 25);
// decimal price3 = ApplyDiscount(100, "SAVE20");

// Задача 218: Реализуйте перегрузку метода для умножения (int, double, decimal)
static decimal Multiply(decimal a, int b)
{
    return a * b;
}

static decimal Multiply(int a, decimal b)
{
    return a * b;
}

static float Multiply(float a, float b)
{
    return a * b;
}

// Пример использования:
// decimal result1 = Multiply(2.5m, 3);
// decimal result2 = Multiply(4, 1.5m);
// float result3 = Multiply(2.5f, 3.0f);

// Задача 219: Создайте перегрузку метода для вычисления скидки (процент, фиксированная сумма)
static double CalculateFinalPrice(double price, double discountRate)
{
    return price * (1 - discountRate / 100);
}

static double CalculateFinalPrice(double price, double discountAmount, string type)
{
    if (type.ToLower() == "fixed")
        return price - discountAmount;
    else if (type.ToLower() == "percentage")
        return price * (1 - discountAmount / 100);
    return price;
}

// Пример использования:
// double final1 = CalculateFinalPrice(100, 10);
// double final2 = CalculateFinalPrice(100, 15, "fixed");
// double final3 = CalculateFinalPrice(100, 20, "percentage");

// Задача 220: Реализуйте перегрузку метода для вычисления периметра разных фигур
static double CalculatePerimeter(double side)
{
    return 4 * side; // квадрат
}

static double CalculatePerimeter(double length, double width)
{
    return 2 * (length + width); // прямоугольник
}

static double CalculatePerimeter(double radius, string circle)
{
    if (circle.ToLower() == "circle")
        return 2 * Math.PI * radius;
    throw new ArgumentException("Неизвестная фигура");
}

static double CalculatePerimeter(double a, double b, double c)
{
    return a + b + c; // треугольник
}

// Пример использования:
// double squarePerim = CalculatePerimeter(5);
// double rectPerim = CalculatePerimeter(4, 6);
// double circlePerim = CalculatePerimeter(3, "circle");
// double trianglePerim = CalculatePerimeter(3, 4, 5);

// Задача 221: Создайте перегруженные методы для работы с массивами разных типов
static T[] CreateArray<T>(T element, int length)
{
    T[] array = new T[length];
    for (int i = 0; i < length; i++)
        array[i] = element;
    return array;
}

static int[] CreateArray(int defaultValue, int length)
{
    int[] array = new int[length];
    for (int i = 0; i < length; i++)
        array[i] = defaultValue;
    return array;
}

static string[] CreateArray(string defaultValue, int length)
{
    string[] array = new string[length];
    for (int i = 0; i < length; i++)
        array[i] = defaultValue;
    return array;
}

// Пример использования:
// int[] numbers = CreateArray(0, 5);
// string[] texts = CreateArray("default", 3);
// bool[] flags = CreateArray(true, 4);

// Задача 222: Создайте перегрузку метода для поиска максимума (2, 3, 4 числа)
static int FindMax(int a, int b)
{
    return Math.Max(a, b);
}

static int FindMax(int a, int b, int c)
{
    return Math.Max(a, Math.Max(b, c));
}

static int FindMax(int a, int b, int c, int d)
{
    return Math.Max(Math.Max(a, b), Math.Max(c, d));
}

// Пример использования:
// int max1 = FindMax(10, 20);
// int max2 = FindMax(10, 20, 15);
// int max3 = FindMax(10, 20, 15, 25);

// Задача 223: Создайте перегрузку метода для поиска максимума (2, 3, 4 числа)
static double FindMax(double a, double b)
{
    return Math.Max(a, b);
}

static double FindMax(double a, double b, double c)
{
    return Math.Max(a, Math.Max(b, c));
}

static double FindMax(params double[] numbers)
{
    return numbers.Max();
}

// Пример использования:
// double max1 = FindMax(1.5, 2.5);
// double max2 = FindMax(1.5, 2.5, 1.8);
// double max3 = FindMax(1.1, 2.2, 3.3, 0.5, 4.4);

// Задача 224: Реализуйте перегрузку метода для вычисления периметра разных фигур
static decimal CalculatePerimeter(decimal side)
{
    return 4 * side;
}

static decimal CalculatePerimeter(decimal length, decimal width)
{
    return 2 * (length + width);
}

static decimal CalculatePerimeter(decimal a, decimal b, decimal c)
{
    return a + b + c;
}

// Пример использования:
// decimal perim1 = CalculatePerimeter(5m);
// decimal perim2 = CalculatePerimeter(4m, 6m);
// decimal perim3 = CalculatePerimeter(3m, 4m, 5m);

// Задача 225: Напишите перегрузку метода для преобразования температуры (Celsius, Fahrenheit, Kelvin)
static double ConvertTemperature(double celsius)
{
    return celsius * 9 / 5 + 32; // Celsius to Fahrenheit
}

static double ConvertTemperature(double value, string fromUnit, string toUnit)
{
    if (fromUnit.ToLower() == "celsius" && toUnit.ToLower() == "fahrenheit")
        return value * 9 / 5 + 32;
    else if (fromUnit.ToLower() == "fahrenheit" && toUnit.ToLower() == "celsius")
        return (value - 32) * 5 / 9;
    else if (fromUnit.ToLower() == "celsius" && toUnit.ToLower() == "kelvin")
        return value + 273.15;
    else if (fromUnit.ToLower() == "kelvin" && toUnit.ToLower() == "celsius")
        return value - 273.15;
    else if (fromUnit.ToLower() == "fahrenheit" && toUnit.ToLower() == "kelvin")
        return (value - 32) * 5 / 9 + 273.15;
    else if (fromUnit.ToLower() == "kelvin" && toUnit.ToLower() == "fahrenheit")
        return (value - 273.15) * 9 / 5 + 32;

    throw new ArgumentException("Неподдерживаемое преобразование");
}

// Пример использования:
// double fahrenheit = ConvertTemperature(25);
// double celsius = ConvertTemperature(98.6, "fahrenheit", "celsius");
// double kelvin = ConvertTemperature(0, "celsius", "kelvin");

// Задача 226: Реализуйте перегрузку метода для вычисления периметра разных фигур
static double GetPerimeter(double radius)
{
    return 2 * Math.PI * radius; // круг
}

static double GetPerimeter(double side, int sides)
{
    return side * sides; // правильный многоугольник
}

// Пример использования:
// double circlePerim = GetPerimeter(5);
// double hexagonPerim = GetPerimeter(4, 6);

// Задача 227: Реализуйте перегрузку метода для вычисления периметра разных фигур
static float CalculatePerimeter(float side)
{
    return 4 * side;
}

static float CalculatePerimeter(float length, float width)
{
    return 2 * (length + width);
}

// Пример использования:
// float perim1 = CalculatePerimeter(5f);
// float perim2 = CalculatePerimeter(4f, 6f);

// Задача 228: Напишите перегруженные методы для парсинга строк в числа разных типов
static int ParseToNumber(string input)
{
    return int.Parse(input);
}

static double ParseToNumber(string input, bool isDouble)
{
    if (isDouble)
        return double.Parse(input);
    return int.Parse(input);
}

static decimal ParseToNumber(string input, string type)
{
    if (type.ToLower() == "decimal")
        return decimal.Parse(input);
    else if (type.ToLower() == "double")
        return (decimal)double.Parse(input);
    return decimal.Parse(input);
}

// Пример использования:
// int num1 = ParseToNumber("123");
// double num2 = ParseToNumber("123.45", true);
// decimal num3 = ParseToNumber("123.456", "decimal");

// Задача 229: Реализуйте перегрузку метода для вычисления площади (круг, прямоугольник)
static float CalculateArea(float radius)
{
    return (float)(Math.PI * radius * radius);
}

static float CalculateArea(float width, float height)
{
    return width * height;
}

// Пример использования:
// float circleArea = CalculateArea(5f);
// float rectangleArea = CalculateArea(4f, 6f);

// Задача 230: Создайте перегрузку метода для поиска максимума (2, 3, 4 числа)
static decimal FindMax(decimal a, decimal b)
{
    return a > b ? a : b;
}

static decimal FindMax(decimal a, decimal b, decimal c)
{
    return FindMax(FindMax(a, b), c);
}

static decimal FindMax(params decimal[] numbers)
{
    return numbers.Max();
}

// Пример использования:
// decimal max1 = FindMax(1.5m, 2.5m);
// decimal max2 = FindMax(1.5m, 2.5m, 1.8m);
// decimal max3 = FindMax(1.1m, 2.2m, 3.3m, 0.5m);

// Задача 231: Реализуйте перегрузку метода для вычисления площади (круг, прямоугольник)
static decimal CalculateArea(decimal side)
{
    return side * side;
}

static decimal CalculateArea(decimal length, decimal width)
{
    return length * width;
}

// Пример использования:
// decimal squareArea = CalculateArea(5m);
// decimal rectangleArea = CalculateArea(4m, 6m);

// Задача 232: Создайте перегруженные методы для сортировки (по возрастанию/убыванию)
static int[] Sort(int[] array)
{
    int[] sorted = (int[])array.Clone();
    Array.Sort(sorted);
    return sorted;
}

static int[] Sort(int[] array, bool ascending)
{
    int[] sorted = Sort(array);
    if (!ascending)
        Array.Reverse(sorted);
    return sorted;
}

static double[] Sort(double[] array, bool ascending = true)
{
    double[] sorted = (double[])array.Clone();
    Array.Sort(sorted);
    if (!ascending)
        Array.Reverse(sorted);
    return sorted;
}

// Пример использования:
// int[] ascSorted = Sort(new int[] {3, 1, 2});
// int[] descSorted = Sort(new int[] {3, 1, 2}, false);
// double[] numbersSorted = Sort(new double[] {3.1, 1.2, 2.3});

// Задача 233: Реализуйте перегруженные методы для вычисления расстояния (2D, 3D точки)
static float CalculateDistance(float x1, float y1, float x2, float y2)
{
    return (float)Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
}

static float CalculateDistance(float x1, float y1, float z1, float x2, float y2, float z2)
{
    return (float)Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2) + Math.Pow(z2 - z1, 2));
}

// Пример использования:
// float dist2D = CalculateDistance(0f, 0f, 3f, 4f);
// float dist3D = CalculateDistance(0f, 0f, 0f, 3f, 4f, 5f);

// Задача 234: Создайте перегрузку метода для поиска максимума (2, 3, 4 числа)
static string FindMax(string a, string b)
{
    return string.Compare(a, b) > 0 ? a : b;
}

static string FindMax(string a, string b, string c)
{
    return FindMax(FindMax(a, b), c);
}

// Пример использования:
// string maxStr1 = FindMax("apple", "banana");
// string maxStr2 = FindMax("apple", "banana", "cherry");

// Задача 235: Реализуйте перегрузку метода для умножения (int, double, decimal)
static long Multiply(long a, long b)
{
    return a * b;
}

static float Multiply(float a, float b)
{
    return a * b;
}

// Пример использования:
// long result1 = Multiply(1000000L, 2000000L);
// float result2 = Multiply(2.5f, 3.0f);

// Задача 236: Создайте перегруженные методы для работы с массивами разных типов
static void FillArray(int[] array, int value)
{
    for (int i = 0; i < array.Length; i++)
        array[i] = value;
}

static void FillArray(string[] array, string value)
{
    for (int i = 0; i < array.Length; i++)
        array[i] = value;
}

static void FillArray(double[] array, double value)
{
    for (int i = 0; i < array.Length; i++)
        array[i] = value;
}

// Пример использования:
// int[] numbers = new int[3];
// FillArray(numbers, 42);
// string[] texts = new string[2];
// FillArray(texts, "hello");

// Задача 237: Создайте перегруженные методы для работы с массивами разных типов
static T GetFirstElement<T>(T[] array)
{
    return array.Length > 0 ? array[0] : default(T);
}

static int GetFirstElement(int[] array)
{
    return array.Length > 0 ? array[0] : 0;
}

static string GetFirstElement(string[] array)
{
    return array.Length > 0 ? array[0] : "";
}

// Пример использования:
// int firstNum = GetFirstElement(new int[] {1, 2, 3});
// string firstStr = GetFirstElement(new string[] {"a", "b", "c"});
// double firstDouble = GetFirstElement(new double[] {1.1, 2.2, 3.3});

// Задача 238: Напишите перегрузку метода для валидации данных (email, телефон, URL)
static bool IsValid(string input, ValidationType type)
{
    switch (type)
    {
        case ValidationType.Email:
            return input.Contains("@") && input.Contains(".");
        case ValidationType.Phone:
            return input.Length >= 10 && input.All(char.IsDigit);
        case ValidationType.URL:
            return input.StartsWith("http://") || input.StartsWith("https://");
        default:
            return false;
    }
}

enum ValidationType { Email, Phone, URL }

// Пример использования:
// bool valid1 = IsValid("test@example.com", ValidationType.Email);
// bool valid2 = IsValid("1234567890", ValidationType.Phone);
// bool valid3 = IsValid("https://example.com", ValidationType.URL);

// Задача 239: Напишите перегруженные методы для парсинга строк в числа разных типов
static bool TryParseToNumber(string input, out int result)
{
    return int.TryParse(input, out result);
}

static bool TryParseToNumber(string input, out double result)
{
    return double.TryParse(input, out result);
}

static bool TryParseToNumber(string input, out decimal result)
{
    return decimal.TryParse(input, out result);
}

// Пример использования:
// if (TryParseToNumber("123", out int intResult)) { }
// if (TryParseToNumber("123.45", out double doubleResult)) { }
// if (TryParseToNumber("123.456", out decimal decimalResult)) { }

// Задача 240: Реализуйте перегруженные методы для конкатенации строк (2, 3, 4 строки)
static string Combine(string str1, string str2, string separator = "")
{
    return str1 + separator + str2;
}

static string Combine(string str1, string str2, string str3, string separator = "")
{
    return str1 + separator + str2 + separator + str3;
}

static string Combine(string[] strings, string separator = "")
{
    return string.Join(separator, strings);
}

// Пример использования:
// string result1 = Combine("Hello", "World", " ");
// string result2 = Combine("a", "b", "c", "-");
// string result3 = Combine(new string[] {"1", "2", "3"}, ", ");

// Задача 241: Реализуйте перегрузку метода для вычисления периметра разных фигур
static double ComputePerimeter(double sideLength, string shape)
{
    switch (shape.ToLower())
    {
        case "square":
            return 4 * sideLength;
        case "pentagon":
            return 5 * sideLength;
        case "hexagon":
            return 6 * sideLength;
        case "octagon":
            return 8 * sideLength;
        default:
            throw new ArgumentException("Неизвестная фигура");
    }
}

// Пример использования:
// double squarePerim = ComputePerimeter(5, "square");
// double hexagonPerim = ComputePerimeter(4, "hexagon");

// Задача 242: Напишите перегрузку метода для вычисления объема (куб, параллелепипед, цилиндр)
static double CalculateVolume(double side)
{
    return side * side * side; // куб
}

static double CalculateVolume(double length, double width, double height)
{
    return length * width * height; // параллелепипед
}

static double CalculateVolume(double radius, double height, string shape)
{
    if (shape.ToLower() == "cylinder")
        return Math.PI * radius * radius * height; // цилиндр
    throw new ArgumentException("Неизвестная фигура");
}

// Пример использования:
// double cubeVol = CalculateVolume(3);
// double boxVol = CalculateVolume(2, 3, 4);
// double cylinderVol = CalculateVolume(2, 5, "cylinder");

// Задача 243: Напишите перегруженные методы для форматирования даты разными способами
static string GetFormattedDate(DateTime date)
{
    return date.ToString("dd/MM/yyyy");
}

static string GetFormattedDate(DateTime date, bool includeTime)
{
    if (includeTime)
        return date.ToString("dd/MM/yyyy HH:mm:ss");
    return GetFormattedDate(date);
}

static string GetFormattedDate(int day, int month, int year)
{
    return new DateTime(year, month, day).ToString("dd/MM/yyyy");
}

// Пример использования:
// string date1 = GetFormattedDate(DateTime.Now);
// string date2 = GetFormattedDate(DateTime.Now, true);
// string date3 = GetFormattedDate(25, 12, 2024);

// Задача 244: Напишите перегруженные методы для парсинга строк в числа разных типов
static object ParseValue(string input, Type targetType)
{
    if (targetType == typeof(int))
        return int.Parse(input);
    else if (targetType == typeof(double))
        return double.Parse(input);
    else if (targetType == typeof(decimal))
        return decimal.Parse(input);
    else if (targetType == typeof(bool))
        return bool.Parse(input);
    else
        return input;
}

// Пример использования:
// int number = (int)ParseValue("123", typeof(int));
// double value = (double)ParseValue("123.45", typeof(double));

// Задача 245: Реализуйте перегрузку метода для умножения (int, double, decimal)
static decimal Multiply(decimal a, decimal b, decimal c)
{
    return a * b * c;
}

static double Multiply(double a, double b, double c)
{
    return a * b * c;
}

// Пример использования:
// decimal result1 = Multiply(2m, 3m, 4m);
// double result2 = Multiply(2.5, 3.0, 4.0);

// Задача 246: Напишите перегруженные методы для вывода информации разных типов
static void LogInfo(string message)
{
    Console.WriteLine($"[INFO] {DateTime.Now:HH:mm:ss} - {message}");
}

static void LogInfo(string message, LogLevel level)
{
    Console.WriteLine($"[{level}] {DateTime.Now:HH:mm:ss} - {message}");
}

static void LogInfo(string message, string category)
{
    Console.WriteLine($"[{category}] {DateTime.Now:HH:mm:ss} - {message}");
}

enum LogLevel { INFO, WARNING, ERROR }

// Пример использования:
// LogInfo("Application started");
// LogInfo("Warning message", LogLevel.WARNING);
// LogInfo("Database query", "DATABASE");

// Задача 247: Напишите перегруженные методы для парсинга строк в числа разных типов
static Number ParseNumber(string input)
{
    if (int.TryParse(input, out int intValue))
        return new Number { IntValue = intValue, Type = NumberType.Integer };
    else if (double.TryParse(input, out double doubleValue))
        return new Number { DoubleValue = doubleValue, Type = NumberType.Double };
    else if (decimal.TryParse(input, out decimal decimalValue))
        return new Number { DecimalValue = decimalValue, Type = NumberType.Decimal };
    else
        throw new FormatException("Неверный формат числа");
}

class Number
{
    public int IntValue { get; set; }
    public double DoubleValue { get; set; }
    public decimal DecimalValue { get; set; }
    public NumberType Type { get; set; }
}

enum NumberType { Integer, Double, Decimal }

// Пример использования:
// Number num = ParseNumber("123.45");

// Задача 248: Напишите перегрузку метода для валидации данных (email, телефон, URL)
static ValidationResult ValidateInput(string input)
{
    bool isValid = false;
    string type = "unknown";

    if (input.Contains("@") && input.Contains("."))
    {
        isValid = true;
        type = "email";
    }
    else if (input.Length >= 10 && input.All(char.IsDigit))
    {
        isValid = true;
        type = "phone";
    }
    else if (input.StartsWith("http://") || input.StartsWith("https://"))
    {
        isValid = true;
        type = "URL";
    }

    return new ValidationResult { IsValid = isValid, Type = type };
}

class ValidationResult
{
    public bool IsValid { get; set; }
    public string Type { get; set; }
}

// Пример использования:
// ValidationResult result = ValidateInput("test@example.com");

// Задача 249: Создайте перегрузку метода для поиска максимума (2, 3, 4 числа)
static DateTime FindMax(DateTime date1, DateTime date2)
{
    return date1 > date2 ? date1 : date2;
}

static DateTime FindMax(DateTime date1, DateTime date2, DateTime date3)
{
    return FindMax(FindMax(date1, date2), date3);
}

// Пример использования:
// DateTime maxDate = FindMax(new DateTime(2024, 1, 1), new DateTime(2024, 12, 31));

// Задача 250: Реализуйте перегрузку метода для вычисления площади (круг, прямоугольник)
static double ComputeArea(double dimension1, double dimension2 = 0, string shape = "square")
{
    switch (shape.ToLower())
    {
        case "square":
            return dimension1 * dimension1;
        case "rectangle":
            return dimension1 * dimension2;
        case "circle":
            return Math.PI * dimension1 * dimension1;
        case "triangle":
            return 0.5 * dimension1 * dimension2;
        default:
            throw new ArgumentException("Неизвестная фигура");
    }
}

// Пример использования:
// double squareArea = ComputeArea(5);
// double rectArea = ComputeArea(4, 6, "rectangle");
// double circleArea = ComputeArea(3, 0, "circle");


// Задача 251: Напишите перегрузку метода для валидации данных (email, телефон, URL)
static string ValidateInput(string input, out bool isValid)
{
    isValid = false;
    string type = "unknown";

    if (input.Contains("@") && input.Contains("."))
    {
        isValid = true;
        type = "email";
    }
    else if (input.Length >= 10 && input.All(char.IsDigit))
    {
        isValid = true;
        type = "phone";
    }
    else if (input.StartsWith("http://") || input.StartsWith("https://"))
    {
        isValid = true;
        type = "URL";
    }

    return type;
}

// Пример использования:
// string type = ValidateInput("test@example.com", out bool isValid);

// Задача 252: Создайте перегруженные методы для сложения двух и трех чисел
static int Add(int a, int b)
{
    return a + b;
}

static int Add(int a, int b, int c)
{
    return a + b + c;
}

static double Add(double a, double b)
{
    return a + b;
}

static double Add(double a, double b, double c)
{
    return a + b + c;
}

// Пример использования:
// int sum1 = Add(1, 2);
// int sum2 = Add(1, 2, 3);
// double sum3 = Add(1.5, 2.5);
// double sum4 = Add(1.5, 2.5, 3.5);

// Задача 253: Напишите перегруженные методы для вывода информации разных типов
static void Output<T>(T value)
{
    Console.WriteLine($"Значение: {value} (тип: {typeof(T).Name})");
}

static void Output(string label, object value)
{
    Console.WriteLine($"{label}: {value}");
}

static void Output(string message, ConsoleColor color)
{
    Console.ForegroundColor = color;
    Console.WriteLine(message);
    Console.ResetColor();
}

// Пример использования:
// Output(42);
// Output("Цена", 99.99);
// Output("Важное сообщение", ConsoleColor.Red);

// Задача 254: Реализуйте перегрузку метода для умножения (int, double, decimal)
static decimal Multiply(decimal a, decimal b, decimal c, decimal d)
{
    return a * b * c * d;
}

static int Multiply(params int[] factors)
{
    int result = 1;
    foreach (int factor in factors)
        result *= factor;
    return result;
}

// Пример использования:
// decimal product1 = Multiply(1m, 2m, 3m, 4m);
// int product2 = Multiply(2, 3, 4, 5);

// Задача 255: Напишите перегрузку метода для вычисления объема (куб, параллелепипед, цилиндр)
static float CalculateVolume(float side)
{
    return side * side * side;
}

static float CalculateVolume(float length, float width, float height)
{
    return length * width * height;
}

static float CalculateVolume(float radius, float height)
{
    return (float)(Math.PI * radius * radius * height);
}

// Пример использования:
// float cubeVol = CalculateVolume(3f);
// float boxVol = CalculateVolume(2f, 3f, 4f);
// float cylinderVol = CalculateVolume(2f, 5f);

// Задача 256: Реализуйте перегрузку метода для вычисления периметра разных фигур
static double GetPerimeter(double a, double b, double c, double d)
{
    return a + b + c + d; // четырехугольник
}

static double GetPerimeter(params double[] sides)
{
    return sides.Sum();
}

// Пример использования:
// double quadPerim = GetPerimeter(2, 3, 4, 5);
// double pentagonPerim = GetPerimeter(1, 2, 3, 4, 5);

// Задача 257: Создайте перегрузку метода для вычисления скидки (процент, фиксированная сумма)
static decimal CalculateDiscount(decimal price, int discountPercent, decimal maxDiscount)
{
    decimal discountAmount = price * discountPercent / 100;
    return price - Math.Min(discountAmount, maxDiscount);
}

static decimal CalculateDiscount(decimal price, decimal discountAmount, decimal minPurchase)
{
    if (price >= minPurchase)
        return price - discountAmount;
    return price;
}

// Пример использования:
// decimal price1 = CalculateDiscount(1000, 20, 150);
// decimal price2 = CalculateDiscount(500, 50, 300);

// Задача 258: Создайте перегрузку метода для вычисления скидки (процент, фиксированная сумма)
static double ApplyDiscount(double price, double discount, bool isPercentage = true)
{
    if (isPercentage)
        return price * (1 - discount / 100);
    else
        return Math.Max(0, price - discount);
}

// Пример использования:
// double price1 = ApplyDiscount(100, 10); // 10% скидка
// double price2 = ApplyDiscount(100, 15, false); // фиксированная скидка 15

// Задача 259: Создайте перегруженные методы для работы с массивами разных типов
static int FindIndex(int[] array, int value)
{
    return Array.IndexOf(array, value);
}

static int FindIndex(string[] array, string value)
{
    return Array.IndexOf(array, value);
}

static int FindIndex(double[] array, double value)
{
    return Array.IndexOf(array, value);
}

// Пример использования:
// int index1 = FindIndex(new int[] {1, 2, 3}, 2);
// int index2 = FindIndex(new string[] {"a", "b", "c"}, "b");

// Задача 260: Создайте перегруженные методы для сортировки (по возрастанию/убыванию)
static void SortArray(int[] array, Comparison<int> comparison)
{
    Array.Sort(array, comparison);
}

static void SortArray(string[] array, StringComparison comparison)
{
    Array.Sort(array, comparison);
}

// Пример использования:
// int[] numbers = {3, 1, 2};
// SortArray(numbers, (a, b) => a.CompareTo(b));
// string[] words = {"banana", "apple", "cherry"};
// SortArray(words, StringComparison.Ordinal);

// Задача 261: Реализуйте перегрузку метода для вычисления площади (круг, прямоугольник)
static double CalculateSurfaceArea(double radius)
{
    return 4 * Math.PI * radius * radius; // сфера
}

static double CalculateSurfaceArea(double length, double width, double height)
{
    return 2 * (length * width + length * height + width * height); // прямоугольный параллелепипед
}

// Пример использования:
// double sphereArea = CalculateSurfaceArea(3);
// double boxArea = CalculateSurfaceArea(2, 3, 4);

// Задача 262: Напишите перегрузку метода для вычисления объема (куб, параллелепипед, цилиндр)
static decimal CalculateVolume(decimal side)
{
    return side * side * side;
}

static decimal CalculateVolume(decimal length, decimal width, decimal height)
{
    return length * width * height;
}

static decimal CalculateVolume(decimal radius, decimal height, string shape)
{
    if (shape.ToLower() == "cylinder")
        return (decimal)Math.PI * radius * radius * height;
    throw new ArgumentException("Неизвестная фигура");
}

// Пример использования:
// decimal cubeVol = CalculateVolume(3m);
// decimal boxVol = CalculateVolume(2m, 3m, 4m);
// decimal cylinderVol = CalculateVolume(2m, 5m, "cylinder");

// Задача 263: Создайте перегруженные методы для сортировки (по возрастанию/убыванию)
static List<int> SortList(List<int> list)
{
    return list.OrderBy(x => x).ToList();
}

static List<int> SortList(List<int> list, bool descending)
{
    return descending ? list.OrderByDescending(x => x).ToList() : SortList(list);
}

static List<string> SortList(List<string> list, StringComparer comparer)
{
    return list.OrderBy(x => x, comparer).ToList();
}

// Пример использования:
// List<int> sorted1 = SortList(new List<int> {3, 1, 2});
// List<int> sorted2 = SortList(new List<int> {3, 1, 2}, true);
// List<string> sorted3 = SortList(new List<string> {"B", "A", "C"}, StringComparer.OrdinalIgnoreCase);

// Задача 264: Создайте перегруженные методы для сложения двух и трех чисел
static string Add(string a, string b)
{
    return a + b;
}

static string Add(string a, string b, string c)
{
    return a + b + c;
}

static DateTime Add(DateTime date, TimeSpan time)
{
    return date + time;
}

// Пример использования:
// string text1 = Add("Hello", "World");
// string text2 = Add("C#", " ", "Programming");
// DateTime newDate = Add(DateTime.Now, TimeSpan.FromDays(7));

// Задача 265: Создайте перегруженные методы для сортировки (по возрастанию/убыванию)
static T[] GenericSort<T>(T[] array) where T : IComparable<T>
{
    T[] sorted = (T[])array.Clone();
    Array.Sort(sorted);
    return sorted;
}

static T[] GenericSort<T>(T[] array, bool descending) where T : IComparable<T>
{
    T[] sorted = GenericSort(array);
    if (descending)
        Array.Reverse(sorted);
    return sorted;
}

// Пример использования:
// int[] sortedNumbers = GenericSort(new int[] {3, 1, 2});
// string[] sortedStrings = GenericSort(new string[] {"banana", "apple", "cherry"});

// Задача 266: Напишите перегруженные методы для форматирования даты разными способами
static string FormatDateTime(DateTime dateTime)
{
    return dateTime.ToString("g");
}

static string FormatDateTime(DateTime dateTime, bool dateOnly)
{
    return dateOnly ? dateTime.ToString("d") : FormatDateTime(dateTime);
}

static string FormatDateTime(DateTime dateTime, string culture)
{
    var cultureInfo = new System.Globalization.CultureInfo(culture);
    return dateTime.ToString(cultureInfo);
}

// Пример использования:
// string format1 = FormatDateTime(DateTime.Now);
// string format2 = FormatDateTime(DateTime.Now, true);
// string format3 = FormatDateTime(DateTime.Now, "en-US");

// Задача 267: Напишите перегруженные методы для парсинга строк в числа разных типов
static T ParseGeneric<T>(string input) where T : IParsable<T>
{
    return T.Parse(input, null);
}

static bool TryParseGeneric<T>(string input, out T result) where T : IParsable<T>
{
    return T.TryParse(input, null, out result);
}

// Пример использования:
// int number = ParseGeneric<int>("123");
// double value = ParseGeneric<double>("123.45");

// Задача 268: Создайте перегрузку метода для поиска элемента (массив, список)
static bool Contains(int[] array, int value)
{
    return array.Contains(value);
}

static bool Contains(List<int> list, int value)
{
    return list.Contains(value);
}

static bool Contains(string[] array, string value, StringComparison comparison)
{
    return array.Any(x => x.Equals(value, comparison));
}

// Пример использования:
// bool found1 = Contains(new int[] {1, 2, 3}, 2);
// bool found2 = Contains(new List<int> {1, 2, 3}, 2);
// bool found3 = Contains(new string[] {"apple", "banana"}, "APPLE", StringComparison.OrdinalIgnoreCase);

// Задача 269: Реализуйте перегрузку метода для вычисления периметра разных фигур
static double CalculatePerimeter(double side, int numberOfSides)
{
    return side * numberOfSides;
}

static double CalculatePerimeter(double majorAxis, double minorAxis, bool isEllipse)
{
    if (isEllipse)
        return Math.PI * (3 * (majorAxis + minorAxis) - Math.Sqrt((3 * majorAxis + minorAxis) * (majorAxis + 3 * minorAxis)));
    throw new ArgumentException("Только для эллипса");
}

// Пример использования:
// double pentagonPerim = CalculatePerimeter(4, 5);
// double ellipsePerim = CalculatePerimeter(5, 3, true);

// Задача 270: Напишите перегрузку метода для валидации данных (email, телефон, URL)
static void ValidateAndPrint(string input)
{
    if (input.Contains("@") && input.Contains("."))
        Console.WriteLine($"Valid email: {input}");
    else if (input.Length >= 10 && input.All(char.IsDigit))
        Console.WriteLine($"Valid phone: {input}");
    else if (input.StartsWith("http://") || input.StartsWith("https://"))
        Console.WriteLine($"Valid URL: {input}");
    else
        Console.WriteLine($"Invalid input: {input}");
}

// Пример использования:
// ValidateAndPrint("test@example.com");
// ValidateAndPrint("1234567890");

// Задача 271: Создайте перегрузку метода для вычисления скидки (процент, фиксированная сумма)
static decimal CalculateFinalPrice(decimal price, decimal taxRate, decimal discountPercent)
{
    decimal discountedPrice = price * (1 - discountPercent / 100);
    return discountedPrice * (1 + taxRate / 100);
}

static decimal CalculateFinalPrice(decimal price, decimal taxRate, decimal discountAmount, bool isFixed)
{
    if (isFixed)
    {
        decimal discountedPrice = Math.Max(0, price - discountAmount);
        return discountedPrice * (1 + taxRate / 100);
    }
    return CalculateFinalPrice(price, taxRate, discountAmount);
}

// Пример использования:
// decimal price1 = CalculateFinalPrice(100, 10, 20); // 20% скидка + 10% налог
// decimal price2 = CalculateFinalPrice(100, 10, 15, true); // фиксированная скидка 15 + 10% налог

// Задача 272: Реализуйте перегруженные методы для конкатенации строк (2, 3, 4 строки)
static string Join(string separator, params string[] values)
{
    return string.Join(separator, values);
}

static string Join(char separator, params string[] values)
{
    return string.Join(separator, values);
}

static string Join(string separator, params object[] values)
{
    return string.Join(separator, values);
}

// Пример использования:
// string result1 = Join(", ", "apple", "banana", "cherry");
// string result2 = Join('-', "2024", "12", "25");
// string result3 = Join(" | ", 1, 2.5, "text", true);

// Задача 273: Создайте перегруженные методы для работы с массивами разных типов
static void ReverseArray(int[] array)
{
    Array.Reverse(array);
}

static void ReverseArray(string[] array)
{
    Array.Reverse(array);
}

static void ReverseArray<T>(T[] array)
{
    Array.Reverse(array);
}

// Пример использования:
// int[] numbers = {1, 2, 3};
// ReverseArray(numbers);
// string[] words = {"a", "b", "c"};
// ReverseArray(words);

// Задача 274: Создайте перегрузку метода для поиска элемента (массив, список)
static int FindIndex<T>(T[] array, T value) where T : IEquatable<T>
{
    for (int i = 0; i < array.Length; i++)
        if (array[i].Equals(value))
            return i;
    return -1;
}

static int FindIndex<T>(List<T> list, T value) where T : IEquatable<T>
{
    return list.IndexOf(value);
}

// Пример использования:
// int index1 = FindIndex(new int[] {1, 2, 3}, 2);
// int index2 = FindIndex(new List<string> {"a", "b", "c"}, "b");

// Задача 275: Создайте перегруженные методы для работы с массивами разных типов
static void InitializeArray(int[] array, int defaultValue)
{
    for (int i = 0; i < array.Length; i++)
        array[i] = defaultValue;
}

static void InitializeArray(double[] array, double defaultValue)
{
    for (int i = 0; i < array.Length; i++)
        array[i] = defaultValue;
}

static void InitializeArray(bool[] array, bool defaultValue)
{
    for (int i = 0; i < array.Length; i++)
        array[i] = defaultValue;
}

// Пример использования:
// int[] numbers = new int[5];
// InitializeArray(numbers, -1);
// bool[] flags = new bool[3];
// InitializeArray(flags, true);

// Задача 276: Реализуйте перегрузку метода для вычисления площади (круг, прямоугольник)
static double CalculateArea(double baseLength, double height, bool isTriangle)
{
    if (isTriangle)
        return 0.5 * baseLength * height;
    return baseLength * height;
}

// Пример использования:
// double triangleArea = CalculateArea(4, 6, true);
// double rectangleArea = CalculateArea(4, 6, false);

// Задача 277: Создайте перегруженные методы для шифрования текста разными алгоритмами
static string TransformText(string text, TextTransformation transformation)
{
    switch (transformation)
    {
        case TextTransformation.UpperCase:
            return text.ToUpper();
        case TextTransformation.LowerCase:
            return text.ToLower();
        case TextTransformation.Reverse:
            return new string(text.Reverse().ToArray());
        case TextTransformation.TitleCase:
            return System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(text);
        default:
            return text;
    }
}

enum TextTransformation { UpperCase, LowerCase, Reverse, TitleCase }

// Пример использования:
// string result1 = TransformText("hello", TextTransformation.UpperCase);
// string result2 = TransformText("HELLO", TextTransformation.LowerCase);

// Задача 278: Напишите перегрузку метода для валидации данных (email, телефон, URL)
static (bool isValid, string message) ValidateWithMessage(string input, string type)
{
    bool isValid = false;
    string message = "";

    switch (type.ToLower())
    {
        case "email":
            isValid = input.Contains("@") && input.Contains(".");
            message = isValid ? "Valid email" : "Invalid email format";
            break;
        case "phone":
            isValid = input.Length >= 10 && input.All(char.IsDigit);
            message = isValid ? "Valid phone" : "Invalid phone format";
            break;
        case "url":
            isValid = input.StartsWith("http://") || input.StartsWith("https://");
            message = isValid ? "Valid URL" : "Invalid URL format";
            break;
        default:
            message = "Unknown validation type";
            break;
    }

    return (isValid, message);
}

// Пример использования:
// var result = ValidateWithMessage("test@example.com", "email");

// Задача 279: Реализуйте перегрузку метода для вычисления площади (круг, прямоугольник)
static decimal CalculateArea(decimal dimension1, decimal dimension2, string shape)
{
    switch (shape.ToLower())
    {
        case "rectangle":
            return dimension1 * dimension2;
        case "triangle":
            return 0.5m * dimension1 * dimension2;
        case "circle":
            return (decimal)Math.PI * dimension1 * dimension1;
        default:
            throw new ArgumentException("Неизвестная фигура");
    }
}

// Пример использования:
// decimal rectArea = CalculateArea(4m, 6m, "rectangle");
// decimal triangleArea = CalculateArea(4m, 6m, "triangle");

// Задача 280: Реализуйте перегруженные методы для вычисления расстояния (2D, 3D точки)
static double CalculateDistance(Point2D p1, Point2D p2)
{
    return Math.Sqrt(Math.Pow(p2.X - p1.X, 2) + Math.Pow(p2.Y - p1.Y, 2));
}

static double CalculateDistance(Point3D p1, Point3D p2)
{
    return Math.Sqrt(Math.Pow(p2.X - p1.X, 2) + Math.Pow(p2.Y - p1.Y, 2) + Math.Pow(p2.Z - p1.Z, 2));
}

class Point2D { public double X, Y; }
class Point3D { public double X, Y, Z; }

// Пример использования:
// double dist2D = CalculateDistance(new Point2D { X = 0, Y = 0 }, new Point2D { X = 3, Y = 4 });
// double dist3D = CalculateDistance(new Point3D { X = 0, Y = 0, Z = 0 }, new Point3D { X = 3, Y = 4, Z = 5 });

// Задача 281: Реализуйте перегрузку метода для вычисления площади (круг, прямоугольник)
static double ComputeArea(double side)
{
    return side * side; // квадрат
}

static double ComputeArea(double length, double width)
{
    return length * width; // прямоугольник
}

static double ComputeArea(double radius, bool isCircle)
{
    if (isCircle)
        return Math.PI * radius * radius;
    throw new ArgumentException("Только для круга");
}

// Пример использования:
// double squareArea = ComputeArea(5);
// double rectangleArea = ComputeArea(4, 6);
// double circleArea = ComputeArea(3, true);

// Задача 282: Реализуйте перегрузку метода для вычисления площади (круг, прямоугольник)
static float GetArea(float side)
{
    return side * side;
}

static float GetArea(float length, float width)
{
    return length * width;
}

static float GetArea(float radius, string shape)
{
    if (shape.ToLower() == "circle")
        return (float)(Math.PI * radius * radius);
    throw new ArgumentException("Неизвестная фигура");
}

// Пример использования:
// float squareArea = GetArea(5f);
// float rectangleArea = GetArea(4f, 6f);
// float circleArea = GetArea(3f, "circle");

// Задача 283: Создайте перегруженные методы для шифрования текста разными алгоритмами
static byte[] Encrypt(string text, Encoding encoding)
{
    return encoding.GetBytes(text);
}

static string Encrypt(string text, int key, CryptoAlgorithm algorithm)
{
    switch (algorithm)
    {
        case CryptoAlgorithm.XOR:
            char[] chars = text.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
                chars[i] = (char)(chars[i] ^ key);
            return new string(chars);
        case CryptoAlgorithm.Caesar:
            return Encrypt(text, key); // используем существующий метод Caesar
        default:
            return text;
    }
}

enum CryptoAlgorithm { XOR, Caesar }

// Пример использования:
// byte[] encrypted1 = Encrypt("hello", Encoding.UTF8);
// string encrypted2 = Encrypt("hello", 42, CryptoAlgorithm.XOR);

// Задача 284: Создайте перегрузку метода для вычисления скидки (процент, фиксированная сумма)
static decimal CalculateDiscountedPrice(decimal price, Discount discount)
{
    return discount.Apply(price);
}

class Discount
{
    public decimal Value { get; set; }
    public bool IsPercentage { get; set; }

    public decimal Apply(decimal price)
    {
        if (IsPercentage)
            return price * (1 - Value / 100);
        else
            return Math.Max(0, price - Value);
    }
}

// Пример использования:
// decimal price = CalculateDiscountedPrice(100, new Discount { Value = 10, IsPercentage = true });

// Задача 285: Реализуйте перегруженные методы для работы с коллекциями (добавление элементов)
static void AddRange<T>(List<T> list, IEnumerable<T> collection)
{
    list.AddRange(collection);
}

static void AddRange<T>(HashSet<T> set, IEnumerable<T> collection)
{
    set.UnionWith(collection);
}

static void AddRange<TKey, TValue>(Dictionary<TKey, TValue> dictionary, IEnumerable<KeyValuePair<TKey, TValue>> pairs)
{
    foreach (var pair in pairs)
        dictionary[pair.Key] = pair.Value;
}

// Пример использования:
// List<int> numbers = new List<int>();
// AddRange(numbers, new int[] {1, 2, 3});
// HashSet<string> set = new HashSet<string>();
// AddRange(set, new string[] {"a", "b", "c"});

// Задача 286: Реализуйте перегруженные методы для работы с коллекциями (добавление элементов)
static void InsertAt<T>(List<T> list, int index, T item)
{
    list.Insert(index, item);
}

static void InsertAt<T>(T[] array, int index, T item)
{
    if (index >= 0 && index < array.Length)
        array[index] = item;
}

// Пример использования:
// List<string> list = new List<string> {"a", "c"};
// InsertAt(list, 1, "b");
// string[] array = new string[3];
// InsertAt(array, 0, "first");

// Задача 287: Напишите перегрузку метода для вычисления объема (куб, параллелепипед, цилиндр)
static double CalculateVolume(double radius)
{
    return (4.0 / 3.0) * Math.PI * Math.Pow(radius, 3); // сфера
}

static double CalculateVolume(double baseRadius, double height, double slantHeight)
{
    return (1.0 / 3.0) * Math.PI * baseRadius * baseRadius * height; // конус
}

// Пример использования:
// double sphereVol = CalculateVolume(3);
// double coneVol = CalculateVolume(2, 5, 5.385);

// Задача 288: Реализуйте перегрузку метода для вычисления площади (круг, прямоугольник)
static double CalculateSurfaceArea(double side)
{
    return 6 * side * side; // куб
}

static double CalculateSurfaceArea(double radius, double height)
{
    return 2 * Math.PI * radius * (radius + height); // цилиндр
}

// Пример использования:
// double cubeSurface = CalculateSurfaceArea(3);
// double cylinderSurface = CalculateSurfaceArea(2, 5);

// Задача 289: Реализуйте перегруженные методы для работы с коллекциями (добавление элементов)
static void RemoveAll<T>(List<T> list, Predicate<T> match)
{
    list.RemoveAll(match);
}

static void RemoveAll<T>(HashSet<T> set, Predicate<T> match)
{
    set.RemoveWhere(match);
}

// Пример использования:
// List<int> numbers = new List<int> {1, 2, 3, 4, 5};
// RemoveAll(numbers, x => x % 2 == 0);
// HashSet<string> words = new HashSet<string> {"apple", "banana", "cherry"};
// RemoveAll(words, x => x.StartsWith("a"));

// Задача 290: Напишите перегруженные методы для вывода информации разных типов
static void Print<T>(T value)
{
    Console.WriteLine($"Value: {value}");
}

static void Print<T>(string label, T value)
{
    Console.WriteLine($"{label}: {value}");
}

static void Print<T>(IEnumerable<T> collection)
{
    Console.WriteLine($"[{string.Join(", ", collection)}]");
}

// Пример использования:
// Print(42);
// Print("Age", 25);
// Print(new int[] {1, 2, 3});

// Задача 291: Напишите перегрузку метода для вычисления объема (куб, параллелепипед, цилиндр)
static decimal ComputeVolume(decimal side)
{
    return side * side * side;
}

static decimal ComputeVolume(decimal length, decimal width, decimal height)
{
    return length * width * height;
}

static decimal ComputeVolume(decimal radius, decimal height)
{
    return (decimal)Math.PI * radius * radius * height;
}

// Пример использования:
// decimal cubeVol = ComputeVolume(3m);
// decimal boxVol = ComputeVolume(2m, 3m, 4m);
// decimal cylinderVol = ComputeVolume(2m, 5m);

// Задача 292: Напишите перегруженные методы для вывода информации разных типов
static void DisplayValue(int value, NumberFormat format)
{
    switch (format)
    {
        case NumberFormat.Decimal:
            Console.WriteLine($"Decimal: {value}");
            break;
        case NumberFormat.Hexadecimal:
            Console.WriteLine($"Hex: 0x{value:X}");
            break;
        case NumberFormat.Binary:
            Console.WriteLine($"Binary: {Convert.ToString(value, 2)}");
            break;
    }
}

enum NumberFormat { Decimal, Hexadecimal, Binary }

// Пример использования:
// DisplayValue(42, NumberFormat.Decimal);
// DisplayValue(42, NumberFormat.Hexadecimal);
// DisplayValue(42, NumberFormat.Binary);

// Задача 293: Реализуйте перегрузку метода для генерации случайных чисел (диапазон, количество)
static int GenerateRandom(int min, int max)
{
    Random rnd = new Random();
    return rnd.Next(min, max + 1);
}

static int[] GenerateRandom(int min, int max, int count)
{
    Random rnd = new Random();
    int[] numbers = new int[count];
    for (int i = 0; i < count; i++)
        numbers[i] = rnd.Next(min, max + 1);
    return numbers;
}

static double GenerateRandom(double min, double max)
{
    Random rnd = new Random();
    return min + (rnd.NextDouble() * (max - min));
}

// Пример использования:
// int random1 = GenerateRandom(1, 100);
// int[] randomArray = GenerateRandom(1, 100, 5);
// double randomDouble = GenerateRandom(0.0, 1.0);

// Задача 294: Напишите перегруженные методы для вывода информации разных типов
static void Log(string message)
{
    Console.WriteLine($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}");
}

static void Log(string message, LogLevel level, string source = "")
{
    string sourceInfo = string.IsNullOrEmpty(source) ? "" : $"[{source}]";
    Console.WriteLine($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{level}]{sourceInfo} {message}");
}

// Пример использования:
// Log("Application started");
// Log("Error occurred", LogLevel.ERROR, "Database");
// Log("Warning", LogLevel.WARNING);

// Задача 295: Реализуйте перегрузку метода для умножения (int, double, decimal)
static ComplexNumber Multiply(ComplexNumber a, ComplexNumber b)
{
    return new ComplexNumber
    {
        Real = a.Real * b.Real - a.Imaginary * b.Imaginary,
        Imaginary = a.Real * b.Imaginary + a.Imaginary * b.Real
    };
}

class ComplexNumber
{
    public double Real { get; set; }
    public double Imaginary { get; set; }
}

// Пример использования:
// ComplexNumber result = Multiply(new ComplexNumber { Real = 1, Imaginary = 2 }, new ComplexNumber { Real = 3, Imaginary = 4 });

// Задача 296: Создайте перегруженные методы для сортировки (по возрастанию/убыванию)
static void QuickSort(int[] array)
{
    Array.Sort(array);
}

static void QuickSort(int[] array, int left, int right)
{
    if (left < right)
    {
        int pivot = Partition(array, left, right);
        QuickSort(array, left, pivot - 1);
        QuickSort(array, pivot + 1, right);
    }
}

static int Partition(int[] array, int left, int right)
{
    int pivot = array[right];
    int i = left - 1;

    for (int j = left; j < right; j++)
    {
        if (array[j] <= pivot)
        {
            i++;
            Swap(array, i, j);
        }
    }

    Swap(array, i + 1, right);
    return i + 1;
}

static void Swap(int[] array, int i, int j)
{
    int temp = array[i];
    array[i] = array[j];
    array[j] = temp;
}

// Пример использования:
// int[] numbers = {3, 1, 2};
// QuickSort(numbers);
// QuickSort(numbers, 0, numbers.Length - 1);

// Задача 297: Создайте перегрузку метода для поиска максимума (2, 3, 4 числа)
static TimeSpan FindMax(TimeSpan t1, TimeSpan t2)
{
    return t1 > t2 ? t1 : t2;
}

static TimeSpan FindMax(TimeSpan t1, TimeSpan t2, TimeSpan t3)
{
    return FindMax(FindMax(t1, t2), t3);
}

// Пример использования:
// TimeSpan maxTime = FindMax(TimeSpan.FromHours(1), TimeSpan.FromHours(2));

// Задача 298: Создайте перегруженные методы для шифрования текста разными алгоритмами
static string ProcessText(string text, Func<string, string> processor)
{
    return processor(text);
}

static string ProcessText(string text, TextOperation operation)
{
    switch (operation)
    {
        case TextOperation.Encrypt:
            return Encrypt(text);
        case TextOperation.Decrypt:
            return Decrypt(text);
        case TextOperation.Reverse:
            return new string(text.Reverse().ToArray());
        default:
            return text;
    }
}

enum TextOperation { Encrypt, Decrypt, Reverse }

// Пример использования:
// string result1 = ProcessText("hello", TextOperation.Encrypt);
// string result2 = ProcessText("hello", x => x.ToUpper());

// Задача 299: Реализуйте перегрузку метода для умножения (int, double, decimal)
static Matrix Multiply(Matrix a, Matrix b)
{
    if (a.Columns != b.Rows)
        throw new InvalidOperationException("Матрицы несовместимы для умножения");

    Matrix result = new Matrix(a.Rows, b.Columns);

    for (int i = 0; i < a.Rows; i++)
        for (int j = 0; j < b.Columns; j++)
            for (int k = 0; k < a.Columns; k++)
                result[i, j] += a[i, k] * b[k, j];

    return result;
}

class Matrix
{
    private double[,] data;
    public int Rows { get; }
    public int Columns { get; }

    public Matrix(int rows, int columns)
    {
        Rows = rows;
        Columns = columns;
        data = new double[rows, columns];
    }

    public double this[int row, int col]
    {
        get => data[row, col];
        set => data[row, col] = value;
    }
}

// Пример использования:
// Matrix result = Multiply(new Matrix(2, 3), new Matrix(3, 2));

// Задача 300: Создайте перегруженные методы для шифрования текста разными алгоритмами
static string Transform(string text, ITextTransformer transformer)
{
    return transformer.Transform(text);
}

static string Transform(string text, params ITextTransformer[] transformers)
{
    string result = text;
    foreach (var transformer in transformers)
        result = transformer.Transform(result);
    return result;
}

interface ITextTransformer
{
    string Transform(string text);
}

class UpperCaseTransformer : ITextTransformer
{
    public string Transform(string text) => text.ToUpper();
}

class ReverseTransformer : ITextTransformer
{
    public string Transform(string text) => new string(text.Reverse().ToArray());
}

// Пример использования:
// string result1 = Transform("hello", new UpperCaseTransformer());
// string result2 = Transform("hello", new UpperCaseTransformer(), new ReverseTransformer());


// Задача 301: Реализуйте метод с именованными параметрами для построения SQL-запроса
static string BuildSQLQuery(string table, string where = null, string orderBy = null, int? limit = null, string select = "*")
{
    var query = $"SELECT {select} FROM {table}";

    if (!string.IsNullOrEmpty(where))
        query += $" WHERE {where}";

    if (!string.IsNullOrEmpty(orderBy))
        query += $" ORDER BY {orderBy}";

    if (limit.HasValue)
        query += $" LIMIT {limit.Value}";

    return query;
}

// Пример использования:
// string query1 = BuildSQLQuery("users");
// string query2 = BuildSQLQuery("users", where: "age > 18", orderBy: "name");
// string query3 = BuildSQLQuery("products", select: "id, name", limit: 10);

// Задача 302: Реализуйте метод с именованными параметрами для создания пользователя
static string CreateUser(string username, string email, string password, string firstName = null, string lastName = null, string phone = null, DateTime? birthDate = null)
{
    var user = new
    {
        Username = username,
        Email = email,
        Password = password,
        FirstName = firstName,
        LastName = lastName,
        Phone = phone,
        BirthDate = birthDate
    };

    return $"User created: {System.Text.Json.JsonSerializer.Serialize(user)}";
}

// Пример использования:
// string user1 = CreateUser("john_doe", "john@example.com", "password123");
// string user2 = CreateUser("jane_doe", "jane@example.com", "password123", firstName: "Jane", lastName: "Doe");

// Задача 303: Реализуйте метод с именованными параметрами для построения SQL-запроса
static string CreateSelectQuery(string tableName, string[] columns = null, string condition = null, string sortBy = null, bool distinct = false)
{
    columns = columns ?? new string[] { "*" };
    string columnList = string.Join(", ", columns);

    var query = distinct ? $"SELECT DISTINCT {columnList} FROM {tableName}"
                         : $"SELECT {columnList} FROM {tableName}";

    if (!string.IsNullOrEmpty(condition))
        query += $" WHERE {condition}";

    if (!string.IsNullOrEmpty(sortBy))
        query += $" ORDER BY {sortBy}";

    return query;
}

// Пример использования:
// string query1 = CreateSelectQuery("employees");
// string query2 = CreateSelectQuery("products", columns: new[] { "id", "name", "price" });
// string query3 = CreateSelectQuery("users", condition: "active = true", sortBy: "created_at DESC");

// Задача 304: Напишите метод с опциональными параметрами для форматирования строки
static string FormatString(string text, bool uppercase = false, bool trim = true, string prefix = "", string suffix = "")
{
    string result = text;

    if (trim)
        result = result.Trim();

    if (uppercase)
        result = result.ToUpper();

    return prefix + result + suffix;
}

// Пример использования:
// string formatted1 = FormatString("  hello world  ");
// string formatted2 = FormatString("hello", uppercase: true, prefix: ">>> ", suffix: " <<<");

// Задача 305: Реализуйте метод с именованными параметрами для создания графика (ширина, высота, цвет)
static string CreateChart(string title, int width = 800, int height = 600, string backgroundColor = "white", string borderColor = "black", int borderWidth = 1, bool showGrid = true)
{
    return $"Chart: {title} | Size: {width}x{height} | BG: {backgroundColor} | Border: {borderColor} ({borderWidth}px) | Grid: {showGrid}";
}

// Пример использования:
// string chart1 = CreateChart("Sales Report");
// string chart2 = CreateChart("Revenue", width: 1200, height: 800, backgroundColor: "lightblue");

// Задача 306: Создайте метод с опциональными параметрами для генерации пароля (длина, символы)
static string GeneratePassword(int length = 12, bool includeUppercase = true, bool includeLowercase = true, bool includeNumbers = true, bool includeSpecial = false)
{
    const string uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const string lowercase = "abcdefghijklmnopqrstuvwxyz";
    const string numbers = "0123456789";
    const string special = "!@#$%^&*()_+-=[]{}|;:,.<>?";

    var chars = "";
    if (includeUppercase) chars += uppercase;
    if (includeLowercase) chars += lowercase;
    if (includeNumbers) chars += numbers;
    if (includeSpecial) chars += special;

    if (string.IsNullOrEmpty(chars))
        throw new ArgumentException("Должен быть включен хотя бы один набор символов");

    Random random = new Random();
    return new string(Enumerable.Repeat(chars, length)
        .Select(s => s[random.Next(s.Length)]).ToArray());
}

// Пример использования:
// string password1 = GeneratePassword();
// string password2 = GeneratePassword(16, includeSpecial: true);
// string password3 = GeneratePassword(8, includeUppercase: false, includeNumbers: true);

// Задача 307: Создайте метод с опциональными параметрами для генерации пароля (длина, символы)
static string CreatePassword(int minLength = 8, int maxLength = 16, string allowedChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
{
    Random random = new Random();
    int length = random.Next(minLength, maxLength + 1);

    return new string(Enumerable.Repeat(allowedChars, length)
        .Select(s => s[random.Next(s.Length)]).ToArray());
}

// Пример использования:
// string password1 = CreatePassword();
// string password2 = CreatePassword(minLength: 12, maxLength: 20);
// string password3 = CreatePassword(allowedChars: "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");

// Задача 308: Реализуйте метод с опциональным параметром для округления чисел (количество знаков)
static double RoundNumber(double number, int decimalPlaces = 2, MidpointRounding rounding = MidpointRounding.ToEven)
{
    return Math.Round(number, decimalPlaces, rounding);
}

// Пример использования:
// double rounded1 = RoundNumber(3.14159);
// double rounded2 = RoundNumber(3.14159, 4);
// double rounded3 = RoundNumber(2.5, 0, MidpointRounding.AwayFromZero);

// Задача 309: Реализуйте метод с опциональными параметрами для создания файла (путь, расширение)
static string CreateFile(string fileName, string extension = "txt", string directory = ".", bool overwrite = false)
{
    string fullPath = Path.Combine(directory, $"{fileName}.{extension}");
    return $"Creating file: {fullPath} (Overwrite: {overwrite})";
}

// Пример использования:
// string file1 = CreateFile("document");
// string file2 = CreateFile("data", "csv", "C:/Files");
// string file3 = CreateFile("backup", "bak", overwrite: true);

// Задача 310: Напишите метод с опциональным параметром для поиска в массиве (начальный индекс)
static int FindInArray(int[] array, int value, int startIndex = 0, bool caseSensitive = true)
{
    for (int i = startIndex; i < array.Length; i++)
    {
        if (array[i] == value)
            return i;
    }
    return -1;
}

// Пример использования:
// int index1 = FindInArray(new int[] {1, 2, 3, 2, 1}, 2);
// int index2 = FindInArray(new int[] {1, 2, 3, 2, 1}, 2, startIndex: 2);

// Задача 311: Создайте метод с опциональными параметрами для подключения к базе данных
static string ConnectToDatabase(string server, string database, string username = "sa", string password = "", int timeout = 30, bool integratedSecurity = false)
{
    string auth = integratedSecurity ? "Integrated Security=true" : $"User Id={username};Password={password}";
    return $"Server={server};Database={database};{auth};Timeout={timeout}";
}

// Пример использования:
// string conn1 = ConnectToDatabase("localhost", "MyDB");
// string conn2 = ConnectToDatabase("db.server.com", "Production", "admin", "secret123", timeout: 60);

// Задача 312: Реализуйте метод с опциональными параметрами для создания файла (путь, расширение)
static FileInfo CreateNewFile(string name, string path = "", string extension = "tmp", long size = 0)
{
    string fileName = $"{name}.{extension}";
    string fullPath = string.IsNullOrEmpty(path) ? fileName : Path.Combine(path, fileName);

    return new FileInfo(fullPath);
}

// Пример использования:
// FileInfo file1 = CreateNewFile("temp");
// FileInfo file2 = CreateNewFile("data", "C:/Temp", "json");

// Задача 313: Реализуйте метод с именованными параметрами для настройки логирования
static string ConfigureLogging(string logLevel = "INFO", string outputFile = "app.log", bool enableConsole = true, bool enableFile = true, int maxFileSize = 10485760, string dateFormat = "yyyy-MM-dd HH:mm:ss")
{
    return $"Logging: Level={logLevel}, File={outputFile}, Console={enableConsole}, FileLogging={enableFile}, MaxSize={maxFileSize}, DateFormat={dateFormat}";
}

// Пример использования:
// string config1 = ConfigureLogging();
// string config2 = ConfigureLogging("DEBUG", "debug.log", maxFileSize: 5242880);

// Задача 314: Напишите метод с опциональным параметром для поиска в массиве (начальный индекс)
static int IndexOf<T>(T[] array, T value, int startIndex = 0, IEqualityComparer<T> comparer = null)
{
    comparer = comparer ?? EqualityComparer<T>.Default;

    for (int i = startIndex; i < array.Length; i++)
    {
        if (comparer.Equals(array[i], value))
            return i;
    }
    return -1;
}

// Пример использования:
// int index1 = IndexOf(new string[] {"a", "b", "c"}, "b");
// int index2 = IndexOf(new string[] {"a", "b", "C"}, "c", comparer: StringComparer.OrdinalIgnoreCase);

// Задача 315: Создайте метод с опциональным параметром для пагинации (страница, размер)
static (int skip, int take) CalculatePagination(int pageNumber = 1, int pageSize = 10)
{
    int skip = (pageNumber - 1) * pageSize;
    return (skip, pageSize);
}

// Пример использования:
// var pagination1 = CalculatePagination();
// var pagination2 = CalculatePagination(pageNumber: 3, pageSize: 25);

// Задача 316: Реализуйте метод с опциональным параметром для вывода сообщения с префиксом
static void PrintMessage(string message, string prefix = ">", ConsoleColor color = ConsoleColor.White, bool addTimestamp = false)
{
    if (addTimestamp)
        prefix = $"[{DateTime.Now:HH:mm:ss}] {prefix}";

    Console.ForegroundColor = color;
    Console.WriteLine($"{prefix} {message}");
    Console.ResetColor();
}

// Пример использования:
// PrintMessage("Hello World");
// PrintMessage("Error occurred", "ERROR", ConsoleColor.Red, addTimestamp: true);

// Задача 317: Создайте метод с именованными параметрами для отправки email (тема, текст, вложения)
static string SendEmail(string to, string subject, string body, string from = "noreply@company.com", string cc = null, string bcc = null, string[] attachments = null, bool isHtml = false)
{
    attachments = attachments ?? Array.Empty<string>();
    return $"To: {to} | From: {from} | Subject: {subject} | CC: {cc ?? "None"} | BCC: {bcc ?? "None"} | Attachments: {attachments.Length} | HTML: {isHtml}";
}

// Пример использования:
// string email1 = SendEmail("user@example.com", "Welcome", "Hello!");
// string email2 = SendEmail("user@example.com", "Report", "<h1>Report</h1>", isHtml: true, attachments: new[] {"file1.pdf", "file2.xlsx"});

// Задача 318: Напишите метод с опциональными параметрами для валидации формы
static (bool isValid, string[] errors) ValidateForm(string username, string email, string password, int minPasswordLength = 8, bool requireSpecialChar = false, int minUsernameLength = 3)
{
    var errors = new List<string>();

    if (username.Length < minUsernameLength)
        errors.Add($"Username must be at least {minUsernameLength} characters");

    if (!email.Contains("@"))
        errors.Add("Invalid email format");

    if (password.Length < minPasswordLength)
        errors.Add($"Password must be at least {minPasswordLength} characters");

    if (requireSpecialChar && !password.Any(ch => !char.IsLetterOrDigit(ch)))
        errors.Add("Password must contain at least one special character");

    return (errors.Count == 0, errors.ToArray());
}

// Пример использования:
// var result1 = ValidateForm("john", "john@example.com", "password");
// var result2 = ValidateForm("jo", "invalid", "pass", requireSpecialChar: true);

// Задача 319: Реализуйте метод с опциональными параметрами для создания файла (путь, расширение)
static string CreateFilePath(string baseName, string extension = "txt", string directory = null, bool useTimestamp = false)
{
    directory = directory ?? Directory.GetCurrentDirectory();

    string fileName = useTimestamp ? $"{baseName}_{DateTime.Now:yyyyMMdd_HHmmss}" : baseName;
    string fullName = $"{fileName}.{extension}";

    return Path.Combine(directory, fullName);
}

// Пример использования:
// string path1 = CreateFilePath("document");
// string path2 = CreateFilePath("backup", "zip", "C:/Backups", useTimestamp: true);

// Задача 320: Напишите метод с опциональными параметрами для форматирования строки
static string FormatText(string text, int maxLength = 0, string ellipsis = "...", TextAlignment alignment = TextAlignment.Left)
{
    if (maxLength > 0 && text.Length > maxLength)
    {
        text = text.Substring(0, maxLength - ellipsis.Length) + ellipsis;
    }

    return alignment switch
    {
        TextAlignment.Left => text.PadRight(maxLength > 0 ? maxLength : text.Length),
        TextAlignment.Right => text.PadLeft(maxLength > 0 ? maxLength : text.Length),
        TextAlignment.Center when maxLength > 0 => text.PadLeft((maxLength + text.Length) / 2).PadRight(maxLength),
        _ => text
    };
}

enum TextAlignment { Left, Center, Right }

// Пример использования:
// string formatted1 = FormatText("Hello World", 15);
// string formatted2 = FormatText("Hello", 10, alignment: TextAlignment.Center);

// Задача 321: Создайте метод с опциональным параметром для вычисления степени числа
static double Power(double baseValue, int exponent = 2)
{
    return Math.Pow(baseValue, exponent);
}

// Пример использования:
// double result1 = Power(5); // 25
// double result2 = Power(2, 10); // 1024

// Задача 322: Напишите метод с опциональными параметрами для валидации формы
static bool ValidateUserInput(string input, bool required = true, int minLength = 0, int maxLength = int.MaxValue, string allowedChars = null)
{
    if (required && string.IsNullOrWhiteSpace(input))
        return false;

    if (input.Length < minLength || input.Length > maxLength)
        return false;

    if (!string.IsNullOrEmpty(allowedChars) && input.Any(c => !allowedChars.Contains(c)))
        return false;

    return true;
}

// Пример использования:
// bool valid1 = ValidateUserInput("username");
// bool valid2 = ValidateUserInput("user123", allowedChars: "abcdefghijklmnopqrstuvwxyz0123456789");
// bool valid3 = ValidateUserInput("", required: false);

// Задача 323: Реализуйте метод с именованными параметрами для построения SQL-запроса
static string BuildUpdateQuery(string table, Dictionary<string, object> setValues, string whereCondition = null, int? limit = null)
{
    var setClause = string.Join(", ", setValues.Select(kv => $"{kv.Key} = {kv.Value}"));
    var query = $"UPDATE {table} SET {setClause}";

    if (!string.IsNullOrEmpty(whereCondition))
        query += $" WHERE {whereCondition}";

    if (limit.HasValue)
        query += $" LIMIT {limit.Value}";

    return query;
}

// Пример использования:
// string query = BuildUpdateQuery("users", new Dictionary<string, object> { ["status"] = "active", ["last_login"] = "NOW()" }, whereCondition: "id = 1");

// Задача 324: Создайте метод с опциональными параметрами для генерации пароля (длина, символы)
static string GenerateSecurePassword(int length = 16, bool mustHaveUppercase = true, bool mustHaveLowercase = true, bool mustHaveDigits = true, bool mustHaveSpecial = true)
{
    const string upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const string lower = "abcdefghijklmnopqrstuvwxyz";
    const string digits = "0123456789";
    const string special = "!@#$%^&*()_+-=[]{}|;:,.<>?";

    var random = new Random();
    var password = new char[length];
    var charSets = new List<string>();

    if (mustHaveUppercase)
    {
        charSets.Add(upper);
        password[0] = upper[random.Next(upper.Length)];
    }
    if (mustHaveLowercase)
    {
        charSets.Add(lower);
        password[1] = lower[random.Next(lower.Length)];
    }
    if (mustHaveDigits)
    {
        charSets.Add(digits);
        password[2] = digits[random.Next(digits.Length)];
    }
    if (mustHaveSpecial)
    {
        charSets.Add(special);
        password[3] = special[random.Next(special.Length)];
    }

    var allChars = string.Concat(charSets);
    for (int i = charSets.Count; i < length; i++)
    {
        password[i] = allChars[random.Next(allChars.Length)];
    }

    return new string(password.OrderBy(x => random.Next()).ToArray());
}

// Пример использования:
// string password1 = GenerateSecurePassword();
// string password2 = GenerateSecurePassword(12, mustHaveSpecial: false);

// Задача 325: Создайте метод с именованными параметрами для расчета стоимости заказа
static decimal CalculateOrderTotal(decimal subtotal, decimal taxRate = 0.1m, decimal discount = 0, decimal shipping = 5.0m, bool applyTaxToShipping = false)
{
    decimal taxableAmount = applyTaxToShipping ? subtotal + shipping : subtotal;
    decimal tax = taxableAmount * taxRate;
    return subtotal + tax + shipping - discount;
}

// Пример использования:
// decimal total1 = CalculateOrderTotal(100);
// decimal total2 = CalculateOrderTotal(100, taxRate: 0.08m, shipping: 10.0m, discount: 15.0m);

// Задача 326: Напишите метод с опциональными параметрами для форматирования строки
static string ProcessString(string input, bool removeWhitespace = false, bool toLowerCase = false, bool toUpperCase = false, string replace = null, string with = "")
{
    string result = input;

    if (removeWhitespace)
        result = string.Concat(result.Where(c => !char.IsWhiteSpace(c)));

    if (toLowerCase)
        result = result.ToLower();
    else if (toUpperCase)
        result = result.ToUpper();

    if (!string.IsNullOrEmpty(replace))
        result = result.Replace(replace, with);

    return result;
}

// Пример использования:
// string result1 = ProcessString("Hello World", removeWhitespace: true);
// string result2 = ProcessString("Hello World", toUpperCase: true, replace: "World", with: "C#");

// Задача 327: Напишите метод с именованными параметрами для создания конфигурации приложения
static string CreateAppConfig(string appName, string version = "1.0.0", string environment = "Production", int maxConnections = 100, bool enableLogging = true, string logLevel = "INFO")
{
    return $"App: {appName} v{version} | Env: {environment} | MaxConnections: {maxConnections} | Logging: {enableLogging} ({logLevel})";
}

// Пример использования:
// string config1 = CreateAppConfig("MyApp");
// string config2 = CreateAppConfig("MyApp", version: "2.1.0", environment: "Development", maxConnections: 50);

// Задача 328: Создайте метод с опциональными параметрами для подключения к базе данных
static string BuildConnectionString(string server, string database, int port = 1433, int timeout = 30, bool pooling = true, int minPoolSize = 0, int maxPoolSize = 100)
{
    return $"Server={server},{port};Database={database};Timeout={timeout};Pooling={pooling};Min Pool Size={minPoolSize};Max Pool Size={maxPoolSize}";
}

// Пример использования:
// string connStr1 = BuildConnectionString("localhost", "MyDB");
// string connStr2 = BuildConnectionString("db.server.com", "ProdDB", port: 5432, timeout: 60);

// Задача 329: Реализуйте метод с опциональным параметром для округления чисел (количество знаков)
static decimal RoundDecimal(decimal number, int decimals = 2, bool useBankersRounding = true)
{
    return useBankersRounding ? Math.Round(number, decimals)
                            : Math.Round(number, decimals, MidpointRounding.AwayFromZero);
}

// Пример использования:
// decimal rounded1 = RoundDecimal(123.4567m);
// decimal rounded2 = RoundDecimal(123.4567m, 3, useBankersRounding: false);

// Задача 330: Напишите метод с опциональным параметром для поиска в массиве (начальный индекс)
static List<int> FindAllInArray(int[] array, int value, int startIndex = 0, int count = -1)
{
    count = count == -1 ? array.Length - startIndex : count;
    var results = new List<int>();

    for (int i = startIndex; i < Math.Min(startIndex + count, array.Length); i++)
    {
        if (array[i] == value)
            results.Add(i);
    }

    return results;
}

// Пример использования:
// var indices1 = FindAllInArray(new int[] {1, 2, 3, 2, 1}, 2);
// var indices2 = FindAllInArray(new int[] {1, 2, 3, 2, 1}, 2, startIndex: 2, count: 2);

// Задача 331: Реализуйте метод с опциональным параметром для вывода сообщения с префиксом
static void LogMessage(string message, LogLevel level = LogLevel.INFO, bool includeStackTrace = false, string source = "Application")
{
    string stackTrace = includeStackTrace ? Environment.StackTrace : "";
    Console.WriteLine($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{level}] [{source}] {message} {stackTrace}");
}

// Пример использования:
// LogMessage("Application started");
// LogMessage("Error occurred", LogLevel.ERROR, includeStackTrace: true, source: "Database");

// Задача 332: Напишите метод с именованными параметрами для фильтрации данных
static IEnumerable<T> FilterData<T>(IEnumerable<T> data, Func<T, bool> predicate = null, int? skip = null, int? take = null, Func<T, object> orderBy = null, bool descending = false)
{
    var result = data;

    if (predicate != null)
        result = result.Where(predicate);

    if (orderBy != null)
        result = descending ? result.OrderByDescending(orderBy) : result.OrderBy(orderBy);

    if (skip.HasValue)
        result = result.Skip(skip.Value);

    if (take.HasValue)
        result = result.Take(take.Value);

    return result;
}

// Пример использования:
// var filtered = FilterData(new[] {1, 2, 3, 4, 5}, predicate: x => x > 2, take: 2, orderBy: x => x);

// Задача 333: Напишите метод с опциональными параметрами для форматирования строки
static string FormatNumber(decimal number, string format = "C", string culture = "en-US", bool useGroupSeparator = true)
{
    var cultureInfo = new System.Globalization.CultureInfo(culture);
    var numberFormat = (System.Globalization.NumberFormatInfo)cultureInfo.NumberFormat.Clone();

    if (!useGroupSeparator)
        numberFormat.NumberGroupSeparator = "";

    return number.ToString(format, numberFormat);
}

// Пример использования:
// string formatted1 = FormatNumber(1234.56m);
// string formatted2 = FormatNumber(1234.56m, "N2", "de-DE", useGroupSeparator: false);

// Задача 334: Реализуйте метод с именованными параметрами для настройки логирования
static LoggerConfig CreateLoggerConfig(string name, string level = "INFO", string filePath = null, bool enableConsole = true, bool enableFile = false, int maxFileSize = 10485760)
{
    return new LoggerConfig
    {
        Name = name,
        Level = level,
        FilePath = filePath,
        EnableConsole = enableConsole,
        EnableFile = enableFile,
        MaxFileSize = maxFileSize
    };
}

class LoggerConfig
{
    public string Name { get; set; }
    public string Level { get; set; }
    public string FilePath { get; set; }
    public bool EnableConsole { get; set; }
    public bool EnableFile { get; set; }
    public int MaxFileSize { get; set; }
}

// Пример использования:
// var config = CreateLoggerConfig("AppLogger", level: "DEBUG", enableFile: true, filePath: "app.log");

// Задача 335: Напишите метод с именованными параметрами для фильтрации данных
static string BuildFilterQuery(string table, string[] columns = null, string where = null, string groupBy = null, string having = null, string orderBy = null)
{
    columns = columns ?? new string[] { "*" };
    string selectClause = string.Join(", ", columns);

    var query = $"SELECT {selectClause} FROM {table}";

    if (!string.IsNullOrEmpty(where))
        query += $" WHERE {where}";

    if (!string.IsNullOrEmpty(groupBy))
        query += $" GROUP BY {groupBy}";

    if (!string.IsNullOrEmpty(having))
        query += $" HAVING {having}";

    if (!string.IsNullOrEmpty(orderBy))
        query += $" ORDER BY {orderBy}";

    return query;
}

// Пример использования:
// string query1 = BuildFilterQuery("sales");
// string query2 = BuildFilterQuery("orders", columns: new[] {"customer_id", "COUNT(*)"}, groupBy: "customer_id", having: "COUNT(*) > 5");

// Задача 336: Создайте метод с именованными параметрами для отправки email (тема, текст, вложения)
static EmailMessage CreateEmail(string to, string subject, string body, string from = null, string replyTo = null, Priority priority = Priority.Normal, bool readReceipt = false)
{
    return new EmailMessage
    {
        To = to,
        From = from,
        Subject = subject,
        Body = body,
        ReplyTo = replyTo,
        Priority = priority,
        ReadReceipt = readReceipt
    };
}

enum Priority { Low, Normal, High }
class EmailMessage
{
    public string To { get; set; }
    public string From { get; set; }
    public string Subject { get; set; }
    public string Body { get; set; }
    public string ReplyTo { get; set; }
    public Priority Priority { get; set; }
    public bool ReadReceipt { get; set; }
}

// Пример использования:
// var email = CreateEmail("user@example.com", "Important", "Please read this", priority: Priority.High, readReceipt: true);

// Задача 337: Напишите метод с именованными параметрами для создания отчета (дата, автор, заголовок)
static Report GenerateReport(string title, string author, DateTime? date = null, ReportFormat format = ReportFormat.PDF, bool includeSummary = true, bool includeCharts = false)
{
    date = date ?? DateTime.Now;
    return new Report
    {
        Title = title,
        Author = author,
        Date = date.Value,
        Format = format,
        IncludeSummary = includeSummary,
        IncludeCharts = includeCharts
    };
}

enum ReportFormat { PDF, Excel, HTML, Word }
class Report
{
    public string Title { get; set; }
    public string Author { get; set; }
    public DateTime Date { get; set; }
    public ReportFormat Format { get; set; }
    public bool IncludeSummary { get; set; }
    public bool IncludeCharts { get; set; }
}

// Пример использования:
// var report = GenerateReport("Monthly Sales", "John Doe", format: ReportFormat.Excel, includeCharts: true);

// Задача 338: Напишите метод с опциональными параметрами для валидации формы
static ValidationResult ValidateUserRegistration(string username, string email, string password, int minAge = 13, string[] allowedDomains = null, bool requireEmailVerification = true)
{
    allowedDomains = allowedDomains ?? new string[] { "gmail.com", "yahoo.com", "outlook.com" };
    var errors = new List<string>();

    if (string.IsNullOrWhiteSpace(username))
        errors.Add("Username is required");

    if (!email.Contains("@") || !allowedDomains.Any(d => email.EndsWith("@" + d)))
        errors.Add("Invalid email domain");

    if (requireEmailVerification)
        errors.Add("Email verification required");

    return new ValidationResult
    {
        IsValid = errors.Count == 0,
        Errors = errors.ToArray()
    };
}

// Пример использования:
// var result = ValidateUserRegistration("john_doe", "john@gmail.com", "password123");

// Задача 339: Напишите метод с именованными параметрами для создания конфигурации приложения
static AppSettings ConfigureApp(string name, string version, bool debug = false, string environment = "Production", int port = 8080, string[] allowedHosts = null)
{
    allowedHosts = allowedHosts ?? new string[] { "localhost" };
    return new AppSettings
    {
        Name = name,
        Version = version,
        Debug = debug,
        Environment = environment,
        Port = port,
        AllowedHosts = allowedHosts
    };
}

class AppSettings
{
    public string Name { get; set; }
    public string Version { get; set; }
    public bool Debug { get; set; }
    public string Environment { get; set; }
    public int Port { get; set; }
    public string[] AllowedHosts { get; set; }
}

// Пример использования:
// var settings = ConfigureApp("MyAPI", "1.0.0", debug: true, port: 5000);

// Задача 340: Создайте метод с именованными параметрами для отправки email (тема, текст, вложения)
static string PrepareEmail(string recipient, string subject, string body, string sender = "system@company.com", string cc = null, DateTime? scheduleFor = null)
{
    string scheduleInfo = scheduleFor.HasValue ? $" (Scheduled for: {scheduleFor.Value:yyyy-MM-dd HH:mm})" : "";
    return $"From: {sender} | To: {recipient} | CC: {cc ?? "None"} | Subject: {subject}{scheduleInfo}";
}

// Пример использования:
// string email1 = PrepareEmail("user@example.com", "Welcome", "Hello!");
// string email2 = PrepareEmail("user@example.com", "Reminder", "Don't forget!", scheduleFor: DateTime.Now.AddDays(1));

// Задача 341: Реализуйте метод с именованными параметрами для построения SQL-запроса
static string BuildInsertQuery(string table, Dictionary<string, object> values, bool ignoreDuplicates = false, string onDuplicateKeyUpdate = null)
{
    var columns = string.Join(", ", values.Keys);
    var valuePlaceholders = string.Join(", ", values.Keys.Select(k => $"@{k}"));

    var query = ignoreDuplicates ? $"INSERT IGNORE INTO {table} ({columns}) VALUES ({valuePlaceholders})"
                                : $"INSERT INTO {table} ({columns}) VALUES ({valuePlaceholders})";

    if (!string.IsNullOrEmpty(onDuplicateKeyUpdate))
        query += $" ON DUPLICATE KEY UPDATE {onDuplicateKeyUpdate}";

    return query;
}

// Пример использования:
// string query = BuildInsertQuery("users", new Dictionary<string, object> { ["name"] = "John", ["email"] = "john@example.com" }, ignoreDuplicates: true);

// Задача 342: Реализуйте метод с опциональным параметром для округления чисел (количество знаков)
static float RoundFloat(float number, int decimalPlaces = 1, MidpointRounding rounding = MidpointRounding.ToEven)
{
    return (float)Math.Round(number, decimalPlaces, rounding);
}

// Пример использования:
// float rounded = RoundFloat(3.14159f, 2);

// Задача 343: Создайте метод с опциональным параметром для вычисления степени числа
static decimal Power(decimal baseValue, int exponent = 2)
{
    decimal result = 1;
    for (int i = 0; i < Math.Abs(exponent); i++)
        result *= baseValue;
    return exponent >= 0 ? result : 1 / result;
}

// Пример использования:
// decimal result1 = Power(5m); // 25
// decimal result2 = Power(2m, -3); // 0.125

// Задача 344: Напишите метод с именованными параметрами для создания конфигурации приложения
static DatabaseConfig CreateDatabaseConfig(string server, string database, string username = "sa", string password = "", int timeout = 30, int maxPoolSize = 100, bool enableSSL = false)
{
    return new DatabaseConfig
    {
        Server = server,
        Database = database,
        Username = username,
        Password = password,
        Timeout = timeout,
        MaxPoolSize = maxPoolSize,
        EnableSSL = enableSSL
    };
}

class DatabaseConfig
{
    public string Server { get; set; }
    public string Database { get; set; }
    public string Username { get; set; }
    public string Password { get; set; }
    public int Timeout { get; set; }
    public int MaxPoolSize { get; set; }
    public bool EnableSSL { get; set; }
}

// Пример использования:
// var dbConfig = CreateDatabaseConfig("localhost", "MyAppDB", timeout: 60, enableSSL: true);

// Задача 345: Создайте метод с именованными параметрами для отправки email (тема, текст, вложения)
static string ComposeEmail(string to, string subject, string body, EmailPriority priority = EmailPriority.Normal, string[] attachments = null, bool isUrgent = false, bool requestReadReceipt = false)
{
    attachments = attachments ?? Array.Empty<string>();
    string urgentFlag = isUrgent ? " [URGENT]" : "";
    string receiptFlag = requestReadReceipt ? " [READ RECEIPT]" : "";
    return $"To: {to} | Subject: {subject}{urgentFlag} | Priority: {priority} | Attachments: {attachments.Length}{receiptFlag}";
}

enum EmailPriority { Low, Normal, High }

// Пример использования:
// string email = ComposeEmail("manager@company.com", "Budget Approval", "Please review...", EmailPriority.High, isUrgent: true);

// Задача 346: Создайте метод с именованными параметрами для расчета стоимости заказа
static OrderSummary CalculateOrder(decimal subtotal, string currency = "USD", decimal discountPercentage = 0, decimal fixedDiscount = 0, decimal taxRate = 0.1m, decimal shippingCost = 0)
{
    decimal discount = Math.Max(subtotal * discountPercentage / 100, fixedDiscount);
    decimal taxableAmount = subtotal - discount;
    decimal tax = taxableAmount * taxRate;
    decimal total = taxableAmount + tax + shippingCost;

    return new OrderSummary
    {
        Subtotal = subtotal,
        Discount = discount,
        Tax = tax,
        Shipping = shippingCost,
        Total = total,
        Currency = currency
    };
}

class OrderSummary
{
    public decimal Subtotal { get; set; }
    public decimal Discount { get; set; }
    public decimal Tax { get; set; }
    public decimal Shipping { get; set; }
    public decimal Total { get; set; }
    public string Currency { get; set; }
}

// Пример использования:
// var order = CalculateOrder(100, discountPercentage: 10, shippingCost: 5.99m);

// Задача 347: Реализуйте метод с опциональным параметром для вывода сообщения с префиксом
static void WriteLine(string text, ConsoleColor foreground = ConsoleColor.Gray, ConsoleColor background = ConsoleColor.Black, bool underline = false, bool bold = false)
{
    Console.ForegroundColor = foreground;
    Console.BackgroundColor = background;

    string formattedText = text;
    if (bold) formattedText = $"\u001b[1m{formattedText}\u001b[0m";
    if (underline) formattedText = $"\u001b[4m{formattedText}\u001b[0m";

    Console.WriteLine(formattedText);
    Console.ResetColor();
}

// Пример использования:
// WriteLine("Important message", ConsoleColor.Yellow, ConsoleColor.DarkBlue, bold: true);

// Задача 348: Напишите метод с опциональным параметром для поиска в массиве (начальный индекс)
static int BinarySearch(int[] array, int value, int startIndex = 0, int endIndex = -1)
{
    endIndex = endIndex == -1 ? array.Length - 1 : endIndex;
    int left = startIndex;
    int right = endIndex;

    while (left <= right)
    {
        int mid = left + (right - left) / 2;

        if (array[mid] == value)
            return mid;
        else if (array[mid] < value)
            left = mid + 1;
        else
            right = mid - 1;
    }

    return -1;
}

// Пример использования:
// int index = BinarySearch(new int[] {1, 2, 3, 4, 5}, 3, 0, 4);

// Задача 349: Создайте метод с именованными параметрами для расчета стоимости заказа
static decimal CalculateShipping(decimal weight, string destination, ShippingMethod method = ShippingMethod.Standard, bool insurance = false, bool express = false, decimal declaredValue = 0)
{
    decimal baseCost = weight * 2.5m; // $2.5 per kg

    // Method multiplier
    decimal multiplier = method switch
    {
        ShippingMethod.Standard => 1.0m,
        ShippingMethod.Expedited => 1.5m,
        ShippingMethod.Overnight => 3.0m,
        _ => 1.0m
    };

    // Express fee
    if (express) baseCost += 15.0m;

    // Insurance
    if (insurance) baseCost += declaredValue * 0.01m;

    return baseCost * multiplier;
}

enum ShippingMethod { Standard, Expedited, Overnight }

// Пример использования:
// decimal shipping = CalculateShipping(5.0m, "NY", ShippingMethod.Expedited, insurance: true, declaredValue: 500);

// Задача 350: Создайте метод с именованными параметрами для расчета стоимости заказа
static Invoice CreateInvoice(string customer, decimal amount, DateTime? issueDate = null, DateTime? dueDate = null, string currency = "USD", decimal taxRate = 0.0m, string notes = "")
{
    issueDate = issueDate ?? DateTime.Today;
    dueDate = dueDate ?? issueDate.Value.AddDays(30);
    decimal tax = amount * taxRate;
    decimal total = amount + tax;

    return new Invoice
    {
        Customer = customer,
        Amount = amount,
        Tax = tax,
        Total = total,
        IssueDate = issueDate.Value,
        DueDate = dueDate.Value,
        Currency = currency,
        Notes = notes
    };
}

class Invoice
{
    public string Customer { get; set; }
    public decimal Amount { get; set; }
    public decimal Tax { get; set; }
    public decimal Total { get; set; }
    public DateTime IssueDate { get; set; }
    public DateTime DueDate { get; set; }
    public string Currency { get; set; }
    public string Notes { get; set; }
}

// Пример использования:
// var invoice = CreateInvoice("ABC Company", 1000, taxRate: 0.1m, notes: "Thank you for your business!");

// Задача 351: Напишите метод с именованными параметрами для создания конфигурации приложения
static CacheConfig ConfigureCache(string name, int maxSize = 1000, TimeSpan? expiration = null, bool enableCompression = false, CacheEvictionPolicy evictionPolicy = CacheEvictionPolicy.LRU)
{
    expiration = expiration ?? TimeSpan.FromMinutes(30);
    return new CacheConfig
    {
        Name = name,
        MaxSize = maxSize,
        Expiration = expiration.Value,
        EnableCompression = enableCompression,
        EvictionPolicy = evictionPolicy
    };
}

enum CacheEvictionPolicy { LRU, FIFO, LFU }
class CacheConfig
{
    public string Name { get; set; }
    public int MaxSize { get; set; }
    public TimeSpan Expiration { get; set; }
    public bool EnableCompression { get; set; }
    public CacheEvictionPolicy EvictionPolicy { get; set; }
}

// Пример использования:
// var cacheConfig = ConfigureCache("UserCache", maxSize: 5000, expiration: TimeSpan.FromHours(1));

// Задача 352: Реализуйте метод с опциональным параметром для вывода сообщения с префиксом
static void DebugLog(string message, string category = "General", bool includeThreadInfo = false, bool includeTimestamp = true, LogLevel level = LogLevel.DEBUG)
{
    string timestamp = includeTimestamp ? $"[{DateTime.Now:HH:mm:ss.fff}]" : "";
    string threadInfo = includeThreadInfo ? $"[Thread:{Environment.CurrentManagedThreadId}]" : "";

    Console.WriteLine($"{timestamp}{threadInfo} [{level}] [{category}] {message}");
}

// Пример использования:
// DebugLog("Database query executed", "Database", includeThreadInfo: true);

// Задача 353: Напишите метод с опциональным параметром для поиска в массиве (начальный индекс)
static T[] SliceArray<T>(T[] array, int start = 0, int? end = null, int step = 1)
{
    end = end ?? array.Length;
    var result = new List<T>();

    for (int i = start; i < end.Value && i < array.Length; i += step)
    {
        result.Add(array[i]);
    }

    return result.ToArray();
}

// Пример использования:
// var slice1 = SliceArray(new int[] {1, 2, 3, 4, 5}, 1, 4);
// var slice2 = SliceArray(new int[] {1, 2, 3, 4, 5}, step: 2);

// Задача 354: Создайте метод с именованными параметрами для отправки email (тема, текст, вложения)
static string DraftEmail(string recipient, string subject, string body, string[] bcc = null, bool encrypt = false, string signature = "Best regards", bool saveDraft = false)
{
    bcc = bcc ?? Array.Empty<string>();
    string encryption = encrypt ? " [ENCRYPTED]" : "";
    string draftStatus = saveDraft ? " [DRAFT]" : "";
    return $"To: {recipient} | Subject: {subject}{encryption}{draftStatus} | BCC: {bcc.Length} recipients | Signature: {signature}";
}

// Пример использования:
// string draft = DraftEmail("team@company.com", "Meeting Agenda", "Let's discuss...", encrypt: true, saveDraft: true);

// Задача 355: Реализуйте метод с именованными параметрами для построения SQL-запроса
static string CreateDeleteQuery(string table, string whereCondition = null, int? limit = null, bool softDelete = false, string deletedAtColumn = "deleted_at")
{
    if (softDelete)
    {
        return $"UPDATE {table} SET {deletedAtColumn} = NOW() WHERE {whereCondition ?? "1=1"}";
    }
    else
    {
        var query = $"DELETE FROM {table}";
        if (!string.IsNullOrEmpty(whereCondition))
            query += $" WHERE {whereCondition}";
        if (limit.HasValue)
            query += $" LIMIT {limit.Value}";
        return query;
    }
}

// Пример использования:
// string query1 = CreateDeleteQuery("temp_data");
// string query2 = CreateDeleteQuery("users", "id = 123", softDelete: true);

// Задача 356: Создайте метод с опциональными параметрами для подключения к базе данных
static string CreateConnectionString(string host, string database, int port = 5432, int commandTimeout = 30, int connectionTimeout = 15, bool sslMode = true, string sslCert = null)
{
    var parts = new List<string>
    {
        $"Host={host}",
        $"Database={database}",
        $"Port={port}",
        $"Command Timeout={commandTimeout}",
        $"Connection Timeout={connectionTimeout}",
        $"SSL Mode={(sslMode ? "Require" : "Disable")}"
    };

    if (!string.IsNullOrEmpty(sslCert))
        parts.Add($"SSL Certificate={sslCert}");

    return string.Join(";", parts);
}

// Пример использования:
// string connStr = CreateConnectionString("localhost", "myapp", sslMode: true, commandTimeout: 60);

// Задача 357: Реализуйте метод с опциональными параметрами для создания файла (путь, расширение)
static FileInfo CreateTempFile(string prefix = "temp", string extension = "tmp", string directory = null, bool randomName = true)
{
    directory = directory ?? Path.GetTempPath();
    string fileName = randomName ?
        $"{prefix}_{Guid.NewGuid():N}.{extension}" :
        $"{prefix}.{extension}";

    return new FileInfo(Path.Combine(directory, fileName));
}

// Пример использования:
// FileInfo tempFile1 = CreateTempFile();
// FileInfo tempFile2 = CreateTempFile("backup", "dat", randomName: false);

// Задача 358: Создайте метод с опциональными параметрами для подключения к базе данных
static DbConnectionConfig SetupConnection(string server, string database, AuthenticationType authType = AuthenticationType.Sql, string username = null, string password = null, bool integratedSecurity = false, int timeout = 30)
{
    return new DbConnectionConfig
    {
        Server = server,
        Database = database,
        AuthType = authType,
        Username = username,
        Password = password,
        IntegratedSecurity = integratedSecurity,
        Timeout = timeout
    };
}

enum AuthenticationType { Sql, Windows, AzureAD }
class DbConnectionConfig
{
    public string Server { get; set; }
    public string Database { get; set; }
    public AuthenticationType AuthType { get; set; }
    public string Username { get; set; }
    public string Password { get; set; }
    public bool IntegratedSecurity { get; set; }
    public int Timeout { get; set; }
}

// Пример использования:
// var dbConfig = SetupConnection("myserver.database.windows.net", "MyDb", AuthenticationType.AzureAD, timeout: 60);

// Задача 359: Напишите метод с опциональным параметром для поиска в массиве (начальный индекс)
static int FindLastIndex<T>(T[] array, T value, int startIndex = -1, IEqualityComparer<T> comparer = null)
{
    comparer = comparer ?? EqualityComparer<T>.Default;
    startIndex = startIndex == -1 ? array.Length - 1 : startIndex;

    for (int i = startIndex; i >= 0; i--)
    {
        if (comparer.Equals(array[i], value))
            return i;
    }

    return -1;
}

// Пример использования:
// int lastIndex = FindLastIndex(new string[] {"a", "b", "c", "b"}, "b");

// Задача 360: Реализуйте метод с опциональным параметром для округления чисел (количество знаков)
static double RoundToSignificantDigits(double number, int significantDigits = 3)
{
    if (number == 0) return 0;

    double scale = Math.Pow(10, Math.Floor(Math.Log10(Math.Abs(number))) + 1 - significantDigits);
    return scale * Math.Round(number / scale);
}

// Пример использования:
// double rounded = RoundToSignificantDigits(123.456789, 4); // 123.5

// Задача 361: Создайте метод с именованными параметрами для HTTP-запроса (метод, заголовки, тело)
static HttpRequestConfig CreateHttpRequest(string url, HttpMethod method = null, Dictionary<string, string> headers = null, string body = null, int timeout = 30, bool followRedirects = true)
{
    method = method ?? HttpMethod.Get;
    headers = headers ?? new Dictionary<string, string>();

    return new HttpRequestConfig
    {
        Url = url,
        Method = method,
        Headers = headers,
        Body = body,
        Timeout = timeout,
        FollowRedirects = followRedirects
    };
}

class HttpRequestConfig
{
    public string Url { get; set; }
    public HttpMethod Method { get; set; }
    public Dictionary<string, string> Headers { get; set; }
    public string Body { get; set; }
    public int Timeout { get; set; }
    public bool FollowRedirects { get; set; }
}

// Пример использования:
// var request = CreateHttpRequest("https://api.example.com/data", HttpMethod.Post, timeout: 60);

// Задача 362: Напишите метод с опциональным параметром для поиска в массиве (начальный индекс)
static int CountOccurrences<T>(T[] array, T value, int startIndex = 0, int endIndex = -1, IEqualityComparer<T> comparer = null)
{
    comparer = comparer ?? EqualityComparer<T>.Default;
    endIndex = endIndex == -1 ? array.Length - 1 : endIndex;

    int count = 0;
    for (int i = startIndex; i <= endIndex && i < array.Length; i++)
    {
        if (comparer.Equals(array[i], value))
            count++;
    }

    return count;
}

// Пример использования:
// int count = CountOccurrences(new int[] {1, 2, 3, 2, 1}, 2, 1, 3);

// Задача 363: Реализуйте метод с именованными параметрами для создания пользователя
static UserProfile CreateUserProfile(string username, string email, string firstName = null, string lastName = null, DateTime? birthDate = null, string phone = null, UserRole role = UserRole.User, bool isActive = true)
{
    return new UserProfile
    {
        Username = username,
        Email = email,
        FirstName = firstName,
        LastName = lastName,
        BirthDate = birthDate,
        Phone = phone,
        Role = role,
        IsActive = isActive
    };
}

enum UserRole { User, Moderator, Admin }
class UserProfile
{
    public string Username { get; set; }
    public string Email { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public DateTime? BirthDate { get; set; }
    public string Phone { get; set; }
    public UserRole Role { get; set; }
    public bool IsActive { get; set; }
}

// Пример использования:
// var user = CreateUserProfile("johndoe", "john@example.com", "John", "Doe", role: UserRole.Admin);

// Задача 364: Напишите метод с опциональными параметрами для форматирования строки
static string FormatPhoneNumber(string phone, string format = "(###) ###-####", string separator = "-", bool includeCountryCode = false, string countryCode = "+1")
{
    // Remove non-digits
    string digits = new string(phone.Where(char.IsDigit).ToArray());

    if (includeCountryCode)
        digits = countryCode.TrimStart('+') + digits;

    // Apply format
    string result = format;
    int digitIndex = 0;

    for (int i = 0; i < result.Length && digitIndex < digits.Length; i++)
    {
        if (result[i] == '#')
        {
            result = result.Remove(i, 1).Insert(i, digits[digitIndex].ToString());
            digitIndex++;
        }
    }

    return result;
}

// Пример использования:
// string phone1 = FormatPhoneNumber("1234567890");
// string phone2 = FormatPhoneNumber("1234567890", "###.###.####", includeCountryCode: true);

// Задача 365: Реализуйте метод с именованными параметрами для создания графика (ширина, высота, цвет)
static ChartSettings ConfigureChart(string title, ChartType type = ChartType.Line, int width = 800, int height = 400, string colorScheme = "Default", bool showLegend = true, bool showGrid = true, decimal opacity = 1.0m)
{
    return new ChartSettings
    {
        Title = title,
        Type = type,
        Width = width,
        Height = height,
        ColorScheme = colorScheme,
        ShowLegend = showLegend,
        ShowGrid = showGrid,
        Opacity = opacity
    };
}

enum ChartType { Line, Bar, Pie, Scatter }
class ChartSettings
{
    public string Title { get; set; }
    public ChartType Type { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
    public string ColorScheme { get; set; }
    public bool ShowLegend { get; set; }
    public bool ShowGrid { get; set; }
    public decimal Opacity { get; set; }
}

// Пример использования:
// var chart = ConfigureChart("Sales Report", ChartType.Bar, width: 1200, colorScheme: "Blue");

// Задача 366: Напишите метод с опциональным параметром для поиска в массиве (начальный индекс)
static bool ContainsAny<T>(T[] array, T[] values, int startIndex = 0, IEqualityComparer<T> comparer = null)
{
    comparer = comparer ?? EqualityComparer<T>.Default;

    for (int i = startIndex; i < array.Length; i++)
    {
        if (values.Any(v => comparer.Equals(array[i], v)))
            return true;
    }

    return false;
}

// Пример использования:
// bool contains = ContainsAny(new int[] {1, 2, 3}, new int[] {3, 4, 5});

// Задача 367: Реализуйте метод с именованными параметрами для создания пользователя
static string RegisterUser(string username, string password, string email, bool sendWelcomeEmail = true, bool requireEmailVerification = true, DateTime? membershipExpires = null, string referralCode = null)
{
    string welcomeEmail = sendWelcomeEmail ? "Welcome email will be sent" : "No welcome email";
    string emailVerification = requireEmailVerification ? "Email verification required" : "No email verification";
    string expiry = membershipExpires.HasValue ? $"Expires: {membershipExpires.Value:yyyy-MM-dd}" : "No expiry";
    string referral = !string.IsNullOrEmpty(referralCode) ? $"Referred by: {referralCode}" : "No referral";

    return $"User: {username} | {welcomeEmail} | {emailVerification} | {expiry} | {referral}";
}

// Пример использования:
// string result = RegisterUser("newuser", "pass123", "user@example.com", membershipExpires: DateTime.Now.AddYears(1));

// Задача 368: Создайте метод с опциональным параметром для вычисления степени числа
static double CalculatePower(double baseNumber, double exponent = 2.0, bool useLogarithm = false)
{
    if (useLogarithm)
        return Math.Exp(exponent * Math.Log(baseNumber));
    else
        return Math.Pow(baseNumber, exponent);
}

// Пример использования:
// double result1 = CalculatePower(2, 3); // 8
// double result2 = CalculatePower(2, 0.5, useLogarithm: true); // √2 ≈ 1.414

// Задача 369: Реализуйте метод с опциональными параметрами для создания файла (путь, расширение)
static string GenerateFileName(string baseName, string extension = "txt", bool includeTimestamp = false, bool includeGuid = false, string prefix = "", string suffix = "")
{
    string timestamp = includeTimestamp ? $"_{DateTime.Now:yyyyMMdd_HHmmss}" : "";
    string guid = includeGuid ? $"_{Guid.NewGuid():N}" : "";

    return $"{prefix}{baseName}{timestamp}{guid}{suffix}.{extension}";
}

// Пример использования:
// string fileName1 = GenerateFileName("report");
// string fileName2 = GenerateFileName("backup", "zip", includeTimestamp: true, includeGuid: true);

// Задача 370: Реализуйте метод с опциональным параметром для вывода сообщения с префиксом
static void StatusMessage(string message, MessageType type = MessageType.Info, bool showIcon = true, bool playSound = false, int duration = 0)
{
    string icon = showIcon ? type switch
    {
        MessageType.Success => "✓",
        MessageType.Warning => "⚠",
        MessageType.Error => "✗",
        MessageType.Info => "ℹ",
        _ => ""
    } : "";

    string sound = playSound ? " [SOUND]" : "";
    string timeout = duration > 0 ? $" (disappears in {duration}ms)" : "";

    Console.WriteLine($"{icon} {message}{sound}{timeout}");
}

enum MessageType { Success, Warning, Error, Info }

// Пример использования:
// StatusMessage("Operation completed", MessageType.Success, playSound: true);

// Задача 371: Напишите метод с опциональным параметром для поиска в массиве (начальный индекс)
static T[] FindAll<T>(T[] array, Predicate<T> match, int startIndex = 0, int count = -1)
{
    count = count == -1 ? array.Length - startIndex : count;
    var results = new List<T>();

    for (int i = startIndex; i < startIndex + count && i < array.Length; i++)
    {
        if (match(array[i]))
            results.Add(array[i]);
    }

    return results.ToArray();
}

// Пример использования:
// var evenNumbers = FindAll(new int[] {1, 2, 3, 4, 5}, x => x % 2 == 0);

// Задача 372: Напишите метод с именованными параметрами для создания отчета (дата, автор, заголовок)
static string GenerateReportHeader(string title, string author, DateTime? generatedDate = null, string department = "General", int pageNumber = 1, bool confidential = false)
{
    generatedDate = generatedDate ?? DateTime.Now;
    string confidentiality = confidential ? "CONFIDENTIAL" : "INTERNAL";

    return $"{confidentiality} | {title} | Author: {author} | Department: {department} | Date: {generatedDate:yyyy-MM-dd} | Page: {pageNumber}";
}

// Пример использования:
// string header = GenerateReportHeader("Q4 Financials", "Jane Smith", department: "Finance", confidential: true);

// Задача 373: Напишите метод с опциональными параметрами для валидации формы
static FormValidationResult ValidateForm(FormData data, bool validateEmail = true, bool validatePhone = true, int minPasswordStrength = 3, bool requireTermsAgreement = true)
{
    var errors = new List<string>();
    var warnings = new List<string>();

    if (validateEmail && !data.Email.Contains("@"))
        errors.Add("Invalid email format");

    if (validatePhone && data.Phone.Length < 10)
        warnings.Add("Phone number seems incomplete");

    if (data.Password.Length < 8)
        errors.Add("Password too short");

    if (requireTermsAgreement && !data.AgreeToTerms)
        errors.Add("Must agree to terms and conditions");

    return new FormValidationResult
    {
        IsValid = errors.Count == 0,
        Errors = errors.ToArray(),
        Warnings = warnings.ToArray()
    };
}

class FormData
{
    public string Email { get; set; }
    public string Phone { get; set; }
    public string Password { get; set; }
    public bool AgreeToTerms { get; set; }
}

class FormValidationResult
{
    public bool IsValid { get; set; }
    public string[] Errors { get; set; }
    public string[] Warnings { get; set; }
}

// Пример использования:
// var result = ValidateForm(new FormData { Email = "test@example.com", Password = "12345678", AgreeToTerms = true });

// Задача 374: Напишите метод с именованными параметрами для создания конфигурации приложения
static SecurityConfig ConfigureSecurity(string appName, bool enableEncryption = true, int passwordMinLength = 8, bool requireSpecialChars = true, int sessionTimeout = 30, bool enable2FA = false)
{
    return new SecurityConfig
    {
        AppName = appName,
        EnableEncryption = enableEncryption,
        PasswordMinLength = passwordMinLength,
        RequireSpecialChars = requireSpecialChars,
        SessionTimeout = sessionTimeout,
        Enable2FA = enable2FA
    };
}

class SecurityConfig
{
    public string AppName { get; set; }
    public bool EnableEncryption { get; set; }
    public int PasswordMinLength { get; set; }
    public bool RequireSpecialChars { get; set; }
    public int SessionTimeout { get; set; }
    public bool Enable2FA { get; set; }
}

// Пример использования:
// var security = ConfigureSecurity("MyApp", passwordMinLength: 12, enable2FA: true);

// Задача 375: Реализуйте метод с именованными параметрами для создания графика (ширина, высота, цвет)
static string RenderChart(string data, ChartOptions options = null)
{
    options = options ?? new ChartOptions();

    return $"Rendering chart: {options.Type} | Size: {options.Width}x{options.Height} | Colors: {options.ColorScheme} | Animation: {options.EnableAnimation}";
}

class ChartOptions
{
    public string Type { get; set; } = "Line";
    public int Width { get; set; } = 800;
    public int Height { get; set; } = 400;
    public string ColorScheme { get; set; } = "Default";
    public bool EnableAnimation { get; set; } = true;
}

// Пример использования:
// string chart = RenderChart("sales_data", new ChartOptions { Type = "Bar", Width = 1200 });

// Задача 376: Напишите метод с именованными параметрами для создания конфигурации приложения
static NotificationConfig SetupNotifications(bool emailEnabled = true, bool smsEnabled = false, bool pushEnabled = true, string emailTemplate = "default", int rateLimit = 100, string timeZone = "UTC")
{
    return new NotificationConfig
    {
        EmailEnabled = emailEnabled,
        SMSEnabled = smsEnabled,
        PushEnabled = pushEnabled,
        EmailTemplate = emailTemplate,
        RateLimit = rateLimit,
        TimeZone = timeZone
    };
}

class NotificationConfig
{
    public bool EmailEnabled { get; set; }
    public bool SMSEnabled { get; set; }
    public bool PushEnabled { get; set; }
    public string EmailTemplate { get; set; }
    public int RateLimit { get; set; }
    public string TimeZone { get; set; }
}

// Пример использования:
// var notifications = SetupNotifications(smsEnabled: true, rateLimit: 500);

// Задача 377: Создайте метод с опциональным параметром для вычисления степени числа
static ComplexNumber Power(ComplexNumber number, int exponent = 1)
{
    if (exponent == 0)
        return new ComplexNumber { Real = 1, Imaginary = 0 };

    ComplexNumber result = number;
    for (int i = 1; i < Math.Abs(exponent); i++)
    {
        result = Multiply(result, number);
    }

    return exponent > 0 ? result : new ComplexNumber { Real = 1 / result.Real, Imaginary = -result.Imaginary / (result.Real * result.Real + result.Imaginary * result.Imaginary) };
}

// Пример использования:
// var result = Power(new ComplexNumber { Real = 1, Imaginary = 1 }, 2);

// Задача 378: Создайте метод с именованными параметрами для расчета стоимости заказа
static PricingResult CalculatePrice(decimal basePrice, string currency = "USD", decimal discount = 0, DiscountType discountType = DiscountType.Percentage, decimal tax = 0, bool includeShipping = true, decimal shippingCost = 5.0m)
{
    decimal finalDiscount = discountType == DiscountType.Percentage ? basePrice * discount / 100 : discount;
    decimal subtotal = basePrice - finalDiscount;
    decimal taxAmount = subtotal * tax / 100;
    decimal shipping = includeShipping ? shippingCost : 0;
    decimal total = subtotal + taxAmount + shipping;

    return new PricingResult
    {
        BasePrice = basePrice,
        Discount = finalDiscount,
        Tax = taxAmount,
        Shipping = shipping,
        Total = total,
        Currency = currency
    };
}

enum DiscountType { Percentage, Fixed }
class PricingResult
{
    public decimal BasePrice { get; set; }
    public decimal Discount { get; set; }
    public decimal Tax { get; set; }
    public decimal Shipping { get; set; }
    public decimal Total { get; set; }
    public string Currency { get; set; }
}

// Пример использования:
// var price = CalculatePrice(100, discount: 10, discountType: DiscountType.Percentage, tax: 8);

// Задача 379: Напишите метод с опциональными параметрами для форматирования строки
static string FormatCurrency(decimal amount, string currencyCode = "USD", int decimalPlaces = 2, bool useSymbol = true, bool useGrouping = true)
{
    var culture = new System.Globalization.CultureInfo("en-US");
    culture.NumberFormat.CurrencySymbol = useSymbol ? GetCurrencySymbol(currencyCode) : currencyCode;
    culture.NumberFormat.CurrencyDecimalDigits = decimalPlaces;
    culture.NumberFormat.CurrencyGroupSeparator = useGrouping ? "," : "";

    return amount.ToString("C", culture);
}

static string GetCurrencySymbol(string code)
{
    return code switch
    {
        "USD" => "$",
        "EUR" => "€",
        "GBP" => "£",
        "JPY" => "¥",
        _ => code
    };
}

// Пример использования:
// string formatted1 = FormatCurrency(1234.56m);
// string formatted2 = FormatCurrency(1234.56m, "EUR", useSymbol: false);

// Задача 380: Реализуйте метод с опциональным параметром для вывода сообщения с префиксом
static void PrintHeader(string title, char borderChar = '=', int padding = 1, ConsoleColor color = ConsoleColor.Cyan, bool center = false)
{
    string border = new string(borderChar, title.Length + padding * 2 + 2);
    string paddedTitle = new string(' ', padding) + title + new string(' ', padding);

    if (center)
    {
        int consoleWidth = Console.WindowWidth;
        border = new string(borderChar, consoleWidth);
        paddedTitle = paddedTitle.PadLeft((consoleWidth + paddedTitle.Length) / 2).PadRight(consoleWidth);
    }

    Console.ForegroundColor = color;
    Console.WriteLine(border);
    Console.WriteLine(paddedTitle);
    Console.WriteLine(border);
    Console.ResetColor();
}

// Пример использования:
// PrintHeader("SYSTEM ADMINISTRATION", '*', 2, ConsoleColor.Yellow);

// Задача 381: Напишите метод с именованными параметрами для создания конфигурации приложения
static ApiConfig ConfigureAPI(string baseUrl, string version = "v1", int timeout = 30, int retryCount = 3, bool enableCaching = true, string authType = "Bearer")
{
    return new ApiConfig
    {
        BaseUrl = baseUrl,
        Version = version,
        Timeout = timeout,
        RetryCount = retryCount,
        EnableCaching = enableCaching,
        AuthType = authType
    };
}

class ApiConfig
{
    public string BaseUrl { get; set; }
    public string Version { get; set; }
    public int Timeout { get; set; }
    public int RetryCount { get; set; }
    public bool EnableCaching { get; set; }
    public string AuthType { get; set; }
}

// Пример использования:
// var apiConfig = ConfigureAPI("https://api.example.com", timeout: 60, retryCount: 5);

// Задача 382: Реализуйте метод с именованными параметрами для создания пользователя
static Employee CreateEmployee(string employeeId, string firstName, string lastName, string department, DateTime hireDate, decimal salary, string position = "Employee", bool isActive = true, string managerId = null)
{
    return new Employee
    {
        EmployeeId = employeeId,
        FirstName = firstName,
        LastName = lastName,
        Department = department,
        HireDate = hireDate,
        Salary = salary,
        Position = position,
        IsActive = isActive,
        ManagerId = managerId
    };
}

class Employee
{
    public string EmployeeId { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Department { get; set; }
    public DateTime HireDate { get; set; }
    public decimal Salary { get; set; }
    public string Position { get; set; }
    public bool IsActive { get; set; }
    public string ManagerId { get; set; }
}

// Пример использования:
// var employee = CreateEmployee("E001", "John", "Doe", "IT", DateTime.Now, 75000, "Senior Developer");

// Задача 383: Напишите метод с именованными параметрами для фильтрации данных
static QueryBuilder BuildQuery(string table, string[] selectColumns = null, string whereClause = null, string orderBy = null, int? limit = null, int? offset = null, bool distinct = false)
{
    selectColumns = selectColumns ?? new string[] { "*" };

    return new QueryBuilder
    {
        Table = table,
        SelectColumns = selectColumns,
        WhereClause = whereClause,
        OrderBy = orderBy,
        Limit = limit,
        Offset = offset,
        Distinct = distinct
    };
}

class QueryBuilder
{
    public string Table { get; set; }
    public string[] SelectColumns { get; set; }
    public string WhereClause { get; set; }
    public string OrderBy { get; set; }
    public int? Limit { get; set; }
    public int? Offset { get; set; }
    public bool Distinct { get; set; }
}

// Пример использования:
// var query = BuildQuery("users", new string[] { "id", "name" }, "active = true", "name ASC", limit: 100);

// Задача 384: Создайте метод с опциональными параметрами для генерации пароля (длина, символы)
static string GenerateMemorablePassword(int wordCount = 4, string separator = "-", bool capitalize = true, bool includeNumbers = true, int numberCount = 2)
{
    string[] words = { "apple", "banana", "cherry", "dragon", "elephant", "flower", "garden", "happy", "island", "jupiter" };
    Random random = new Random();

    var selectedWords = Enumerable.Range(0, wordCount)
        .Select(_ => words[random.Next(words.Length)])
        .ToArray();

    if (capitalize)
        selectedWords = selectedWords.Select(w => char.ToUpper(w[0]) + w.Substring(1)).ToArray();

    string password = string.Join(separator, selectedWords);

    if (includeNumbers)
    {
        string numbers = new string(Enumerable.Range(0, numberCount)
            .Select(_ => (char)('0' + random.Next(10)))
            .ToArray());
        password += separator + numbers;
    }

    return password;
}

// Пример использования:
// string password1 = GenerateMemorablePassword();
// string password2 = GenerateMemorablePassword(3, "_", includeNumbers: false);

// Задача 385: Напишите метод с именованными параметрами для создания конфигурации приложения
static BackupConfig ConfigureBackup(string sourcePath, string destinationPath, BackupType type = BackupType.Full, int retentionDays = 30, bool compress = true, string schedule = "Daily", bool verify = false)
{
    return new BackupConfig
    {
        SourcePath = sourcePath,
        DestinationPath = destinationPath,
        Type = type,
        RetentionDays = retentionDays,
        Compress = compress,
        Schedule = schedule,
        Verify = verify
    };
}

enum BackupType { Full, Incremental, Differential }
class BackupConfig
{
    public string SourcePath { get; set; }
    public string DestinationPath { get; set; }
    public BackupType Type { get; set; }
    public int RetentionDays { get; set; }
    public bool Compress { get; set; }
    public string Schedule { get; set; }
    public bool Verify { get; set; }
}

// Пример использования:
// var backup = ConfigureBackup("C:/Data", "D:/Backup", BackupType.Incremental, retentionDays: 90);

// Задача 386: Реализуйте метод с опциональным параметром для вывода сообщения с префиксом
static void LogProgress(string operation, int current, int total, string unit = "items", bool showPercentage = true, bool showBar = true, int barWidth = 20)
{
    double percentage = (double)current / total;
    string percentText = showPercentage ? $"{percentage:P1}" : "";

    string bar = "";
    if (showBar)
    {
        int filledWidth = (int)(barWidth * percentage);
        bar = "[" + new string('=', filledWidth) + new string(' ', barWidth - filledWidth) + "] ";
    }

    Console.WriteLine($"{operation}: {bar}{current}/{total} {unit} {percentText}");
}

// Пример использования:
// LogProgress("Processing files", 25, 100, showBar: true);

// Задача 387: Реализуйте метод с именованными параметрами для создания графика (ширина, высота, цвет)
static Visualization CreateVisualization(string title, VisualizationType type = VisualizationType.Chart, Theme theme = Theme.Light, bool interactive = true, bool responsive = true, int animationDuration = 1000)
{
    return new Visualization
    {
        Title = title,
        Type = type,
        Theme = theme,
        Interactive = interactive,
        Responsive = responsive,
        AnimationDuration = animationDuration
    };
}

enum VisualizationType { Chart, Graph, Map, Diagram }
enum Theme { Light, Dark, Custom }
class Visualization
{
    public string Title { get; set; }
    public VisualizationType Type { get; set; }
    public Theme Theme { get; set; }
    public bool Interactive { get; set; }
    public bool Responsive { get; set; }
    public int AnimationDuration { get; set; }
}

// Пример использования:
// var viz = CreateVisualization("Sales Overview", VisualizationType.Chart, Theme.Dark);

// Задача 388: Реализуйте метод с опциональным параметром для вывода сообщения с префиксом
static void Alert(string message, AlertLevel level = AlertLevel.Info, bool soundAlert = false, bool flash = false, int repeat = 1)
{
    ConsoleColor color = level switch
    {
        AlertLevel.Success => ConsoleColor.Green,
        AlertLevel.Warning => ConsoleColor.Yellow,
        AlertLevel.Error => ConsoleColor.Red,
        AlertLevel.Info => ConsoleColor.Blue,
        _ => ConsoleColor.White
    };

    string sound = soundAlert ? " [BEEP]" : "";
    string flashText = flash ? " [FLASHING]" : "";
    string repeatText = repeat > 1 ? $" (x{repeat})" : "";

    Console.ForegroundColor = color;
    for (int i = 0; i < repeat; i++)
    {
        Console.WriteLine($"[{level}] {message}{sound}{flashText}{repeatText}");
    }
    Console.ResetColor();
}

enum AlertLevel { Success, Warning, Error, Info }

// Пример использования:
// Alert("System overload detected!", AlertLevel.Error, soundAlert: true, repeat: 3);

// Задача 389: Реализуйте метод с именованными параметрами для создания пользователя
static Customer CreateCustomer(string customerId, string name, string email, CustomerType type = CustomerType.Regular, DateTime? joinDate = null, decimal creditLimit = 1000, bool isActive = true)
{
    joinDate = joinDate ?? DateTime.Now;

    return new Customer
    {
        CustomerId = customerId,
        Name = name,
        Email = email,
        Type = type,
        JoinDate = joinDate.Value,
        CreditLimit = creditLimit,
        IsActive = isActive
    };
}

enum CustomerType { Regular, Premium, VIP }
class Customer
{
    public string CustomerId { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public CustomerType Type { get; set; }
    public DateTime JoinDate { get; set; }
    public decimal CreditLimit { get; set; }
    public bool IsActive { get; set; }
}

// Пример использования:
// var customer = CreateCustomer("C001", "Acme Corp", "contact@acme.com", CustomerType.Premium, creditLimit: 5000);

// Задача 390: Создайте метод с именованными параметрами для отправки email (тема, текст, вложения)
static string ScheduleEmail(string to, string subject, string body, DateTime sendTime, string timeZone = "UTC", bool isRecurring = false, string recurrence = null, int priority = 1)
{
    string recurring = isRecurring ? $" (Recurring: {recurrence})" : "";
    string priorityText = priority > 1 ? $" [PRIORITY {priority}]" : "";

    return $"Scheduled: {sendTime:yyyy-MM-dd HH:mm} {timeZone} | To: {to} | Subject: {subject}{priorityText}{recurring}";
}

// Пример использования:
// string scheduled = ScheduleEmail("team@company.com", "Weekly Report", "Attached...", DateTime.Today.AddDays(1).AddHours(9), isRecurring: true, recurrence: "Weekly");

// Задача 391: Напишите метод с именованными параметрами для фильтрации данных
static SearchCriteria CreateSearch(string query, string[] fields = null, int page = 1, int pageSize = 10, string sortBy = "relevance", bool exactMatch = false, string language = "en")
{
    fields = fields ?? new string[] { "title", "content", "tags" };

    return new SearchCriteria
    {
        Query = query,
        Fields = fields,
        Page = page,
        PageSize = pageSize,
        SortBy = sortBy,
        ExactMatch = exactMatch,
        Language = language
    };
}

class SearchCriteria
{
    public string Query { get; set; }
    public string[] Fields { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
    public string SortBy { get; set; }
    public bool ExactMatch { get; set; }
    public string Language { get; set; }
}

// Пример использования:
// var search = CreateSearch("machine learning", fields: new[] { "title", "abstract" }, pageSize: 20);

// Задача 392: Реализуйте метод с именованными параметрами для создания пользователя
static string CreateAdminUser(string username, string email, string password, AdminLevel level = AdminLevel.Moderator, string[] permissions = null, DateTime? expiryDate = null)
{
    permissions = permissions ?? new string[] { "read", "write" };
    string expiry = expiryDate.HasValue ? $" (Expires: {expiryDate:yyyy-MM-dd})" : " (No expiry)";

    return $"Admin User: {username} | Level: {level} | Permissions: {string.Join(", ", permissions)}{expiry}";
}

enum AdminLevel { Moderator, Administrator, SuperAdmin }

// Пример использования:
// string admin = CreateAdminUser("superuser", "admin@system.com", "secure123", AdminLevel.SuperAdmin, new[] { "read", "write", "delete" });

// Задача 393: Напишите метод с именованными параметрами для фильтрации данных
static FilterOptions ApplyFilters(string baseQuery, DateRange dateRange = null, string[] categories = null, decimal? minPrice = null, decimal? maxPrice = null, string location = null, bool inStockOnly = true)
{
    dateRange = dateRange ?? new DateRange { Start = DateTime.Today.AddMonths(-1), End = DateTime.Today };
    categories = categories ?? Array.Empty<string>();

    return new FilterOptions
    {
        BaseQuery = baseQuery,
        DateRange = dateRange,
        Categories = categories,
        MinPrice = minPrice,
        MaxPrice = maxPrice,
        Location = location,
        InStockOnly = inStockOnly
    };
}

class DateRange
{
    public DateTime Start { get; set; }
    public DateTime End { get; set; }
}

class FilterOptions
{
    public string BaseQuery { get; set; }
    public DateRange DateRange { get; set; }
    public string[] Categories { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public string Location { get; set; }
    public bool InStockOnly { get; set; }
}

// Пример использования:
// var filters = ApplyFilters("products", new DateRange { Start = new DateTime(2024, 1, 1), End = DateTime.Today }, minPrice: 10, maxPrice: 100);

// Задача 394: Создайте метод с опциональными параметрами для подключения к базе данных
static string BuildRedisConnection(string host = "localhost", int port = 6379, string password = null, int database = 0, int timeout = 30, bool ssl = false)
{
    var parts = new List<string>
    {
        $"{host}:{port}",
        $"database={database}",
        $"timeout={timeout}",
        $"ssl={ssl}"
    };

    if (!string.IsNullOrEmpty(password))
        parts.Add($"password={password}");

    return string.Join(",", parts);
}

// Пример использования:
// string redisConn = BuildRedisConnection("redis.server.com", password: "secret", ssl: true);

// Задача 395: Реализуйте метод с именованными параметрами для настройки логирования
static LogConfig SetupApplicationLogs(string appName, string level = "INFO", string[] targets = null, string format = "default", int maxFileSize = 10485760, int maxFiles = 5, bool enableMetrics = false)
{
    targets = targets ?? new string[] { "console", "file" };

    return new LogConfig
    {
        AppName = appName,
        Level = level,
        Targets = targets,
        Format = format,
        MaxFileSize = maxFileSize,
        MaxFiles = maxFiles,
        EnableMetrics = enableMetrics
    };
}

class LogConfig
{
    public string AppName { get; set; }
    public string Level { get; set; }
    public string[] Targets { get; set; }
    public string Format { get; set; }
    public int MaxFileSize { get; set; }
    public int MaxFiles { get; set; }
    public bool EnableMetrics { get; set; }
}

// Пример использования:
// var logConfig = SetupApplicationLogs("MyAPI", level: "DEBUG", targets: new[] { "file", "syslog" });

// Задача 396: Создайте метод с именованными параметрами для расчета стоимости заказа
static Subscription CalculateSubscription(string plan, int users = 1, int duration = 12, bool annualBilling = true, decimal discount = 0, bool includeSupport = true)
{
    decimal basePrice = plan.ToLower() switch
    {
        "basic" => 10,
        "standard" => 25,
        "premium" => 50,
        "enterprise" => 100,
        _ => 0
    };

    decimal total = basePrice * users * duration;
    if (annualBilling) total *= 0.9m; // 10% discount for annual billing
    total -= discount;
    if (includeSupport) total += users * 5;

    return new Subscription
    {
        Plan = plan,
        Users = users,
        Duration = duration,
        Total = total,
        AnnualBilling = annualBilling,
        IncludesSupport = includeSupport
    };
}

class Subscription
{
    public string Plan { get; set; }
    public int Users { get; set; }
    public int Duration { get; set; }
    public decimal Total { get; set; }
    public bool AnnualBilling { get; set; }
    public bool IncludesSupport { get; set; }
}

// Пример использования:
// var subscription = CalculateSubscription("premium", users: 5, duration: 24, annualBilling: true);

// Задача 397: Напишите метод с именованными параметрами для фильтрации данных
static DataQuery BuildDataQuery(string source, string[] columns = null, QueryCondition[] conditions = null, string groupBy = null, string having = null, int? limit = null)
{
    columns = columns ?? new string[] { "*" };
    conditions = conditions ?? Array.Empty<QueryCondition>();

    return new DataQuery
    {
        Source = source,
        Columns = columns,
        Conditions = conditions,
        GroupBy = groupBy,
        Having = having,
        Limit = limit
    };
}

class QueryCondition
{
    public string Column { get; set; }
    public string Operator { get; set; }
    public object Value { get; set; }
}

class DataQuery
{
    public string Source { get; set; }
    public string[] Columns { get; set; }
    public QueryCondition[] Conditions { get; set; }
    public string GroupBy { get; set; }
    public string Having { get; set; }
    public int? Limit { get; set; }
}

// Пример использования:
// var query = BuildDataQuery("sales", new[] { "product", "SUM(amount)" }, groupBy: "product");

// Задача 398: Напишите метод с именованными параметрами для создания конфигурации приложения
static MonitoringConfig SetupMonitoring(string appName, int checkInterval = 60, string[] metrics = null, AlertConfig alerts = null, string dashboardUrl = null, bool enableReports = true)
{
    metrics = metrics ?? new string[] { "cpu", "memory", "disk" };
    alerts = alerts ?? new AlertConfig { Enabled = true, Threshold = 80 };

    return new MonitoringConfig
    {
        AppName = appName,
        CheckInterval = checkInterval,
        Metrics = metrics,
        Alerts = alerts,
        DashboardUrl = dashboardUrl,
        EnableReports = enableReports
    };
}

class AlertConfig
{
    public bool Enabled { get; set; }
    public decimal Threshold { get; set; }
}

class MonitoringConfig
{
    public string AppName { get; set; }
    public int CheckInterval { get; set; }
    public string[] Metrics { get; set; }
    public AlertConfig Alerts { get; set; }
    public string DashboardUrl { get; set; }
    public bool EnableReports { get; set; }
}

// Пример использования:
// var monitoring = SetupMonitoring("WebApp", checkInterval: 30, metrics: new[] { "cpu", "memory", "response_time" });

// Задача 399: Реализуйте метод с именованными параметрами для создания графика (ширина, высота, цвет)
static DashboardWidget CreateWidget(string title, WidgetType type = WidgetType.Chart, int refreshInterval = 300, bool autoRefresh = true, string dataSource = null, string[] filters = null)
{
    filters = filters ?? Array.Empty<string>();

    return new DashboardWidget
    {
        Title = title,
        Type = type,
        RefreshInterval = refreshInterval,
        AutoRefresh = autoRefresh,
        DataSource = dataSource,
        Filters = filters
    };
}

enum WidgetType { Chart, Table, Gauge, Map, KPI }
class DashboardWidget
{
    public string Title { get; set; }
    public WidgetType Type { get; set; }
    public int RefreshInterval { get; set; }
    public bool AutoRefresh { get; set; }
    public string DataSource { get; set; }
    public string[] Filters { get; set; }
}

// Пример использования:
// var widget = CreateWidget("Revenue Trends", WidgetType.Chart, refreshInterval: 60, autoRefresh: true);

// Задача 400: Реализуйте метод с именованными параметрами для построения SQL-запроса
static string BuildComplexQuery(string operation, string table, string[] columns = null, JoinClause[] joins = null, string where = null, string orderBy = null, string groupBy = null, string having = null, int? limit = null, int? offset = null)
{
    columns = columns ?? new string[] { "*" };
    joins = joins ?? Array.Empty<JoinClause>();

    string columnList = string.Join(", ", columns);
    string joinClauses = string.Join(" ", joins.Select(j => $"{j.Type} JOIN {j.Table} ON {j.Condition}"));

    var query = $"{operation} {columnList} FROM {table} {joinClauses}";

    if (!string.IsNullOrEmpty(where)) query += $" WHERE {where}";
    if (!string.IsNullOrEmpty(groupBy)) query += $" GROUP BY {groupBy}";
    if (!string.IsNullOrEmpty(having)) query += $" HAVING {having}";
    if (!string.IsNullOrEmpty(orderBy)) query += $" ORDER BY {orderBy}";
    if (limit.HasValue) query += $" LIMIT {limit.Value}";
    if (offset.HasValue) query += $" OFFSET {offset.Value}";

    return query;
}

class JoinClause
{
    public string Type { get; set; } // INNER, LEFT, RIGHT, etc.
    public string Table { get; set; }
    public string Condition { get; set; }
}

// Пример использования:
// string query = BuildComplexQuery("SELECT", "users", 
//     new[] { "users.name", "orders.total" },
//     new[] { new JoinClause { Type = "INNER", Table = "orders", Condition = "users.id = orders.user_id" } },
//     "users.active = 1", "orders.total DESC", limit: 100);