﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AdvancedAlgorithmsAndPatterns
{
    #region Блок 1: Продвинутые алгоритмы

    // 1.1: Задача о рюкзаке (0/1 Knapsack)
    public class KnapsackSolver
    {
        public static (int maxValue, List<int> items) Solve01Knapsack(int[] weights, int[] values, int capacity)
        {
            int n = weights.Length;
            int[,] dp = new int[n + 1, capacity + 1];

            // Заполнение DP таблицы
            for (int i = 1; i <= n; i++)
            {
                for (int w = 0; w <= capacity; w++)
                {
                    if (weights[i - 1] <= w)
                    {
                        dp[i, w] = Math.Max(
                            dp[i - 1, w],
                            dp[i - 1, w - weights[i - 1]] + values[i - 1]
                        );
                    }
                    else
                    {
                        dp[i, w] = dp[i - 1, w];
                    }
                }
            }

            // Восстановление выбранных предметов
            List<int> selectedItems = new List<int>();
            int remainingCapacity = capacity;

            for (int i = n; i > 0 && remainingCapacity > 0; i--)
            {
                if (dp[i, remainingCapacity] != dp[i - 1, remainingCapacity])
                {
                    selectedItems.Add(i - 1);
                    remainingCapacity -= weights[i - 1];
                }
            }

            return (dp[n, capacity], selectedItems);
        }

        // Unbounded knapsack
        public static int SolveUnboundedKnapsack(int[] weights, int[] values, int capacity)
        {
            int[] dp = new int[capacity + 1];

            for (int w = 1; w <= capacity; w++)
            {
                for (int i = 0; i < weights.Length; i++)
                {
                    if (weights[i] <= w)
                    {
                        dp[w] = Math.Max(dp[w], dp[w - weights[i]] + values[i]);
                    }
                }
            }

            return dp[capacity];
        }
    }

    // 1.2: Дерево сегментов с ленивым распространением
    public class SegmentTree
    {
        private int[] tree;
        private int[] lazy;
        private int n;

        public SegmentTree(int[] arr)
        {
            n = arr.Length;
            tree = new int[4 * n];
            lazy = new int[4 * n];
            Build(arr, 1, 0, n - 1);
        }

        private void Build(int[] arr, int node, int start, int end)
        {
            if (start == end)
            {
                tree[node] = arr[start];
            }
            else
            {
                int mid = (start + end) / 2;
                Build(arr, 2 * node, start, mid);
                Build(arr, 2 * node + 1, mid + 1, end);
                tree[node] = tree[2 * node] + tree[2 * node + 1];
            }
        }

        public void UpdateRange(int l, int r, int value)
        {
            UpdateRange(1, 0, n - 1, l, r, value);
        }

        private void UpdateRange(int node, int start, int end, int l, int r, int value)
        {
            if (lazy[node] != 0)
            {
                tree[node] += (end - start + 1) * lazy[node];
                if (start != end)
                {
                    lazy[2 * node] += lazy[node];
                    lazy[2 * node + 1] += lazy[node];
                }
                lazy[node] = 0;
            }

            if (start > end || start > r || end < l)
                return;

            if (start >= l && end <= r)
            {
                tree[node] += (end - start + 1) * value;
                if (start != end)
                {
                    lazy[2 * node] += value;
                    lazy[2 * node + 1] += value;
                }
                return;
            }

            int mid = (start + end) / 2;
            UpdateRange(2 * node, start, mid, l, r, value);
            UpdateRange(2 * node + 1, mid + 1, end, l, r, value);
            tree[node] = tree[2 * node] + tree[2 * node + 1];
        }

        public int QueryRange(int l, int r)
        {
            return QueryRange(1, 0, n - 1, l, r);
        }

        private int QueryRange(int node, int start, int end, int l, int r)
        {
            if (start > end || start > r || end < l)
                return 0;

            if (lazy[node] != 0)
            {
                tree[node] += (end - start + 1) * lazy[node];
                if (start != end)
                {
                    lazy[2 * node] += lazy[node];
                    lazy[2 * node + 1] += lazy[node];
                }
                lazy[node] = 0;
            }

            if (start >= l && end <= r)
                return tree[node];

            int mid = (start + end) / 2;
            int left = QueryRange(2 * node, start, mid, l, r);
            int right = QueryRange(2 * node + 1, mid + 1, end, l, r);
            return left + right;
        }
    }

    // 1.3: Алгоритм Дейкстры
    public class Dijkstra
    {
        public static (int[] distances, int[] previous) FindShortestPaths(int n, List<(int to, int weight)>[] graph, int start)
        {
            int[] distances = new int[n];
            int[] previous = new int[n];
            bool[] visited = new bool[n];

            for (int i = 0; i < n; i++)
            {
                distances[i] = int.MaxValue;
                previous[i] = -1;
            }
            distances[start] = 0;

            var priorityQueue = new SortedSet<(int distance, int node)>(
                Comparer<(int distance, int node)>.Create((a, b) =>
                    a.distance == b.distance ? a.node.CompareTo(b.node) : a.distance.CompareTo(b.distance)));

            priorityQueue.Add((0, start));

            while (priorityQueue.Count > 0)
            {
                var current = priorityQueue.Min;
                priorityQueue.Remove(current);
                int u = current.node;

                if (visited[u]) continue;
                visited[u] = true;

                foreach (var edge in graph[u])
                {
                    int v = edge.to;
                    int alt = distances[u] + edge.weight;

                    if (alt < distances[v])
                    {
                        distances[v] = alt;
                        previous[v] = u;
                        priorityQueue.Add((alt, v));
                    }
                }
            }

            return (distances, previous);
        }

        public static List<List<int>> GetAllShortestPaths(int[] previous, int target)
        {
            var allPaths = new List<List<int>>();
            ReconstructPaths(previous, target, new List<int>(), allPaths);
            return allPaths;
        }

        private static void ReconstructPaths(int[] previous, int current, List<int> path, List<List<int>> allPaths)
        {
            path.Insert(0, current);

            if (previous[current] == -1)
            {
                allPaths.Add(new List<int>(path));
            }
            else
            {
                ReconstructPaths(previous, previous[current], path, allPaths);
            }

            path.RemoveAt(0);
        }
    }

    // 1.4: Система непересекающихся множеств (Union-Find)
    public class UnionFind
    {
        private int[] parent;
        private int[] rank;
        private int[] size;

        public UnionFind(int n)
        {
            parent = new int[n];
            rank = new int[n];
            size = new int[n];

            for (int i = 0; i < n; i++)
            {
                parent[i] = i;
                rank[i] = 0;
                size[i] = 1;
            }
        }

        public int Find(int x)
        {
            if (parent[x] != x)
                parent[x] = Find(parent[x]); // Path compression
            return parent[x];
        }

        public void Union(int x, int y)
        {
            int rootX = Find(x);
            int rootY = Find(y);

            if (rootX != rootY)
            {
                // Union by rank
                if (rank[rootX] < rank[rootY])
                {
                    parent[rootX] = rootY;
                    size[rootY] += size[rootX];
                }
                else if (rank[rootX] > rank[rootY])
                {
                    parent[rootY] = rootX;
                    size[rootX] += size[rootY];
                }
                else
                {
                    parent[rootY] = rootX;
                    rank[rootX]++;
                    size[rootX] += size[rootY];
                }
            }
        }

        public bool Connected(int x, int y) => Find(x) == Find(y);
        public int GetSize(int x) => size[Find(x)];
    }

    #endregion

    #region Блок 2: Продвинутое ООП

    // 2.1: Паттерн Observer с обработкой исключений
    public interface IObserver<T>
    {
        void OnNext(T value);
        void OnError(Exception error);
        void OnCompleted();
    }

    public interface IObservable<T>
    {
        IDisposable Subscribe(IObserver<T> observer);
    }

    public class Subject<T> : IObservable<T>, IObserver<T>
    {
        private readonly List<IObserver<T>> observers = new List<IObserver<T>>();
        private bool isCompleted = false;

        public IDisposable Subscribe(IObserver<T> observer)
        {
            if (!observers.Contains(observer))
                observers.Add(observer);

            return new Unsubscriber(observers, observer);
        }

        public void OnNext(T value)
        {
            if (isCompleted) return;

            foreach (var observer in observers.ToArray())
            {
                try
                {
                    observer.OnNext(value);
                }
                catch (Exception ex)
                {
                    observer.OnError(ex);
                }
            }
        }

        public void OnError(Exception error)
        {
            foreach (var observer in observers.ToArray())
            {
                observer.OnError(error);
            }
        }

        public void OnCompleted()
        {
            isCompleted = true;
            foreach (var observer in observers.ToArray())
            {
                observer.OnCompleted();
            }
            observers.Clear();
        }

        private class Unsubscriber : IDisposable
        {
            private List<IObserver<T>> observers;
            private IObserver<T> observer;

            public Unsubscriber(List<IObserver<T>> observers, IObserver<T> observer)
            {
                this.observers = observers;
                this.observer = observer;
            }

            public void Dispose()
            {
                if (observer != null && observers.Contains(observer))
                    observers.Remove(observer);
            }
        }
    }

    // 2.2: Паттерн Decorator
    public interface IDataService
    {
        string GetData(string key);
        void SaveData(string key, string data);
    }

    public class BasicDataService : IDataService
    {
        private Dictionary<string, string> storage = new Dictionary<string, string>();

        public string GetData(string key)
        {
            Console.WriteLine($"Getting data for key: {key}");
            return storage.TryGetValue(key, out var data) ? data : null;
        }

        public void SaveData(string key, string data)
        {
            Console.WriteLine($"Saving data for key: {key}");
            storage[key] = data;
        }
    }

    public class LoggingDecorator : IDataService
    {
        private readonly IDataService wrapped;
        private readonly ILogger logger;

        public LoggingDecorator(IDataService wrapped, ILogger logger)
        {
            this.wrapped = wrapped;
            this.logger = logger;
        }

        public string GetData(string key)
        {
            logger.Log($"Getting data for key: {key}");
            var stopwatch = Stopwatch.StartNew();

            try
            {
                var result = wrapped.GetData(key);
                stopwatch.Stop();
                logger.Log($"Successfully got data for key: {key} in {stopwatch.ElapsedMilliseconds}ms");
                return result;
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                logger.Log($"Error getting data for key: {key} - {ex.Message}");
                throw;
            }
        }

        public void SaveData(string key, string data)
        {
            logger.Log($"Saving data for key: {key}");
            var stopwatch = Stopwatch.StartNew();

            try
            {
                wrapped.SaveData(key, data);
                stopwatch.Stop();
                logger.Log($"Successfully saved data for key: {key} in {stopwatch.ElapsedMilliseconds}ms");
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                logger.Log($"Error saving data for key: {key} - {ex.Message}");
                throw;
            }
        }
    }

    public interface ILogger
    {
        void Log(string message);
    }

    public class ConsoleLogger : ILogger
    {
        public void Log(string message)
        {
            Console.WriteLine($"[LOG] {DateTime.Now:HH:mm:ss.fff}: {message}");
        }
    }

    // 2.3: Паттерн Strategy
    public interface ISortStrategy<T>
    {
        void Sort(T[] array);
    }

    public class QuickSortStrategy<T> : ISortStrategy<T> where T : IComparable<T>
    {
        public void Sort(T[] array)
        {
            QuickSort(array, 0, array.Length - 1);
        }

        private void QuickSort(T[] array, int left, int right)
        {
            if (left < right)
            {
                int pivot = Partition(array, left, right);
                QuickSort(array, left, pivot - 1);
                QuickSort(array, pivot + 1, right);
            }
        }

        private int Partition(T[] array, int left, int right)
        {
            T pivot = array[right];
            int i = left - 1;

            for (int j = left; j < right; j++)
            {
                if (array[j].CompareTo(pivot) <= 0)
                {
                    i++;
                    Swap(array, i, j);
                }
            }

            Swap(array, i + 1, right);
            return i + 1;
        }

        private void Swap(T[] array, int i, int j)
        {
            (array[i], array[j]) = (array[j], array[i]);
        }
    }

    public class MergeSortStrategy<T> : ISortStrategy<T> where T : IComparable<T>
    {
        public void Sort(T[] array)
        {
            MergeSort(array, 0, array.Length - 1);
        }

        private void MergeSort(T[] array, int left, int right)
        {
            if (left < right)
            {
                int mid = (left + right) / 2;
                MergeSort(array, left, mid);
                MergeSort(array, mid + 1, right);
                Merge(array, left, mid, right);
            }
        }

        private void Merge(T[] array, int left, int mid, int right)
        {
            int n1 = mid - left + 1;
            int n2 = right - mid;

            T[] leftArray = new T[n1];
            T[] rightArray = new T[n2];

            Array.Copy(array, left, leftArray, 0, n1);
            Array.Copy(array, mid + 1, rightArray, 0, n2);

            int i = 0, j = 0, k = left;

            while (i < n1 && j < n2)
            {
                if (leftArray[i].CompareTo(rightArray[j]) <= 0)
                {
                    array[k] = leftArray[i];
                    i++;
                }
                else
                {
                    array[k] = rightArray[j];
                    j++;
                }
                k++;
            }

            while (i < n1)
            {
                array[k] = leftArray[i];
                i++;
                k++;
            }

            while (j < n2)
            {
                array[k] = rightArray[j];
                j++;
                k++;
            }
        }
    }

    public class Sorter<T> where T : IComparable<T>
    {
        private ISortStrategy<T> strategy;

        public Sorter(ISortStrategy<T> strategy)
        {
            this.strategy = strategy;
        }

        public void SetStrategy(ISortStrategy<T> newStrategy)
        {
            this.strategy = newStrategy;
        }

        public void Sort(T[] array)
        {
            strategy.Sort(array);
        }
    }

    #endregion

    #region Блок 3: Асинхронность и многопоточность

    // 3.1: Потокобезопасный кэш
    public class ThreadSafeCache<TKey, TValue>
    {
        private readonly Dictionary<TKey, TValue> cache = new Dictionary<TKey, TValue>();
        private readonly ReaderWriterLockSlim lockSlim = new ReaderWriterLockSlim();
        private readonly int maxSize;
        private readonly LinkedList<TKey> accessOrder = new LinkedList<TKey>();

        public ThreadSafeCache(int maxSize = 1000)
        {
            this.maxSize = maxSize;
        }

        public bool TryGet(TKey key, out TValue value)
        {
            lockSlim.EnterReadLock();
            try
            {
                if (cache.TryGetValue(key, out value))
                {
                    // Обновляем порядок доступа
                    lock (accessOrder)
                    {
                        accessOrder.Remove(key);
                        accessOrder.AddFirst(key);
                    }
                    return true;
                }
                value = default(TValue);
                return false;
            }
            finally
            {
                lockSlim.ExitReadLock();
            }
        }

        public void Set(TKey key, TValue value)
        {
            lockSlim.EnterWriteLock();
            try
            {
                if (cache.Count >= maxSize)
                {
                    // Удаляем самый старый элемент (LRU)
                    var oldestKey = accessOrder.Last.Value;
                    cache.Remove(oldestKey);
                    accessOrder.RemoveLast();
                }

                cache[key] = value;
                accessOrder.AddFirst(key);
            }
            finally
            {
                lockSlim.ExitWriteLock();
            }
        }

        public bool Remove(TKey key)
        {
            lockSlim.EnterWriteLock();
            try
            {
                bool removed = cache.Remove(key);
                if (removed)
                {
                    lock (accessOrder)
                    {
                        accessOrder.Remove(key);
                    }
                }
                return removed;
            }
            finally
            {
                lockSlim.ExitWriteLock();
            }
        }

        public void Clear()
        {
            lockSlim.EnterWriteLock();
            try
            {
                cache.Clear();
                accessOrder.Clear();
            }
            finally
            {
                lockSlim.ExitWriteLock();
            }
        }
    }

    // 3.2: Producer-Consumer паттерн
    public class ProducerConsumer<T>
    {
        private readonly BlockingCollection<T> queue = new BlockingCollection<T>(new ConcurrentQueue<T>());
        private readonly List<Task> consumerTasks = new List<Task>();
        private readonly CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

        public ProducerConsumer(int consumerCount, Action<T> processItem)
        {
            for (int i = 0; i < consumerCount; i++)
            {
                consumerTasks.Add(Task.Run(() => Consume(processItem)));
            }
        }

        public void Produce(T item)
        {
            queue.Add(item);
        }

        private void Consume(Action<T> processItem)
        {
            foreach (var item in queue.GetConsumingEnumerable(cancellationTokenSource.Token))
            {
                try
                {
                    processItem(item);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error processing item: {ex.Message}");
                }
            }
        }

        public void Stop()
        {
            queue.CompleteAdding();
            cancellationTokenSource.Cancel();
            Task.WaitAll(consumerTasks.ToArray());
        }
    }

    #endregion

    #region Блок 4: Продвинутые алгоритмы строк

    // 4.1: Расстояние Левенштейна
    public class LevenshteinDistance
    {
        public static int Calculate(string s1, string s2)
        {
            int[,] dp = new int[s1.Length + 1, s2.Length + 1];

            for (int i = 0; i <= s1.Length; i++)
                dp[i, 0] = i;

            for (int j = 0; j <= s2.Length; j++)
                dp[0, j] = j;

            for (int i = 1; i <= s1.Length; i++)
            {
                for (int j = 1; j <= s2.Length; j++)
                {
                    int cost = (s1[i - 1] == s2[j - 1]) ? 0 : 1;

                    dp[i, j] = Math.Min(
                        Math.Min(dp[i - 1, j] + 1,     // удаление
                                dp[i, j - 1] + 1),     // вставка
                        dp[i - 1, j - 1] + cost        // замена
                    );
                }
            }

            return dp[s1.Length, s2.Length];
        }

        public static List<string> GetEditOperations(string s1, string s2)
        {
            var operations = new List<string>();
            int i = s1.Length;
            int j = s2.Length;

            while (i > 0 || j > 0)
            {
                if (i > 0 && j > 0 && s1[i - 1] == s2[j - 1])
                {
                    operations.Add($"Keep '{s1[i - 1]}'");
                    i--;
                    j--;
                }
                else
                {
                    int delete = (i > 0) ? Calculate(s1.Substring(0, i - 1), s2.Substring(0, j)) : int.MaxValue;
                    int insert = (j > 0) ? Calculate(s1.Substring(0, i), s2.Substring(0, j - 1)) : int.MaxValue;
                    int replace = (i > 0 && j > 0) ? Calculate(s1.Substring(0, i - 1), s2.Substring(0, j - 1)) : int.MaxValue;

                    int min = Math.Min(Math.Min(delete, insert), replace);

                    if (min == delete)
                    {
                        operations.Add($"Delete '{s1[i - 1]}'");
                        i--;
                    }
                    else if (min == insert)
                    {
                        operations.Add($"Insert '{s2[j - 1]}'");
                        j--;
                    }
                    else
                    {
                        operations.Add($"Replace '{s1[i - 1]}' with '{s2[j - 1]}'");
                        i--;
                        j--;
                    }
                }
            }

            operations.Reverse();
            return operations;
        }
    }

    // 4.2: Алгоритм KMP
    public class KMPAlgorithm
    {
        public static int[] BuildFailureFunction(string pattern)
        {
            int[] lps = new int[pattern.Length];
            int length = 0;
            int i = 1;

            while (i < pattern.Length)
            {
                if (pattern[i] == pattern[length])
                {
                    length++;
                    lps[i] = length;
                    i++;
                }
                else
                {
                    if (length != 0)
                    {
                        length = lps[length - 1];
                    }
                    else
                    {
                        lps[i] = 0;
                        i++;
                    }
                }
            }

            return lps;
        }

        public static List<int> Search(string text, string pattern)
        {
            var occurrences = new List<int>();
            int[] lps = BuildFailureFunction(pattern);
            int i = 0; // индекс для text
            int j = 0; // индекс для pattern

            while (i < text.Length)
            {
                if (pattern[j] == text[i])
                {
                    i++;
                    j++;
                }

                if (j == pattern.Length)
                {
                    occurrences.Add(i - j);
                    j = lps[j - 1];
                }
                else if (i < text.Length && pattern[j] != text[i])
                {
                    if (j != 0)
                        j = lps[j - 1];
                    else
                        i++;
                }
            }

            return occurrences;
        }
    }

    #endregion

    #region Блок 5: Архитектура и производительность

    // 5.1: Система логирования
    public enum LogLevel
    {
        Debug,
        Info,
        Warning,
        Error,
        Critical
    }

    public interface ILogWriter
    {
        Task WriteAsync(LogEntry entry);
    }

    public class LogEntry
    {
        public DateTime Timestamp { get; set; }
        public LogLevel Level { get; set; }
        public string Message { get; set; }
        public string Category { get; set; }
        public Exception Exception { get; set; }

        public override string ToString()
        {
            return $"{Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{Level}] {Category}: {Message}" +
                   (Exception != null ? $" | Exception: {Exception.Message}" : "");
        }
    }

    public class AsyncLogger
    {
        private readonly List<ILogWriter> writers = new List<ILogWriter>();
        private readonly Queue<LogEntry> logQueue = new Queue<LogEntry>();
        private readonly SemaphoreSlim semaphore = new SemaphoreSlim(1);
        private readonly CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        private readonly Task processingTask;

        public AsyncLogger()
        {
            processingTask = Task.Run(ProcessLogs);
        }

        public void AddWriter(ILogWriter writer)
        {
            writers.Add(writer);
        }

        public void Log(LogLevel level, string category, string message, Exception exception = null)
        {
            var entry = new LogEntry
            {
                Timestamp = DateTime.Now,
                Level = level,
                Category = category,
                Message = message,
                Exception = exception
            };

            logQueue.Enqueue(entry);
        }

        private async Task ProcessLogs()
        {
            while (!cancellationTokenSource.Token.IsCancellationRequested)
            {
                if (logQueue.Count > 0)
                {
                    await semaphore.WaitAsync();
                    try
                    {
                        var tasks = new List<Task>();
                        while (logQueue.Count > 0)
                        {
                            var entry = logQueue.Dequeue();
                            foreach (var writer in writers)
                            {
                                tasks.Add(writer.WriteAsync(entry));
                            }
                        }
                        await Task.WhenAll(tasks);
                    }
                    finally
                    {
                        semaphore.Release();
                    }
                }
                await Task.Delay(100);
            }
        }

        public async Task StopAsync()
        {
            cancellationTokenSource.Cancel();
            await processingTask;
        }
    }

    public class FileLogWriter : ILogWriter
    {
        private readonly string filePath;
        private readonly StreamWriter writer;

        public FileLogWriter(string filePath)
        {
            this.filePath = filePath;
            writer = new StreamWriter(filePath, true);
        }

        public async Task WriteAsync(LogEntry entry)
        {
            await writer.WriteLineAsync(entry.ToString());
            await writer.FlushAsync();
        }

        public void Dispose()
        {
            writer?.Dispose();
        }
    }

    // 5.2: Система кэширования
    [AttributeUsage(AttributeTargets.Method)]
    public class MemoizeAttribute : Attribute
    {
        public int TimeToLiveSeconds { get; set; } = 300;
    }

    public class Memoizer
    {
        private readonly Dictionary<string, (object value, DateTime expiry)> cache = new Dictionary<string, (object, DateTime)>();
        private readonly ReaderWriterLockSlim cacheLock = new ReaderWriterLockSlim();

        public T Memoize<T>(string key, Func<T> func, int timeToLiveSeconds = 300)
        {
            cacheLock.EnterReadLock();
            try
            {
                if (cache.TryGetValue(key, out var cached) && cached.expiry > DateTime.Now)
                {
                    return (T)cached.value;
                }
            }
            finally
            {
                cacheLock.ExitReadLock();
            }

            var result = func();

            cacheLock.EnterWriteLock();
            try
            {
                cache[key] = (result, DateTime.Now.AddSeconds(timeToLiveSeconds));
            }
            finally
            {
                cacheLock.ExitWriteLock();
            }

            return result;
        }

        public void Invalidate(string key)
        {
            cacheLock.EnterWriteLock();
            try
            {
                cache.Remove(key);
            }
            finally
            {
                cacheLock.ExitWriteLock();
            }
        }

        public void Clear()
        {
            cacheLock.EnterWriteLock();
            try
            {
                cache.Clear();
            }
            finally
            {
                cacheLock.ExitWriteLock();
            }
        }
    }

    #endregion

    #region Блок 6: Криптография и безопасность

    // 6.1: Хеширование паролей
    public class PasswordHasher
    {
        private const int SaltSize = 16;
        private const int HashSize = 32;
        private const int Iterations = 100000;

        public string HashPassword(string password)
        {
            // Генерация случайной соли
            byte[] salt = new byte[SaltSize];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }

            // Создание хеша
            byte[] hash = PBKDF2(password, salt, Iterations, HashSize);

            // Комбинирование соли и хеша
            byte[] hashBytes = new byte[SaltSize + HashSize];
            Array.Copy(salt, 0, hashBytes, 0, SaltSize);
            Array.Copy(hash, 0, hashBytes, SaltSize, HashSize);

            return Convert.ToBase64String(hashBytes);
        }

        public bool VerifyPassword(string password, string hashedPassword)
        {
            byte[] hashBytes = Convert.FromBase64String(hashedPassword);

            // Извлечение соли
            byte[] salt = new byte[SaltSize];
            Array.Copy(hashBytes, 0, salt, 0, SaltSize);

            // Извлечение хеша
            byte[] storedHash = new byte[HashSize];
            Array.Copy(hashBytes, SaltSize, storedHash, 0, HashSize);

            // Создание хеша для проверки
            byte[] computedHash = PBKDF2(password, salt, Iterations, HashSize);

            // Сравнение хешей
            return SlowEquals(storedHash, computedHash);
        }

        private byte[] PBKDF2(string password, byte[] salt, int iterations, int outputBytes)
        {
            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations, HashAlgorithmName.SHA256))
            {
                return pbkdf2.GetBytes(outputBytes);
            }
        }

        private bool SlowEquals(byte[] a, byte[] b)
        {
            uint diff = (uint)a.Length ^ (uint)b.Length;
            for (int i = 0; i < a.Length && i < b.Length; i++)
            {
                diff |= (uint)(a[i] ^ b[i]);
            }
            return diff == 0;
        }
    }

    // 6.2: AES шифрование
    public class AesEncryption
    {
        public static (string cipherText, string iv) Encrypt(string plainText, string key)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.GenerateIV();

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (var ms = new MemoryStream())
                {
                    using (var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    using (var sw = new StreamWriter(cs))
                    {
                        sw.Write(plainText);
                    }

                    byte[] encrypted = ms.ToArray();
                    return (Convert.ToBase64String(encrypted), Convert.ToBase64String(aes.IV));
                }
            }
        }

        public static string Decrypt(string cipherText, string key, string iv)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.IV = Convert.FromBase64String(iv);

                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (var ms = new MemoryStream(Convert.FromBase64String(cipherText)))
                using (var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                using (var sr = new StreamReader(cs))
                {
                    return sr.ReadToEnd();
                }
            }
        }
    }

    #endregion

    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("🚀 ПРОДВИНУТЫЕ АЛГОРИТМЫ И ПАТТЕРНЫ - ДЕМОНСТРАЦИЯ\n");

            // 1.1: Задача о рюкзаке
            Console.WriteLine("1.1 ЗАДАЧА О РЮКЗАКЕ:");
            int[] weights = { 2, 3, 4, 5 };
            int[] values = { 3, 4, 5, 6 };
            int capacity = 5;

            var (maxValue, items) = KnapsackSolver.Solve01Knapsack(weights, values, capacity);
            Console.WriteLine($"Максимальная стоимость: {maxValue}");
            Console.WriteLine($"Выбранные предметы: [{string.Join(", ", items)}]");

            // 1.2: Дерево сегментов
            Console.WriteLine("\n1.2 ДЕРЕВО СЕГМЕНТОВ:");
            int[] arr = { 1, 3, 5, 7, 9, 11 };
            var segTree = new SegmentTree(arr);
            Console.WriteLine($"Сумма [1, 3]: {segTree.QueryRange(1, 3)}");
            segTree.UpdateRange(1, 4, 2);
            Console.WriteLine($"Сумма [1, 3] после обновления: {segTree.QueryRange(1, 3)}");

            // 1.3: Алгоритм Дейкстры
            Console.WriteLine("\n1.3 АЛГОРИТМ ДЕЙКСТРЫ:");
            int n = 5;
            var graph = new List<(int to, int weight)>[n];
            for (int i = 0; i < n; i++) graph[i] = new List<(int, int)>();

            graph[0].Add((1, 4));
            graph[0].Add((2, 1));
            graph[1].Add((3, 1));
            graph[2].Add((1, 2));
            graph[2].Add((3, 5));
            graph[3].Add((4, 3));

            var (distances, previous) = Dijkstra.FindShortestPaths(n, graph, 0);
            Console.WriteLine("Расстояния: " + string.Join(", ", distances));

            var paths = Dijkstra.GetAllShortestPaths(previous, 4);
            Console.WriteLine("Пути до вершины 4:");
            foreach (var path in paths)
            {
                Console.WriteLine($"  {string.Join(" -> ", path)}");
            }

            // 1.4: Union-Find
            Console.WriteLine("\n1.4 UNION-FIND:");
            var uf = new UnionFind(5);
            uf.Union(0, 1);
            uf.Union(2, 3);
            uf.Union(1, 4);
            Console.WriteLine($"0 и 4 соединены: {uf.Connected(0, 4)}");
            Console.WriteLine($"0 и 2 соединены: {uf.Connected(0, 2)}");

            // 2.1: Паттерн Observer
            Console.WriteLine("\n2.1 ПАТТЕРН OBSERVER:");
            var subject = new Subject<int>();
            var observer = new SimpleObserver<int>();
            subject.Subscribe(observer);
            subject.OnNext(1);
            subject.OnNext(2);
            subject.OnCompleted();

            // 2.2: Паттерн Decorator
            Console.WriteLine("\n2.2 ПАТТЕРН DECORATOR:");
            IDataService basicService = new BasicDataService();
            IDataService loggedService = new LoggingDecorator(basicService, new ConsoleLogger());
            loggedService.SaveData("test", "value");
            var result = loggedService.GetData("test");
            Console.WriteLine($"Полученные данные: {result}");

            // 2.3: Паттерн Strategy
            Console.WriteLine("\n2.3 ПАТТЕРН STRATEGY:");
            int[] numbers = { 5, 2, 8, 1, 9 };
            var sorter = new Sorter<int>(new QuickSortStrategy<int>());
            sorter.Sort(numbers);
            Console.WriteLine($"Быстрая сортировка: {string.Join(", ", numbers)}");

            sorter.SetStrategy(new MergeSortStrategy<int>());
            sorter.Sort(numbers);
            Console.WriteLine($"Сортировка слиянием: {string.Join(", ", numbers)}");

            // 3.1: Потокобезопасный кэш
            Console.WriteLine("\n3.1 ПОТОКОБЕЗОПАСНЫЙ КЭШ:");
            var cache = new ThreadSafeCache<string, int>();
            cache.Set("a", 1);
            cache.Set("b", 2);
            if (cache.TryGet("a", out int value))
            {
                Console.WriteLine($"Значение из кэша: {value}");
            }

            // 4.1: Расстояние Левенштейна
            Console.WriteLine("\n4.1 РАССТОЯНИЕ ЛЕВЕНШТЕЙНА:");
            string s1 = "kitten";
            string s2 = "sitting";
            int distance = LevenshteinDistance.Calculate(s1, s2);
            Console.WriteLine($"Расстояние между '{s1}' и '{s2}': {distance}");

            var operations = LevenshteinDistance.GetEditOperations(s1, s2);
            Console.WriteLine("Операции редактирования:");
            foreach (var op in operations)
            {
                Console.WriteLine($"  {op}");
            }

            // 4.2: Алгоритм KMP
            Console.WriteLine("\n4.2 АЛГОРИТМ KMP:");
            string text = "ABABDABACDABABCABAB";
            string pattern = "ABABCABAB";
            var occurrences = KMPAlgorithm.Search(text, pattern);
            Console.WriteLine($"Вхождения '{pattern}' в '{text}': [{string.Join(", ", occurrences)}]");

            // 6.1: Хеширование паролей
            Console.WriteLine("\n6.1 ХЕШИРОВАНИЕ ПАРОЛЕЙ:");
            var hasher = new PasswordHasher();
            string password = "mySecurePassword123";
            string hashed = hasher.HashPassword(password);
            Console.WriteLine($"Хеш пароля: {hashed}");
            bool isValid = hasher.VerifyPassword(password, hashed);
            Console.WriteLine($"Пароль верифицирован: {isValid}");

            // 6.2: AES шифрование
            Console.WriteLine("\n6.2 AES ШИФРОВАНИЕ:");
            string secret = "Confidential data";
            string key = "0123456789ABCDEF0123456789ABCDEF"; // 32 bytes for AES-256
            var (cipherText, iv) = AesEncryption.Encrypt(secret, key);
            string decrypted = AesEncryption.Decrypt(cipherText, key, iv);
            Console.WriteLine($"Исходный текст: {secret}");
            Console.WriteLine($"Зашифрованный: {cipherText}");
            Console.WriteLine($"Расшифрованный: {decrypted}");

            Console.WriteLine("\n🎉 ДЕМОНСТРАЦИЯ ЗАВЕРШЕНА!");
        }
    }

    // Простой Observer для демонстрации
    public class SimpleObserver<T> : IObserver<T>
    {
        public void OnNext(T value)
        {
            Console.WriteLine($"Observer получил: {value}");
        }

        public void OnError(Exception error)
        {
            Console.WriteLine($"Observer получил ошибку: {error.Message}");
        }

        public void OnCompleted()
        {
            Console.WriteLine("Observer завершил работу");
        }
    }
}