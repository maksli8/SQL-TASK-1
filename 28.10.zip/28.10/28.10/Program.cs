﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace OOP_Examples
{
    // Раздел 1: Основы ООП
    class Animal
    {
        public void MakeSound()
        {
            Console.WriteLine("Some sound");
        }
    }

    class Car
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
    }

    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }

        public Person() { }

        public Person(string name, int age)
        {
            Name = name;
            Age = age;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Имя: {Name}, Возраст: {Age}");
        }
    }

    class Rectangle
    {
        public double Width { get; set; }
        public double Height { get; set; }

        public Rectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }

        public double CalculateArea()
        {
            return Width * Height;
        }
    }

    // Раздел 2: Классы и Объекты
    class Dog
    {
        public string Name { get; set; }

        public void Bark()
        {
            Console.WriteLine($"{Name} говорит: Гав-гав!");
        }
    }

    class Employee
    {
        public string Name { get; set; }
        public decimal Salary { get; set; }

        public Employee(string name, decimal salary)
        {
            Name = name;
            Salary = salary;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Сотрудник: {Name}, Зарплата: {Salary:C}");
        }
    }

    // Раздел 3: Члены Класса
    class Calculator
    {
        public int Add(int a, int b)
        {
            return a + b;
        }

        public int Subtract(int a, int b)
        {
            return a - b;
        }

        public int Multiply(int a, int b)
        {
            return a * b;
        }

        public double Divide(int a, int b)
        {
            if (b == 0)
                throw new DivideByZeroException("Деление на ноль невозможно");
            return (double)a / b;
        }
    }

    class StringHelper
    {
        public string Reverse(string s)
        {
            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }

        public bool IsPalindrome(string s)
        {
            string reversed = Reverse(s);
            return s.Equals(reversed, StringComparison.OrdinalIgnoreCase);
        }
    }

    // Раздел 4: Свойства
    class BankAccount
    {
        private decimal balance;

        public string AccountNumber { get; }
        public string Owner { get; set; }

        public decimal Balance
        {
            get { return balance; }
            private set
            {
                if (value >= 0)
                    balance = value;
                else
                    Console.WriteLine("Баланс не может быть отрицательным");
            }
        }

        public BankAccount(string accountNumber, string owner, decimal initialBalance = 0)
        {
            AccountNumber = accountNumber;
            Owner = owner;
            Balance = initialBalance;
        }

        public void Deposit(decimal amount)
        {
            if (amount > 0)
            {
                Balance += amount;
                Console.WriteLine($"Пополнение: {amount:C}. Новый баланс: {Balance:C}");
            }
            else
            {
                Console.WriteLine("Сумма пополнения должна быть положительной");
            }
        }

        public bool Withdraw(decimal amount)
        {
            if (amount > 0 && amount <= Balance)
            {
                Balance -= amount;
                Console.WriteLine($"Снятие: {amount:C}. Новый баланс: {Balance:C}");
                return true;
            }
            else
            {
                Console.WriteLine("Недостаточно средств или неверная сумма");
                return false;
            }
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Счет: {AccountNumber}");
            Console.WriteLine($"Владелец: {Owner}");
            Console.WriteLine($"Баланс: {Balance:C}");
        }
    }

    // Раздел 5: ReadOnly Свойства
    class Student
    {
        public string StudentId { get; }
        public string Name { get; set; }
        public DateTime EnrollmentDate { get; }
        public double GPA { get; set; }

        private List<string> courses;

        public Student(string studentId, string name)
        {
            StudentId = studentId;
            Name = name;
            EnrollmentDate = DateTime.Now;
            GPA = 0.0;
            courses = new List<string>();
        }

        public void AddCourse(string courseName)
        {
            if (!courses.Contains(courseName))
            {
                courses.Add(courseName);
                Console.WriteLine($"Курс '{courseName}' добавлен");
            }
        }

        public void DisplayCourses()
        {
            Console.WriteLine($"Курсы студента {Name}:");
            foreach (var course in courses)
            {
                Console.WriteLine($" - {course}");
            }
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Студент: {Name}");
            Console.WriteLine($"ID: {StudentId}");
            Console.WriteLine($"GPA: {GPA:F2}");
            Console.WriteLine($"Дата зачисления: {EnrollmentDate:yyyy-MM-dd}");
        }
    }

    // Раздел 6: WriteOnly Свойства
    class User
    {
        public string Username { get; set; }
        public string Email { get; set; }

        private string password;

        public string Password
        {
            set
            {
                password = HashPassword(value);
                Console.WriteLine("Пароль установлен");
            }
        }

        private string HashPassword(string plainPassword)
        {
            // Простая имитация хеширования (в реальном приложении используйте надежные методы)
            return Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(plainPassword));
        }

        public bool VerifyPassword(string inputPassword)
        {
            return HashPassword(inputPassword) == password;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Пользователь: {Username}");
            Console.WriteLine($"Email: {Email}");
            // Пароль не отображается - он writeonly
        }
    }

    // Раздел 7: Конструкторы
    class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public int Pages { get; set; }
        public string ISBN { get; }

        public Book(string title, string author, int pages, string isbn)
        {
            Title = title;
            Author = author;
            Pages = pages;
            ISBN = isbn;
        }

        public Book(string title, string author) : this(title, author, 0, "Не указан") { }

        public void DisplayInfo()
        {
            Console.WriteLine($"Книга: '{Title}'");
            Console.WriteLine($"Автор: {Author}");
            Console.WriteLine($"Страниц: {Pages}");
            Console.WriteLine($"ISBN: {ISBN}");
        }
    }

    class Temperature
    {
        public double Celsius { get; set; }

        public double Fahrenheit
        {
            get { return Celsius * 9 / 5 + 32; }
            set { Celsius = (value - 32) * 5 / 9; }
        }

        public Temperature(double celsius)
        {
            Celsius = celsius;
        }

        public void DisplayBothScales()
        {
            Console.WriteLine($"Температура: {Celsius:F1}°C = {Fahrenheit:F1}°F");
        }
    }

    // Утилитарные классы
    class StringValidator
    {
        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        public static bool IsStrongPassword(string password)
        {
            return !string.IsNullOrEmpty(password) &&
                   password.Length >= 8 &&
                   password.Any(char.IsUpper) &&
                   password.Any(char.IsLower) &&
                   password.Any(char.IsDigit);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== ДЕМОНСТРАЦИЯ ООП В C# ===");
            Console.WriteLine();

            // 1. Демонстрация базовых классов
            Console.WriteLine("1. Базовые классы:");
            Console.WriteLine("-------------------");

            Animal animal = new Animal();
            animal.MakeSound();

            Person person = new Person("Иван Иванов", 25);
            person.DisplayInfo();

            Rectangle rect = new Rectangle(5, 10);
            Console.WriteLine($"Прямоугольник: {rect.Width}x{rect.Height}, Площадь: {rect.CalculateArea()}");
            Console.WriteLine();

            // 2. Демонстрация классов с поведением
            Console.WriteLine("2. Классы с поведением:");
            Console.WriteLine("-----------------------");

            Dog dog = new Dog { Name = "Бобик" };
            dog.Bark();

            Employee emp = new Employee("Мария Петрова", 75000);
            emp.DisplayInfo();
            Console.WriteLine();

            // 3. Демонстрация утилитарных классов
            Console.WriteLine("3. Утилитарные классы:");
            Console.WriteLine("----------------------");

            Calculator calc = new Calculator();
            Console.WriteLine($"5 + 3 = {calc.Add(5, 3)}");
            Console.WriteLine($"10 - 4 = {calc.Subtract(10, 4)}");

            StringHelper stringHelper = new StringHelper();
            string testString = "hello";
            Console.WriteLine($"Реверс '{testString}': {stringHelper.Reverse(testString)}");
            Console.WriteLine($"Является ли 'radar' палиндромом: {stringHelper.IsPalindrome("radar")}");
            Console.WriteLine();

            // 4. Демонстрация банковского счета
            Console.WriteLine("4. Банковский счет:");
            Console.WriteLine("-------------------");

            BankAccount account = new BankAccount("ACC123456", "Петр Сидоров", 1000);
            account.DisplayInfo();
            account.Deposit(500);
            account.Withdraw(200);
            account.Withdraw(2000); // Недостаточно средств
            Console.WriteLine();

            // 5. Демонстрация студента с readonly свойствами
            Console.WriteLine("5. Студент (readonly свойства):");
            Console.WriteLine("-------------------------------");

            Student student = new Student("STU001", "Анна Козлова");
            student.GPA = 4.2;
            student.AddCourse("Математика");
            student.AddCourse("Программирование");
            student.AddCourse("Физика");
            student.DisplayInfo();
            student.DisplayCourses();
            Console.WriteLine();

            // 6. Демонстрация пользователя с writeonly свойствами
            Console.WriteLine("6. Пользователь (writeonly свойства):");
            Console.WriteLine("------------------------------------");

            User user = new User { Username = "alex_2024", Email = "alex@example.com" };
            user.Password = "MySecurePassword123"; // Установка пароля
            user.DisplayInfo();
            Console.WriteLine($"Проверка пароля 'wrong': {user.VerifyPassword("wrong")}");
            Console.WriteLine($"Проверка пароля 'MySecurePassword123': {user.VerifyPassword("MySecurePassword123")}");
            Console.WriteLine();

            // 7. Демонстрация книг с конструкторами
            Console.WriteLine("7. Книги (конструкторы):");
            Console.WriteLine("------------------------");

            Book book1 = new Book("Война и мир", "Лев Толстой", 1225, "978-5-389-07464-4");
            Book book2 = new Book("Преступление и наказание", "Федор Достоевский");

            book1.DisplayInfo();
            Console.WriteLine();
            book2.DisplayInfo();
            Console.WriteLine();

            // 8. Демонстрация температуры
            Console.WriteLine("8. Температура:");
            Console.WriteLine("---------------");

            Temperature temp = new Temperature(25);
            temp.DisplayBothScales();

            temp.Fahrenheit = 100;
            temp.DisplayBothScales();
            Console.WriteLine();

            // 9. Демонстрация валидации
            Console.WriteLine("9. Валидация:");
            Console.WriteLine("-------------");

            string[] emails = { "test@example.com", "invalid-email", "another@test.org" };
            string[] passwords = { "Weak", "StrongPass123", "12345678" };

            Console.WriteLine("Проверка email:");
            foreach (string email in emails)
            {
                Console.WriteLine($"  {email}: {(StringValidator.IsValidEmail(email) ? "Valid" : "Invalid")}");
            }

            Console.WriteLine("Проверка паролей:");
            foreach (string password in passwords)
            {
                Console.WriteLine($"  {password}: {(StringValidator.IsStrongPassword(password) ? "Strong" : "Weak")}");
            }
            Console.WriteLine();

            Console.ReadLine();
        }
    }
}