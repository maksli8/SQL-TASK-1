﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.WriteLine("РАЗДЕЛ 1: ЧАСТИЧНЫЕ КЛАССЫ");

        // Демонстрация частичных классов
        Person person = new Person();
        person.Name = "Иван Иванов";
        person.Age = 25;
        person.DisplayInfo();
        Console.WriteLine($"Совершеннолетний: {person.IsAdult()}");

        Calculator calc = new Calculator();
        Console.WriteLine($"5 + 3 = {calc.Add(5, 3)}");
        Console.WriteLine($"5 - 3 = {calc.Subtract(5, 3)}");

        Console.WriteLine("\nРАЗДЕЛ 5: АССОЦИАЦИЯ МЕЖДУ КЛАССАМИ");

        // Создание курсов
        Course math = new Course("Математика", "MATH101", 3);
        Course english = new Course("Английский язык", "ENG101", 3);
        Course history = new Course("История", "HIST101", 2);
        Course physics = new Course("Физика", "PHYS101", 4);

        // Создание студентов
        Student student1 = new Student("Иван Петров", 101);
        Student student2 = new Student("Мария Сидорова", 102);

        // Регистрация студентов на курсы (это вызовет вывод сообщений о зачислении)
        student1.EnrollInCourse(math);
        student1.EnrollInCourse(english);
        student1.EnrollInCourse(physics);

        student2.EnrollInCourse(math);
        student2.EnrollInCourse(history);
        student2.EnrollInCourse(english);

        // Вывод информации о курсах студентов
        student1.DisplayCourses();
        Console.WriteLine($"Всего кредитов: {student1.GetTotalCredits()}");

        student2.DisplayCourses();
        Console.WriteLine($"Всего кредитов: {student2.GetTotalCredits()}");
    }
}

// =============================================
// РАЗДЕЛ 1: ЧАСТИЧНЫЕ КЛАССЫ
// =============================================

// Частичный класс Person - часть 1 (поля)
public partial class Person
{
    private string name;
    private int age;

    public string Name { get => name; set => name = value; }
    public int Age { get => age; set => age = value; }
}

// Частичный класс Person - часть 2 (методы)
public partial class Person
{
    public void DisplayInfo()
    {
        Console.WriteLine($"Имя: {Name}, Возраст: {Age}");
    }

    public bool IsAdult() => Age >= 18;
}

// Частичный класс Calculator - часть 1 (сложение)
public partial class Calculator
{
    public int Add(int a, int b) => a + b;
}

// Частичный класс Calculator - часть 2 (вычитание)
public partial class Calculator
{
    public int Subtract(int a, int b) => a - b;
}

// =============================================
// РАЗДЕЛ 5: АССОЦИАЦИЯ МЕЖДУ КЛАССАМИ
// =============================================

public class Course
{
    public string Name { get; set; }
    public string Code { get; set; }
    public int Credits { get; set; }

    public Course(string name, string code, int credits)
    {
        Name = name;
        Code = code;
        Credits = credits;
    }

    public override string ToString()
    {
        return $"{Name} ({Code}) - {Credits} кредитов";
    }
}

public class Student
{
    public string Name { get; set; }
    public int StudentID { get; set; }

    // Ассоциация - один студент может посещать многие курсы
    private List<Course> enrolledCourses = new List<Course>();

    public Student(string name, int id)
    {
        Name = name;
        StudentID = id;
    }

    public void EnrollInCourse(Course course)
    {
        if (!enrolledCourses.Contains(course))
        {
            enrolledCourses.Add(course);
            // Этот Console.WriteLine даст нужный вывод
            Console.WriteLine($"{Name} зачислен на курс: {course.Name}");
        }
    }

    public void DisplayCourses()
    {
        Console.WriteLine($"\nКурсы студента {Name}:");
        if (enrolledCourses.Count == 0)
        {
            Console.WriteLine("  Нет активных курсов");
            return;
        }

        foreach (Course course in enrolledCourses)
        {
            Console.WriteLine($"  - {course}");
        }
    }

    public int GetTotalCredits()
    {
        int total = 0;
        foreach (Course course in enrolledCourses)
        {
            total += course.Credits;
        }
        return total;
    }
}