﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TransportCompanyManagement
{
    // Перечисление типов транспорта
    public enum VehicleType
    {
        Truck,      // Грузовик
        Minivan,    // Маршрутка
        Car         // Легковой
    }

    // Перечисление статусов доставки
    public enum DeliveryStatus
    {
        Planned,    // Запланирована
        InProgress, // В процессе
        Completed,  // Завершена
        Delayed     // Задержана
    }

    // Класс Транспортное средство
    public class Vehicle
    {
        public int Id { get; set; }
        public string LicensePlate { get; set; }     // Гос. номер
        public VehicleType Type { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public double Capacity { get; set; }         // Грузоподъемность (кг) или пассажировместимость
        public bool IsAvailable { get; set; }
        public double FuelConsumption { get; set; }  // Расход топлива на 100 км

        public Vehicle(int id, string licensePlate, VehicleType type, string model,
                      int year, double capacity, double fuelConsumption)
        {
            Id = id;
            LicensePlate = licensePlate;
            Type = type;
            Model = model;
            Year = year;
            Capacity = capacity;
            FuelConsumption = fuelConsumption;
            IsAvailable = true;
        }

        public override string ToString()
        {
            return $"{Id}: {Type} {Model} ({LicensePlate}), {Year} год, вместимость: {Capacity}";
        }
    }

    // Класс Водитель
    public class Driver
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public string LicenseNumber { get; set; }    // Номер водительских прав
        public DateTime LicenseExpiryDate { get; set; }
        public string PhoneNumber { get; set; }
        public List<VehicleType> AllowedVehicleTypes { get; set; } // Типы ТС, которые может водить
        public bool IsAvailable { get; set; }

        public Driver(int id, string fullName, string licenseNumber,
                     DateTime licenseExpiryDate, string phoneNumber)
        {
            Id = id;
            FullName = fullName;
            LicenseNumber = licenseNumber;
            LicenseExpiryDate = licenseExpiryDate;
            PhoneNumber = phoneNumber;
            AllowedVehicleTypes = new List<VehicleType>();
            IsAvailable = true;
        }

        public bool IsLicenseValid()
        {
            return LicenseExpiryDate > DateTime.Now;
        }

        public override string ToString()
        {
            string status = IsLicenseValid() ? "Действительны" : "Просрочены";
            return $"{Id}: {FullName}, права: {LicenseNumber} ({status})";
        }
    }

    // Класс Маршрут
    public class Route
    {
        public int Id { get; set; }
        public string StartPoint { get; set; }
        public string EndPoint { get; set; }
        public double Distance { get; set; }         // Расстояние в км
        public double EstimatedTime { get; set; }    // Расчетное время в часах
        public decimal RouteCost { get; set; }       // Стоимость маршрута

        public Route(int id, string startPoint, string endPoint,
                    double distance, double estimatedTime, decimal routeCost)
        {
            Id = id;
            StartPoint = startPoint;
            EndPoint = endPoint;
            Distance = distance;
            EstimatedTime = estimatedTime;
            RouteCost = routeCost;
        }

        public override string ToString()
        {
            return $"{Id}: {StartPoint} -> {EndPoint}, {Distance} км, {EstimatedTime} ч, стоимость: {RouteCost} руб.";
        }
    }

    // Класс Доставка
    public class Delivery
    {
        public int Id { get; set; }
        public Route Route { get; set; }
        public Vehicle Vehicle { get; set; }
        public Driver Driver { get; set; }
        public string ClientName { get; set; }
        public string CargoDescription { get; set; }
        public double CargoWeight { get; set; }
        public DateTime PlannedDate { get; set; }
        public DateTime? ActualDate { get; set; }
        public DeliveryStatus Status { get; set; }
        public decimal ClientPayment { get; set; }   // Платеж от клиента
        public decimal Expenses { get; set; }        // Расходы на рейс

        public Delivery(int id, Route route, Vehicle vehicle, Driver driver,
                       string clientName, string cargoDescription, double cargoWeight,
                       DateTime plannedDate, decimal clientPayment)
        {
            Id = id;
            Route = route;
            Vehicle = vehicle;
            Driver = driver;
            ClientName = clientName;
            CargoDescription = cargoDescription;
            CargoWeight = cargoWeight;
            PlannedDate = plannedDate;
            Status = DeliveryStatus.Planned;
            ClientPayment = clientPayment;
            Expenses = 0;
        }

        public decimal CalculateProfit()
        {
            return ClientPayment - Expenses;
        }

        public override string ToString()
        {
            return $"{Id}: {ClientName}, {Route.StartPoint} -> {Route.EndPoint}, статус: {Status}";
        }
    }

    // Класс Расходы
    public class Expense
    {
        public int Id { get; set; }
        public int VehicleId { get; set; }
        public int? DeliveryId { get; set; }         // Может быть null если расход общий
        public ExpenseType Type { get; set; }
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
        public string Description { get; set; }

        public Expense(int id, int vehicleId, int? deliveryId, ExpenseType type,
                      decimal amount, DateTime date, string description)
        {
            Id = id;
            VehicleId = vehicleId;
            DeliveryId = deliveryId;
            Type = type;
            Amount = amount;
            Date = date;
            Description = description;
        }

        public override string ToString()
        {
            string deliveryInfo = DeliveryId.HasValue ? $"Доставка: {DeliveryId}" : "Общий расход";
            return $"{Id}: {Type}, {Amount} руб., {Date.ToShortDateString()}, {deliveryInfo}";
        }
    }

    public enum ExpenseType
    {
        Fuel,           // Топливо
        Maintenance,    // Техобслуживание
        Repair,         // Ремонт
        Insurance,      // Страховка
        Other           // Прочие
    }

    // Основной класс управления транспортной компанией
    public class TransportCompany
    {
        private List<Vehicle> vehicles;
        private List<Driver> drivers;
        private List<Route> routes;
        private List<Delivery> deliveries;
        private List<Expense> expenses;
        private int nextVehicleId = 1;
        private int nextDriverId = 1;
        private int nextRouteId = 1;
        private int nextDeliveryId = 1;
        private int nextExpenseId = 1;

        public TransportCompany()
        {
            vehicles = new List<Vehicle>();
            drivers = new List<Driver>();
            routes = new List<Route>();
            deliveries = new List<Delivery>();
            expenses = new List<Expense>();

            // Инициализация тестовыми данными
            InitializeTestData();
        }

        private void InitializeTestData()
        {
            // Добавляем транспорт
            vehicles.Add(new Vehicle(nextVehicleId++, "А123БВ", VehicleType.Truck, "КАМАЗ 65115",
                2020, 15000, 30));
            vehicles.Add(new Vehicle(nextVehicleId++, "В456ГД", VehicleType.Minivan, "ГАЗель NEXT",
                2021, 12, 12));
            vehicles.Add(new Vehicle(nextVehicleId++, "Е789ЖЗ", VehicleType.Car, "Hyundai Solaris",
                2019, 5, 7));

            // Добавляем водителей
            drivers.Add(new Driver(nextDriverId++, "Иванов Иван Иванович", "1234567890",
                new DateTime(2025, 12, 31), "+7-911-123-45-67"));
            drivers[0].AllowedVehicleTypes.Add(VehicleType.Truck);
            drivers[0].AllowedVehicleTypes.Add(VehicleType.Minivan);

            drivers.Add(new Driver(nextDriverId++, "Петров Петр Петрович", "0987654321",
                new DateTime(2024, 6, 30), "+7-911-987-65-43"));
            drivers[1].AllowedVehicleTypes.Add(VehicleType.Car);
            drivers[1].AllowedVehicleTypes.Add(VehicleType.Minivan);

            // Добавляем маршруты
            routes.Add(new Route(nextRouteId++, "Москва", "Санкт-Петербург", 710, 10, 25000));
            routes.Add(new Route(nextRouteId++, "Москва", "Казань", 815, 12, 30000));
            routes.Add(new Route(nextRouteId++, "Москва", "Владимир", 190, 3, 8000));

            // Добавляем расходы
            expenses.Add(new Expense(nextExpenseId++, 1, null, ExpenseType.Fuel, 15000,
                DateTime.Now.AddDays(-10), "Заправка под полный бак"));
            expenses.Add(new Expense(nextExpenseId++, 2, null, ExpenseType.Maintenance, 8000,
                DateTime.Now.AddDays(-5), "Регламентное ТО"));
        }

        // Управление автопарком
        public void AddVehicle(string licensePlate, VehicleType type, string model,
                              int year, double capacity, double fuelConsumption)
        {
            vehicles.Add(new Vehicle(nextVehicleId++, licensePlate, type, model,
                year, capacity, fuelConsumption));
            Console.WriteLine("Транспортное средство добавлено.");
        }

        public void ShowAllVehicles()
        {
            Console.WriteLine("\n=== Весь автопарк ===");
            foreach (var vehicle in vehicles)
            {
                Console.WriteLine(vehicle);
            }
        }

        public void ShowAvailableVehicles()
        {
            Console.WriteLine("\n=== Доступный транспорт ===");
            var available = vehicles.Where(v => v.IsAvailable).ToList();
            foreach (var vehicle in available)
            {
                Console.WriteLine(vehicle);
            }
        }

        // Управление водителями
        public void AddDriver(string fullName, string licenseNumber,
                            DateTime licenseExpiryDate, string phoneNumber)
        {
            drivers.Add(new Driver(nextDriverId++, fullName, licenseNumber,
                licenseExpiryDate, phoneNumber));
            Console.WriteLine("Водитель добавлен.");
        }

        public void ShowAllDrivers()
        {
            Console.WriteLine("\n=== Все водители ===");
            foreach (var driver in drivers)
            {
                Console.WriteLine(driver);
                Console.WriteLine($"  Может управлять: {string.Join(", ", driver.AllowedVehicleTypes)}");
            }
        }

        public void ShowDriversWithExpiredLicenses()
        {
            Console.WriteLine("\n=== Водители с просроченными правами ===");
            var expired = drivers.Where(d => !d.IsLicenseValid()).ToList();
            foreach (var driver in expired)
            {
                Console.WriteLine(driver);
            }
        }

        // Управление маршрутами
        public void AddRoute(string startPoint, string endPoint,
                           double distance, double estimatedTime, decimal routeCost)
        {
            routes.Add(new Route(nextRouteId++, startPoint, endPoint,
                distance, estimatedTime, routeCost));
            Console.WriteLine("Маршрут добавлен.");
        }

        public void ShowAllRoutes()
        {
            Console.WriteLine("\n=== Все маршруты ===");
            foreach (var route in routes)
            {
                Console.WriteLine(route);
            }
        }

        // Система доставок
        public void CreateDelivery(int routeId, int vehicleId, int driverId,
                                  string clientName, string cargoDescription,
                                  double cargoWeight, DateTime plannedDate, decimal payment)
        {
            var route = routes.FirstOrDefault(r => r.Id == routeId);
            var vehicle = vehicles.FirstOrDefault(v => v.Id == vehicleId);
            var driver = drivers.FirstOrDefault(d => d.Id == driverId);

            if (route == null || vehicle == null || driver == null)
            {
                Console.WriteLine("Ошибка: неверные данные!");
                return;
            }

            if (!vehicle.IsAvailable)
            {
                Console.WriteLine("Ошибка: транспорт занят!");
                return;
            }

            if (!driver.IsAvailable)
            {
                Console.WriteLine("Ошибка: водитель занят!");
                return;
            }

            if (!driver.AllowedVehicleTypes.Contains(vehicle.Type))
            {
                Console.WriteLine("Ошибка: водитель не может управлять данным типом транспорта!");
                return;
            }

            var delivery = new Delivery(nextDeliveryId++, route, vehicle, driver,
                clientName, cargoDescription, cargoWeight, plannedDate, payment);

            deliveries.Add(delivery);
            vehicle.IsAvailable = false;
            driver.IsAvailable = false;

            Console.WriteLine($"Доставка #{delivery.Id} создана!");
        }

        public void StartDelivery(int deliveryId)
        {
            var delivery = deliveries.FirstOrDefault(d => d.Id == deliveryId);
            if (delivery != null && delivery.Status == DeliveryStatus.Planned)
            {
                delivery.Status = DeliveryStatus.InProgress;
                Console.WriteLine($"Доставка #{deliveryId} начата.");
            }
            else
            {
                Console.WriteLine("Не удалось начать доставку.");
            }
        }

        public void CompleteDelivery(int deliveryId, DateTime actualDate)
        {
            var delivery = deliveries.FirstOrDefault(d => d.Id == deliveryId);
            if (delivery != null && delivery.Status == DeliveryStatus.InProgress)
            {
                delivery.Status = DeliveryStatus.Completed;
                delivery.ActualDate = actualDate;
                delivery.Vehicle.IsAvailable = true;
                delivery.Driver.IsAvailable = true;

                // Рассчитываем расходы на топливо для этой доставки
                decimal fuelCost = (decimal)(delivery.Route.Distance / 100 *
                    delivery.Vehicle.FuelConsumption * 50); // 50 руб/литр

                expenses.Add(new Expense(nextExpenseId++, delivery.Vehicle.Id,
                    deliveryId, ExpenseType.Fuel, fuelCost, actualDate,
                    $"Топливо для доставки #{deliveryId}"));

                delivery.Expenses = fuelCost;

                Console.WriteLine($"Доставка #{deliveryId} завершена.");
                Console.WriteLine($"Прибыль: {delivery.CalculateProfit()} руб.");
            }
            else
            {
                Console.WriteLine("Не удалось завершить доставку.");
            }
        }

        // Учет расходов
        public void AddExpense(int vehicleId, int? deliveryId, ExpenseType type,
                              decimal amount, DateTime date, string description)
        {
            expenses.Add(new Expense(nextExpenseId++, vehicleId, deliveryId,
                type, amount, date, description));
            Console.WriteLine("Расход добавлен.");
        }

        // Отчеты
        public void GenerateDeliveryReport(DateTime startDate, DateTime endDate)
        {
            Console.WriteLine($"\n=== Отчет по доставкам за период {startDate.ToShortDateString()} - {endDate.ToShortDateString()} ===");

            var periodDeliveries = deliveries.Where(d =>
                d.PlannedDate >= startDate && d.PlannedDate <= endDate).ToList();

            Console.WriteLine($"Всего доставок: {periodDeliveries.Count}");
            Console.WriteLine($"Завершено: {periodDeliveries.Count(d => d.Status == DeliveryStatus.Completed)}");
            Console.WriteLine($"В процессе: {periodDeliveries.Count(d => d.Status == DeliveryStatus.InProgress)}");

            decimal totalRevenue = periodDeliveries.Sum(d => d.ClientPayment);
            decimal totalExpenses = periodDeliveries.Sum(d => d.Expenses);
            decimal totalProfit = totalRevenue - totalExpenses;

            Console.WriteLine($"\nОбщая выручка: {totalRevenue} руб.");
            Console.WriteLine($"Общие расходы: {totalExpenses} руб.");
            Console.WriteLine($"Общая прибыль: {totalProfit} руб.");

            Console.WriteLine("\nДетали доставок:");
            foreach (var delivery in periodDeliveries)
            {
                Console.WriteLine($"  #{delivery.Id}: {delivery.ClientName}, " +
                    $"маршрут: {delivery.Route.StartPoint} -> {delivery.Route.EndPoint}, " +
                    $"статус: {delivery.Status}, прибыль: {delivery.CalculateProfit()} руб.");
            }
        }

        public void GenerateDistanceReport()
        {
            Console.WriteLine("\n=== Отчет по пройденным расстояниям ===");

            var completedDeliveries = deliveries.Where(d => d.Status == DeliveryStatus.Completed);

            double totalDistance = completedDeliveries.Sum(d => d.Route.Distance);
            Console.WriteLine($"Общее пройденное расстояние: {totalDistance} км");

            Console.WriteLine("\nПо типам транспорта:");
            var byVehicleType = completedDeliveries
                .GroupBy(d => d.Vehicle.Type)
                .Select(g => new { Type = g.Key, Distance = g.Sum(d => d.Route.Distance) });

            foreach (var item in byVehicleType)
            {
                Console.WriteLine($"  {item.Type}: {item.Distance} км");
            }
        }

        public void ShowCurrentDeliveries()
        {
            Console.WriteLine("\n=== Текущие доставки ===");
            var current = deliveries.Where(d =>
                d.Status == DeliveryStatus.Planned ||
                d.Status == DeliveryStatus.InProgress).ToList();

            foreach (var delivery in current)
            {
                Console.WriteLine($"#{delivery.Id}: {delivery.ClientName}, " +
                    $"{delivery.Route.StartPoint} -> {delivery.Route.EndPoint}, " +
                    $"водитель: {delivery.Driver.FullName}, статус: {delivery.Status}");
            }
        }

        public void ShowAllExpenses()
        {
            Console.WriteLine("\n=== Все расходы ===");
            foreach (var expense in expenses)
            {
                Console.WriteLine(expense);
            }

            decimal total = expenses.Sum(e => e.Amount);
            Console.WriteLine($"\nОбщая сумма расходов: {total} руб.");
        }

        // Функция отслеживания доставки
        public void TrackDelivery(int deliveryId)
        {
            var delivery = deliveries.FirstOrDefault(d => d.Id == deliveryId);
            if (delivery != null)
            {
                Console.WriteLine($"\n=== Отслеживание доставки #{deliveryId} ===");
                Console.WriteLine($"Клиент: {delivery.ClientName}");
                Console.WriteLine($"Груз: {delivery.CargoDescription} ({delivery.CargoWeight} кг)");
                Console.WriteLine($"Маршрут: {delivery.Route.StartPoint} -> {delivery.Route.EndPoint}");
                Console.WriteLine($"Расстояние: {delivery.Route.Distance} км");
                Console.WriteLine($"Водитель: {delivery.Driver.FullName}");
                Console.WriteLine($"Транспорт: {delivery.Vehicle.Model} ({delivery.Vehicle.LicensePlate})");
                Console.WriteLine($"Статус: {delivery.Status}");
                Console.WriteLine($"Планируемая дата: {delivery.PlannedDate.ToShortDateString()}");

                if (delivery.ActualDate.HasValue)
                {
                    Console.WriteLine($"Фактическая дата: {delivery.ActualDate.Value.ToShortDateString()}");
                }

                Console.WriteLine($"Стоимость для клиента: {delivery.ClientPayment} руб.");
                Console.WriteLine($"Расходы на доставку: {delivery.Expenses} руб.");
                Console.WriteLine($"Прибыль: {delivery.CalculateProfit()} руб.");
            }
            else
            {
                Console.WriteLine("Доставка не найдена.");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            TransportCompany company = new TransportCompany();
            bool exit = false;

            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== Система управления транспортной компанией ===");

            while (!exit)
            {
                ShowMainMenu();
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        ManageVehicles(company);
                        break;
                    case "2":
                        ManageDrivers(company);
                        break;
                    case "3":
                        ManageRoutes(company);
                        break;
                    case "4":
                        ManageDeliveries(company);
                        break;
                    case "5":
                        ManageExpenses(company);
                        break;
                    case "6":
                        GenerateReports(company);
                        break;
                    case "7":
                        TrackDeliveryMenu(company);
                        break;
                    case "0":
                        exit = true;
                        Console.WriteLine("Выход из программы...");
                        break;
                    default:
                        Console.WriteLine("Неверный выбор. Попробуйте снова.");
                        break;
                }
            }
        }

        static void ShowMainMenu()
        {
            Console.WriteLine("\n=== ГЛАВНОЕ МЕНЮ ===");
            Console.WriteLine("1. Управление автопарком");
            Console.WriteLine("2. Управление водителями");
            Console.WriteLine("3. Управление маршрутами");
            Console.WriteLine("4. Управление доставками");
            Console.WriteLine("5. Учет расходов");
            Console.WriteLine("6. Отчеты");
            Console.WriteLine("7. Отслеживание доставки");
            Console.WriteLine("0. Выход");
            Console.Write("Выберите пункт меню: ");
        }

        static void ManageVehicles(TransportCompany company)
        {
            bool back = false;
            while (!back)
            {
                Console.WriteLine("\n=== УПРАВЛЕНИЕ АВТОПАРКОМ ===");
                Console.WriteLine("1. Показать весь автопарк");
                Console.WriteLine("2. Показать доступный транспорт");
                Console.WriteLine("3. Добавить транспорт");
                Console.WriteLine("0. Назад");
                Console.Write("Выберите пункт: ");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        company.ShowAllVehicles();
                        break;
                    case "2":
                        company.ShowAvailableVehicles();
                        break;
                    case "3":
                        Console.Write("Гос. номер: ");
                        string plate = Console.ReadLine();
                        Console.Write("Тип (1-Грузовик, 2-Маршрутка, 3-Легковой): ");
                        VehicleType type = (VehicleType)(int.Parse(Console.ReadLine()) - 1);
                        Console.Write("Модель: ");
                        string model = Console.ReadLine();
                        Console.Write("Год выпуска: ");
                        int year = int.Parse(Console.ReadLine());
                        Console.Write("Вместимость (кг или чел): ");
                        double capacity = double.Parse(Console.ReadLine());
                        Console.Write("Расход топлива на 100 км: ");
                        double fuelConsumption = double.Parse(Console.ReadLine());

                        company.AddVehicle(plate, type, model, year, capacity, fuelConsumption);
                        break;
                    case "0":
                        back = true;
                        break;
                }
            }
        }

        static void ManageDrivers(TransportCompany company)
        {
            bool back = false;
            while (!back)
            {
                Console.WriteLine("\n=== УПРАВЛЕНИЕ ВОДИТЕЛЯМИ ===");
                Console.WriteLine("1. Показать всех водителей");
                Console.WriteLine("2. Показать водителей с просроченными правами");
                Console.WriteLine("3. Добавить водителя");
                Console.WriteLine("0. Назад");
                Console.Write("Выберите пункт: ");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        company.ShowAllDrivers();
                        break;
                    case "2":
                        company.ShowDriversWithExpiredLicenses();
                        break;
                    case "3":
                        Console.Write("ФИО: ");
                        string name = Console.ReadLine();
                        Console.Write("Номер прав: ");
                        string license = Console.ReadLine();
                        Console.Write("Срок действия прав (гггг-мм-дд): ");
                        DateTime expiry = DateTime.Parse(Console.ReadLine());
                        Console.Write("Телефон: ");
                        string phone = Console.ReadLine();

                        company.AddDriver(name, license, expiry, phone);
                        break;
                    case "0":
                        back = true;
                        break;
                }
            }
        }

        static void ManageRoutes(TransportCompany company)
        {
            bool back = false;
            while (!back)
            {
                Console.WriteLine("\n=== УПРАВЛЕНИЕ МАРШРУТАМИ ===");
                Console.WriteLine("1. Показать все маршруты");
                Console.WriteLine("2. Добавить маршрут");
                Console.WriteLine("0. Назад");
                Console.Write("Выберите пункт: ");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        company.ShowAllRoutes();
                        break;
                    case "2":
                        Console.Write("Пункт отправления: ");
                        string start = Console.ReadLine();
                        Console.Write("Пункт назначения: ");
                        string end = Console.ReadLine();
                        Console.Write("Расстояние (км): ");
                        double distance = double.Parse(Console.ReadLine());
                        Console.Write("Расчетное время (ч): ");
                        double time = double.Parse(Console.ReadLine());
                        Console.Write("Стоимость маршрута (руб): ");
                        decimal cost = decimal.Parse(Console.ReadLine());

                        company.AddRoute(start, end, distance, time, cost);
                        break;
                    case "0":
                        back = true;
                        break;
                }
            }
        }

        static void ManageDeliveries(TransportCompany company)
        {
            bool back = false;
            while (!back)
            {
                Console.WriteLine("\n=== УПРАВЛЕНИЕ ДОСТАВКАМИ ===");
                Console.WriteLine("1. Показать текущие доставки");
                Console.WriteLine("2. Создать новую доставку");
                Console.WriteLine("3. Начать доставку");
                Console.WriteLine("4. Завершить доставку");
                Console.WriteLine("0. Назад");
                Console.Write("Выберите пункт: ");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        company.ShowCurrentDeliveries();
                        break;
                    case "2":
                        Console.Write("ID маршрута: ");
                        int routeId = int.Parse(Console.ReadLine());
                        Console.Write("ID транспорта: ");
                        int vehicleId = int.Parse(Console.ReadLine());
                        Console.Write("ID водителя: ");
                        int driverId = int.Parse(Console.ReadLine());
                        Console.Write("Имя клиента: ");
                        string client = Console.ReadLine();
                        Console.Write("Описание груза: ");
                        string cargo = Console.ReadLine();
                        Console.Write("Вес груза (кг): ");
                        double weight = double.Parse(Console.ReadLine());
                        Console.Write("Планируемая дата (гггг-мм-дд): ");
                        DateTime date = DateTime.Parse(Console.ReadLine());
                        Console.Write("Стоимость для клиента (руб): ");
                        decimal payment = decimal.Parse(Console.ReadLine());

                        company.CreateDelivery(routeId, vehicleId, driverId,
                            client, cargo, weight, date, payment);
                        break;
                    case "3":
                        Console.Write("ID доставки для начала: ");
                        int startId = int.Parse(Console.ReadLine());
                        company.StartDelivery(startId);
                        break;
                    case "4":
                        Console.Write("ID доставки для завершения: ");
                        int completeId = int.Parse(Console.ReadLine());
                        Console.Write("Фактическая дата (гггг-мм-дд): ");
                        DateTime actualDate = DateTime.Parse(Console.ReadLine());
                        company.CompleteDelivery(completeId, actualDate);
                        break;
                    case "0":
                        back = true;
                        break;
                }
            }
        }

        static void ManageExpenses(TransportCompany company)
        {
            bool back = false;
            while (!back)
            {
                Console.WriteLine("\n=== УЧЕТ РАСХОДОВ ===");
                Console.WriteLine("1. Показать все расходы");
                Console.WriteLine("2. Добавить расход");
                Console.WriteLine("0. Назад");
                Console.Write("Выберите пункт: ");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        company.ShowAllExpenses();
                        break;
                    case "2":
                        Console.Write("ID транспорта: ");
                        int vehicleId = int.Parse(Console.ReadLine());
                        Console.Write("ID доставки (0 если общий): ");
                        int deliveryInput = int.Parse(Console.ReadLine());
                        int? deliveryId = deliveryInput == 0 ? null : (int?)deliveryInput;
                        Console.Write("Тип расхода (1-Топливо, 2-ТО, 3-Ремонт, 4-Страховка, 5-Прочее): ");
                        ExpenseType type = (ExpenseType)(int.Parse(Console.ReadLine()) - 1);
                        Console.Write("Сумма (руб): ");
                        decimal amount = decimal.Parse(Console.ReadLine());
                        Console.Write("Дата (гггг-мм-дд): ");
                        DateTime date = DateTime.Parse(Console.ReadLine());
                        Console.Write("Описание: ");
                        string desc = Console.ReadLine();

                        company.AddExpense(vehicleId, deliveryId, type, amount, date, desc);
                        break;
                    case "0":
                        back = true;
                        break;
                }
            }
        }

        static void GenerateReports(TransportCompany company)
        {
            bool back = false;
            while (!back)
            {
                Console.WriteLine("\n=== ОТЧЕТЫ ===");
                Console.WriteLine("1. Отчет по доставкам за период");
                Console.WriteLine("2. Отчет по пройденным расстояниям");
                Console.WriteLine("0. Назад");
                Console.Write("Выберите пункт: ");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        Console.Write("Начальная дата (гггг-мм-дд): ");
                        DateTime start = DateTime.Parse(Console.ReadLine());
                        Console.Write("Конечная дата (гггг-мм-дд): ");
                        DateTime end = DateTime.Parse(Console.ReadLine());
                        company.GenerateDeliveryReport(start, end);
                        break;
                    case "2":
                        company.GenerateDistanceReport();
                        break;
                    case "0":
                        back = true;
                        break;
                }
            }
        }

        static void TrackDeliveryMenu(TransportCompany company)
        {
            Console.Write("\nВведите ID доставки для отслеживания: ");
            if (int.TryParse(Console.ReadLine(), out int deliveryId))
            {
                company.TrackDelivery(deliveryId);
            }
            else
            {
                Console.WriteLine("Неверный ID.");
            }
        }
    }
}