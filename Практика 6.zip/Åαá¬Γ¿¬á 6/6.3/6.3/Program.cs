﻿using System;

namespace Tasks1_23
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Выберите номер задания (1-23): ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1: Task1(); break;
                case 2: Task2(); break;
                case 3: Task3(); break;
                case 4: Task4(); break;
                case 5: Task5(); break;
                case 6: Task6(); break;
                case 7: Task7(); break;
                case 8: Task8(); break;
                case 9: Task9(); break;
                case 10: Task10(); break;
                case 11: Task11(); break;
                case 12: Task12(); break;
                case 13: Task13(); break;
                case 14: Task14(); break;
                case 15: Task15(); break;
                case 16: Task16(); break;
                case 17: Task17(); break;
                case 18: Task18(); break;
                case 19: Task19(); break;
                case 20: Task20(); break;
                case 21: Task21(); break;
                case 22: Task22(); break;
                case 23: Task23(); break;
                default: Console.WriteLine("Такого задания нет."); break;
            }
        }

        #region Задание 1
        static void Task1()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double W = 0;
            for (int i = 2; i <= k; i++)
                W += Math.Pow(-1, i) * Factorial(i + 3) / (2 * (i - 4));
            Console.WriteLine($"W = {W}");
        }
        #endregion

        #region Задание 2
        static void Task2()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());

            double U = 1;
            for (int i = 2; i <= k; i++)
                U *= (x * Factorial(i - 12)) / (i - 6);
            Console.WriteLine($"U = {U}");
        }
        #endregion

        #region Задание 3
        static void Task3()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());

            double S = 0;
            for (int k = 1; k <= n; k++)
                S += Math.Pow(-3, k + 1) * x / (2 * (k - 2) * Factorial(3 * k + 1));
            Console.WriteLine($"S = {S}");
        }
        #endregion

        #region Задание 4
        static void Task4()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());

            double Q = 0;
            for (int k = 2; k <= n; k++)
                Q += Math.Pow(-1, k) * (k - 7) / (2 * n * Factorial(k));
            Console.WriteLine($"Q = {Q}");
        }
        #endregion

        #region Задание 5
        static void Task5()
        {
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());

            double W = 0;
            for (int j = 1; j <= 9; j++)
                W += (7 - x) * Factorial(j) / Math.Pow(j - 3, 5);

            double prod = 1;
            for (int m = 1; m <= 17; m++)
                prod *= (Math.Pow(m, 3) - 8) / (m - 12);

            W *= prod;
            Console.WriteLine($"W = {W}");
        }
        #endregion

        #region Задание 6
        static void Task6()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double W = 0;
            for (int i = 1; i <= k; i++)
                W += Math.Pow(-1, i) * Factorial(i + 3) / (i - 4);
            Console.WriteLine($"W = {W}");
        }
        #endregion

        #region Задание 7
        static void Task7()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());

            double Q = 0;
            for (int i = 1; i <= n; i++)
                Q += Math.Pow(-1, i) * (x + 3) / (2 * i * Factorial(i));
            Console.WriteLine($"Q = {Q}");
        }
        #endregion

        #region Задание 8
        static void Task8()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());

            double P = 1;
            for (int j = 1; j <= k; j++)
                P *= (j - 2) * Factorial(j + 2) / ((j - 5) * (j - 7));
            Console.WriteLine($"P = {P}");
        }
        #endregion

        #region Задание 9
        static void Task9()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            double S = 0;
            for (int k = 1; k <= n; k++)
                S += Math.Pow(-1, k) * (Math.Pow(k, 3) - 27) / (3 * Factorial(k + 2));
            Console.WriteLine($"S = {S}");
        }
        #endregion

        #region Задание 10
        static void Task10()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double Z = 1;
            for (int i = 1; i <= k; i++)
                Z *= Math.Pow(-1, i) * Math.Pow(5, i) / (i - 11);
            Console.WriteLine($"Z = {Z}");
        }
        #endregion

        #region Задание 11
        static void Task11()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());

            double U = 1;
            for (int i = 1; i <= k; i++)
                U *= (x * Factorial(i - 2)) / (i - 1);
            Console.WriteLine($"U = {U}");
        }
        #endregion

        #region Задание 12
        static void Task12()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double A = 1;
            for (int j = 1; j <= k; j++)
                A *= (Math.Pow(j, 2) - 4) / (j + 1);
            Console.WriteLine($"A = {A}");
        }
        #endregion

        #region Задание 13
        static void Task13()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            double S = 0;
            for (int k = 1; k <= n; k++)
                S += (k + 3) * (k + 7) / Factorial(k);
            Console.WriteLine($"S = {S}");
        }
        #endregion

        #region Задание 14
        static void Task14()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double Z = 1;
            for (int i = 1; i <= k; i++)
                Z *= Math.Pow(-1, i) * Math.Pow(i, 2) / (i - 1);
            Console.WriteLine($"Z = {Z}");
        }
        #endregion

        #region Задание 15
        static void Task15()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            double S = 0;
            for (int k = 1; k <= n; k++)
                S += Math.Pow(-1, k) * Math.Pow(k, 2) / (k + 1);
            Console.WriteLine($"S = {S}");
        }
        #endregion

        #region Задание 16
        static void Task16()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double Z = 1;
            for (int n = 2; n <= k; n++)
                Z *= (n + 2) * n - 4 / (n + 3);
            Console.WriteLine($"Z = {Z}");
        }
        #endregion

        #region Задание 17
        static void Task17()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double W = 0;
            for (int i = 1; i <= k; i++)
                W += Math.Pow(-1, i) * Math.Pow(i, 3) / (i + 4);
            Console.WriteLine($"W = {W}");
        }
        #endregion

        #region Задание 18
        static void Task18()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double P = 1;
            for (int j = 1; j <= k; j++)
                P *= (j - 2) * Factorial(j + 2) / ((j - 5) * (j - 7));
            Console.WriteLine($"P = {P}");
        }
        #endregion

        #region Задание 19
        static void Task19()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            double S = 0;
            for (int k = 1; k <= n; k++)
                S += Math.Pow(-1, k) * (Math.Pow(k, 3) - 27) / (3 * Factorial(k + 2));
            Console.WriteLine($"S = {S}");
        }
        #endregion

        #region Задание 20
        static void Task20()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double Z = 1;
            for (int i = 1; i <= k; i++)
                Z *= Math.Pow(-1, i) * Math.Pow(i, 5) / (i - 11);
            Console.WriteLine($"Z = {Z}");
        }
        #endregion

        #region Задание 21
        static void Task21()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());

            double U = 1;
            for (int i = 1; i <= k; i++)
                U *= (x * Factorial(i - 2)) / (i - 1);
            Console.WriteLine($"U = {U}");
        }
        #endregion

        #region Задание 22
        static void Task22()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double A = 1;
            for (int j = 1; j <= k; j++)
                A *= (Math.Pow(j, 2) - 4) / (j + 1);
            Console.WriteLine($"A = {A}");
        }
        #endregion

        #region Задание 23
        static void Task23()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            double S = 0;
            for (int k = 1; k <= n; k++)
                S += (k + 3) * (k + 7) / Factorial(k);
            Console.WriteLine($"S = {S}");
        }
        #endregion

        // вспомогательная функция факториала
        static double Factorial(int n)
        {
            if (n < 0) return 1;
            double f = 1;
            for (int i = 2; i <= n; i++) f *= i;
            return f;
        }
    }
}