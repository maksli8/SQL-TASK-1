﻿using System;

namespace TableFunctions
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите номер варианта (6–16): ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 6: Variant6(); break;
                case 7: Variant7(); break;
                case 8: Variant8(); break;
                case 9: Variant9(); break;
                case 10: Variant10(); break;
                case 11: Variant11(); break;
                case 12: Variant12(); break;
                case 13: Variant13(); break;
                case 14: Variant14(); break;
                case 15: Variant15(); break;
                case 16: Variant16(); break;
                default: Console.WriteLine("Такого варианта нет."); break;
            }
        }

        static long Factorial(int n)
        {
            long res = 1;
            for (int i = 2; i <= n; i++) res *= i;
            return res;
        }

        #region Вариант 6
        static void Variant6()
        {
            double xStart = -3, xEnd = 2.5, h = 1.1;
            for (double x = xStart; x <= xEnd + 1e-9; x += h)
            {
                double f;
                if (x > 0)
                {
                    f = 0;
                    for (int k = 1; k <= 8; k++)
                        f += Math.Pow(-1, k) * Math.Pow(x, k) / Factorial(k);
                }
                else
                {
                    f = Math.Tan(Math.PI * x);
                }
                Console.WriteLine($"x = {x:F2}\t f(x) = {f:F6}");
            }
        }
        #endregion

        #region Вариант 7
        static void Variant7()
        {
            double xStart = 0, xEnd = 4, h = 0.4;
            for (double x = xStart; x <= xEnd + 1e-9; x += h)
            {
                double u;
                if (x <= 1.5) u = x * x - x + 1;
                else if (x <= 2.5) u = Math.Atan(x);
                else u = Math.Sin(x - 1) + Math.Cos(x + 1);

                double f = 1.5 + Math.Log(Math.Abs(Math.Sin(u)));
                Console.WriteLine($"x = {x:F2}\t f(x) = {f:F6}");
            }
        }
        #endregion

        #region Вариант 8
        static void Variant8()
        {
            double xStart = -1, xEnd = 2, h = 0.15;
            for (double x = xStart; x <= xEnd + 1e-9; x += h)
            {
                double f;
                if (x > 0)
                    f = Math.Log(Math.Sqrt(x));
                else
                {
                    f = 0;
                    for (int k = 2; k <= 7; k++)
                        f += Math.Pow(x, k) / Factorial(k);
                }
                Console.WriteLine($"x = {x:F2}\t f(x) = {f:F6}");
            }
        }
        #endregion

        #region Вариант 9
        static void Variant9()
        {
            double xStart = 0.5, xEnd = 2, h = 0.15;
            for (double x = xStart; x <= xEnd + 1e-9; x += h)
            {
                double f = 0;
                for (int k = 1; k <= 8; k++)
                    f += Math.Pow(-3, k) * Math.Pow(x, k) / Factorial(k);

                Console.WriteLine($"x = {x:F2}\t f(x) = {f:F6}");
            }
        }
        #endregion

        #region Вариант 10
        static void Variant10()
        {
            double xStart = -2, xEnd = 1, h = 0.5;
            for (double x = xStart; x <= xEnd + 1e-9; x += h)
            {
                double f;
                if (x > 0)
                {
                    f = 0;
                    for (int k = 3; k <= 9; k++)
                        f += Math.Pow(x, k);
                }
                else
                {
                    f = Math.Pow(2 - x, -x);
                }
                Console.WriteLine($"x = {x:F2}\t f(x) = {f:F6}");
            }
        }
        #endregion

        #region Вариант 11
        static void Variant11()
        {
            double xStart = -1, xEnd = 1, h = 0.25;
            for (double x = xStart; x <= xEnd + 1e-9; x += h)
            {
                double u = x * x - Math.Asin(x * x);
                double f;
                if (x > Math.PI)
                    f = Math.Pow(Math.Abs(Math.Cos(x)), u);
                else
                    f = Math.Pow(u, Math.Sin(x));
                Console.WriteLine($"x = {x:F2}\t f(x) = {f:F6}");
            }
        }
        #endregion

        #region Вариант 12
        static void Variant12()
        {
            double xStart = 1, xEnd = 3, h = 0.2;
            for (double x = xStart; x <= xEnd + 1e-9; x += h)
            {
                double u;
                if (x <= 2) u = (x + 1) / (3 - x);
                else u = Math.Sin(x - 1) * Math.Cos(x + 1);

                double f = Math.Exp(u);
                Console.WriteLine($"x = {x:F2}\t f(x) = {f:F6}");
            }
        }
        #endregion

        #region Вариант 13
        static void Variant13()
        {
            double xStart = -1, xEnd = 2, h = 0.2;
            for (double x = xStart; x <= xEnd + 1e-9; x += h)
            {
                double f;
                if (x > 0)
                {
                    f = 0;
                    for (int k = 1; k <= 7; k++)
                        f += Math.Pow(x, k) / Factorial(k);
                }
                else
                {
                    f = Math.Atan(Math.PI * x);
                }
                Console.WriteLine($"x = {x:F2}\t f(x) = {f:F6}");
            }
        }
        #endregion

        #region Вариант 14
        static void Variant14()
        {
            double xStart = 1, xEnd = 2, h = 0.1;
            for (double x = xStart; x <= xEnd + 1e-9; x += h)
            {
                double f = 0;
                for (int k = 1; k <= 7; k++)
                    f += Math.Pow(x, 2 * k) / Factorial(2 * k);

                Console.WriteLine($"x = {x:F2}\t f(x) = {f:F6}");
            }
        }
        #endregion

        #region Вариант 15
        static void Variant15()
        {
            double xStart = -5, xEnd = 5, h = 0.5;
            for (double x = xStart; x <= xEnd + 1e-9; x += h)
            {
                double u;
                if (x < -3) u = x * x - x + 1;
                else if (x <= 3) u = Math.Atan(x);
                else u = Math.Sin(x - 1) + Math.Cos(x + 1);

                double f = 2.5 * x * x * Math.Log10(8 - Math.Sin(u));
                Console.WriteLine($"x = {x:F2}\t f(x) = {f:F6}");
            }
        }
        #endregion

        #region Вариант 16
        static void Variant16()
        {
            double xStart = -3, xEnd = 2.3, h = 0.25;
            for (double x = xStart; x <= xEnd + 1e-9; x += h)
            {
                double f;
                if (x > 0)
                {
                    f = 0;
                    for (int k = 2; k <= 5; k++)
                        f += Math.Pow(x, k);
                }
                else
                {
                    f = Math.Pow(x, 3.5) * Math.Sin(x);
                }
                Console.WriteLine($"x = {x:F2}\t f(x) = {f:F6}");
            }
        }
        #endregion
    }
}