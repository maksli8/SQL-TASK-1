﻿using System;

namespace _6._1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Выберите номер задания (15-30): ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 15: Task15(); break;
                case 16: Task16(); break;
                case 17: Task17(); break;
                case 18: Task18(); break;
                case 19: Task19(); break;
                case 20: Task20(); break;
                case 21: Task21(); break;
                case 22: Task22(); break;
                case 23: Task23(); break;
                case 24: Task24(); break;
                case 25: Task25(); break;
                case 26: Task26(); break;
                case 27: Task27(); break;
                case 28: Task28(); break;
                case 29: Task29(); break;
                case 30: Task30(); break;
                default: Console.WriteLine("Такого задания нет."); break;
            }
        }

        #region Задание 15
        static void Task15()
        {
            Console.Write("Введите X (|X| < 1): ");
            double X = double.Parse(Console.ReadLine());
            Console.Write("Введите N (>= 0): ");
            int N = int.Parse(Console.ReadLine());

            double sum = 0;
            for (int i = 0; i <= N; i++)
                sum += Math.Pow(-1, i) * Math.Pow(X, 2 * i + 1) / (2 * i + 1);

            Console.WriteLine($"arctg({X}) ≈ {sum}");
        }
        #endregion

        #region Задание 16
        static void Task16()
        {
            Console.Write("Введите N (>1): ");
            int N = int.Parse(Console.ReadLine());
            Console.Write("Введите A: ");
            double A = double.Parse(Console.ReadLine());
            Console.Write("Введите B (B > A): ");
            double B = double.Parse(Console.ReadLine());

            if (N <= 1 || B <= A)
            {
                Console.WriteLine("Ошибка: N > 1 и B > A");
                return;
            }

            double H = (B - A) / (N - 1);
            Console.WriteLine($"H = {H}");
            Console.Write("Точки разбиения: ");
            for (int i = 0; i < N; i++)
            {
                double point = A + i * H;
                Console.Write(point + " ");
            }
            Console.WriteLine();
        }
        #endregion

        #region Задание 17
        static void Task17()
        {
            Console.Write("Введите N (>2): ");
            int N = int.Parse(Console.ReadLine());
            Console.Write("Введите A: ");
            double A = double.Parse(Console.ReadLine());
            Console.Write("Введите B (B > A): ");
            double B = double.Parse(Console.ReadLine());

            if (N <= 2 || B <= A)
            {
                Console.WriteLine("Ошибка: N > 2 и B > A");
                return;
            }

            double H = (B - A) / (N - 1);
            Console.WriteLine($"H = {H}");
            for (int i = 0; i < N; i++)
            {
                double X = A + i * H;
                double F = 1 - Math.Sin(X);
                Console.WriteLine($"F({X}) = {F}");
            }
        }
        #endregion

        #region Задание 18
        static void Task18()
        {
            Console.Write("Введите D (>0): ");
            double D = double.Parse(Console.ReadLine());

            if (D <= 0)
            {
                Console.WriteLine("Ошибка: D > 0");
                return;
            }

            double prev = 2;
            int K = 2;
            while (true)
            {
                double current = 2 + 1 / prev;
                if (Math.Abs(current - prev) < D)
                {
                    Console.WriteLine($"K = {K}, A(K-1) = {prev}, A(K) = {current}");
                    break;
                }
                prev = current;
                K++;
            }
        }
        #endregion

        #region Задание 19
        static void Task19()
        {
            Console.Write("Введите D (>0): ");
            double D = double.Parse(Console.ReadLine());

            if (D <= 0)
            {
                Console.WriteLine("Ошибка: D > 0");
                return;
            }

            double a1 = 1, a2 = 2;
            int K = 3;
            while (true)
            {
                double current = (a1 + a2) / 2;
                if (Math.Abs(current - a2) < D)
                {
                    Console.WriteLine($"K = {K}, A(K-1) = {a2}, A(K) = {current}");
                    break;
                }
                a1 = a2;
                a2 = current;
                K++;
            }
        }
        #endregion

        #region Задание 20
        static void Task20()
        {
            Console.Write("Введите M (>=10): ");
            int M = int.Parse(Console.ReadLine());

            if (M < 10)
            {
                Console.WriteLine("Ошибка: M >= 10");
                return;
            }

            Console.WriteLine("Нечетные кратные пяти:");
            for (int i = 10; i <= M; i++)
                if (i % 5 == 0 && i % 2 == 1)
                    Console.Write(i + " ");
            Console.WriteLine();
        }
        #endregion

        #region Задание 21
        static void Task21()
        {
            for (int i = 11; i <= 99; i++)
                Console.WriteLine($"{i}^2 = {i * i}");
        }
        #endregion

        #region Задание 22
        static void Task22()
        {
            while (true)
            {
                Console.Write("Введите x (или 'q' для выхода): ");
                string input = Console.ReadLine();
                if (input == "q") break;

                double x = double.Parse(input);
                double y;

                if (0 < x && x < 3.14)
                    y = Math.Sin(x);
                else if (-3.14 <= x && x < 0)
                    y = x;
                else if (x <= -2 * 3.14 || x >= 2 * 3.14)
                    y = Math.Pow(x, 2);
                else
                    y = 0;

                Console.WriteLine($"y = {y}");
            }
        }
        #endregion

        #region Задание 23
        static void Task23()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());

            double fact = 1;
            double sum = 0;
            for (int i = 1; i <= 2 * n; i++)
            {
                fact *= i;
                sum += fact;
            }
            Console.WriteLine($"Сумма факториалов до 2n = {sum}");
        }
        #endregion

        #region Задание 24
        static void Task24()
        {
            Console.Write("Введите M (>=10): ");
            int M = int.Parse(Console.ReadLine());

            if (M < 10)
            {
                Console.WriteLine("Ошибка: M >= 10");
                return;
            }

            int maxDigit = 0;
            for (int i = 10; i <= M; i++)
            {
                int number = i;
                while (number > 0)
                {
                    int digit = number % 10;
                    if (digit > maxDigit) maxDigit = digit;
                    number /= 10;
                }
            }
            Console.WriteLine($"Наибольшая цифра: {maxDigit}");
        }
        #endregion

        #region Задание 25
        static void Task25()
        {
            Console.Write("Введите N (>=10): ");
            int N = int.Parse(Console.ReadLine());

            if (N < 10)
            {
                Console.WriteLine("Ошибка: N >= 10");
                return;
            }

            for (int i = 10; i <= N; i++)
            {
                int number = i;
                int sum = 0;
                while (number > 0)
                {
                    sum += number % 10;
                    number /= 10;
                }
                string str = i.ToString();
                int firstDigit = int.Parse(str[0].ToString());
                Console.WriteLine($"Число: {i}, первая цифра: {firstDigit}, сумма цифр: {sum}");
            }
        }
        #endregion

        #region Задание 26
        static void Task26()
        {
            Console.Write("Введите число: ");
            string num = Console.ReadLine();

            string reversed = "";
            for (int i = num.Length - 1; i >= 0; i--)
                reversed += num[i];

            if (num == reversed)
                Console.WriteLine("Число является палиндромом");
            else
                Console.WriteLine("Число НЕ является палиндромом");
        }
        #endregion

        #region Задание 27
        static void Task27()
        {
            int sum = 0;
            for (int i = 12; i <= 80; i++)
            {
                sum += i * i;
                Console.WriteLine(sum);
            }
        }
        #endregion

        #region Задание 28
        static void Task28()
        {
            for (int i = 22; i <= 88; i++)
            {
                int diff = (i * i) - ((i - 1) * (i - 1));
                Console.WriteLine(diff);
            }
        }
        #endregion

        #region Задание 29
        static void Task29()
        {
            Console.Write("Введите A: ");
            double A = double.Parse(Console.ReadLine());
            Console.Write("Введите N (>0): ");
            int N = int.Parse(Console.ReadLine());

            for (int i = 1; i <= N; i++)
            {
                double diff = (i * i) - (A * A);
                Console.WriteLine($"Разность квадратов {i} и {A} = {diff}");
            }
        }
        #endregion

        #region Задание 30
        static void Task30()
        {
            Console.Write("Введите N (>=10): ");
            int N = int.Parse(Console.ReadLine());

            if (N < 10)
            {
                Console.WriteLine("Ошибка: N >= 10");
                return;
            }

            int minDigit = 9;
            for (int i = 10; i <= N; i++)
            {
                int number = i;
                while (number > 0)
                {
                    int digit = number % 10;
                    if (digit < minDigit) minDigit = digit;
                    number /= 10;
                }
            }
            Console.WriteLine($"Наименьшая цифра: {minDigit}");
        }
        #endregion
    }
}
