﻿using System;

namespace PiecewiseFunctions
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите номер варианта (6–15): ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 6: Variant6(); break;
                case 7: Variant7(); break;
                case 8: Variant8(); break;
                case 9: Variant9(); break;
                case 10: Variant10(); break;
                case 11: Variant11(); break;
                case 12: Variant12(); break;
                case 13: Variant13(); break;
                case 14: Variant14(); break;
                case 15: Variant15(); break;
                default: Console.WriteLine("Такого варианта нет."); break;
            }
        }

        #region Вариант 6
        static void Variant6()
        {
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());
            double y;

            if (x > 3.8)
                y = Math.Log(1 + x);
            else if (x >= 2.8 && x <= 3.8)
                y = Math.Exp(-x);
            else
                y = Math.Cos(x);

            Console.WriteLine($"y = {y}");
        }
        #endregion

        #region Вариант 7
        static void Variant7()
        {
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());
            double y;

            if (x > 3.61)
                y = Math.Exp(-x + 0.5);
            else if (x >= 0 && x <= 3.61)
                y = 1;
            else
                y = 0.5 * x;

            Console.WriteLine($"y = {y}");
        }
        #endregion

        #region Вариант 8
        static void Variant8()
        {
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());
            double y;

            if (x > 1.5)
                y = 2 * x * Math.Sqrt(Math.Abs(Math.Cos(2 * x)));
            else if (x >= 0 && x <= 1.5)
                y = Math.Exp(-Math.Cos(3 * x));
            else
                y = x;

            Console.WriteLine($"y = {y}");
        }
        #endregion

        #region Вариант 9
        static void Variant9()
        {
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());
            double y;

            if (x > 2.5)
                y = 1 - Math.Sqrt(Math.Abs(Math.Cos(2 * x)));
            else if (x >= 1 && x <= 2.5)
                y = x * x - x;
            else
                y = 1 + x * x;

            Console.WriteLine($"y = {y}");
        }
        #endregion

        #region Вариант 10
        static void Variant10()
        {
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());
            double y;

            if (x > 4.5)
                y = 2 * x;
            else if (x >= 0 && x <= 4.5)
                y = Math.Abs(1 - Math.Log(Math.Abs(1 + x))) + x * x;
            else
                y = Math.Exp(-x);

            Console.WriteLine($"y = {y}");
        }
        #endregion

        #region Вариант 11
        static void Variant11()
        {
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());
            double y;

            if (x > 2)
                y = Math.Sqrt(Math.Log(x * x - 1));
            else if (x >= 0 && x <= 2)
                y = -2 * Math.Pow(x, 3);
            else
                y = Math.Exp(Math.Sin(x));

            Console.WriteLine($"y = {y}");
        }
        #endregion

        #region Вариант 12
        static void Variant12()
        {
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());
            double y;

            if (x > 3.5)
                y = 1 - 2 * Math.Pow(x, 3);
            else if (x >= 0 && x <= 3.5)
                y = Math.Sqrt(Math.Cos(2 * x - 1));
            else
                y = Math.Exp(-Math.Cos(2 * x));

            Console.WriteLine($"y = {y}");
        }
        #endregion

        #region Вариант 13
        static void Variant13()
        {
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());
            double y;

            if (x > 2.5)
                y = x + 1;
            else if (x >= 0 && x <= 2.5)
                y = 1 - Math.Pow(x, 5);
            else
                y = x + Math.Log(Math.Abs(Math.Sin(x)));

            Console.WriteLine($"y = {y}");
        }
        #endregion

        #region Вариант 14
        static void Variant14()
        {
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());
            double y;

            if (x > 2.5)
                y = x - 2;
            else if (x >= 0 && x <= 2.5)
                y = 1 + x * x;
            else
                y = (x * Math.Log(Math.Abs(Math.Cos(x))));

            Console.WriteLine($"y = {y}");
        }
        #endregion

        #region Вариант 15
        static void Variant15()
        {
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());
            double y;

            if (x > 4.5)
                y = 1 + 3 * x;
            else if (x >= 1 && x <= 4.5)
                y = Math.Exp(-2 * x);
            else
                y = Math.Cos(2 * x);

            Console.WriteLine($"y = {y}");
        }
        #endregion
    }
}