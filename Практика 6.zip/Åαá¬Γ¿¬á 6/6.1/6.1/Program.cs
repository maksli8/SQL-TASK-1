﻿using System;

namespace _6._1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Выберите номер задания (1-14): ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1: Task1(); break;
                case 2: Task2(); break;
                case 3: Task3(); break;
                case 4: Task4(); break;
                case 5: Task5(); break;
                case 6: Task6(); break;
                case 7: Task7(); break;
                case 8: Task8(); break;
                case 9: Task9(); break;
                case 10: Task10(); break;
                case 11: Task11(); break;
                case 12: Task12(); break;
                case 13: Task13(); break;
                case 14: Task14(); break;
                default: Console.WriteLine("Такого задания нет."); break;
            }
        }

        #region Задание 1
        static void Task1()
        {
            Console.Write("Введите A: ");
            int A = int.Parse(Console.ReadLine());
            Console.Write("Введите B: ");
            int B = int.Parse(Console.ReadLine());

            if (A >= B) { Console.WriteLine("Ошибка: A < B"); return; }

            int count = 0;
            for (int i = A; i <= B; i++) { Console.Write(i + " "); count++; }
            Console.WriteLine($"\nКоличество чисел: {count}");
        }
        #endregion

        #region Задание 2
        static void Task2()
        {
            Console.Write("Введите A: ");
            int A = int.Parse(Console.ReadLine());
            Console.Write("Введите B: ");
            int B = int.Parse(Console.ReadLine());

            if (B <= 4) { Console.WriteLine("Ошибка: B > 4"); return; }

            int count = 0;
            for (int i = B - 1; i > A; i--) { Console.Write(i + " "); count++; }
            Console.WriteLine($"\nКоличество чисел: {count}");
        }
        #endregion

        #region Задание 3
        static void Task3()
        {
            Console.Write("Введите A: ");
            double A = double.Parse(Console.ReadLine());
            Console.Write("Введите N (>0): ");
            int N = int.Parse(Console.ReadLine());

            double result = 1;
            for (int i = 0; i < N; i++) result *= A;
            Console.WriteLine($"A^N = {result}");
        }
        #endregion

        #region Задание 4
        static void Task4()
        {
            Console.Write("Введите A: ");
            double A = double.Parse(Console.ReadLine());
            Console.Write("Введите N (>0): ");
            int N = int.Parse(Console.ReadLine());

            for (int i = 1; i <= N; i++)
                Console.WriteLine($"A^{i} = {Math.Pow(A, i)}");
        }
        #endregion

        #region Задание 5
        static void Task5()
        {
            Console.Write("Введите A: ");
            double A = double.Parse(Console.ReadLine());
            Console.Write("Введите N (>0): ");
            int N = int.Parse(Console.ReadLine());

            double sum1 = 0, sum2 = 0;
            for (int i = 0; i <= N; i++)
            {
                sum1 += Math.Pow(A, i);
                sum2 += Math.Pow(-1, i) * Math.Pow(A, i);
            }
            Console.WriteLine($"1 + A + A^2 + ... + A^N = {sum1}");
            Console.WriteLine($"1 - A + A^2 - ... + (-1)^N * A^N = {sum2}");
        }
        #endregion

        #region Задание 6
        static void Task6()
        {
            Console.Write("Введите N: ");
            int N = int.Parse(Console.ReadLine());

            int K = 1;
            while (3 * K <= N) K++;
            Console.WriteLine($"Наименьшее K: {K}, 3K = {3 * K}");
        }
        #endregion

        #region Задание 7
        static void Task7()
        {
            Console.Write("Введите N: ");
            int N = int.Parse(Console.ReadLine());
            Console.Write("Введите M: ");
            int M = int.Parse(Console.ReadLine());

            int K = N;
            while (3 * K >= M) K--;
            K++;
            Console.WriteLine($"Наибольшее K: {K}, 3K = {3 * K}");
        }
        #endregion

        #region Задание 8
        static void Task8()
        {
            Console.Write("Введите A (>1): ");
            double A = double.Parse(Console.ReadLine());

            double sum = 0;
            int N = 1;
            while (sum <= A)
            {
                sum += 1.0 / N * (N % 2 == 0 ? -1 : 1);
                N++;
            }
            Console.WriteLine($"N = {N - 1}, сумма = {sum}");
        }
        #endregion

        #region Задание 9
        static void Task9()
        {
            Console.Write("Введите N (>0): ");
            int N = int.Parse(Console.ReadLine());

            double prod = 1;
            for (int i = 1; i <= N; i++) prod *= i;
            Console.WriteLine($"Произведение = {prod}");
        }
        #endregion

        #region Задание 10
        static void Task10()
        {
            Console.Write("Введите N (>0): ");
            int N = int.Parse(Console.ReadLine());

            double prod = 1;
            for (int i = 1; i <= N; i++) prod *= 1.0 / i;
            Console.WriteLine($"Произведение = {prod}");
        }
        #endregion

        #region Задание 11
        static void Task11()
        {
            Console.Write("Введите X: ");
            double X = double.Parse(Console.ReadLine());
            Console.Write("Введите N: ");
            int N = int.Parse(Console.ReadLine());

            double sum = 1;
            for (int i = 1; i <= N; i++) sum += Math.Pow(X, i) / i;
            Console.WriteLine($"Сумма = {sum}");
        }
        #endregion

        #region Задание 12
        static void Task12()
        {
            Console.Write("Введите X: ");
            double X = double.Parse(Console.ReadLine());
            Console.Write("Введите N: ");
            int N = int.Parse(Console.ReadLine());

            double sum = 0;
            for (int i = 0; i <= N; i++)
                sum += Math.Pow(-1, i) * Math.Pow(X, 2 * i + 1) / (2 * i + 1);
            Console.WriteLine($"Сумма = {sum}");
        }
        #endregion

        #region Задание 13
        static void Task13()
        {
            Console.Write("Введите X: ");
            double X = double.Parse(Console.ReadLine());
            Console.Write("Введите N: ");
            int N = int.Parse(Console.ReadLine());

            double sum = 0;
            for (int i = 0; i <= N; i++)
                sum += Math.Pow(-1, i) * Math.Pow(X, 2 * i) / (2 * i + 1);
            Console.WriteLine($"Сумма = {sum}");
        }
        #endregion

        #region Задание 14
        static void Task14()
        {
            Console.Write("Введите X (|X| < 1): ");
            double X = double.Parse(Console.ReadLine());
            Console.Write("Введите N: ");
            int N = int.Parse(Console.ReadLine());

            double sum = 0;
            for (int i = 1; i <= N; i++)
                sum += Math.Pow(-1, i - 1) * Math.Pow(X, i) / i;
            Console.WriteLine($"ln(1+X) ≈ {sum}");
        }
        #endregion
    }
}
