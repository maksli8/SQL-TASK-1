﻿using System;
using System.Collections.Generic;

namespace Tasks1_22
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Выберите номер задания (1-22): ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1: Task1(); break;
                case 2: Task2(); break;
                case 3: Task3(); break;
                case 4: Task4(); break;
                case 5: Task5(); break;
                case 6: Task6(); break;
                case 7: Task7(); break;
                case 8: Task8(); break;
                case 9: Task9(); break;
                case 10: Task10(); break;
                case 11: Task11(); break;
                case 12: Task12(); break;
                case 13: Task13(); break;
                case 14: Task14(); break;
                case 15: Task15(); break;
                case 16: Task16(); break;
                case 17: Task17(); break;
                case 18: Task18(); break;
                case 19: Task19(); break;
                case 20: Task20(); break;
                case 21: Task21(); break;
                case 22: Task22(); break;
                default: Console.WriteLine("Такого задания нет."); break;
            }
        }

        #region Задание 1
        static void Task1()
        {
            Console.Write("Введите число A: ");
            int A = int.Parse(Console.ReadLine());
            Console.Write("Введите степень N: ");
            int N = int.Parse(Console.ReadLine());
            Console.WriteLine($"A^N = {Math.Pow(A, N)}");
        }
        #endregion

        #region Задание 2
        static void Task2()
        {
            Console.Write("Введите N: ");
            int N = int.Parse(Console.ReadLine());
            long fact = 1;
            for (int i = 2; i <= N; i++) fact *= i;
            Console.WriteLine($"{N}! = {fact}");
        }
        #endregion

        #region Задание 3
        static void Task3()
        {
            Console.Write("Введите N: ");
            int N = int.Parse(Console.ReadLine());
            long sum = 0;
            for (int i = 1; i <= N; i++) sum += i * i;
            Console.WriteLine($"Сумма квадратов = {sum}");
        }
        #endregion

        #region Задание 4
        static void Task4()
        {
            Console.Write("Введите N: ");
            int N = int.Parse(Console.ReadLine());
            long sum = 0;
            for (int i = 1; i <= N; i++)
                sum += (i % 2 == 0) ? i * i : i * i * i;
            Console.WriteLine($"Сумма = {sum}");
        }
        #endregion

        #region Задание 5
        static void Task5()
        {
            Console.Write("Введите N: ");
            int N = int.Parse(Console.ReadLine());
            for (int i = 1; i <= N; i++)
            {
                if (i % 5 != 0 && i % 3 == 0)
                {
                    int s = SumDigits(i);
                    if (s % 5 != 0 && s % 3 == 0)
                        Console.WriteLine(i);
                }
            }
        }
        static int SumDigits(int x)
        {
            int s = 0;
            while (x > 0) { s += x % 10; x /= 10; }
            return s;
        }
        #endregion

        #region Задание 6
        static void Task6()
        {
            Console.Write("Введите N: ");
            int N = int.Parse(Console.ReadLine());
            for (int i = 1; i <= N; i++) if (i % 5 == 0) Console.WriteLine(i);
        }
        #endregion

        #region Задание 7
        static void Task7()
        {
            Console.Write("Введите число: ");
            int n = int.Parse(Console.ReadLine());
            bool isPowerOfTwo = (n > 0) && ((n & (n - 1)) == 0);
            Console.WriteLine(isPowerOfTwo ? "Является степенью двойки" : "Не является степенью двойки");
        }
        #endregion

        #region Задание 8
        static void Task8()
        {
            Console.Write("Введите число: ");
            int n = int.Parse(Console.ReadLine());
            Console.Write($"Разложение на множители: ");
            for (int i = 2; i <= n; i++)
            {
                while (n % i == 0)
                {
                    Console.Write(i + " ");
                    n /= i;
                }
            }
            Console.WriteLine();
        }
        #endregion

        #region Задание 9
        static void Task9()
        {
            Console.Write("Введите X: ");
            int X = int.Parse(Console.ReadLine());
            for (int n = 2; n <= X; n++)
            {
                int sum = 0;
                for (int d = 1; d < n; d++) if (n % d == 0) sum += d;
                if (sum == n) Console.WriteLine(n);
            }
        }
        #endregion

        #region Задание 10
        static void Task10()
        {
            Console.Write("Введите m: ");
            int m = int.Parse(Console.ReadLine());
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            long sum = 0;
            for (int i = m; i <= n; i++) sum += i * i;
            Console.WriteLine($"Сумма квадратов = {sum}");
        }
        #endregion

        #region Задание 11
        static void Task11()
        {
            Console.Write("Введите m: ");
            int m = int.Parse(Console.ReadLine());
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            long sum = 0;
            for (int i = m; i <= n; i++) if (i % 2 != 0) sum += i * i;
            Console.WriteLine($"Сумма квадратов нечётных = {sum}");
        }
        #endregion

        #region Задание 12
        static void Task12()
        {
            long prod = 1;
            for (int i = -80; i <= 80; i++)
                if (i % 2 != 0 && i % 7 == 0) prod *= i;
            Console.WriteLine($"Произведение = {prod}");
        }
        #endregion

        #region Задание 13
        static void Task13()
        {
            int sum = 0;
            for (int i = -10; i <= 10; i++) if (i > 0 && i % 9 == 0) sum += i;
            Console.WriteLine($"Сумма = {sum}");
        }
        #endregion

        #region Задание 14
        static void Task14()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            int count = 0;
            for (int i = 100; i <= 800; i++) if (i > n) count++;
            Console.WriteLine($"Количество = {count}");
        }
        #endregion

        #region Задание 15
        static void Task15()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            for (int i = 1; i < n; i++)
            {
                if (Gcd(i, n) == 1) Console.Write(i + " ");
            }
            Console.WriteLine();
        }
        static int Gcd(int a, int b)
        {
            while (b != 0) { int t = a % b; a = b; b = t; }
            return a;
        }
        #endregion

        #region Задание 16
        static void Task16()
        {
            Console.Write("Введите p: ");
            int p = int.Parse(Console.ReadLine());
            Console.Write("Введите d: ");
            int d = int.Parse(Console.ReadLine());
            for (int i = 1; i <= d; i++)
                if (d % i == 0 && Gcd(i, p) == 1) Console.Write(i + " ");
            Console.WriteLine();
        }
        #endregion

        #region Задание 17
        static void Task17()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            for (int i = 2; i <= n; i++)
                if (n % i == 0 && IsPrime(i)) Console.Write(i + " ");
            Console.WriteLine();
        }
        static bool IsPrime(int n)
        {
            if (n < 2) return false;
            for (int i = 2; i * i <= n; i++) if (n % i == 0) return false;
            return true;
        }
        #endregion

        #region Задание 18
        static void Task18()
        {
            int count = 0, num = 2;
            while (count < 100)
            {
                if (IsPrime(num)) { Console.Write(num + " "); count++; }
                num++;
            }
            Console.WriteLine();
        }
        #endregion

        #region Задание 19
        static void Task19()
        {
            Console.Write("Введите m: ");
            int m = int.Parse(Console.ReadLine());
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            long prod = 1;
            for (int i = m; i <= n; i++) if (i % 2 == 0) prod *= (i * i);
            Console.WriteLine($"Произведение = {prod}");
        }
        #endregion

        #region Задание 20
        static void Task20()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            long sum = 0;
            for (int i = 1; i <= n; i++)
            {
                long term = 1;
                for (int j = i; j <= 2 * i; j++) term *= j;
                sum += term;
            }
            Console.WriteLine($"Сумма = {sum}");
        }
        #endregion

        #region Задание 21
        static void Task21()
        {
            Console.Write("Введите N: ");
            int N = int.Parse(Console.ReadLine());
            long diff = 0;
            for (int i = 1; i <= N; i += 2) diff -= i * i * i;
            Console.WriteLine($"Разность кубов = {diff}");
        }
        #endregion

        #region Задание 22
        static void Task22()
        {
            Console.Write("Введите m: ");
            int m = int.Parse(Console.ReadLine());
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            long sum = 0;
            for (int i = m; i <= n; i++) sum += i;
            long result = sum * sum;
            Console.WriteLine($"(Сумма)^2 = {result}");
        }
        #endregion
    }
}