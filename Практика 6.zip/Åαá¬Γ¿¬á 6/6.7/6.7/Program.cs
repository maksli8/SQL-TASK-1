﻿using System;

namespace Functions19_30
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Выберите номер варианта (19-30): ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 19: Task19(); break;
                case 20: Task20(); break;
                case 21: Task21(); break;
                case 22: Task22(); break;
                case 23: Task23(); break;
                case 24: Task24(); break;
                case 25: Task25(); break;
                case 26: Task26(); break;
                case 27: Task27(); break;
                case 28: Task28(); break;
                case 29: Task29(); break;
                case 30: Task30(); break;
                default: Console.WriteLine("Такого варианта нет."); break;
            }
        }

        static void PrintValues(double a, double b, double h, Func<double, double> f)
        {
            for (double x = a; x <= b; x += h)
                Console.WriteLine($"x = {x:F2}, y = {f(x):F4}");
        }

        #region Вариант 19
        static void Task19() => PrintValues(1.1, 2.9, 0.1, x => Math.Pow(x, 3) - 6 * x * x + 2);
        #endregion

        #region Вариант 20
        static void Task20() => PrintValues(1, 3, 1, x => 3 * Math.Sin(Math.Sqrt(x)) + 0.25 * x - 3);
        #endregion

        #region Вариант 21
        static void Task21() => PrintValues(0, 2, 1, x => 3 * Math.Cos(x) - Math.Abs(x - 4) + 2);
        #endregion

        #region Вариант 22
        static void Task22() => PrintValues(1.1, 2.9, 0.1, x => 0.25 * x * x - 2.8 * x - 2);
        #endregion

        #region Вариант 23
        static void Task23() => PrintValues(1, 3, 1, x => Math.Log(x * x) - 1.8 * Math.Sin(x));
        #endregion

        #region Вариант 24
        static void Task24() => PrintValues(0, 3, 1, x => x * x + 4 * Math.Sin(Math.PI * x));
        #endregion

        #region Вариант 25
        static void Task25() => PrintValues(1, 2.9, 0.9, x => 0.5 * x * x - 1 - Math.Log(x - 3));
        #endregion

        #region Вариант 26
        static void Task26() => PrintValues(0, 3, 1, x => Math.Sqrt(1 + x) - 3 * Math.Cos(x));
        #endregion

        #region Вариант 27
        static void Task27() => PrintValues(1, 3, 1, x => Math.Log(x * x) + x - 5);
        #endregion

        #region Вариант 28
        static void Task28() => PrintValues(0, 2, 1, x => Math.Pow(x, 3) - 1.75 * x + 0.75);
        #endregion

        #region Вариант 29
        static void Task29() => PrintValues(0, 2, 1, x => 0.5 * x - 1 - 2 * Math.Cos(x + Math.PI / 4));
        #endregion

        #region Вариант 30
        static void Task30() => PrintValues(1.1, 3.1, 1, x => 3 * x - 2 * Math.Log(x) - 5);
        #endregion
    }
}