﻿using System;

namespace Functions1_18
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Выберите номер варианта (1-18): ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1: Task1(); break;
                case 2: Task2(); break;
                case 3: Task3(); break;
                case 4: Task4(); break;
                case 5: Task5(); break;
                case 6: Task6(); break;
                case 7: Task7(); break;
                case 8: Task8(); break;
                case 9: Task9(); break;
                case 10: Task10(); break;
                case 11: Task11(); break;
                case 12: Task12(); break;
                case 13: Task13(); break;
                case 14: Task14(); break;
                case 15: Task15(); break;
                case 16: Task16(); break;
                case 17: Task17(); break;
                case 18: Task18(); break;
                default: Console.WriteLine("Такого варианта нет."); break;
            }
        }

        static void PrintValues(double a, double b, double h, Func<double, double> f)
        {
            for (double x = a; x <= b; x += h)
                Console.WriteLine($"x = {x:F2}, y = {f(x):F4}");
        }

        #region Вариант 1
        static void Task1() => PrintValues(0, 2, 1, x => x * x + Math.Sin(5 * x));
        #endregion

        #region Вариант 2
        static void Task2() => PrintValues(1, 3, 1, x => x * x - Math.Cos(Math.PI * x) * Math.Cos(Math.PI * x));
        #endregion

        #region Вариант 3
        static void Task3() => PrintValues(0, 2, 2, x => 1.8 * x - Math.Sin(10 * x));
        #endregion

        #region Вариант 4
        static void Task4() => PrintValues(2, 4, 1, x => Math.Pow(2, x) - 2 * x * x - 1);
        #endregion

        #region Вариант 5
        static void Task5() => PrintValues(0, 2, 1, x => x * x - Math.Cos(x + 1));
        #endregion

        #region Вариант 6
        static void Task6() => PrintValues(1, 3, 1, x => Math.Pow(x, 3) - 4 * x * x + 2);
        #endregion

        #region Вариант 7
        static void Task7() => PrintValues(0.15, 2.1, 0.1, x => x - Math.Cos(0.04 * x));
        #endregion

        #region Вариант 8
        static void Task8() => PrintValues(1, 3, 1, x => Math.Exp(x) - 2 * Math.Sqrt(x));
        #endregion

        #region Вариант 9
        static void Task9() => PrintValues(2, 4, 1, x => Math.Pow(x, 3) + 3 * x * x - 3);
        #endregion

        #region Вариант 10
        static void Task10() => PrintValues(0, 2.5, 0.5, x => x * x + 2 * Math.PI * Math.Cos(Math.PI * x));
        #endregion

        #region Вариант 11
        static void Task11() => PrintValues(1.3, 4, 0.5, x => 5 * Math.Pow(x, 3) + 2 * x * x - 15 * x - 6);
        #endregion

        #region Вариант 12
        static void Task12() => PrintValues(2, 4.1, 0.1, x => Math.Log10(x) - Math.Pow((x - 2), 2));
        #endregion

        #region Вариант 13
        static void Task13() => PrintValues(0, 2.5, 0.5, x => Math.Sqrt(x) - 2 * Math.Cos(0.5 * Math.PI * x));
        #endregion

        #region Вариант 14
        static void Task14() => PrintValues(0, 2, 1, x => x * x - x * Math.Cos(Math.PI * x));
        #endregion

        #region Вариант 15
        static void Task15() => PrintValues(1, 3, 1, x => Math.Pow(x, 3) - 7 * x - 7);
        #endregion

        #region Вариант 16
        static void Task16() => PrintValues(0.1, 2.7, 0.1, x => Math.Abs(x * x - 4) + 0.25 * x - 2);
        #endregion

        #region Вариант 17
        static void Task17() => PrintValues(0, 2, 1, x => x * x - Math.Sin(Math.PI * x));
        #endregion

        #region Вариант 18
        static void Task18() => PrintValues(1, 29, 1, x => Math.Log(x * x) - x + 4);
        #endregion
    }
}