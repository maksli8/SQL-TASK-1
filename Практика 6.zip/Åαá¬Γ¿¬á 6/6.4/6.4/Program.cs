﻿using System;

namespace Tasks9_30
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Выберите номер задания (9-30): ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 9: Task9(); break;
                case 10: Task10(); break;
                case 11: Task11(); break;
                case 12: Task12(); break;
                case 13: Task13(); break;
                case 14: Task14(); break;
                case 15: Task15(); break;
                case 24: Task24(); break;
                case 25: Task25(); break;
                case 26: Task26(); break;
                case 27: Task27(); break;
                case 28: Task28(); break;
                case 29: Task29(); break;
                case 30: Task30(); break;
                default: Console.WriteLine("Такого задания нет."); break;
            }
        }

        #region Задание 9
        static void Task9()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double W = 0;
            for (int i = 1; i <= k; i++)
                W += Math.Pow(-1, i) * Math.Pow(i - 3, 2) / Factorial(i);
            Console.WriteLine($"W = {W}");
        }
        #endregion

        #region Задание 10
        static void Task10()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            double Q = 0;
            for (int k = 1; k <= n; k++)
                Q += Math.Pow(-1, k) * (k - 7) / Factorial(k + n);
            Console.WriteLine($"Q = {Q}");
        }
        #endregion

        #region Задание 11
        static void Task11()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());
            double S = 0;
            for (int k = 1; k <= n; k++)
                S += Math.Pow(-1, 3 * k + 1) * Math.Pow(x, k + 7) * (Math.Pow(k, 2) - 9) / (k - 2);
            Console.WriteLine($"S = {S}");
        }
        #endregion

        #region Задание 12
        static void Task12()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double W = 0;
            for (int i = 1; i <= k; i++)
                W += Math.Pow(-1, i) * Math.Pow(i, 3) / (i - 3);
            Console.WriteLine($"W = {W}");
        }
        #endregion

        #region Задание 13
        static void Task13()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            double Q = 0;
            for (int k = 1; k <= n; k++)
                Q += Math.Pow(k - 3, k - 5) * (k + 7) / Factorial(k);
            Console.WriteLine($"Q = {Q}");
        }
        #endregion

        #region Задание 14
        static void Task14()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());
            double S = 0;
            for (int k = 1; k <= n; k++)
                S += Math.Pow(-2, k) * Math.Pow(x, k + 7) * Math.Pow(3, k) / (k - 5);
            Console.WriteLine($"S = {S}");
        }
        #endregion

        #region Задание 15
        static void Task15()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double Y = 0;
            for (int n = 1; n <= k; n++)
                Y += Math.Pow(-1, n) * (Math.Pow(n, 2) - 9) / Factorial(3 * n);
            Console.WriteLine($"Y = {Y}");
        }
        #endregion

        #region Задание 24
        static void Task24()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double Z = 1;
            for (int j = 3; j <= k; j++)
                Z *= (j + 2) / (j - 3) * ((j + 5) / (j - 11));
            Console.WriteLine($"Z = {Z}");
        }
        #endregion

        #region Задание 25
        static void Task25()
        {
            Console.Write("Введите n: ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("Введите x: ");
            double x = double.Parse(Console.ReadLine());
            double S = 0;
            for (int k = 1; k <= n; k++)
                S += Math.Pow(-3, 3 * k + 1) * x / (k - 2);
            Console.WriteLine($"S = {S}");
        }
        #endregion

        #region Задание 26
        static void Task26()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double P = 1;
            for (int j = 1; j <= k; j++)
                P *= (j - 6) / (j - 3) * Math.Sqrt(j / 5.0);
            Console.WriteLine($"P = {P}");
        }
        #endregion

        #region Задание 27
        static void Task27()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double Z = 1;
            for (int j = 4; j <= k; j++)
                Z *= (j + 2) / (j - 3) * Math.Sqrt(j / 5.0 + 5);
            Console.WriteLine($"Z = {Z}");
        }
        #endregion

        #region Задание 28
        static void Task28()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double Z = 1;
            for (int n = 3; n <= k; n++)
                Z *= (n + 2) / (n + 3) - 9;
            Console.WriteLine($"Z = {Z}");
        }
        #endregion

        #region Задание 29
        static void Task29()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double P = 1;
            for (int j = 2; j <= k; j++)
                P *= (j - 6) / ((j - 3) * (j - 1));
            Console.WriteLine($"P = {P}");
        }
        #endregion

        #region Задание 30
        static void Task30()
        {
            Console.Write("Введите k: ");
            int k = int.Parse(Console.ReadLine());
            double A = 1;
            for (int j = 3; j <= k; j++)
                A *= (j - 4) / (j - 3) * Math.Sqrt(j / 5.0);
            Console.WriteLine($"A = {A}");
        }
        #endregion

        static double Factorial(int n)
        {
            if (n < 0) return 1;
            double f = 1;
            for (int i = 2; i <= n; i++) f *= i;
            return f;
        }
    }
}