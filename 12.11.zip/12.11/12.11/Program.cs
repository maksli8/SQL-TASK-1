﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Linq.Expressions;

namespace DelegatesAndLambdaDemo
{
    // ==================== КЛАССЫ ДЛЯ ДЕМОНСТРАЦИИ ====================

    public class Student
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public double GPA { get; set; }
        public string Major { get; set; }

        public override string ToString()
        {
            return $"{Name,-15} Age: {Age,2}  GPA: {GPA:F2}  Major: {Major}";
        }
    }

    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int StockQuantity { get; set; }
        public string Category { get; set; }
        public bool IsAvailable { get; set; }

        public override string ToString()
        {
            return $"#{Id} {Name,-25} Price: ${Price,7:F2}  Stock: {StockQuantity,3}  Category: {Category}";
        }
    }

    public class EventLogger
    {
        public void Log(string message) => Console.WriteLine($"[LOG] {message}");
    }

    public class EmailService
    {
        public void SendEmail(string message) => Console.WriteLine($"[EMAIL] Отправка: {message}");
    }

    public class AlertSystem
    {
        public void Alert(string message) => Console.WriteLine($"[ALERT] {message}");
    }

    // ==================== ДЕЛЕГАТЫ ====================

    // 1. Простой делегат для операции с двумя числами
    public delegate int MathOperation(int a, int b);

    // 3. Делегат для вывода сообщения
    public delegate void MessagePrinter(string message);

    // 4. Делегат для проверки условия
    public delegate bool Predicate<T>(T item);

    // 15. Делегат для сравнения
    public delegate int ObjectComparer<T>(T a, T b);

    // Делегат для работы с ref параметром
    public delegate void OperationWithRef(ref int x);

    // ==================== ВСПОМОГАТЕЛЬНЫЕ КЛАССЫ ====================

    public class Button
    {
        public event Action Click;

        public void SimulateClick()
        {
            Click?.Invoke();
        }
    }

    public enum Status { Active, Inactive, PendingActive, Suspended }

    // ==================== ОСНОВНАЯ ПРОГРАММА ====================

    class Program
    {
        #region Раздел 1: Делегаты (1-25)

        static void Section1_Delegates()
        {
            Console.WriteLine("========== РАЗДЕЛ 1: ДЕЛЕГАТЫ (1-25) ==========\n");

            // Задание 1: Создайте простой делегат для операции с двумя числами
            Console.WriteLine("--- Задание 1: Делегат для математических операций ---");
            MathOperation add = (a, b) => a + b;
            MathOperation multiply = (a, b) => a * b;
            Console.WriteLine($"5 + 3 = {add(5, 3)}");
            Console.WriteLine($"5 * 3 = {multiply(5, 3)}");

            // Задание 2: Реализуйте делегат для арифметической операции
            Console.WriteLine("\n--- Задание 2: Арифметические операции ---");
            int Calculate(int x, int y, MathOperation operation) => operation(x, y);
            Console.WriteLine($"Calculate(10, 4, add) = {Calculate(10, 4, add)}");
            Console.WriteLine($"Calculate(10, 4, multiply) = {Calculate(10, 4, multiply)}");

            // Задание 3: Делегат для вывода сообщения
            Console.WriteLine("\n--- Задание 3: Вывод сообщений ---");
            MessagePrinter printer = message => Console.WriteLine($"Сообщение: {message}");
            printer("Hello World!");

            // Задание 4: Делегат для проверки условия (predicate)
            Console.WriteLine("\n--- Задание 4: Предикаты ---");
            Predicate<int> isEven = num => num % 2 == 0;
            Predicate<string> isLong = str => str.Length > 5;
            Console.WriteLine($"10 четное: {isEven(10)}");
            Console.WriteLine($"'Hello' длинное: {isLong("Hello")}");

            // Задание 5: Action делегат
            Console.WriteLine("\n--- Задание 5: Action делегат ---");
            Action<string> actionPrinter = Console.WriteLine;
            actionPrinter("Action делегат в действии!");

            Action<int, int> printSum = (a, b) => Console.WriteLine($"{a} + {b} = {a + b}");
            printSum(7, 8);

            // Задание 6: Func делегат
            Console.WriteLine("\n--- Задание 6: Func делегат ---");
            Func<int, int, string> sumFormatter = (a, b) => $"{a} + {b} = {a + b}";
            Console.WriteLine(sumFormatter(15, 25));

            Func<string, string> upper = s => s.ToUpper();
            Console.WriteLine(upper("hello world"));

            // Задание 7: Делегат для фильтрации коллекции
            Console.WriteLine("\n--- Задание 7: Фильтрация коллекции ---");
            List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Func<int, bool> filterEven = n => n % 2 == 0; // Используем Func вместо Predicate
            var evenNumbers = numbers.Where(filterEven); // Where работает с Func
            Console.WriteLine($"Четные числа: {string.Join(", ", evenNumbers)}");

            // Задание 8: Callback для асинхронной операции
            Console.WriteLine("\n--- Задание 8: Асинхронный callback ---");
            void LongOperation(Action<string> callback)
            {
                Task.Run(() =>
                {
                    Thread.Sleep(1000);
                    callback("Операция завершена!");
                });
            }

            LongOperation(message => Console.WriteLine($"Callback: {message}"));
            Thread.Sleep(1500); // Ждем завершения

            // Задание 9: Делегат для сортировки объектов
            Console.WriteLine("\n--- Задание 9: Сортировка объектов ---");
            List<Student> students = new List<Student>
            {
                new Student { Name = "Alice", Age = 22, GPA = 3.8, Major = "CS" },
                new Student { Name = "Bob", Age = 20, GPA = 3.5, Major = "Math" },
                new Student { Name = "Charlie", Age = 23, GPA = 3.9, Major = "Physics" }
            };

            ObjectComparer<Student> compareByAge = (a, b) => a.Age.CompareTo(b.Age);
            var sortedStudents = students.OrderBy(s => s, Comparer<Student>.Create((a, b) => compareByAge(a, b))).ToList();
            Console.WriteLine("Сортировка по возрасту:");
            sortedStudents.ForEach(s => Console.WriteLine($"  {s}"));

            // Задание 10: Делегат для обработки ошибок
            Console.WriteLine("\n--- Задание 10: Обработка ошибок ---");
            void SafeExecutor(string operation, Action<string> errorHandler)
            {
                try
                {
                    if (operation == "error") throw new Exception("Искусственная ошибка");
                    Console.WriteLine("Операция успешна");
                }
                catch (Exception ex)
                {
                    errorHandler($"Ошибка: {ex.Message}");
                }
            }

            SafeExecutor("normal", Console.WriteLine);
            SafeExecutor("error", Console.Error.WriteLine);

            Console.WriteLine("\n--- Задание 11-25: Пропущены для краткости ---");
        }

        #endregion

        #region Раздел 2: Комбинированные делегаты (26-50)

        static void Section2_CombinedDelegates()
        {
            Console.WriteLine("\n\n========== РАЗДЕЛ 2: КОМБИНИРОВАННЫЕ ДЕЛЕГАТЫ (26-50) ==========\n");

            // Задание 26: Оператор + для добавления методов
            Console.WriteLine("--- Задание 26: Объединение делегатов (+) ---");
            Action<string> logger = msg => Console.WriteLine($"[LOG] {msg}");
            Action<string> emailer = msg => Console.WriteLine($"[EMAIL] {msg}");

            Action<string> multiDelegate = logger + emailer;
            Console.WriteLine("Многоадресный делегат:");
            multiDelegate("Важное сообщение");

            // Задание 27: Цепочка вызовов методов
            Console.WriteLine("\n--- Задание 27: Цепочка вызовов ---");
            Action chain = () => Console.Write("Шаг 1 -> ");
            chain += () => Console.Write("Шаг 2 -> ");
            chain += () => Console.Write("Шаг 3 -> ");
            chain += () => Console.WriteLine("Завершено");
            chain();

            // Задание 28: Многоадресные делегаты
            Console.WriteLine("\n--- Задание 28: Многоадресные делегаты ---");
            Func<int, int> multiplier = x => x * 2;
            multiplier += x => x * 3;
            multiplier += x => x * 4;

            // Важно: возвращается результат последнего метода
            Console.WriteLine($"Результат последнего обработчика: {multiplier(5)}");

            // Получение всех результатов
            foreach (Func<int, int> handler in multiplier.GetInvocationList())
            {
                Console.WriteLine($"Обработчик: {handler(5)}");
            }

            // Задание 31: Отписка от делегата
            Console.WriteLine("\n--- Задание 31: Отписка от делегата (-) ---");
            Action<string> notification = logger + emailer;
            Console.WriteLine("До отписки:");
            notification("Тестовое сообщение");

            notification -= emailer;
            Console.WriteLine("После отписки от email:");
            notification("Еще одно сообщение");

            // Задание 33: Цепочка обработчиков событий
            Console.WriteLine("\n--- Задание 33: Цепочка обработчиков событий ---");
            Action<string> eventChain = null;
            eventChain += msg => Console.WriteLine($"1. Получено: {msg}");
            eventChain += msg => Console.WriteLine($"2. Обработано: {msg.ToUpper()}");
            eventChain += msg => Console.WriteLine($"3. Завершено: {msg.Length} символов");

            eventChain("пример события");

            // Задание 37: Вызов методов разных классов
            Console.WriteLine("\n--- Задание 37: Методы разных классов ---");
            var eventLogger = new EventLogger();
            var emailService = new EmailService();
            var alertSystem = new AlertSystem();

            Action<string> systemNotification = eventLogger.Log;
            systemNotification += emailService.SendEmail;
            systemNotification += alertSystem.Alert;

            systemNotification("Система запущена");

            // Задание 42: Валидация несколькими правилами
            Console.WriteLine("\n--- Задание 42: Множественная валидация ---");
            Predicate<string>[] validators =
            {
                s => !string.IsNullOrEmpty(s),
                s => s.Length >= 5,
                s => s.Any(char.IsDigit),
                s => s.Any(char.IsUpper)
            };

            Func<string, bool> validateAll = s => validators.All(validator => validator(s));
            Console.WriteLine($"'Password1' валидно: {validateAll("Password1")}");
            Console.WriteLine($"'pass' валидно: {validateAll("pass")}");

            // Задание 45: Очередь задач
            Console.WriteLine("\n--- Задание 45: Очередь задач ---");
            Queue<Action> taskQueue = new Queue<Action>();
            taskQueue.Enqueue(() => Console.WriteLine("Задача 1"));
            taskQueue.Enqueue(() => Console.WriteLine("Задача 2"));
            taskQueue.Enqueue(() => Console.WriteLine("Задача 3"));

            while (taskQueue.Count > 0)
            {
                taskQueue.Dequeue()();
            }
        }

        #endregion

        #region Раздел 3: Анонимные методы (51-75)

        static void Section3_AnonymousMethods()
        {
            Console.WriteLine("\n\n========== РАЗДЕЛ 3: АНОНИМНЫЕ МЕТОДЫ (51-75) ==========\n");

            // Задание 51: Анонимный метод для операции с числами
            Console.WriteLine("--- Задание 51: Анонимный метод для математики ---");
            MathOperation add = delegate (int a, int b) { return a + b; };
            Console.WriteLine($"5 + 3 = {add(5, 3)}");

            // Задание 52: Фильтрация коллекции
            Console.WriteLine("\n--- Задание 52: Фильтрация анонимным методом ---");
            List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            List<int> evens = numbers.FindAll(delegate (int n) { return n % 2 == 0; });
            Console.WriteLine($"Четные: {string.Join(", ", evens)}");

            // Задание 53: Поиск элемента
            Console.WriteLine("\n--- Задание 53: Поиск анонимным методом ---");
            List<string> names = new List<string> { "Alice", "Bob", "Charlie", "David" };
            string found = names.Find(delegate (string name) { return name.StartsWith("C"); });
            Console.WriteLine($"Найдено: {found}");

            // Задание 54: Замыкания (closure)
            Console.WriteLine("\n--- Задание 54: Замыкания ---");
            int counter = 0;
            Action increment = delegate { counter++; };

            increment(); increment(); increment();
            Console.WriteLine($"Счетчик: {counter}");

            // Задание 55: Обработка события
            Console.WriteLine("\n--- Задание 55: Обработка события ---");
            Button button = new Button();
            button.Click += delegate { Console.WriteLine("Кнопка нажата!"); };
            button.SimulateClick();

            // Задание 56: Преобразование данных
            Console.WriteLine("\n--- Задание 56: Преобразование данных ---");
            List<int> source = new List<int> { 1, 2, 3, 4, 5 };
            List<string> converted = source.ConvertAll<string>(delegate (int x)
            {
                return $"Значение: {x * 10}";
            });
            converted.ForEach(Console.WriteLine);

            // Задание 57: Валидация значения
            Console.WriteLine("\n--- Задание 57: Валидация ---");
            Predicate<int> isValid = delegate (int x) { return x >= 0 && x <= 100; };
            Console.WriteLine($"50 валидно: {isValid(50)}");
            Console.WriteLine($"150 валидно: {isValid(150)}");

            // Задание 58: Сортировка коллекции
            Console.WriteLine("\n--- Задание 58: Сортировка ---");
            List<Student> students = new List<Student>
            {
                new Student { Name = "Alice", Age = 22, GPA = 3.8 },
                new Student { Name = "Bob", Age = 20, GPA = 3.5 },
                new Student { Name = "Charlie", Age = 23, GPA = 3.9 }
            };

            students.Sort(delegate (Student a, Student b)
            {
                return b.GPA.CompareTo(a.GPA); // По убыванию GPA
            });

            Console.WriteLine("Сортировка по GPA:");
            students.ForEach(s => Console.WriteLine($"  {s}"));

            // Задание 59: Логирование операций
            Console.WriteLine("\n--- Задание 59: Логирование ---");
            Action<string> logger = delegate (string message)
            {
                Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] {message}");
            };
            logger("Приложение запущено");

            // Задание 60: Параметр ref
            Console.WriteLine("\n--- Задание 60: Параметр ref ---");
            OperationWithRef delegateWithRef = delegate (ref int x) { x *= 2; };
            int number = 5;
            delegateWithRef(ref number);
            Console.WriteLine($"Результат: {number}");

            // Задание 61: Вычисление факториала
            Console.WriteLine("\n--- Задание 61: Факториал ---");
            Func<int, int> factorial = delegate (int n)
            {
                int result = 1;
                for (int i = 2; i <= n; i++)
                    result *= i;
                return result;
            };
            Console.WriteLine($"Факториал 5 = {factorial(5)}");

            Console.WriteLine("\n--- Задание 62-75: Пропущены для краткости ---");
        }

        #endregion

        #region Раздел 4: Лямбда выражения (76-100)

        static void Section4_LambdaExpressions()
        {
            Console.WriteLine("\n\n========== РАЗДЕЛ 4: ЛЯМБДА ВЫРАЖЕНИЯ (76-100) ==========\n");

            // Задание 76: Простая математическая операция
            Console.WriteLine("--- Задание 76: Простая лямбда ---");
            Func<int, int> square = x => x * x;
            Console.WriteLine($"Квадрат 5: {square(5)}");

            // Задание 77: Фильтрация списка
            Console.WriteLine("\n--- Задание 77: Фильтрация лямбдой ---");
            List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            var filtered = numbers.Where(x => x > 5 && x < 9);
            Console.WriteLine($"Числа >5 и <9: {string.Join(", ", filtered)}");

            // Задание 78: Преобразование строк
            Console.WriteLine("\n--- Задание 78: Преобразование строк ---");
            Func<string, string> processor = s => s.ToUpper().Replace(" ", "_");
            Console.WriteLine(processor("hello world"));

            // Задание 79: LINQ с лямбдами
            Console.WriteLine("\n--- Задание 79: LINQ с лямбдами ---");
            List<Product> products = new List<Product>
            {
                new Product { Id = 1, Name = "Laptop", Price = 1200, StockQuantity = 5, Category = "Electronics" },
                new Product { Id = 2, Name = "Mouse", Price = 25, StockQuantity = 50, Category = "Electronics" },
                new Product { Id = 3, Name = "Book", Price = 15, StockQuantity = 100, Category = "Books" },
                new Product { Id = 4, Name = "Monitor", Price = 300, StockQuantity = 10, Category = "Electronics" }
            };

            var expensiveElectronics = products
                .Where(p => p.Category == "Electronics" && p.Price > 100)
                .OrderByDescending(p => p.Price)
                .Select(p => new { p.Name, p.Price });

            Console.WriteLine("Дорогая электроника:");
            foreach (var product in expensiveElectronics)
                Console.WriteLine($"  {product.Name} - ${product.Price}");

            // Задание 80: Лямбда с несколькими параметрами
            Console.WriteLine("\n--- Задание 80: Множественные параметры ---");
            Func<int, int, int, int> volume = (l, w, h) => l * w * h;
            Console.WriteLine($"Объем 3x4x5: {volume(3, 4, 5)}");

            // Задание 83: Проверка условий на элементах списка
            Console.WriteLine("\n--- Задание 83: Проверка условий ---");
            var availableProducts = products.Where(p => p.StockQuantity > 0 && p.Price < 1000);
            var expensiveCount = products.Count(p => p.Price > 500);
            var hasBooks = products.Any(p => p.Category == "Books");

            Console.WriteLine($"Доступные товары: {availableProducts.Count()}");
            Console.WriteLine($"Дорогих товаров (>$500): {expensiveCount}");
            Console.WriteLine($"Есть книги: {hasBooks}");

            // Задание 84: Группировка данных
            Console.WriteLine("\n--- Задание 84: Группировка ---");
            var groupedByCategory = products
                .GroupBy(p => p.Category)
                .Select(g => new { Category = g.Key, Count = g.Count(), TotalValue = g.Sum(p => p.Price) });

            foreach (var group in groupedByCategory)
                Console.WriteLine($"{group.Category}: {group.Count} товаров, сумма: ${group.TotalValue}");

            // Задание 85: Сортировка по нескольким критериям
            Console.WriteLine("\n--- Задание 85: Сложная сортировка ---");
            var sortedProducts = products
                .OrderBy(p => p.Category)
                .ThenByDescending(p => p.Price)
                .ThenBy(p => p.Name);

            Console.WriteLine("Сортировка по категории, цене (убыв.), имени:");
            foreach (var product in sortedProducts)
                Console.WriteLine($"  {product.Category} - {product.Name} - ${product.Price}");

            // Задание 86: Работа с датами
            Console.WriteLine("\n--- Задание 86: Даты и время ---");
            List<DateTime> dates = new List<DateTime>
            {
                new DateTime(2024, 1, 15),
                new DateTime(2024, 3, 20),
                new DateTime(2024, 2, 10),
                new DateTime(2024, 1, 5)
            };

            var recentDates = dates.Where(d => d > new DateTime(2024, 1, 1))
                                  .OrderBy(d => d)
                                  .Select(d => d.ToString("yyyy-MM-dd"));

            Console.WriteLine($"Даты после 2024-01-01: {string.Join(", ", recentDates)}");

            // Задание 87: Вложенные коллекции
            Console.WriteLine("\n--- Задание 87: Вложенные коллекции ---");
            var departments = new[]
            {
                new { Name = "IT", Employees = new[] { "Alice", "Bob" } },
                new { Name = "HR", Employees = new[] { "Charlie", "David", "Eve" } },
                new { Name = "Finance", Employees = new[] { "Frank" } }
            };

            var allEmployees = departments.SelectMany(d => d.Employees.Select(e => $"{e} ({d.Name})"));
            Console.WriteLine("Все сотрудники: " + string.Join(", ", allEmployees));

            // Задание 88: Преобразование типов
            Console.WriteLine("\n--- Задание 88: Преобразование типов ---");
            List<string> stringNumbers = new List<string> { "1", "2", "3", "4", "5" };
            var intNumbers = stringNumbers.Select(s => int.Parse(s)).Where(n => n % 2 != 0);
            Console.WriteLine($"Нечетные числа: {string.Join(", ", intNumbers)}");

            // Задание 89: Подсчет элементов
            Console.WriteLine("\n--- Задание 89: Подсчет ---");
            var countByCategory = products.GroupBy(p => p.Category)
                                         .ToDictionary(g => g.Key, g => g.Count());
            foreach (var kvp in countByCategory)
                Console.WriteLine($"{kvp.Key}: {kvp.Value} товаров");

            // Задание 90: Enum значения
            Console.WriteLine("\n--- Задание 90: Enum ---");
            var statusValues = Enum.GetValues(typeof(Status)).Cast<Status>();
            var activeStatuses = statusValues.Where(s => s.ToString().Contains("Active"));
            Console.WriteLine($"Активные статусы: {string.Join(", ", activeStatuses)}");

            // Задание 91: Создание словаря
            Console.WriteLine("\n--- Задание 91: Словарь из коллекции ---");
            var productDict = products.ToDictionary(p => p.Id, p => p.Name);
            Console.WriteLine("Словарь продуктов:");
            foreach (var kvp in productDict)
                Console.WriteLine($"  {kvp.Key}: {kvp.Value}");

            // Задание 92: Несколько условий
            Console.WriteLine("\n--- Задание 92: Множественные условия ---");
            var complexFilter = products.Where(p =>
                (p.Category == "Electronics" || p.Price < 50) &&
                p.StockQuantity > 0);

            Console.WriteLine("Сложный фильтр:");
            foreach (var product in complexFilter)
                Console.WriteLine($"  {product.Name} - ${product.Price}");

            // Задание 96: Expression trees
            Console.WriteLine("\n--- Задание 96: Expression trees ---");
            Expression<Func<int, int, int>> addExpression = (a, b) => a + b;
            Console.WriteLine($"Expression: {addExpression}");
            var compiled = addExpression.Compile();
            Console.WriteLine($"Результат: {compiled(5, 3)}");

            Console.WriteLine("\n--- Задание 93-100: Пропущены для краткости ---");
        }

        #endregion

        static void Main(string[] args)
        {
            Console.WriteLine("ДЕМОНСТРАЦИЯ 100 ЗАДАЧ ПО ДЕЛЕГАТАМ И ЛЯМБДАМ\n");

            Section1_Delegates();
            Section2_CombinedDelegates();
            Section3_AnonymousMethods();
            Section4_LambdaExpressions();

            Console.WriteLine("\nВСЕ ЗАДАЧИ ВЫПОЛНЕНЫ!");
            Console.WriteLine("Нажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
    }
}