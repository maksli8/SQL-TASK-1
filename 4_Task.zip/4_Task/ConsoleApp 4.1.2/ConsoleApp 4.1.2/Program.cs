﻿// 16
//Console.WriteLine("Введите координаты точки (x, y)");
//double x = Convert.ToDouble(Console.ReadLine());
//double y = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите радиусы R и r");
//double R = Convert.ToDouble(Console.ReadLine());
//double r = Convert.ToDouble(Console.ReadLine());

//double distance = Math.Sqrt(x * x + y * y);
//if (distance >= r && distance <= R)
//    Console.WriteLine("Точка внутри тора");
//else
//    Console.WriteLine("Точка вне тора");


// 17
//Console.WriteLine("Введите координаты точки (x, y)");
//double x = Convert.ToDouble(Console.ReadLine());
//double y = Convert.ToDouble(Console.ReadLine());

//if (x > 0 && y < 0)
//    Console.WriteLine("Точка в четвертой четверти");
//else
//    Console.WriteLine("Точка не в четвертой четверти");


// 18
//Console.WriteLine("Введите стороны треугольника a, b, c");
//double a = Convert.ToDouble(Console.ReadLine());
//double b = Convert.ToDouble(Console.ReadLine());
//double c = Convert.ToDouble(Console.ReadLine());

//if (Math.Abs(a - b) < 1e-6 || Math.Abs(a - c) < 1e-6 || Math.Abs(b - c) < 1e-6)
//    Console.WriteLine("Треугольник равнобедренный");
//else
//    Console.WriteLine("Треугольник не равнобедренный");


// 19
//Console.WriteLine("Введите три целых числа a, b, c");
//int a = Convert.ToInt32(Console.ReadLine());
//int b = Convert.ToInt32(Console.ReadLine());
//int c = Convert.ToInt32(Console.ReadLine());

//if (Math.Pow(c, 2) == Math.Pow(a, 2) + Math.Pow(b, 2))
//    Console.WriteLine("Тройка Пифагора");
//else
//    Console.WriteLine("Не тройка Пифагора");


// 20
//Console.WriteLine("Введите объемную скорость 1 (л/с)");
//double v1 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите объемную скорость 2 (м³/мин)");
//double v2 = Convert.ToDouble(Console.ReadLine());

//v2 = v2 / 1000 * 60; // переведем м³/мин в л/с

//if (v1 > v2)
//    Console.WriteLine("Скорость 1 больше");
//else
//    Console.WriteLine("Скорость 2 больше");


// 21
//Console.WriteLine("Введите площадь круга и квадрата");
//double circle = Convert.ToDouble(Console.ReadLine());
//double square = Convert.ToDouble(Console.ReadLine());

//double circleRadius = Math.Sqrt(circle / Math.PI);
//double squareSide = Math.Sqrt(square);

//if (circleRadius * 2 <= squareSide)
//    Console.WriteLine("Круг уместится в квадрате");
//else
//    Console.WriteLine("Круг не уместится в квадрате");


// 22
//Console.WriteLine("Введите массы и объемы двух тел (m1, v1, m2, v2)");
//double m1 = Convert.ToDouble(Console.ReadLine());
//double v1 = Convert.ToDouble(Console.ReadLine());
//double m2 = Convert.ToDouble(Console.ReadLine());
//double v2 = Convert.ToDouble(Console.ReadLine());

//double density1 = m1 / v1;
//double density2 = m2 / v2;

//if (density1 > density2)
//    Console.WriteLine("Первое тело плотнее");
//else
//    Console.WriteLine("Второе тело плотнее");


// 23
//Console.WriteLine("Введите скорости: км/ч и м/с");
//double v1 = Convert.ToDouble(Console.ReadLine());
//double v2 = Convert.ToDouble(Console.ReadLine());

//v1 = v1 / 3.6; // переведем км/ч в м/с

//if (v1 > v2)
//    Console.WriteLine("Скорость в км/ч больше");
//else
//    Console.WriteLine("Скорость в м/с больше");


// 24
//Console.WriteLine("Введите сторону треугольника a и радиус круга R");
//double a = Convert.ToDouble(Console.ReadLine());
//double R = Convert.ToDouble(Console.ReadLine());

//double triArea = Math.Pow(a, 2) * Math.Sqrt(3) / 4;
//double circleArea = Math.PI * Math.Pow(R, 2);

//if (circleArea <= triArea)
//    Console.WriteLine("Круг уместится в треугольнике");
//else
//    Console.WriteLine("Круг не уместится в треугольнике");


// 25
//Console.WriteLine("Введите сторону треугольника a и радиус круга R");
//double a = Convert.ToDouble(Console.ReadLine());
//double R = Convert.ToDouble(Console.ReadLine());

//double triArea = Math.Pow(a, 2) * Math.Sqrt(3) / 4;
//double circleArea = Math.PI * Math.Pow(R, 2);

//if (triArea <= circleArea)
//    Console.WriteLine("Треугольник уместится в круге");
//else
//    Console.WriteLine("Треугольник не уместится в круге");


// 26
//Console.WriteLine("Введите сопротивления и напряжения для двух участков (R1, U1, R2, U2)");
//double R1 = Convert.ToDouble(Console.ReadLine());
//double U1 = Convert.ToDouble(Console.ReadLine());
//double R2 = Convert.ToDouble(Console.ReadLine());
//double U2 = Convert.ToDouble(Console.ReadLine());

//double I1 = U1 / R1;
//double I2 = U2 / R2;

//if (I1 < I2)
//    Console.WriteLine("Меньший ток протекает по первому участку");
//else
//    Console.WriteLine("Меньший ток протекает по второму участку");


// 27
//Console.WriteLine("Введите массу и радиус Венеры (mV, rV)");
//double mV = Convert.ToDouble(Console.ReadLine());
//double rV = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите массу и радиус Сатурна (mS, rS)");
//double mS = Convert.ToDouble(Console.ReadLine());
//double rS = Convert.ToDouble(Console.ReadLine());

//double G = 6.7e-11;

//double gV = G * mV / (rV * rV);
//double gS = G * mS / (rS * rS);

//if (gV > gS)
//    Console.WriteLine("Ускорение на Венере больше");
//else
//    Console.WriteLine("Ускорение на Сатурне больше");


// 28
//Console.WriteLine("Введите текущее время (0-24)");
//double hour = Convert.ToDouble(Console.ReadLine());

//if (hour >= 0 && hour < 12)
//    Console.WriteLine("Утро");
//else if (hour >= 12 && hour < 18)
//    Console.WriteLine("День");
//else
//    Console.WriteLine("Вечер/Ночь");


// 29
//Console.WriteLine("Введите широту и долготу");
//double latitude = Convert.ToDouble(Console.ReadLine());
//double longitude = Convert.ToDouble(Console.ReadLine());

//if (latitude >= 0)
//    Console.WriteLine("Северное полушарие");
//else
//    Console.WriteLine("Южное полушарие");

//if (longitude >= 0 && longitude <= 180)
//    Console.WriteLine("Восточное полушарие");
//else
//    Console.WriteLine("Западное полушарие");


// 30
//Console.WriteLine("Введите расстояния до звезд: Сирнус и Арктур (в световых годах)");
//double sirius = Convert.ToDouble(Console.ReadLine());
//double arcturus = Convert.ToDouble(Console.ReadLine());

//if (sirius > arcturus)
//    Console.WriteLine("Сирнус дальше");
//else
//    Console.WriteLine("Арктур дальше");

//Console.WriteLine("Введите натуральное число");
//int num = Convert.ToInt32(Console.ReadLine());

//if (num % 2 == 0)
//    Console.WriteLine("Число четное");
//else if (num % 10 == 7)
//    Console.WriteLine("Число оканчивается на 7");
//else
//    Console.WriteLine("Число нечетное и не оканчивается на 7");