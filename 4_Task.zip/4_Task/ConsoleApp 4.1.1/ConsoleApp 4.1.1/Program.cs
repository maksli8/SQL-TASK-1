﻿// 1
//Console.WriteLine("Введите первое число");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите второе число");
//double y = Convert.ToDouble(Console.ReadLine());

//double sumSquares = Math.Pow(x, 2) + Math.Pow(y, 2);
//double squareSum = Math.Pow(x + y, 2);

//if (sumSquares > squareSum)
//    Console.WriteLine("Сумма квадратов больше квадрата суммы");
//else
//    Console.WriteLine("Квадрат суммы больше суммы квадратов");


// 2
//Console.WriteLine("Введите зарплату");
//double salary = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите стаж (лет)");
//double experience = Convert.ToDouble(Console.ReadLine());

//double bonus = 0;
//if (experience >= 2 && experience < 5)
//    bonus = 0.02 * salary;
//else if (experience >= 5 && experience < 10)
//    bonus = 0.05 * salary;

//Console.WriteLine($"Надбавка: {bonus}");
//Console.WriteLine($"Итого к выплате: {salary + bonus}");


// 3
//Console.WriteLine("Введите координаты точки A (x0, y0)");
//double x0 = Convert.ToDouble(Console.ReadLine());
//double y0 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите координаты точки B (x1, y1)");
//double x1 = Convert.ToDouble(Console.ReadLine());
//double y1 = Convert.ToDouble(Console.ReadLine());

//double distA = Math.Sqrt(Math.Pow(x0, 2) + Math.Pow(y0, 2));
//double distB = Math.Sqrt(Math.Pow(x1, 2) + Math.Pow(y1, 2));

//if (distA > distB)
//    Console.WriteLine("Точка A наиболее удалена от начала координат");
//else
//    Console.WriteLine("Точка B наиболее удалена от начала координат");


// 4
//Console.WriteLine("Введите стороны треугольника a, b, c");
//double a = Convert.ToDouble(Console.ReadLine());
//double b = Convert.ToDouble(Console.ReadLine());
//double c = Convert.ToDouble(Console.ReadLine());

//double[] sides = { a, b, c };
//Array.Sort(sides); // наибольшая сторона последняя

//if (Math.Abs(Math.Pow(sides[2], 2) - (Math.Pow(sides[0], 2) + Math.Pow(sides[1], 2))) < 1e-6)
//    Console.WriteLine("Треугольник прямоугольный");
//else
//    Console.WriteLine("Треугольник не прямоугольный");


// 5
//Console.WriteLine("Введите три числа");
//double n1 = Convert.ToDouble(Console.ReadLine());
//double n2 = Convert.ToDouble(Console.ReadLine());
//double n3 = Convert.ToDouble(Console.ReadLine());

//n1 = n1 > 0 ? Math.Pow(n1, 2) : n1;
//n2 = n2 > 0 ? Math.Pow(n2, 2) : n2;
//n3 = n3 > 0 ? Math.Pow(n3, 2) : n3;

//Console.WriteLine($"Результат: {n1}, {n2}, {n3}");


// 6
//Console.WriteLine("Введите координаты точки (x, y)");
//double x = Convert.ToDouble(Console.ReadLine());
//double y = Convert.ToDouble(Console.ReadLine());

//if (x > 0 && y > 0)
//    Console.WriteLine("Точка в первой четверти");
//else if (x < 0 && y > 0)
//    Console.WriteLine("Точка во второй четверти");
//else if (x < 0 && y < 0)
//    Console.WriteLine("Точка в третьей четверти");
//else if (x > 0 && y < 0)
//    Console.WriteLine("Точка в четвертой четверти");
//else
//    Console.WriteLine("Точка лежит на оси координат");


// 7
//Console.WriteLine("Введите координаты точки A (x, y)");
//double x = Convert.ToDouble(Console.ReadLine());
//double y = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите радиус R");
//double R = Convert.ToDouble(Console.ReadLine());

//double distance = Math.Sqrt(Math.Pow(x, 2) + Math.Pow(y, 2));
//if (distance <= R)
//    Console.WriteLine("Точка внутри окружности");
//else
//    Console.WriteLine("Точка вне окружности");


// 8
//Console.WriteLine("Введите стороны первого треугольника a1, b1, c1");
//double a1 = Convert.ToDouble(Console.ReadLine());
//double b1 = Convert.ToDouble(Console.ReadLine());
//double c1 = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите стороны второго треугольника a2, b2, c2");
//double a2 = Convert.ToDouble(Console.ReadLine());
//double b2 = Convert.ToDouble(Console.ReadLine());
//double c2 = Convert.ToDouble(Console.ReadLine());

//double s1 = 0.25 * Math.Sqrt((a1 + b1 + c1) * (a1 + b1 - c1) * (a1 - b1 + c1) * (-a1 + b1 + c1));
//double s2 = 0.25 * Math.Sqrt((a2 + b2 + c2) * (a2 + b2 - c2) * (a2 - b2 + c2) * (-a2 + b2 + c2));

//if (s1 > s2)
//    Console.WriteLine("Площадь первого треугольника больше");
//else
//    Console.WriteLine("Площадь второго треугольника больше");


// 9
//Console.WriteLine("Введите сторону квадрата a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите радиус окружности R");
//double R = Convert.ToDouble(Console.ReadLine());

//double squareArea = Math.Pow(a, 2);
//double circleArea = Math.PI * Math.Pow(R, 2);

//if (squareArea > circleArea)
//    Console.WriteLine("Площадь квадрата больше");
//else
//    Console.WriteLine("Площадь окружности больше");


// 10
//Console.WriteLine("Введите три числа");
//double n1 = Convert.ToDouble(Console.ReadLine());
//double n2 = Convert.ToDouble(Console.ReadLine());
//double n3 = Convert.ToDouble(Console.ReadLine());

//n1 = n1 > 0 ? Math.Pow(n1, 3) : 0;
//n2 = n2 > 0 ? Math.Pow(n2, 3) : 0;
//n3 = n3 > 0 ? Math.Pow(n3, 3) : 0;

//Console.WriteLine($"Результат: {n1}, {n2}, {n3}");


// 11
//Console.WriteLine("Введите число");
//int num = Convert.ToInt32(Console.ReadLine());

//if (num % 2 == 0)
//    Console.WriteLine("Число четное");
//else if (num % 10 == 3)
//    Console.WriteLine("Число оканчивается на 3");
//else
//    Console.WriteLine("Число нечетное и не оканчивается на 3");


// 12
//Console.WriteLine("Введите координаты точки (x, y)");
//double x = Convert.ToDouble(Console.ReadLine());
//double y = Convert.ToDouble(Console.ReadLine());

//if (x > 0 && y > 0)
//    Console.WriteLine("Точка в первой четверти");
//else
//    Console.WriteLine("Точка не в первой четверти");


// 13
//Console.WriteLine("Введите сумму вклада");
//double deposit = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите срок договора (полгода/год)");
//string term = Console.ReadLine().ToLower();

//double rate = term == "полгода" ? 0.06 : 0.08;
//double total = deposit * (1 + rate);
//Console.WriteLine($"Сумма выплат процентов: {deposit * rate}");
//Console.WriteLine($"Общая сумма к выплате: {total}");


// 14
//Console.WriteLine("Введите два числа");
//double x = Convert.ToDouble(Console.ReadLine());
//double y = Convert.ToDouble(Console.ReadLine());

//double diffSquares = Math.Pow(x, 2) - Math.Pow(y, 2);
//double absSquareDiff = Math.Abs(x - y) * Math.Abs(x - y);

//if (diffSquares > absSquareDiff)
//    Console.WriteLine("Разность квадратов больше");
//else
//    Console.WriteLine("Модуль квадрата разности больше");


// 15
//Console.WriteLine("Введите координаты точки A (x0, y0)");
//double x0 = Convert.ToDouble(Console.ReadLine());
//double y0 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите координаты точки B (x1, y1)");
//double x1 = Convert.ToDouble(Console.ReadLine());
//double y1 = Convert.ToDouble(Console.ReadLine());

//double distA = Math.Sqrt(x0 * x0 + y0 * y0);
//double distB = Math.Sqrt(x1 * x1 + y1 * y1);

//if (distA < distB)
//    Console.WriteLine("Точка A наименее удалена от начала координат");
//else
//    Console.WriteLine("Точка B наименее удалена от начала координат");