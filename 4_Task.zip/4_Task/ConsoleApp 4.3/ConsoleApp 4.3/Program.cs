﻿// 1
// Решение уравнения a*x + b + c = 0 с учетом a != 0
//Console.WriteLine("Введите a, b, c");
//double a = Convert.ToDouble(Console.ReadLine());
//double b = Convert.ToDouble(Console.ReadLine());
//double c = Convert.ToDouble(Console.ReadLine());

//if (a != 0)
//{
//    double x = -c / a;
//    Console.WriteLine($"Решение уравнения: x = {x}");
//}
//else
//{
//    if (b + c == 0)
//        Console.WriteLine("Бесконечное количество решений");
//    else
//        Console.WriteLine("Решений нет");
//}


// 2
// Проверка двухзначного числа на наличие цифр 5 и a
//Console.WriteLine("Введите двухзначное число");
//int num = Convert.ToInt32(Console.ReadLine());

//int digit1 = num / 10;
//int digit2 = num % 10;

//Console.WriteLine($"Содержит цифру 5: {(digit1 == 5 || digit2 == 5)}");
//Console.WriteLine($"Содержит цифру a: {(digit1 == a || digit2 == a)}"); // a задается отдельно


// 3
// Проверка двухзначного числа на пары цифр 3 и 7, 4 и 8, или 9
//Console.WriteLine("Введите двухзначное число");
//int num = Convert.ToInt32(Console.ReadLine());
//int d1 = num / 10;
//int d2 = num % 10;

//Console.WriteLine($"Содержит цифры 3 и 7: {( (d1==3 && d2==7) || (d1==7 && d2==3) )}");
//Console.WriteLine($"Содержит (4 и 8) или 9: {((d1==4 && d2==8)||(d1==8 && d2==4)||(d1==9 || d2==9))}");


// 4
// Добавление слова "копейка" в правильной форме
//Console.WriteLine("Введите число от 1 до 99");
//int n = Convert.ToInt32(Console.ReadLine());
//string text;

//if (n % 10 == 1 && n != 11)
//    text = "копейка";
//else if (n % 10 >= 2 && n % 10 <= 4 && !(n >= 12 && n <= 14))
//    text = "копейки";
//else
//    text = "копеек";

//Console.WriteLine($"{n} {text}");


// 5
// Проверка четырехзначного числа на палиндром
//Console.WriteLine("Введите четырехзначное число");
//int n = Convert.ToInt32(Console.ReadLine());
//int d1 = n / 1000;
//int d2 = (n / 100) % 10;
//int d3 = (n / 10) % 10;
//int d4 = n % 10;

//if (d1 == d4 && d2 == d3)
//    Console.WriteLine("Число является палиндромом");
//else
//    Console.WriteLine("Число не является палиндромом");


// 6
// Проверка шестизначного числа на "счастливое"
//Console.WriteLine("Введите шестизначное число");
//int n = Convert.ToInt32(Console.ReadLine());
//int sum1 = n / 100000 + (n / 10000) % 10 + (n / 1000) % 10;
//int sum2 = (n / 100) % 10 + (n / 10) % 10 + n % 10;

//if (sum1 == sum2)
//    Console.WriteLine("Число 'счастливое'");
//else
//    Console.WriteLine("Число не 'счастливое'");


// 7
// Определение дня недели по номеру дня года (1 января — понедельник)
//Console.WriteLine("Введите число от 1 до 365");
//int day = Convert.ToInt32(Console.ReadLine());
//string[] week = { "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье" };
//Console.WriteLine($"День недели: {week[(day - 1) % 7]}");


// 8
// Попадание снаряда в цель
//Console.WriteLine("Введите Vo, угол a (градусы), H, R, h");
//double Vo = Convert.ToDouble(Console.ReadLine());
//double a = Convert.ToDouble(Console.ReadLine()) * Math.PI / 180; // перевод в радианы
//double H = Convert.ToDouble(Console.ReadLine());
//double R = Convert.ToDouble(Console.ReadLine());
//double h = Convert.ToDouble(Console.ReadLine());

//double t = R / (Vo * Math.Cos(a));
//double y = Vo * Math.Sin(a) * t - 9.8 / 2 * t * t;

//if (y >= H && y <= H + h)
//    Console.WriteLine("Снаряд попадет в цель");
//else
//    Console.WriteLine("Снаряд промахнется");


// 9
// Проверка трехзначного числа на сумму и произведение цифр
//Console.WriteLine("Введите трехзначное число");
//int n = Convert.ToInt32(Console.ReadLine());
//int d1 = n / 100;
//int d2 = (n / 10) % 10;
//int d3 = n % 10;
//int sum = d1 + d2 + d3;
//int product = d1 * d2 * d3;

//Console.WriteLine($"Сумма цифр двухзначная: {sum >= 10 && sum <= 99}");
//Console.WriteLine($"Произведение цифр трехзначное: {product >= 100 && product <= 999}");


// 10
// Проверка произведения цифр на b и кратность суммы 3
//Console.WriteLine("Введите трехзначное число и число b");
//int n = Convert.ToInt32(Console.ReadLine());
//int b = Convert.ToInt32(Console.ReadLine());
//int d1 = n / 100;
//int d2 = (n / 10) % 10;
//int d3 = n % 10;
//int sum = d1 + d2 + d3;
//int product = d1 * d2 * d3;

//Console.WriteLine($"Произведение цифр больше b: {product > b}");
//Console.WriteLine($"Сумма цифр кратна 3: {sum % 3 == 0}");


// 11
// Проверка одинаковости цифр трехзначного числа
//Console.WriteLine("Введите трехзначное число");
//int n = Convert.ToInt32(Console.ReadLine());
//int d1 = n / 100;
//int d2 = (n / 10) % 10;
//int d3 = n % 10;

//Console.WriteLine($"Все цифры одинаковые: {d1 == d2 && d2 == d3}");
//Console.WriteLine($"Есть хотя бы одна пара одинаковых цифр: {d1 == d2 || d1 == d3 || d2 == d3}");


// 12
// Проверка, лежит ли точка A(x,y) в области, ограниченной параболой y=2-x^2 и прямой y=-2
//Console.WriteLine("Введите координаты точки A (x, y)");
//double x = Convert.ToDouble(Console.ReadLine());
//double y = Convert.ToDouble(Console.ReadLine());

//if (y >= -2 && y <= 2 - x * x)
//    Console.WriteLine("Точка находится в области");
//else
//    Console.WriteLine("Точка вне области");