﻿// 13
// Проверка возможности проведения перпендикуляра через точку
//Console.WriteLine("Введите координаты точек A(x1, y1), B(x2, y2), C(x3, y3)");
//double x1 = Convert.ToDouble(Console.ReadLine());
//double y1 = Convert.ToDouble(Console.ReadLine());
//double x2 = Convert.ToDouble(Console.ReadLine());
//double y2 = Convert.ToDouble(Console.ReadLine());
//double x3 = Convert.ToDouble(Console.ReadLine());
//double y3 = Convert.ToDouble(Console.ReadLine());

//double dx = x2 - x1;
//double dy = y2 - y1;

//if (dx == 0 && x3 != x1 || dy == 0 && y3 != y1 || dx != 0 && dy != 0)
//    Console.WriteLine("Можно провести прямую, перпендикулярную AB через C");
//else
//    Console.WriteLine("Невозможно провести перпендикуляр через C");

// 14
// Расчет рейтинга бакалавра для поступления в магистратуру
//Console.WriteLine("Введите средний балл диплома (3–5) и стаж работы в годах");
//double avg = Convert.ToDouble(Console.ReadLine());
//double experience = Convert.ToDouble(Console.ReadLine());
//double coef = 0;

//if (experience == 0) coef = 1;
//else if (experience < 2) coef = 1.3;
//else if (experience >= 2 && experience <= 5) coef = 1.6;
//else coef = 1;

//double rating = avg * coef;
//Console.WriteLine($"Рейтинг: {rating}");
//Console.WriteLine(rating >= 45 ? "Прием в магистратуру возможен" : "Прием невозможен");

// 15
// Определение координат четвертой вершины прямоугольника
//Console.WriteLine("Введите координаты трех вершин прямоугольника A(x1,y1), B(x2,y2), C(x3,y3)");
//double x1 = Convert.ToDouble(Console.ReadLine());
//double y1 = Convert.ToDouble(Console.ReadLine());
//double x2 = Convert.ToDouble(Console.ReadLine());
//double y2 = Convert.ToDouble(Console.ReadLine());
//double x3 = Convert.ToDouble(Console.ReadLine());
//double y3 = Convert.ToDouble(Console.ReadLine());

//double x4 = x1 ^ x2 ^ x3; // XOR для нахождения неизвестной координаты, если стороны параллельны осям
//double y4 = y1 ^ y2 ^ y3;
//Console.WriteLine($"Координаты четвертой вершины: ({x4}, {y4})");

// 16
// Четырехзначное число: проверка суммы цифр и кратности 7
//Console.WriteLine("Введите четырехзначное число");
//int n = Convert.ToInt32(Console.ReadLine());
//int d1 = n / 1000;
//int d2 = (n / 100) % 10;
//int d3 = (n / 10) % 10;
//int d4 = n % 10;
//int sumFirstTwo = d1 + d2;
//int sumLastTwo = d3 + d4;
//int sumAll = d1 + d2 + d3 + d4;

//Console.WriteLine($"Сумма первых двух цифр равна сумме последних: {sumFirstTwo == sumLastTwo}");
//Console.WriteLine($"Сумма всех цифр кратна 7: {sumAll % 7 == 0}");

// 17
// Четырехзначное число: кратность произведения цифр
//Console.WriteLine("Введите четырехзначное число и число a");
//int n = Convert.ToInt32(Console.ReadLine());
//int a = Convert.ToInt32(Console.ReadLine());
//int d1 = n / 1000;
//int d2 = (n / 100) % 10;
//int d3 = (n / 10) % 10;
//int d4 = n % 10;
//int product = d1 * d2 * d3 * d4;

//Console.WriteLine($"Произведение цифр кратно 3: {product % 3 == 0}");
//Console.WriteLine($"Произведение цифр кратно {a}: {product % a == 0}");

// 18
// Проверка, помещается ли прямоугольник a,b в прямоугольник c,d
//Console.WriteLine("Введите стороны прямоугольника a,b,c,d");
//double a = Convert.ToDouble(Console.ReadLine());
//double b = Convert.ToDouble(Console.ReadLine());
//double c = Convert.ToDouble(Console.ReadLine());
//double d = Convert.ToDouble(Console.ReadLine());

//bool fits = (a <= c && b <= d) || (a <= d && b <= c);
//Console.WriteLine($"Прямоугольник помещается: {fits}");

// 19
// Проверка, помещается ли кирпич a,b,c в отверстие x,y
//Console.WriteLine("Введите размеры кирпича a,b,c и отверстия x,y");
//double a = Convert.ToDouble(Console.ReadLine());
//double b = Convert.ToDouble(Console.ReadLine());
//double c = Convert.ToDouble(Console.ReadLine());
//double x = Convert.ToDouble(Console.ReadLine());
//double y = Convert.ToDouble(Console.ReadLine());

//double[] brick = new double[] { a, b, c };
//Array.Sort(brick); // от меньшего к большему
//double[] hole = new double[] { x, y };
//Array.Sort(hole);

//bool fits = brick[0] <= hole[0] && brick[1] <= hole[1];
//Console.WriteLine($"Кирпич помещается в отверстие: {fits}");