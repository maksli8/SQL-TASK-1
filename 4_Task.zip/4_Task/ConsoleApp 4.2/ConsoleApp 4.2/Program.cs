﻿// 16
//Console.WriteLine("Введите три целых числа (стороны треугольника a, b, c)");
//int a = Convert.ToInt32(Console.ReadLine());
//int b = Convert.ToInt32(Console.ReadLine());
//int c = Convert.ToInt32(Console.ReadLine());

//if (a + b > c && a + c > b && b + c > a)
//    Console.WriteLine("Треугольник построить возможно");
//else
//    Console.WriteLine("Треугольник построить невозможно");


// 17
//Console.WriteLine("Введите координаты точки B (x, y)");
//double x = Convert.ToDouble(Console.ReadLine());
//double y = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите погрешность eps");
//double eps = Convert.ToDouble(Console.ReadLine());
//double f;

//if (x > 1)
//    f = Math.Sin(Math.Pow(x, 2));
//else if (Math.Abs(x) <= 1)
//    f = Math.Asin(Math.Pow(x, 2)) + 4.5 * Math.Pow(x, 2) + 4 * x * x + 2;
//else
//    f = 0; // пример для других случаев

//if (Math.Abs(f - y) < eps)
//    Console.WriteLine("Точка лежит на кривой");
//else
//    Console.WriteLine("Точка не лежит на кривой");


// 18
//Console.WriteLine("Введите координаты точки A (x, y)");
//double x = Convert.ToDouble(Console.ReadLine());
//double y = Convert.ToDouble(Console.ReadLine());

//if (y <= 2 - x * x && y >= 0)
//    Console.WriteLine("Точка внутри области параболы");
//else
//    Console.WriteLine("Точка вне области");


// 19
//Console.WriteLine("Введите координаты точки B (x, y) и радиус окружности R");
//double x = Convert.ToDouble(Console.ReadLine());
//double y = Convert.ToDouble(Console.ReadLine());
//double R = Convert.ToDouble(Console.ReadLine());

//double distance = Math.Sqrt(x * x + y * y);
//if (distance <= R)
//    Console.WriteLine("Точка внутри окружности");
//else
//    Console.WriteLine("Точка вне окружности");


// 20
//Console.WriteLine("Введите стороны треугольника a, b, c");
//double a = Convert.ToDouble(Console.ReadLine());
//double b = Convert.ToDouble(Console.ReadLine());
//double c = Convert.ToDouble(Console.ReadLine());

//if (Math.Abs(Math.Pow(a, 2) + Math.Pow(b, 2) - Math.Pow(c, 2)) < 1e-6 ||
//    Math.Abs(Math.Pow(a, 2) + Math.Pow(c, 2) - Math.Pow(b, 2)) < 1e-6 ||
//    Math.Abs(Math.Pow(b, 2) + Math.Pow(c, 2) - Math.Pow(a, 2)) < 1e-6)
//    Console.WriteLine("Треугольник прямоугольный");
//else
//    Console.WriteLine("Треугольник не прямоугольный");


// 21
//Console.WriteLine("Введите кинетическую энергию W (кэВ), радиус от 1 до 6 см, индукцию B (мТл)");
//double W = Convert.ToDouble(Console.ReadLine()); // в кэВ
//double e = 1.6e-19; // элементарный заряд, Кл
//double m = 9.11e-31; // масса электрона, кг
//double B = Convert.ToDouble(Console.ReadLine()) * 1e-3; // мТл -> Тл
//double R_min = 0.01; // м
//double R_max = 0.06; // м

//double v = Math.Sqrt(2 * W * 1e3 * e / m); // скорость электрона
//double R = m * v / (e * B);

//if (R >= R_min && R <= R_max)
//    Console.WriteLine("Траектория электрона попадает в кольцо");
//else
//    Console.WriteLine("Траектория не попадает в кольцо");


// 22
//Console.WriteLine("Введите координаты точек на оси OX a, b, c");
//double a = Convert.ToDouble(Console.ReadLine());
//double b = Convert.ToDouble(Console.ReadLine());
//double c = Convert.ToDouble(Console.ReadLine());

//double distB = Math.Abs(b - a);
//double distC = Math.Abs(c - a);

//if (distB < distC)
//    Console.WriteLine("Точка B ближе к A");
//else
//    Console.WriteLine("Точка C ближе к A");


// 23
//Console.WriteLine("Введите два числа a и b");
//int a = Convert.ToInt32(Console.ReadLine());
//int b = Convert.ToInt32(Console.ReadLine());

//if (a % b == 0 || b % a == 0)
//    Console.WriteLine("Одно число делится на другое");
//else
//    Console.WriteLine("Числа не делятся друг на друга");


// 24
//Console.WriteLine("Введите три числа a, b, c");
//double a = Convert.ToDouble(Console.ReadLine());
//double b = Convert.ToDouble(Console.ReadLine());
//double c = Convert.ToDouble(Console.ReadLine());

//if (a == b || a == c || b == c)
//    Console.WriteLine("Есть хотя бы одна пара равных чисел");
//else
//    Console.WriteLine("Пары равных чисел нет");


// 25
//Console.WriteLine("Введите скорость электрона v (Мм/с)");
//double v = Convert.ToDouble(Console.ReadLine());
//double R = 0.005; // м
//double B = 0.056; // Т
//double e = 1.6e-19; 
//double m = 9.11e-31;

//double v_m = v * 1e6; // в м/с
//double R_electron = m * v_m / (e * B);

//if (R_electron <= R)
//    Console.WriteLine("Электрон попадает в кольцо");
//else
//    Console.WriteLine("Электрон не попадает в кольцо");


// 26
//Console.WriteLine("Введите три числа");
//double a = Convert.ToDouble(Console.ReadLine());
//double b = Convert.ToDouble(Console.ReadLine());
//double c = Convert.ToDouble(Console.ReadLine());

//double avg = (a + b + c) / 3;

//if (Math.Abs(a) > avg) Console.WriteLine(a);
//if (Math.Abs(b) > avg) Console.WriteLine(b);
//if (Math.Abs(c) > avg) Console.WriteLine(c);


// 27
//Console.WriteLine("Введите текущее время (0-24)");
//double hour = Convert.ToDouble(Console.ReadLine());

//if (hour >= 6 && hour < 12)
//    Console.WriteLine("Утро");
//else if (hour >= 12 && hour < 18)
//    Console.WriteLine("День");
//else if (hour >= 18 && hour < 24)
//    Console.WriteLine("Вечер");
//else
//    Console.WriteLine("Ночь");


// 28
//Console.WriteLine("Введите массы и радиусы планет Венера (mV, rV), Земля (mZ, rZ), Сатурн (mS, rS)");
//double mV = Convert.ToDouble(Console.ReadLine());
//double rV = Convert.ToDouble(Console.ReadLine());
//double mZ = Convert.ToDouble(Console.ReadLine());
//double rZ = Convert.ToDouble(Console.ReadLine());
//double mS = Convert.ToDouble(Console.ReadLine());
//double rS = Convert.ToDouble(Console.ReadLine());

//double G = 6.7e-11; // гравитационная постоянная

//double gV = G * mV / (rV * rV);
//double gZ = G * mZ / (rZ * rZ);
//double gS = G * mS / (rS * rS);

//double maxG = Math.Max(gV, Math.Max(gZ, gS));

//if (maxG == gV)
//    Console.WriteLine("Наибольшее ускорение силы тяжести на Венере");
//else if (maxG == gZ)
//    Console.WriteLine("Наибольшее ускорение силы тяжести на Земле");
//else
//    Console.WriteLine("Наибольшее ускорение силы тяжести на Сатурне");