﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace CSharpBasicsComplete
{
    #region Тема 8: ООП классы

    // 8.1: Класс "Студент"
    public class Student
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public double Grade { get; set; }

        public Student(string name, int age, double grade)
        {
            Name = name;
            Age = age;
            Grade = grade;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Студент: {Name}, Возраст: {Age}, Оценка: {Grade}");
        }
    }

    // 8.2: Класс "Банковский счет" с инкапсуляцией
    public class BankAccount
    {
        private string _accountNumber;
        private decimal _balance;
        private string _ownerName;

        public BankAccount(string accountNumber, string ownerName, decimal initialBalance = 0)
        {
            _accountNumber = accountNumber;
            _ownerName = ownerName;
            _balance = initialBalance;
        }

        public void Deposit(decimal amount)
        {
            if (amount > 0)
            {
                _balance += amount;
                Console.WriteLine($"Пополнение: +{amount:C}. Новый баланс: {_balance:C}");
            }
        }

        public bool Withdraw(decimal amount)
        {
            if (amount > 0 && amount <= _balance)
            {
                _balance -= amount;
                Console.WriteLine($"Снятие: -{amount:C}. Новый баланс: {_balance:C}");
                return true;
            }
            Console.WriteLine("Недостаточно средств или неверная сумма");
            return false;
        }

        public decimal GetBalance() => _balance;
        public string GetAccountInfo() => $"Счет: {_accountNumber}, Владелец: {_ownerName}";
    }

    // 8.3: Наследование - иерархия "Животные"
    public abstract class Animal
    {
        public string Name { get; set; }
        public int Age { get; set; }

        protected Animal(string name, int age)
        {
            Name = name;
            Age = age;
        }

        public abstract void MakeSound();
        public virtual void DisplayInfo()
        {
            Console.WriteLine($"Животное: {Name}, Возраст: {Age}");
        }
    }

    public class Dog : Animal
    {
        public string Breed { get; set; }

        public Dog(string name, int age, string breed) : base(name, age)
        {
            Breed = breed;
        }

        public override void MakeSound()
        {
            Console.WriteLine($"{Name} говорит: Гав-гав!");
        }

        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Порода: {Breed}");
        }
    }

    public class Cat : Animal
    {
        public bool IsIndoor { get; set; }

        public Cat(string name, int age, bool isIndoor) : base(name, age)
        {
            IsIndoor = isIndoor;
        }

        public override void MakeSound()
        {
            Console.WriteLine($"{Name} говорит: Мяу-мяу!");
        }

        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Домашний: {(IsIndoor ? "Да" : "Нет")}");
        }
    }

    // 8.4: Класс "Прямоугольник" с конструкторами
    public class Rectangle
    {
        public double Width { get; set; }
        public double Height { get; set; }

        // Конструктор по умолчанию
        public Rectangle()
        {
            Width = 1;
            Height = 1;
        }

        // Конструктор с параметрами
        public Rectangle(double width, double height)
        {
            Width = width;
            Height = height;
        }

        // Конструктор копирования
        public Rectangle(Rectangle other)
        {
            Width = other.Width;
            Height = other.Height;
        }

        public double GetArea() => Width * Height;
        public double GetPerimeter() => 2 * (Width + Height);

        public void DisplayInfo()
        {
            Console.WriteLine($"Прямоугольник: {Width} x {Height}");
            Console.WriteLine($"Площадь: {GetArea()}, Периметр: {GetPerimeter()}");
        }
    }

    // 8.5: Статические члены класса
    public static class MathHelper
    {
        public static int InstanceCount { get; private set; } = 0;

        public static double CalculateCircleArea(double radius)
        {
            InstanceCount++;
            return Math.PI * radius * radius;
        }

        public static double CalculateDistance(double x1, double y1, double x2, double y2)
        {
            InstanceCount++;
            return Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
        }

        public static void ResetCounter()
        {
            InstanceCount = 0;
        }
    }

    // 8.6: Полиморфизм - геометрические фигуры
    public abstract class Shape
    {
        public string Name { get; set; }

        public abstract double GetArea();
        public abstract double GetPerimeter();

        public virtual void DisplayInfo()
        {
            Console.WriteLine($"Фигура: {Name}");
            Console.WriteLine($"Площадь: {GetArea():F2}, Периметр: {GetPerimeter():F2}");
        }
    }

    public class Circle : Shape
    {
        public double Radius { get; set; }

        public Circle(double radius)
        {
            Name = "Круг";
            Radius = radius;
        }

        public override double GetArea() => Math.PI * Radius * Radius;
        public override double GetPerimeter() => 2 * Math.PI * Radius;
    }

    public class Square : Shape
    {
        public double Side { get; set; }

        public Square(double side)
        {
            Name = "Квадрат";
            Side = side;
        }

        public override double GetArea() => Side * Side;
        public override double GetPerimeter() => 4 * Side;
    }

    // 8.7: Интерфейсы - сортируемые объекты
    public interface IComparable
    {
        int CompareTo(object obj);
    }

    public class Product : IComparable
    {
        public string Name { get; set; }
        public decimal Price { get; set; }

        public Product(string name, decimal price)
        {
            Name = name;
            Price = price;
        }

        public int CompareTo(object obj)
        {
            if (obj is Product other)
                return Price.CompareTo(other.Price);
            throw new ArgumentException("Object is not a Product");
        }

        public override string ToString() => $"{Name}: {Price:C}";
    }

    // 8.8: Свойства с валидацией - класс "Книга"
    public class Book
    {
        private string _title;
        private string _author;
        private decimal _price;

        public string Title
        {
            get => _title;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Название не может быть пустым");
                _title = value;
            }
        }

        public string Author
        {
            get => _author;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Автор не может быть пустым");
                _author = value;
            }
        }

        public decimal Price
        {
            get => _price;
            set
            {
                if (value < 0)
                    throw new ArgumentException("Цена не может быть отрицательной");
                _price = value;
            }
        }

        public Book(string title, string author, decimal price)
        {
            Title = title;
            Author = author;
            Price = price;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Книга: '{Title}', Автор: {Author}, Цена: {Price:C}");
        }
    }

    // 8.9: Перегрузка операторов - ComplexNumber
    public class ComplexNumber
    {
        public double Real { get; set; }
        public double Imaginary { get; set; }

        public ComplexNumber(double real, double imaginary)
        {
            Real = real;
            Imaginary = imaginary;
        }

        // Перегрузка оператора сложения
        public static ComplexNumber operator +(ComplexNumber a, ComplexNumber b)
        {
            return new ComplexNumber(a.Real + b.Real, a.Imaginary + b.Imaginary);
        }

        // Перегрузка оператора вычитания
        public static ComplexNumber operator -(ComplexNumber a, ComplexNumber b)
        {
            return new ComplexNumber(a.Real - b.Real, a.Imaginary - b.Imaginary);
        }

        // Перегрузка оператора умножения
        public static ComplexNumber operator *(ComplexNumber a, ComplexNumber b)
        {
            return new ComplexNumber(
                a.Real * b.Real - a.Imaginary * b.Imaginary,
                a.Real * b.Imaginary + a.Imaginary * b.Real
            );
        }

        public override string ToString()
        {
            return $"{Real} + {Imaginary}i";
        }
    }

    // 8.10: Композиция - класс "Автомобиль"
    public class Engine
    {
        public string Type { get; set; }
        public double Power { get; set; } // в лошадиных силах

        public Engine(string type, double power)
        {
            Type = type;
            Power = power;
        }

        public void Start()
        {
            Console.WriteLine($"Двигатель {Type} запущен. Мощность: {Power} л.с.");
        }
    }

    public class Car
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public Engine Engine { get; set; }

        public Car(string brand, string model, Engine engine)
        {
            Brand = brand;
            Model = model;
            Engine = engine;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Автомобиль: {Brand} {Model}");
            Engine.Start();
        }
    }

    // 8.11: Индексаторы - класс "Список покупок"
    public class ShoppingList
    {
        private List<string> _items = new List<string>();

        // Индексатор
        public string this[int index]
        {
            get
            {
                if (index >= 0 && index < _items.Count)
                    return _items[index];
                throw new IndexOutOfRangeException();
            }
            set
            {
                if (index >= 0 && index < _items.Count)
                    _items[index] = value;
                else if (index == _items.Count)
                    _items.Add(value);
                else
                    throw new IndexOutOfRangeException();
            }
        }

        public void AddItem(string item) => _items.Add(item);
        public void RemoveItem(string item) => _items.Remove(item);
        public int Count => _items.Count;

        public void DisplayList()
        {
            Console.WriteLine("Список покупок:");
            for (int i = 0; i < _items.Count; i++)
            {
                Console.WriteLine($"  {i + 1}. {_items[i]}");
            }
        }
    }

    #endregion

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("🎯 C# ОСНОВЫ - ПОЛНАЯ ДЕМОНСТРАЦИЯ 9 ТЕМ\n");

            // Тема 1: Введение
            DemonstrateTopic1();

            // Тема 2: Условные операторы
            DemonstrateTopic2();

            // Тема 3: Циклы
            DemonstrateTopic3();

            // Тема 4: Массивы
            DemonstrateTopic4();

            // Тема 5: Методы
            DemonstrateTopic5();

            // Тема 6: Рекурсия
            DemonstrateTopic6();

            // Тема 7: Алгоритмы
            DemonstrateTopic7();

            // Тема 8: ООП
            DemonstrateTopic8();

            // Тема 9: Файлы
            DemonstrateTopic9();

            Console.WriteLine("\n🎉 ВСЕ ЗАДАНИЯ ВЫПОЛНЕНЫ!");
        }

        #region Тема 1: Введение (10 заданий)

        static void DemonstrateTopic1()
        {
            Console.WriteLine("📘 ТЕМА 1: ВВЕДЕНИЕ\n");

            // 1.1 Hello, World!
            Console.WriteLine("1.1 Hello, World!");
            Console.WriteLine("Hello, World!");

            // 1.2 Калькулятор двух чисел
            Console.WriteLine("\n1.2 Калькулятор двух чисел");
            double a = 10, b = 3;
            Console.WriteLine($"{a} + {b} = {a + b}");
            Console.WriteLine($"{a} - {b} = {a - b}");
            Console.WriteLine($"{a} * {b} = {a * b}");
            Console.WriteLine($"{a} / {b} = {a / b:F2}");

            // 1.3 Конвертер температур
            Console.WriteLine("\n1.3 Конвертер температур");
            double celsius = 25;
            double fahrenheit = celsius * 9 / 5 + 32;
            Console.WriteLine($"{celsius}°C = {fahrenheit}°F");

            // 1.4 Площадь прямоугольника
            Console.WriteLine("\n1.4 Площадь прямоугольника");
            double width = 5, height = 3;
            double area = width * height;
            double perimeter = 2 * (width + height);
            Console.WriteLine($"Прямоугольник {width}x{height}: Площадь = {area}, Периметр = {perimeter}");

            // 1.5 Остаток от деления
            Console.WriteLine("\n1.5 Остаток от деления");
            int num1 = 17, num2 = 5;
            Console.WriteLine($"{num1} % {num2} = {num1 % num2}");

            // 1.6 Обмен значениями переменных
            Console.WriteLine("\n1.6 Обмен значениями переменных");
            int x = 5, y = 10;
            Console.WriteLine($"До: x = {x}, y = {y}");
            x = x + y;
            y = x - y;
            x = x - y;
            Console.WriteLine($"После: x = {x}, y = {y}");

            // 1.7 Среднее арифметическое
            Console.WriteLine("\n1.7 Среднее арифметическое");
            double avg = (15 + 25 + 35) / 3.0;
            Console.WriteLine($"Среднее (15, 25, 35) = {avg:F2}");

            // 1.8 Площадь круга
            Console.WriteLine("\n1.8 Площадь круга");
            double radius = 7;
            double circleArea = Math.PI * radius * radius;
            Console.WriteLine($"Площадь круга (r={radius}) = {circleArea:F2}");

            // 1.9 Возраст в секундах
            Console.WriteLine("\n1.9 Возраст в секундах");
            int age = 25;
            long seconds = age * 365 * 24 * 60 * 60;
            Console.WriteLine($"{age} лет = {seconds:N0} секунд");

            // 1.10 Конвертер валют
            Console.WriteLine("\n1.10 Конвертер валют");
            decimal rubles = 1000;
            decimal usdRate = 0.011m, eurRate = 0.010m;
            Console.WriteLine($"{rubles} RUB = {rubles * usdRate:C} USD");
            Console.WriteLine($"{rubles} RUB = {rubles * eurRate:C} EUR");
        }

        #endregion

        #region Тема 2: Условные операторы (12 заданий)

        static void DemonstrateTopic2()
        {
            Console.WriteLine("\n📘 ТЕМА 2: УСЛОВНЫЕ ОПЕРАТОРЫ\n");

            // 2.1 Проверка четности
            Console.WriteLine("2.1 Проверка четности");
            int number = 7;
            Console.WriteLine($"{number} - {(number % 2 == 0 ? "четное" : "нечетное")}");

            // 2.2 Максимум из трех чисел
            Console.WriteLine("\n2.2 Максимум из трех чисел");
            int n1 = 5, n2 = 12, n3 = 8;
            int max = Math.Max(n1, Math.Max(n2, n3));
            Console.WriteLine($"Максимум из ({n1}, {n2}, {n3}) = {max}");

            // 2.3 Калькулятор с операциями
            Console.WriteLine("\n2.3 Калькулятор с операциями");
            char operation = '+';
            double op1 = 10, op2 = 4;
            switch (operation)
            {
                case '+': Console.WriteLine($"{op1} + {op2} = {op1 + op2}"); break;
                case '-': Console.WriteLine($"{op1} - {op2} = {op1 - op2}"); break;
                case '*': Console.WriteLine($"{op1} * {op2} = {op1 * op2}"); break;
                case '/': Console.WriteLine($"{op1} / {op2} = {op1 / op2}"); break;
                default: Console.WriteLine("Неизвестная операция"); break;
            }

            // 2.4 Високосный год
            Console.WriteLine("\n2.4 Високосный год");
            int year = 2024;
            bool isLeap = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
            Console.WriteLine($"{year} - {(isLeap ? "високосный" : "не високосный")}");

            // 2.5 Оценка по баллам
            Console.WriteLine("\n2.5 Оценка по баллам");
            int score = 85;
            char grade = score >= 90 ? 'A' :
                        score >= 80 ? 'B' :
                        score >= 70 ? 'C' :
                        score >= 60 ? 'D' : 'F';
            Console.WriteLine($"{score} баллов = оценка {grade}");

            // 2.6 Определение времени суток
            Console.WriteLine("\n2.6 Определение времени суток");
            int hour = 14;
            string timeOfDay = hour >= 5 && hour < 12 ? "Утро" :
                              hour >= 12 && hour < 18 ? "День" :
                              hour >= 18 && hour < 23 ? "Вечер" : "Ночь";
            Console.WriteLine($"{hour}:00 - {timeOfDay}");

            // 2.7 Классификация треугольника
            Console.WriteLine("\n2.7 Классификация треугольника");
            double side1 = 3, side2 = 4, side3 = 5;
            if (side1 == side2 && side2 == side3)
                Console.WriteLine("Равносторонний треугольник");
            else if (side1 == side2 || side2 == side3 || side1 == side3)
                Console.WriteLine("Равнобедренный треугольник");
            else
                Console.WriteLine("Разносторонний треугольник");

            // 2.8 Проверка возраста
            Console.WriteLine("\n2.8 Проверка возраста");
            int personAge = 17;
            string category = personAge < 13 ? "Ребенок" :
                             personAge < 20 ? "Подросток" :
                             personAge < 65 ? "Взрослый" : "Пенсионер";
            Console.WriteLine($"{personAge} лет - {category}");

            // 2.9 Решение квадратного уравнения
            Console.WriteLine("\n2.9 Решение квадратного уравнения");
            SolveQuadraticEquation(1, -3, 2);

            // 2.10 Калькулятор скидок
            Console.WriteLine("\n2.10 Калькулятор скидок");
            decimal purchaseAmount = 1200;
            decimal discount = purchaseAmount > 1000 ? 0.1m :
                              purchaseAmount > 500 ? 0.05m : 0;
            decimal finalAmount = purchaseAmount * (1 - discount);
            Console.WriteLine($"Сумма: {purchaseAmount:C}, Скидка: {discount:P}, Итого: {finalAmount:C}");

            // 2.11 Название месяца
            Console.WriteLine("\n2.11 Название месяца");
            int month = 3;
            string monthName = month switch
            {
                1 => "Январь",
                2 => "Февраль",
                3 => "Март",
                4 => "Апрель",
                5 => "Май",
                6 => "Июнь",
                7 => "Июль",
                8 => "Август",
                9 => "Сентябрь",
                10 => "Октябрь",
                11 => "Ноябрь",
                12 => "Декабрь",
                _ => "Неверный месяц"
            };
            Console.WriteLine($"Месяц {month}: {monthName}");

            // 2.12 Проверка пароля
            Console.WriteLine("\n2.12 Проверка пароля");
            string password = "Secure123";
            bool isStrong = password.Length >= 8 &&
                           password.Any(char.IsUpper) &&
                           password.Any(char.IsLower) &&
                           password.Any(char.IsDigit);
            Console.WriteLine($"Пароль '{password}' - {(isStrong ? "надежный" : "ненадежный")}");
        }

        static void SolveQuadraticEquation(double a, double b, double c)
        {
            double discriminant = b * b - 4 * a * c;
            if (discriminant > 0)
            {
                double x1 = (-b + Math.Sqrt(discriminant)) / (2 * a);
                double x2 = (-b - Math.Sqrt(discriminant)) / (2 * a);
                Console.WriteLine($"Корни: x1 = {x1:F2}, x2 = {x2:F2}");
            }
            else if (discriminant == 0)
            {
                double x = -b / (2 * a);
                Console.WriteLine($"Один корень: x = {x:F2}");
            }
            else
            {
                Console.WriteLine("Действительных корней нет");
            }
        }

        #endregion

        #region Тема 3: Циклы (12 заданий)

        static void DemonstrateTopic3()
        {
            Console.WriteLine("\n📘 ТЕМА 3: ЦИКЛЫ\n");

            // 3.1 Вывод чисел от 1 до N
            Console.WriteLine("3.1 Вывод чисел от 1 до N");
            int N = 5;
            Console.Write($"Числа от 1 до {N}: ");
            for (int i = 1; i <= N; i++)
                Console.Write(i + " ");
            Console.WriteLine();

            // 3.2 Сумма чисел от 1 до N
            Console.WriteLine("\n3.2 Сумма чисел от 1 до N");
            int sum = 0;
            for (int i = 1; i <= N; i++)
                sum += i;
            Console.WriteLine($"Сумма чисел от 1 до {N} = {sum}");

            // 3.3 Таблица умножения
            Console.WriteLine("\n3.3 Таблица умножения");
            Console.WriteLine("Таблица умножения 5x5:");
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= 5; j++)
                {
                    Console.Write($"{i * j,4}");
                }
                Console.WriteLine();
            }

            // 3.4 Факториал числа
            Console.WriteLine("\n3.4 Факториал числа");
            int factNum = 5;
            long factorial = 1;
            for (int i = 1; i <= factNum; i++)
                factorial *= i;
            Console.WriteLine($"{factNum}! = {factorial}");

            // 3.5 Числа Фибоначчи
            Console.WriteLine("\n3.5 Числа Фибоначчи");
            int fibCount = 10;
            Console.Write($"Первые {fibCount} чисел Фибоначчи: ");
            int a = 0, b = 1;
            for (int i = 0; i < fibCount; i++)
            {
                Console.Write(a + " ");
                int temp = a;
                a = b;
                b = temp + b;
            }
            Console.WriteLine();

            // 3.6 Проверка на простое число
            Console.WriteLine("\n3.6 Проверка на простое число");
            int primeCheck = 17;
            bool isPrime = IsPrime(primeCheck);
            Console.WriteLine($"{primeCheck} - {(isPrime ? "простое" : "составное")}");

            // 3.7 Переворот числа
            Console.WriteLine("\n3.7 Переворот числа");
            int numToReverse = 12345;
            int reversed = ReverseNumber(numToReverse);
            Console.WriteLine($"{numToReverse} -> {reversed}");

            // 3.8 Сумма цифр числа
            Console.WriteLine("\n3.8 Сумма цифр числа");
            int numForSum = 1234;
            int digitSum = SumOfDigits(numForSum);
            Console.WriteLine($"Сумма цифр {numForSum} = {digitSum}");

            // 3.9 Вывод простых чисел
            Console.WriteLine("\n3.9 Вывод простых чисел");
            Console.Write("Простые числа до 30: ");
            for (int i = 2; i <= 30; i++)
            {
                if (IsPrime(i))
                    Console.Write(i + " ");
            }
            Console.WriteLine();

            // 3.10 Угадай число
            Console.WriteLine("\n3.10 Угадай число");
            GuessNumberGame();

            // 3.11 Пирамида из звездочек
            Console.WriteLine("\n3.11 Пирамида из звездочек");
            int pyramidHeight = 5;
            for (int i = 1; i <= pyramidHeight; i++)
            {
                Console.WriteLine(new string(' ', pyramidHeight - i) + new string('*', 2 * i - 1));
            }

            // 3.12 НОД двух чисел
            Console.WriteLine("\n3.12 НОД двух чисел");
            int gcdNum1 = 48, gcdNum2 = 18;
            int gcd = FindGCD(gcdNum1, gcdNum2);
            Console.WriteLine($"НОД({gcdNum1}, {gcdNum2}) = {gcd}");
        }

        static bool IsPrime(int n)
        {
            if (n < 2) return false;
            for (int i = 2; i <= Math.Sqrt(n); i++)
            {
                if (n % i == 0) return false;
            }
            return true;
        }

        static int ReverseNumber(int n)
        {
            int reversed = 0;
            while (n > 0)
            {
                reversed = reversed * 10 + n % 10;
                n /= 10;
            }
            return reversed;
        }

        static int SumOfDigits(int n)
        {
            int sum = 0;
            while (n > 0)
            {
                sum += n % 10;
                n /= 10;
            }
            return sum;
        }

        static void GuessNumberGame()
        {
            Random random = new Random();
            int secretNumber = random.Next(1, 101);
            int attempts = 0;
            int guess = 0;

            Console.WriteLine("Угадайте число от 1 до 100!");

            while (guess != secretNumber)
            {
                Console.Write("Ваша попытка: ");
                guess = int.Parse(Console.ReadLine());
                attempts++;

                if (guess < secretNumber)
                    Console.WriteLine("Загаданное число больше!");
                else if (guess > secretNumber)
                    Console.WriteLine("Загаданное число меньше!");
                else
                    Console.WriteLine($"Поздравляем! Вы угадали за {attempts} попыток.");
            }
        }

        static int FindGCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }

        #endregion

        #region Тема 4: Массивы (12 заданий)

        static void DemonstrateTopic4()
        {
            Console.WriteLine("\n📘 ТЕМА 4: МАССИВЫ\n");

            // 4.1 Заполнение и вывод массива
            Console.WriteLine("4.1 Заполнение и вывод массива");
            int[] array = new int[10];
            Random rand = new Random();
            for (int i = 0; i < array.Length; i++)
                array[i] = rand.Next(1, 101);

            Console.WriteLine($"Массив: [{string.Join(", ", array)}]");

            // 4.2 Сумма элементов массива
            Console.WriteLine("\n4.2 Сумма элементов массива");
            int arraySum = 0;
            foreach (int num in array)
                arraySum += num;
            Console.WriteLine($"Сумма элементов: {arraySum}");

            // 4.3 Поиск максимального элемента
            Console.WriteLine("\n4.3 Поиск максимального элемента");
            int max = array[0];
            int maxIndex = 0;
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] > max)
                {
                    max = array[i];
                    maxIndex = i;
                }
            }
            Console.WriteLine($"Максимум: {max} (индекс {maxIndex})");

            // 4.4 Переворот массива
            Console.WriteLine("\n4.4 Переворот массива");
            int[] reversedArray = new int[array.Length];
            Array.Copy(array, reversedArray, array.Length);
            Array.Reverse(reversedArray);
            Console.WriteLine($"Перевернутый массив: [{string.Join(", ", reversedArray)}]");

            // 4.5 Поиск элемента в массиве
            Console.WriteLine("\n4.5 Поиск элемента в массиве");
            int searchValue = 50;
            int foundIndex = -1;
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == searchValue)
                {
                    foundIndex = i;
                    break;
                }
            }
            Console.WriteLine($"Число {searchValue} {(foundIndex != -1 ? $"найдено на позиции {foundIndex}" : "не найдено")}");

            // 4.6 Подсчет четных и нечетных
            Console.WriteLine("\n4.6 Подсчет четных и нечетных");
            int evenCount = 0, oddCount = 0;
            foreach (int num in array)
            {
                if (num % 2 == 0) evenCount++;
                else oddCount++;
            }
            Console.WriteLine($"Четных: {evenCount}, Нечетных: {oddCount}");

            // 4.7 Сортировка пузырьком
            Console.WriteLine("\n4.7 Сортировка пузырьком");
            int[] sortArray = new int[array.Length];
            Array.Copy(array, sortArray, array.Length);
            BubbleSort(sortArray);
            Console.WriteLine($"Отсортированный массив: [{string.Join(", ", sortArray)}]");

            // 4.8 Двумерный массив (матрица)
            Console.WriteLine("\n4.8 Двумерный массив (матрица)");
            int[,] matrix = new int[3, 4];
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = rand.Next(1, 10);
                    Console.Write($"{matrix[i, j],3}");
                }
                Console.WriteLine();
            }

            // 4.9 Сумма элементов по диагонали
            Console.WriteLine("\n4.9 Сумма элементов по диагонали");
            int[,] squareMatrix = new int[3, 3];
            int diagonalSum = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    squareMatrix[i, j] = rand.Next(1, 10);
                    Console.Write($"{squareMatrix[i, j],3}");
                    if (i == j) diagonalSum += squareMatrix[i, j];
                }
                Console.WriteLine();
            }
            Console.WriteLine($"Сумма главной диагонали: {diagonalSum}");

            // 4.10 Зубчатый массив
            Console.WriteLine("\n4.10 Зубчатый массив");
            int[][] jaggedArray = new int[3][];
            for (int i = 0; i < jaggedArray.Length; i++)
            {
                jaggedArray[i] = new int[i + 2];
                for (int j = 0; j < jaggedArray[i].Length; j++)
                {
                    jaggedArray[i][j] = rand.Next(1, 10);
                }
                Console.WriteLine($"Строка {i}: [{string.Join(", ", jaggedArray[i])}]");
            }

            // 4.11 Транспонирование матрицы
            Console.WriteLine("\n4.11 Транспонирование матрицы");
            int[,] original = { { 1, 2, 3 }, { 4, 5, 6 } };
            int[,] transposed = TransposeMatrix(original);
            Console.WriteLine("Оригинальная матрица:");
            PrintMatrix(original);
            Console.WriteLine("Транспонированная матрица:");
            PrintMatrix(transposed);

            // 4.12 Объединение двух массивов
            Console.WriteLine("\n4.12 Объединение двух массивов");
            int[] array1 = { 1, 3, 5, 7 };
            int[] array2 = { 2, 4, 6, 8 };
            int[] merged = MergeSortedArrays(array1, array2);
            Console.WriteLine($"Объединенный массив: [{string.Join(", ", merged)}]");
        }

        static void BubbleSort(int[] arr)
        {
            for (int i = 0; i < arr.Length - 1; i++)
            {
                for (int j = 0; j < arr.Length - i - 1; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        (arr[j], arr[j + 1]) = (arr[j + 1], arr[j]);
                    }
                }
            }
        }

        static int[,] TransposeMatrix(int[,] matrix)
        {
            int rows = matrix.GetLength(0);
            int cols = matrix.GetLength(1);
            int[,] result = new int[cols, rows];

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    result[j, i] = matrix[i, j];
                }
            }
            return result;
        }

        static void PrintMatrix(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write($"{matrix[i, j],3}");
                }
                Console.WriteLine();
            }
        }

        static int[] MergeSortedArrays(int[] arr1, int[] arr2)
        {
            int[] result = new int[arr1.Length + arr2.Length];
            int i = 0, j = 0, k = 0;

            while (i < arr1.Length && j < arr2.Length)
            {
                if (arr1[i] < arr2[j])
                    result[k++] = arr1[i++];
                else
                    result[k++] = arr2[j++];
            }

            while (i < arr1.Length)
                result[k++] = arr1[i++];

            while (j < arr2.Length)
                result[k++] = arr2[j++];

            return result;
        }

        #endregion

        #region Тема 5: Методы (11 заданий)

        static void DemonstrateTopic5()
        {
            Console.WriteLine("\n📘 ТЕМА 5: МЕТОДЫ\n");

            // 5.1 Метод для вычисления суммы
            Console.WriteLine("5.1 Метод для вычисления суммы");
            Console.WriteLine($"Сумма 5 и 7: {Add(5, 7)}");

            // 5.2 Метод для проверки четности
            Console.WriteLine("\n5.2 Метод для проверки четности");
            Console.WriteLine($"8 - четное: {IsEven(8)}");
            Console.WriteLine($"7 - четное: {IsEven(7)}");

            // 5.3 Метод для вычисления факториала
            Console.WriteLine("\n5.3 Метод для вычисления факториала");
            Console.WriteLine($"Факториал 6: {Factorial(6)}");

            // 5.4 Метод с параметрами по умолчанию
            Console.WriteLine("\n5.4 Метод с параметрами по умолчанию");
            Console.WriteLine($"Степень числа: {Power(2)}"); // по умолчанию степень 2
            Console.WriteLine($"Степень числа: {Power(2, 3)}"); // степень 3

            // 5.5 Метод для поиска максимума
            Console.WriteLine("\n5.5 Метод для поиска максимума");
            int[] numbers = { 3, 7, 2, 9, 1 };
            Console.WriteLine($"Максимум в массиве: {FindMax(numbers)}");

            // 5.6 Перегрузка методов
            Console.WriteLine("\n5.6 Перегрузка методов");
            Console.WriteLine($"Сумма int: {Add(2, 3)}");
            Console.WriteLine($"Сумма double: {Add(2.5, 3.7)}");
            Console.WriteLine($"Конкатенация строк: {Add("Hello", "World")}");

            // 5.7 Метод с параметром ref
            Console.WriteLine("\n5.7 Метод с параметром ref");
            int refValue = 10;
            Console.WriteLine($"До: {refValue}");
            IncrementRef(ref refValue);
            Console.WriteLine($"После: {refValue}");

            // 5.8 Метод с параметром out
            Console.WriteLine("\n5.8 Метод с параметром out");
            if (TryDivide(10, 2, out double result))
                Console.WriteLine($"Результат деления: {result}");
            else
                Console.WriteLine("Деление на ноль!");

            // 5.9 Метод для сортировки массива
            Console.WriteLine("\n5.9 Метод для сортировки массива");
            int[] sortArray = { 5, 2, 8, 1, 9 };
            Console.WriteLine($"До сортировки: [{string.Join(", ", sortArray)}]");
            SortArray(sortArray);
            Console.WriteLine($"После сортировки: [{string.Join(", ", sortArray)}]");

            // 5.10 Метод для проверки палиндрома
            Console.WriteLine("\n5.10 Метод для проверки палиндрома");
            string palindromeTest = "радар";
            Console.WriteLine($"'{palindromeTest}' - палиндром: {IsPalindrome(palindromeTest)}");

            // 5.11 Метод с переменным числом параметров
            Console.WriteLine("\n5.11 Метод с переменным числом параметров");
            Console.WriteLine($"Сумма чисел: {SumParams(1, 2, 3, 4, 5)}");
            Console.WriteLine($"Сумма чисел: {SumParams(10, 20, 30)}");
        }

        static int Add(int a, int b) => a + b;
        static bool IsEven(int n) => n % 2 == 0;
        static long Factorial(int n) => n <= 1 ? 1 : n * Factorial(n - 1);
        static double Power(double x, int exponent = 2) => Math.Pow(x, exponent);
        static int FindMax(int[] arr) => arr.Max();

        // Перегрузки метода Add
        static double Add(double a, double b) => a + b;
        static string Add(string a, string b) => a + " " + b;

        static void IncrementRef(ref int value) => value++;
        static bool TryDivide(double a, double b, out double result)
        {
            result = 0;
            if (b == 0) return false;
            result = a / b;
            return true;
        }

        static void SortArray(int[] arr) => Array.Sort(arr);
        static bool IsPalindrome(string s)
        {
            string clean = s.ToLower().Replace(" ", "");
            return clean.SequenceEqual(clean.Reverse());
        }

        static int SumParams(params int[] numbers) => numbers.Sum();

        #endregion

        #region Тема 6: Рекурсия (10 заданий)

        static void DemonstrateTopic6()
        {
            Console.WriteLine("\n📘 ТЕМА 6: РЕКУРСИЯ\n");

            // 6.1 Факториал (рекурсивный)
            Console.WriteLine("6.1 Факториал (рекурсивный)");
            Console.WriteLine($"5! = {RecursiveFactorial(5)}");

            // 6.2 Числа Фибоначчи (рекурсивные)
            Console.WriteLine("\n6.2 Числа Фибоначчи (рекурсивные)");
            Console.WriteLine($"Фибоначчи(7) = {Fibonacci(7)}");

            // 6.3 Сумма цифр числа (рекурсивная)
            Console.WriteLine("\n6.3 Сумма цифр числа (рекурсивная)");
            Console.WriteLine($"Сумма цифр 1234: {RecursiveDigitSum(1234)}");

            // 6.4 Степень числа (рекурсивная)
            Console.WriteLine("\n6.4 Степень числа (рекурсивная)");
            Console.WriteLine($"2^5 = {RecursivePower(2, 5)}");

            // 6.5 НОД (рекурсивный алгоритм Евклида)
            Console.WriteLine("\n6.5 НОД (рекурсивный алгоритм Евклида)");
            Console.WriteLine($"НОД(48, 18) = {RecursiveGCD(48, 18)}");

            // 6.6 Переворот строки (рекурсивный)
            Console.WriteLine("\n6.6 Переворот строки (рекурсивный)");
            Console.WriteLine($"Перевернутая строка: {RecursiveReverse("Hello")}");

            // 6.7 Бинарный поиск (рекурсивный)
            Console.WriteLine("\n6.7 Бинарный поиск (рекурсивный)");
            int[] sortedArray = { 1, 3, 5, 7, 9, 11, 13, 15 };
            int target = 7;
            int index = RecursiveBinarySearch(sortedArray, target, 0, sortedArray.Length - 1);
            Console.WriteLine($"Число {target} найдено на позиции: {index}");

            // 6.8 Сумма элементов массива (рекурсивная)
            Console.WriteLine("\n6.8 Сумма элементов массива (рекурсивная)");
            Console.WriteLine($"Сумма массива: {RecursiveArraySum(sortedArray, 0)}");

            // 6.9 Ханойские башни
            Console.WriteLine("\n6.9 Ханойские башни");
            SolveHanoiTowers(3, 'A', 'C', 'B');

            // 6.10 Проверка палиндрома (рекурсивная)
            Console.WriteLine("\n6.10 Проверка палиндрома (рекурсивная)");
            string testStr = "радар";
            Console.WriteLine($"'{testStr}' - палиндром: {RecursiveIsPalindrome(testStr)}");
        }

        static long RecursiveFactorial(int n)
        {
            if (n <= 1) return 1;
            return n * RecursiveFactorial(n - 1);
        }

        static int Fibonacci(int n)
        {
            if (n <= 1) return n;
            return Fibonacci(n - 1) + Fibonacci(n - 2);
        }

        static int RecursiveDigitSum(int n)
        {
            if (n == 0) return 0;
            return n % 10 + RecursiveDigitSum(n / 10);
        }

        static double RecursivePower(double x, int n)
        {
            if (n == 0) return 1;
            return x * RecursivePower(x, n - 1);
        }

        static int RecursiveGCD(int a, int b)
        {
            if (b == 0) return a;
            return RecursiveGCD(b, a % b);
        }

        static string RecursiveReverse(string s)
        {
            if (s.Length <= 1) return s;
            return RecursiveReverse(s.Substring(1)) + s[0];
        }

        static int RecursiveBinarySearch(int[] arr, int target, int left, int right)
        {
            if (left > right) return -1;

            int mid = left + (right - left) / 2;

            if (arr[mid] == target) return mid;
            if (arr[mid] > target) return RecursiveBinarySearch(arr, target, left, mid - 1);
            return RecursiveBinarySearch(arr, target, mid + 1, right);
        }

        static int RecursiveArraySum(int[] arr, int index)
        {
            if (index >= arr.Length) return 0;
            return arr[index] + RecursiveArraySum(arr, index + 1);
        }

        static void SolveHanoiTowers(int n, char from, char to, char aux)
        {
            if (n == 1)
            {
                Console.WriteLine($"Переместить диск 1 с {from} на {to}");
                return;
            }

            SolveHanoiTowers(n - 1, from, aux, to);
            Console.WriteLine($"Переместить диск {n} с {from} на {to}");
            SolveHanoiTowers(n - 1, aux, to, from);
        }

        static bool RecursiveIsPalindrome(string s)
        {
            if (s.Length <= 1) return true;
            if (s[0] != s[s.Length - 1]) return false;
            return RecursiveIsPalindrome(s.Substring(1, s.Length - 2));
        }

        #endregion

        #region Тема 7: Алгоритмы (11 заданий)

        static void DemonstrateTopic7()
        {
            Console.WriteLine("\n📘 ТЕМА 7: АЛГОРИТМЫ\n");

            // 7.1 Сортировка выбором
            Console.WriteLine("7.1 Сортировка выбором");
            int[] selectionArray = { 64, 25, 12, 22, 11 };
            Console.WriteLine($"До сортировки: [{string.Join(", ", selectionArray)}]");
            SelectionSort(selectionArray);
            Console.WriteLine($"После сортировки выбором: [{string.Join(", ", selectionArray)}]");

            // 7.2 Сортировка вставками
            Console.WriteLine("\n7.2 Сортировка вставками");
            int[] insertionArray = { 12, 11, 13, 5, 6 };
            Console.WriteLine($"До сортировки: [{string.Join(", ", insertionArray)}]");
            InsertionSort(insertionArray);
            Console.WriteLine($"После сортировки вставками: [{string.Join(", ", insertionArray)}]");

            // 7.3 Быстрая сортировка
            Console.WriteLine("\n7.3 Быстрая сортировка");
            int[] quickArray = { 10, 7, 8, 9, 1, 5 };
            Console.WriteLine($"До сортировки: [{string.Join(", ", quickArray)}]");
            QuickSort(quickArray, 0, quickArray.Length - 1);
            Console.WriteLine($"После быстрой сортировки: [{string.Join(", ", quickArray)}]");

            // 7.4 Сортировка слиянием
            Console.WriteLine("\n7.4 Сортировка слиянием");
            int[] mergeArray = { 38, 27, 43, 3, 9, 82, 10 };
            Console.WriteLine($"До сортировки: [{string.Join(", ", mergeArray)}]");
            MergeSort(mergeArray, 0, mergeArray.Length - 1);
            Console.WriteLine($"После сортировки слиянием: [{string.Join(", ", mergeArray)}]");

            // 7.5 Линейный поиск
            Console.WriteLine("\n7.5 Линейный поиск");
            int[] linearArray = { 2, 3, 4, 10, 40 };
            int linearTarget = 10;
            int linearIndex = LinearSearch(linearArray, linearTarget);
            Console.WriteLine($"Число {linearTarget} найдено на позиции: {linearIndex}");

            // 7.6 Бинарный поиск (итеративный)
            Console.WriteLine("\n7.6 Бинарный поиск (итеративный)");
            int binaryIndex = BinarySearch(linearArray, linearTarget);
            Console.WriteLine($"Число {linearTarget} найдено на позиции: {binaryIndex}");

            // 7.7 Поиск минимума и максимума за один проход
            Console.WriteLine("\n7.7 Поиск минимума и максимума за один проход");
            var minMax = FindMinMax(linearArray);
            Console.WriteLine($"Минимум: {minMax.Min}, Максимум: {minMax.Max}");

            // 7.8 Решето Эратосфена
            Console.WriteLine("\n7.8 Решето Эратосфена");
            int primeLimit = 30;
            var primes = SieveOfEratosthenes(primeLimit);
            Console.WriteLine($"Простые числа до {primeLimit}: [{string.Join(", ", primes)}]");

            // 7.9 Проверка на анаграмму
            Console.WriteLine("\n7.9 Проверка на анаграмму");
            string str1 = "listen", str2 = "silent";
            Console.WriteLine($"'{str1}' и '{str2}' - анаграммы: {AreAnagrams(str1, str2)}");

            // 7.10 Алгоритм Кадане
            Console.WriteLine("\n7.10 Алгоритм Кадане");
            int[] kadaneArray = { -2, 1, -3, 4, -1, 2, 1, -5, 4 };
            int maxSubarray = KadaneAlgorithm(kadaneArray);
            Console.WriteLine($"Максимальная сумма подмассива: {maxSubarray}");

            // 7.11 Поиск повторяющихся элементов
            Console.WriteLine("\n7.11 Поиск повторяющихся элементов");
            int[] duplicateArray = { 1, 2, 3, 4, 2, 5, 3, 6 };
            var duplicates = FindDuplicates(duplicateArray);
            Console.WriteLine($"Повторяющиеся элементы: [{string.Join(", ", duplicates)}]");
        }

        static void SelectionSort(int[] arr)
        {
            for (int i = 0; i < arr.Length - 1; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < arr.Length; j++)
                {
                    if (arr[j] < arr[minIndex])
                        minIndex = j;
                }
                (arr[i], arr[minIndex]) = (arr[minIndex], arr[i]);
            }
        }

        static void InsertionSort(int[] arr)
        {
            for (int i = 1; i < arr.Length; i++)
            {
                int key = arr[i];
                int j = i - 1;
                while (j >= 0 && arr[j] > key)
                {
                    arr[j + 1] = arr[j];
                    j--;
                }
                arr[j + 1] = key;
            }
        }

        static void QuickSort(int[] arr, int low, int high)
        {
            if (low < high)
            {
                int pi = Partition(arr, low, high);
                QuickSort(arr, low, pi - 1);
                QuickSort(arr, pi + 1, high);
            }
        }

        static int Partition(int[] arr, int low, int high)
        {
            int pivot = arr[high];
            int i = low - 1;

            for (int j = low; j < high; j++)
            {
                if (arr[j] < pivot)
                {
                    i++;
                    (arr[i], arr[j]) = (arr[j], arr[i]);
                }
            }
            (arr[i + 1], arr[high]) = (arr[high], arr[i + 1]);
            return i + 1;
        }

        static void MergeSort(int[] arr, int left, int right)
        {
            if (left < right)
            {
                int mid = left + (right - left) / 2;
                MergeSort(arr, left, mid);
                MergeSort(arr, mid + 1, right);
                Merge(arr, left, mid, right);
            }
        }

        static void Merge(int[] arr, int left, int mid, int right)
        {
            int n1 = mid - left + 1;
            int n2 = right - mid;

            int[] leftArr = new int[n1];
            int[] rightArr = new int[n2];

            Array.Copy(arr, left, leftArr, 0, n1);
            Array.Copy(arr, mid + 1, rightArr, 0, n2);

            int i = 0, j = 0, k = left;
            while (i < n1 && j < n2)
            {
                if (leftArr[i] <= rightArr[j])
                    arr[k++] = leftArr[i++];
                else
                    arr[k++] = rightArr[j++];
            }

            while (i < n1) arr[k++] = leftArr[i++];
            while (j < n2) arr[k++] = rightArr[j++];
        }

        static int LinearSearch(int[] arr, int target)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == target)
                    return i;
            }
            return -1;
        }

        static int BinarySearch(int[] arr, int target)
        {
            int left = 0, right = arr.Length - 1;
            while (left <= right)
            {
                int mid = left + (right - left) / 2;
                if (arr[mid] == target) return mid;
                if (arr[mid] < target) left = mid + 1;
                else right = mid - 1;
            }
            return -1;
        }

        static (int Min, int Max) FindMinMax(int[] arr)
        {
            int min = arr[0], max = arr[0];
            for (int i = 1; i < arr.Length; i++)
            {
                if (arr[i] < min) min = arr[i];
                if (arr[i] > max) max = arr[i];
            }
            return (min, max);
        }

        static List<int> SieveOfEratosthenes(int n)
        {
            bool[] isPrime = new bool[n + 1];
            for (int i = 2; i <= n; i++) isPrime[i] = true;

            for (int p = 2; p * p <= n; p++)
            {
                if (isPrime[p])
                {
                    for (int i = p * p; i <= n; i += p)
                        isPrime[i] = false;
                }
            }

            var primes = new List<int>();
            for (int i = 2; i <= n; i++)
            {
                if (isPrime[i])
                    primes.Add(i);
            }
            return primes;
        }

        static bool AreAnagrams(string s1, string s2)
        {
            if (s1.Length != s2.Length) return false;

            var charCount = new Dictionary<char, int>();
            foreach (char c in s1)
            {
                if (charCount.ContainsKey(c))
                    charCount[c]++;
                else
                    charCount[c] = 1;
            }

            foreach (char c in s2)
            {
                if (!charCount.ContainsKey(c) || charCount[c] == 0)
                    return false;
                charCount[c]--;
            }
            return true;
        }

        static int KadaneAlgorithm(int[] arr)
        {
            int maxSoFar = arr[0], maxEndingHere = arr[0];
            for (int i = 1; i < arr.Length; i++)
            {
                maxEndingHere = Math.Max(arr[i], maxEndingHere + arr[i]);
                maxSoFar = Math.Max(maxSoFar, maxEndingHere);
            }
            return maxSoFar;
        }

        static List<int> FindDuplicates(int[] arr)
        {
            var seen = new HashSet<int>();
            var duplicates = new HashSet<int>();

            foreach (int num in arr)
            {
                if (seen.Contains(num))
                    duplicates.Add(num);
                else
                    seen.Add(num);
            }
            return duplicates.ToList();
        }

        #endregion

        #region Тема 8: ООП (12 заданий)

        static void DemonstrateTopic8()
        {
            Console.WriteLine("\n📘 ТЕМА 8: ООП\n");

            // 8.1 Создание класса "Студент"
            Console.WriteLine("8.1 Класс 'Студент'");
            var student = new Student("Иван Петров", 20, 4.5);
            student.DisplayInfo();

            // 8.2 Инкапсуляция - класс "Банковский счет"
            Console.WriteLine("\n8.2 Класс 'Банковский счет'");
            var account = new BankAccount("123456789", "Иван Иванов", 1000);
            Console.WriteLine(account.GetAccountInfo());
            account.Deposit(500);
            account.Withdraw(200);
            Console.WriteLine($"Баланс: {account.GetBalance():C}");

            // 8.3 Наследование - иерархия "Животные"
            Console.WriteLine("\n8.3 Наследование - иерархия 'Животные'");
            Animal dog = new Dog("Бобик", 3, "Овчарка");
            Animal cat = new Cat("Мурка", 2, true);
            dog.DisplayInfo();
            dog.MakeSound();
            cat.DisplayInfo();
            cat.MakeSound();

            // 8.4 Конструкторы - класс "Прямоугольник"
            Console.WriteLine("\n8.4 Конструкторы - класс 'Прямоугольник'");
            var rect1 = new Rectangle();
            var rect2 = new Rectangle(5, 3);
            var rect3 = new Rectangle(rect2);
            rect1.DisplayInfo();
            rect2.DisplayInfo();
            rect3.DisplayInfo();

            // 8.5 Статические члены класса
            Console.WriteLine("\n8.5 Статические члены класса");
            Console.WriteLine($"Площадь круга (r=5): {MathHelper.CalculateCircleArea(5):F2}");
            Console.WriteLine($"Расстояние между точками: {MathHelper.CalculateDistance(0, 0, 3, 4):F2}");
            Console.WriteLine($"Количество вызовов: {MathHelper.InstanceCount}");

            // 8.6 Полиморфизм - геометрические фигуры
            Console.WriteLine("\n8.6 Полиморфизм - геометрические фигуры");
            Shape circle = new Circle(5);
            Shape square = new Square(4);
            circle.DisplayInfo();
            square.DisplayInfo();

            // 8.7 Интерфейсы - сортируемые объекты
            Console.WriteLine("\n8.7 Интерфейсы - сортируемые объекты");
            var products = new List<Product>
            {
                new Product("Ноутбук", 50000),
                new Product("Мышь", 1500),
                new Product("Монитор", 30000)
            };
            products.Sort();
            Console.WriteLine("Отсортированные продукты:");
            for (int i = 0; i < products.Count; i++)
            {
                Product? product1 = products[i];
                Console.WriteLine($"  {product1}");
            }

            // 8.8 Свойства с валидацией - класс "Книга"
            Console.WriteLine("\n8.8 Свойства с валидацией - класс 'Книга'");
            try
            {
                var book = new Book("Война и мир", "Лев Толстой", 1500);
                book.DisplayInfo();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }

            // 8.9 Перегрузка операторов - ComplexNumber
            Console.WriteLine("\n8.9 Перегрузка операторов - ComplexNumber");
            var complex1 = new ComplexNumber(3, 2);
            var complex2 = new ComplexNumber(1, 4);
            var sum = complex1 + complex2;
            var product = complex1 * complex2;
            Console.WriteLine($"({complex1}) + ({complex2}) = {sum}");
            Console.WriteLine($"({complex1}) * ({complex2}) = {product}");

            // 8.10 Композиция - класс "Автомобиль"
            Console.WriteLine("\n8.10 Композиция - класс 'Автомобиль'");
            var engine = new Engine("V6", 250);
            var car = new Car("Toyota", "Camry", engine);
            car.DisplayInfo();

            // 8.11 Индексаторы - класс "Список покупок"
            Console.WriteLine("\n8.11 Индексаторы - класс 'Список покупок'");
            var shoppingList = new ShoppingList();
            shoppingList.AddItem("Хлеб");
            shoppingList.AddItem("Молоко");
            shoppingList.AddItem("Яйца");
            shoppingList.DisplayList();
            Console.WriteLine($"Второй элемент: {shoppingList[1]}");
            shoppingList[1] = "Сыр";
            shoppingList.DisplayList();

            // 8.12 Обработка исключений в классах
            Console.WriteLine("\n8.12 Обработка исключений в классах");
            try
            {
                var invalidBook = new Book("", "Автор", -100);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Поймано исключение: {ex.Message}");
            }
        }

        #endregion

        #region Тема 9: Файлы (10 заданий)

        static void DemonstrateTopic9()
        {
            Console.WriteLine("\n📘 ТЕМА 9: ФАЙЛЫ\n");

            string testFilePath = "test_file.txt";
            string numbersFilePath = "numbers.txt";

            // 9.1 Запись текста в файл
            Console.WriteLine("9.1 Запись текста в файл");
            using (StreamWriter writer = new StreamWriter(testFilePath))
            {
                writer.WriteLine("Первая строка текста");
                writer.WriteLine("Вторая строка текста");
                writer.WriteLine("Третья строка текста");
            }
            Console.WriteLine($"Текст записан в файл: {testFilePath}");

            // 9.2 Чтение текста из файла
            Console.WriteLine("\n9.2 Чтение текста из файла");
            using (StreamReader reader = new StreamReader(testFilePath))
            {
                string content = reader.ReadToEnd();
                Console.WriteLine("Содержимое файла:");
                Console.WriteLine(content);
            }

            // 9.3 Построчное чтение файла
            Console.WriteLine("\n9.3 Построчное чтение файла");
            using (StreamReader reader = new StreamReader(testFilePath))
            {
                string line;
                int lineNumber = 1;
                while ((line = reader.ReadLine()) != null)
                {
                    Console.WriteLine($"Строка {lineNumber}: {line}");
                    lineNumber++;
                }
            }

            // 9.4 Подсчет количества строк
            Console.WriteLine("\n9.4 Подсчет количества строк");
            int lineCount = File.ReadLines(testFilePath).Count();
            Console.WriteLine($"Количество строк в файле: {lineCount}");

            // 9.5 Добавление текста в существующий файл
            Console.WriteLine("\n9.5 Добавление текста в существующий файл");
            using (StreamWriter writer = new StreamWriter(testFilePath, true))
            {
                writer.WriteLine("Добавленная строка");
            }
            Console.WriteLine("Текст добавлен в файл");

            // 9.6 Копирование содержимого файла
            Console.WriteLine("\n9.6 Копирование содержимого файла");
            string copyFilePath = "test_file_copy.txt";
            File.Copy(testFilePath, copyFilePath, true);
            Console.WriteLine($"Файл скопирован в: {copyFilePath}");

            // 9.7 Поиск слова в файле
            Console.WriteLine("\n9.7 Поиск слова в файле");
            string searchWord = "строка";
            var linesWithWord = File.ReadLines(testFilePath)
                .Where(line => line.Contains(searchWord))
                .ToList();
            Console.WriteLine($"Строки содержащие '{searchWord}':");
            foreach (var line in linesWithWord)
                Console.WriteLine($"  {line}");

            // 9.8 Запись массива в файл
            Console.WriteLine("\n9.8 Запись массива в файл");
            int[] numbersArray = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            File.WriteAllLines(numbersFilePath, numbersArray.Select(n => n.ToString()));
            Console.WriteLine($"Массив записан в файл: {numbersFilePath}");

            // 9.9 Чтение чисел из файла в массив
            Console.WriteLine("\n9.9 Чтение чисел из файла в массив");
            int[] readNumbers = File.ReadAllLines(numbersFilePath)
                .Select(int.Parse)
                .ToArray();
            Console.WriteLine($"Прочитанные числа: [{string.Join(", ", readNumbers)}]");

            // 9.10 Статистика текстового файла
            Console.WriteLine("\n9.10 Статистика текстового файла");
            var fileInfo = new FileInfo(testFilePath);
            string fileContent = File.ReadAllText(testFilePath);
            int charCount = fileContent.Length;
            int wordCount = fileContent.Split(new[] { ' ', '\n', '\r', '\t' },
                StringSplitOptions.RemoveEmptyEntries).Length;

            Console.WriteLine($"Статистика файла {testFilePath}:");
            Console.WriteLine($"  Размер: {fileInfo.Length} байт");
            Console.WriteLine($"  Строк: {lineCount}");
            Console.WriteLine($"  Слов: {wordCount}");
            Console.WriteLine($"  Символов: {charCount}");

            // Очистка тестовых файлов
            File.Delete(testFilePath);
            File.Delete(copyFilePath);
            File.Delete(numbersFilePath);
        }

        #endregion
    }
}