﻿// 1
//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - f");
//double f = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"G = {(Math.Exp(2 * y) + Math.Sin(f)) / Math.Log(3.8 * y + f)}");


// 2
Console.WriteLine("Введите значение переменной - y");
double y = Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Введите значение переменной - d");
double d = Convert.ToDouble(Console.ReadLine());

Console.WriteLine($"F = {Math.Log(d) + (3.5 * Math.Pow(d, 2) + 1) / (Math.Cos(2) * y)}");

