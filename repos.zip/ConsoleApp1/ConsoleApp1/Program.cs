﻿// 3
//Console.WriteLine("Введите значение переменной - n");
//double n = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine($"G = {n * (y + 3.5) + Math.Sqrt(y)}");

// 5
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine($"L = {1.51 * Math.Cos(Math.Pow(x, 2)) + 2 * Math.Pow(x, 3)}");

// 7
//Console.WriteLine("Введите значение переменной - m");
//double m = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine($"N = {Math.Pow(m, 2) + 2.8 * Math.Abs(m) + 0.55}");

// 8
//Console.WriteLine("Введите значение переменной - y");
//y = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine($"T = {Math.Sqrt(Math.Abs(6 * Math.Pow(y, 2) - 0.1 * y + 4))}");

// 13
//Console.WriteLine("Введите значение переменной - y");
//y = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine($"E = {Math.Sqrt(Math.Abs(3 * Math.Pow(y, 2) + 0.5 * y + 4))}");

// 15
//Console.WriteLine("Введите значение переменной - y");
//y = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine($"H = {Math.Sin(Math.Pow(y, 2)) - 2.8 * y + Math.Sqrt(Math.Abs(y))}");

// 17
//Console.WriteLine("Введите значение переменной - y");
//y = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine($"N = {3 * Math.Pow(y, 2) + Math.Sqrt(y) + 1}");

// 18
//Console.WriteLine("Введите значение переменной - y");
//y = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine($"Z = {3 * Math.Pow(y, 2) + Math.Sqrt(Math.Pow(y, 3) + 1)}");

// 19
//Console.WriteLine("Введите значение переменной - n");
//n = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите значение переменной - y");
//y = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите значение переменной - g");
//double g = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine($"P = {n * Math.Pow(y, 3) + 1.09 * g}");

// 29
//Console.WriteLine("Введите значение переменной - y");
//y = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine($"N = {3 * Math.Pow(y, 2) + Math.Sqrt(Math.Abs(y + 1))}"); 

// 6
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());
//.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"M  = {Math.Cos(2 * x) + 3.6 * Math.Exp(x)}");