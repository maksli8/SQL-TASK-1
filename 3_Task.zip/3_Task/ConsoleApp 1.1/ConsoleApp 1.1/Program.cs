﻿// 4
//Console.WriteLine("Введите сторону a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите сторону b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите сторону c");
//double c = Convert.ToDouble(Console.ReadLine());

//bool isRight =
//    Math.Abs(a * a + b * b - c * c) < 1e-6 ||
//    Math.Abs(a * a + c * c - b * b) < 1e-6 ||
//    Math.Abs(b * b + c * c - a * a) < 1e-6;

//if (isRight)
//    Console.WriteLine("Треугольник прямоугольный");
//else
//    Console.WriteLine("Треугольник не прямоугольный");


// 5
//Console.WriteLine("Введите номер месяца");
//int month = Convert.ToInt32(Console.ReadLine());

//if (month == 12 || month == 1 || month == 2)
//    Console.WriteLine("Зима");
//else if (month >= 3 && month <= 5)
//    Console.WriteLine("Весна");
//else if (month >= 6 && month <= 8)
//    Console.WriteLine("Лето");
//else if (month >= 9 && month <= 11)
//    Console.WriteLine("Осень");
//else
//    Console.WriteLine("Некорректный номер месяца");


// 6
//Console.WriteLine("Введите число A");
//double A = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите число B");
//double B = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите число C");
//double C = Convert.ToDouble(Console.ReadLine());

//if (A + B + C > 0)
//{
//    A *= 2;
//    B *= 2;
//    C *= 2;
//}
//else
//{
//    A = 0;
//    B = 0;
//    C = 0;
//}
//Console.WriteLine($"A = {A}, B = {B}, C = {C}");


// 7
//Console.WriteLine("Введите x0");
//double x0 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите y0");
//double y0 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите x1");
//double x1 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите y1");
//double y1 = Convert.ToDouble(Console.ReadLine());

//double dA = Math.Sqrt(x0 * x0 + y0 * y0);
//double dB = Math.Sqrt(x1 * x1 + y1 * y1);

//if (dA < dB)
//    Console.WriteLine("Точка A ближе к началу координат");
//else if (dB < dA)
//    Console.WriteLine("Точка B ближе к началу координат");
//else
//    Console.WriteLine("Точки равноудалены от начала координат");


// 8
//Console.WriteLine("Введите сторону a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите сторону b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите сторону c");
//double c = Convert.ToDouble(Console.ReadLine());

//if (a == b || a == c || b == c)
//    Console.WriteLine("Треугольник равнобедренный");
//else
//    Console.WriteLine("Треугольник не равнобедренный");


// 9
//Console.WriteLine("Введите стоимость минуты у первого оператора (в копейках)");
//double cost1 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите скидку у первого оператора (%)");
//double disc1 = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите стоимость минуты у второго оператора (в копейках)");
//double cost2 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите скидку у второго оператора (%)");
//double disc2 = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите стоимость минуты у третьего оператора (в копейках)");
//double cost3 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите скидку у третьего оператора (%)");
//double disc3 = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите количество минут в будние дни");
//double weekMinutes = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите количество минут в выходные дни");
//double weekendMinutes = Convert.ToDouble(Console.ReadLine());

//double sum1 = weekMinutes * cost1 + weekendMinutes * cost1 * (1 - disc1 / 100.0);
//double sum2 = weekMinutes * cost2 + weekendMinutes * cost2 * (1 - disc2 / 100.0);
//double sum3 = weekMinutes * cost3 + weekendMinutes * cost3 * (1 - disc3 / 100.0);

//Console.WriteLine($"Стоимость у первого оператора: {sum1 / 100} руб.");
//Console.WriteLine($"Стоимость у второго оператора: {sum2 / 100} руб.");
//Console.WriteLine($"Стоимость у третьего оператора: {sum3 / 100} руб.");


// 10
//Console.WriteLine("Введите номер темы (1-3)");
//int theme = Convert.ToInt32(Console.ReadLine());
//Console.WriteLine("Введите вариант (a, b или c)");
//string variant = Console.ReadLine();

//string message = "";
//if (theme == 1) message = "Новогодние";
//else if (theme == 2) message = "С Днем Рождения";
//else if (theme == 3) message = "С Днем Защитника Отечества";
//else message = "Неверная тема";

//if ((variant == "a" || variant == "b" || variant == "c") && theme >= 1 && theme <= 3)
//    Console.WriteLine($"{message}, вариант {variant}");
//else
//    Console.WriteLine("Неверные данные");


// 11
//Console.WriteLine("Введите число a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите число b");
//double b = Convert.ToDouble(Console.ReadLine());

//if (a * b < 0)
//{
//    a = -a;
//    b = -b;
//}
//else
//{
//    a = 0;
//    b = 0;
//}
//Console.WriteLine($"a = {a}, b = {b}");


// 12
//Console.WriteLine("Введите число A");
//double A = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите число B");
//double B = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите число C");
//double C = Convert.ToDouble(Console.ReadLine());

//double min = Math.Min(A, Math.Min(B, C));
//Console.WriteLine($"Наименьшее число: {min}");


// 13
//Console.WriteLine("Введите число x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите число y");
//double y = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите число z");
//double z = Convert.ToDouble(Console.ReadLine());

//double avg = (x + y + z) / 3;

//Console.WriteLine("Числа, которые больше среднего по модулю:");
//if (Math.Abs(x) > avg) Console.WriteLine($"x = {x}");
//if (Math.Abs(y) > avg) Console.WriteLine($"y = {y}");
//if (Math.Abs(z) > avg) Console.WriteLine($"z = {z}");