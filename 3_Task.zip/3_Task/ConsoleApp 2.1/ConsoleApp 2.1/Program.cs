﻿// 1
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x < -Math.Log(a))
//    y = Math.Asin(x) + b * Math.Cos(z * x);
//else if (x >= -Math.Log(a) && x <= b)
//    y = Math.Pow(a, 2) - Math.Cos(a + z * x);
//else
//    y = 12.5 * a + (6 - 2 * Math.Pow(x, 2));

//Console.WriteLine($"y = {y}");


// 2
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите c");
//double c = Convert.ToDouble(Console.ReadLine());

//double y;
//if (Math.Exp(a + b) > Math.E)
//    y = Math.Sin(Math.Exp(a + b)) + Math.Pow(x, 7);
//else if (Math.Exp(a + b) == Math.E)
//    y = Math.Atan(a * b * c) + Math.Sqrt(x);
//else
//    y = Math.Cos(x) / (x + a * b * c);

//Console.WriteLine($"y = {y}");


// 3
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x <= a)
//    y = 2.8 * Math.Pow(Math.Sin(a * x), 2) - b * Math.Pow(x, 2);
//else if (x > a && x <= 67)
//    y = z * Math.Cos(a * x + b) + Math.Log(3);
//else
//    y = 2.3 * Math.Exp(x) + z * a * b * x;

//Console.WriteLine($"y = {y}");


// 4
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите c");
//double c = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x <= a + c)
//    y = Math.Sin(a * x) + Math.Cos(b * c);
//else
//    y = Math.Pow(a, 2) + 0.002;

//Console.WriteLine($"y = {y}");


// 5
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите c");
//double c = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x > a)
//    y = Math.Sin(Math.Exp(a) + b) + Math.Pow(x, 7);
//else if (x == a)
//    y = Math.Atan(a * b * c) + Math.Sqrt(x);
//else
//    y = Math.Cos(x) / (a * b * c);

//Console.WriteLine($"y = {y}");


// 6
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x <= a)
//    y = 2.8 * Math.Pow(Math.Sin(a * x), 2) - b * Math.Pow(x, 2);
//else if (x > a && x <= 67)
//    y = z * Math.Cos(a * x + b) + Math.Log(3);
//else
//    y = 2.3 * Math.Exp(x) + z * a * b * x;

//Console.WriteLine($"y = {y}");


// 7
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите c");
//double c = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x <= a + c)
//    y = Math.Sin(a * x) + Math.Cos(b * c);
//else
//    y = Math.Pow(a, 2) + 0.002;

//Console.WriteLine($"y = {y}");


// 8
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите k");
//double k = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите m");
//double m = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите n");
//double n = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x <= m + n)
//    y = Math.Log(x) + n * a;
//else if (x > m + n)
//    y = x - m + n;
//else
//    y = k * x + Math.Cos(x);

//Console.WriteLine($"y = {y}");


// 9
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x < a)
//    y = Math.Asin(x) + b * Math.Cos(z * x + a);
//else if (x >= a && x <= 3)
//    y = Math.Pow(a + b * x, 2) - Math.Sin(a + z * x);
//else
//    y = Math.Sqrt(x) - Math.Sin(b * x + z);

//Console.WriteLine($"y = {y}");


// 10
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите c");
//double c = Convert.ToDouble(Console.ReadLine());

//double y;
//if (Math.Log(a) == x)
//    y = Math.Cos(x - b - c);
//else
//    y = Math.Sin(x + a - b);

//Console.WriteLine($"y = {y}");


// 11
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x <= a)
//    y = Math.Exp(a) - 3.5 * Math.Pow(Math.Cos(2 + b * x), 2);
//else if (x > a && x <= 333)
//    y = a + Math.Log(a + b * x) - 2 * x;
//else
//    y = a + Math.Pow(Math.Cos(a + b * x * z), 2);

//Console.WriteLine($"y = {y}");


// 12
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите k");
//double k = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите m");
//double m = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите n");
//double n = Convert.ToDouble(Console.ReadLine());

//double y;
//if (3 * x > m + n)
//    y = Math.Log(k * x + m * n);
//else if (3 * x == Math.Abs(m + n))
//    y = Math.Sin(k * a * n) + n * x;
//else
//    y = 0; // если x < m+n, результат по формуле

//Console.WriteLine($"y = {y}");
