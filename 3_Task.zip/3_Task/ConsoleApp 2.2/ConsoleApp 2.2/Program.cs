﻿// 13
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите k");
//double k = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите r");
//double r = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите s");
//double s = Convert.ToDouble(Console.ReadLine());

//double y;
//if (Math.Cos(x) == Math.Cos(75))
//    y = Math.Exp(2 * k) + Math.Log(x);
//else if (Math.Cos(x) > Math.Cos(75))
//    y = Math.Pow(x, 2) + k + 75 * x;
//else
//    y = Math.Atan(k * x + r * s);

//Console.WriteLine($"y = {y}");


// 14
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x == 3 * a)
//    y = 2.53 * Math.Pow(x, 2) + a * x - 4.5 * Math.Cos(x * z);
//else if (x > a && x <= 3)
//    y = Math.Pow(a, 2) - 5.4 * x + Math.Log(x * z);
//else
//    y = 6.5 * Math.Pow(b, 2) + (a - x * z);

//Console.WriteLine($"y = {y}");


// 15
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите c");
//double c = Convert.ToDouble(Console.ReadLine());

//double y;
//if (Math.Pow(x, 2) == a + c)
//    y = Math.Pow(Math.Cos(b * x), 2) + 5.1 * Math.Pow(c, 7);
//else if (Math.Pow(x, 2) > a + c)
//    y = Math.Cos(Math.Pow(b, 3) * Math.Pow(x, 2)) + Math.Log(b * x - Math.Pow(a, 2));
//else
//    y = 0; // если x^2 < a+c

//Console.WriteLine($"y = {y}");


// 16
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x < 6.5)
//    y = Math.Log(a + Math.Pow(b, 2) * x) + a;
//else if (x >= 6.5 && x <= 625)
//    y = Math.Pow(Math.Cos(a * x + x * z), 2) + a;
//else
//    y = 0; // если x > 625

//Console.WriteLine($"y = {y}");


// 17
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x < a)
//    y = a + Math.Sin(b * x) + Math.Pow(Math.Cos(x), 2);
//else if (x >= a && x < Math.Log(b))
//    y = -Math.Sqrt(a + b * x + Math.Sin(z * x));
//else
//    y = Math.Log(a + b * x + z);

//Console.WriteLine($"y = {y}");


// 18
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x <= -Math.Log(a))
//    y = Math.Pow(3.5 * a - 7.3 * b * x + Math.Sin(2 * x), 2);
//else
//    y = Math.Tan(a - x - Math.Pow(x, 2));

//Console.WriteLine($"y = {y}");


// 19
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите c");
//double c = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x < a)
//    y = c * Math.Sin(37 * x) + b * Math.Sin(c * x + a);
//else if (x >= a && x < 3)
//    y = a + Math.Log(b * x) - Math.Pow(Math.Sin(a + c * x), 2);
//else
//    y = Math.Cos(a + b * x) + c * x;

//Console.WriteLine($"y = {y}");


// 20
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите f");
//double f = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x <= a)
//    y = Math.Exp(x) + f * Math.Cos(b * x);
//else if (x > a && x <= 3)
//    y = a + Math.Cos(b * x) - Math.Log(f);
//else
//    y = Math.Pow(Math.Cos(a + b / x), 2);

//Console.WriteLine($"y = {y}");


// 21
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x == a)
//    y = Math.Acos(Math.Pow(x, 2)) + b * Math.Sin(z * x);
//else if (x > a && x <= 4.53)
//    y = Math.Atan(a * x + z) + Math.Pow(Math.Sin(b * x), 2);
//else
//    y = Math.Log(a * x - 3) + 27;

//Console.WriteLine($"y = {y}");