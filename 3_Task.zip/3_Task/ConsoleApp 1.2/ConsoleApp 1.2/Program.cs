﻿// 15
//Console.WriteLine("Введите координату x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите координату y");
//double y = Convert.ToDouble(Console.ReadLine());

//if (x > 0 && y < 0)
//    Console.WriteLine("Точка находится в четвертой четверти");
//else
//    Console.WriteLine("Точка не находится в четвертой четверти");


// 16
//Console.WriteLine("Введите сторону a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите сторону b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите сторону c");
//double c = Convert.ToDouble(Console.ReadLine());

//double minSide = Math.Min(a, Math.Min(b, c));
//double areaTriangle = Math.Sqrt((a + b + c) / 2 * ((a + b + c) / 2 - a) * ((a + b + c) / 2 - b) * ((a + b + c) / 2 - c));
//double areaSquare = minSide * minSide;

//if (areaTriangle > areaSquare)
//    Console.WriteLine("Площадь треугольника больше площади квадрата");
//else
//    Console.WriteLine("Площадь квадрата больше площади треугольника");


// 17
//Console.WriteLine("Введите координату x1");
//double x1 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите координату y1");
//double y1 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите координату x2");
//double x2 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите координату y2");
//double y2 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите координату x3");
//double x3 = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите координату y3");
//double y3 = Convert.ToDouble(Console.ReadLine());

//bool inFirstQuadrant = x1 > 0 && y1 > 0 && x2 > 0 && y2 > 0 && x3 > 0 && y3 > 0;

//if (inFirstQuadrant)
//    Console.WriteLine("Все точки находятся в первой четверти");
//else
//    Console.WriteLine("Не все точки находятся в первой четверти");


// 18
//Console.WriteLine("Введите координату x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите координату y");
//double y = Convert.ToDouble(Console.ReadLine());

//double f;
//if (Math.Abs(x) == 2)
//    f = x * x;
//else if (x < 2)
//    f = 4;
//else
//    f = 2; // можно подставить любое значение, по условию

//double eps = 1e-3;
//if (Math.Abs(f - y) <= eps)
//    Console.WriteLine("Погрешность в пределах допустимого");
//else
//    Console.WriteLine("Погрешность больше допустимой");


// 19
//Console.WriteLine("Введите широту (φ)");
//double latitude = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите долготу (λ)");
//double longitude = Convert.ToDouble(Console.ReadLine());

//string ns = latitude >= 0 ? "Северное полушарие" : "Южное полушарие";
//string ew = longitude >= 0 ? "Восточное полушарие" : "Западное полушарие";

//Console.WriteLine($"Точка находится в {ns}, {ew}");


// 20
//Console.WriteLine("Введите сторону a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите сторону b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите сторону c");
//double c = Convert.ToDouble(Console.ReadLine());

//if (a == b && b == c)
//    Console.WriteLine("Треугольник равносторонний");
//else if (Math.Abs(a*a + b*b - c*c) < 1e-6 || Math.Abs(a*a + c*c - b*b) < 1e-6 || Math.Abs(b*b + c*c - a*a) < 1e-6)
//    Console.WriteLine("Треугольник прямоугольный");
//else
//    Console.WriteLine("Простой треугольник");


// 21
//Console.WriteLine("Введите число a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите число b");
//double b = Convert.ToDouble(Console.ReadLine());

//if (a * b < 0)
//{
//    a = -a;
//    b = -b;
//}
//else
//{
//    a = 0;
//    b = 0;
//}
//Console.WriteLine($"a = {a}, b = {b}");


// 22
//Console.WriteLine("Введите число A");
//double A = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите число B");
//double B = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите число C");
//double C = Convert.ToDouble(Console.ReadLine());

//double min = Math.Min(A, Math.Min(B, C));
//Console.WriteLine($"Наименьшее число: {min}");


// 23
//Console.WriteLine("Введите число a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите число b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите число c");
//double c = Convert.ToDouble(Console.ReadLine());

//int binaryNumber = 0b1101011; // двоичное число 1101011 = 107 десятичное

//if (a > binaryNumber) Console.WriteLine($"a = {a} больше {binaryNumber}");
//if (b > binaryNumber) Console.WriteLine($"b = {b} больше {binaryNumber}");
//if (c > binaryNumber) Console.WriteLine($"c = {c} больше {binaryNumber}");


// 24
//Console.WriteLine("Введите число a (восьмиричная)");
//int a = Convert.ToInt32(Console.ReadLine(), 8);
//Console.WriteLine("Введите число b (восьмиричная)");
//int b = Convert.ToInt32(Console.ReadLine(), 8);
//Console.WriteLine("Введите число c (восьмиричная)");
//int c = Convert.ToInt32(Console.ReadLine(), 8);

//int max = Math.Max(a, Math.Max(b, c));
//Console.WriteLine($"Наибольшее число: {max}");


// 25
//Console.WriteLine("Введите число a (шестнадцатеричная)");
//int a = Convert.ToInt32(Console.ReadLine(), 16);
//Console.WriteLine("Введите число b (шестнадцатеричная)");
//int b = Convert.ToInt32(Console.ReadLine(), 16);
//Console.WriteLine("Введите число c (шестнадцатеричная)");
//int c = Convert.ToInt32(Console.ReadLine(), 16);

//int min = Math.Min(a, Math.Min(b, c));
//Console.WriteLine($"Наименьшее число: {min}");
