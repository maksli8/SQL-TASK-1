﻿// 22
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x < a)
//    y = a + b * x + Math.Pow(Math.Sin(2 * x), 2);
//else if (x >= a && x <= b)
//    y = a + Math.Log(a * b) - z * x + Math.Log(x);
//else
//    y = Math.Pow(a + Math.Tan(2 * x), 2) + b * Math.Sin(x);

//Console.WriteLine($"y = {y}");


// 23
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x <= b && x > a)
//    y = Math.Log(b * z * x) + Math.Pow(z * a, 3);
//else if (x > b)
//    y = Math.Pow(a * x, 2) + b * z * a + Math.Pow(Math.Sin(z * x), 2);
//else
//    y = Math.Cos(a * x + b) + Math.Log(2 * x);

//Console.WriteLine($"y = {y}");


// 24
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x < a)
//    y = Math.Pow(x, 2) + (2 + 7.7 * a * b * x);
//else if (x <= 67)
//    y = Math.Tan(a * x + z) + Math.Cos(b * x);
//else
//    y = Math.Log(Math.Pow(Math.Sin(a + b * x + 2 * Math.Pow(x, 7)), 2));

//Console.WriteLine($"y = {y}");


// 25
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x < a)
//    y = a + z * Math.Pow(Math.Cos(b * x), 2);
//else if (x == b)
//    y = a + Math.Pow(Math.Sin(b * x), 2) + Math.Log(2 * x);
//else
//    y = b + a - 2 * Math.Pow(a - Math.Cos(x), 2);

//Console.WriteLine($"y = {y}");


// 26
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x < -0.5)
//    y = Math.Pow(2 * z + 1, 2) - Math.Pow(3.71 - Math.Pow(x, 3), 2);
//else if (x > 0.5)
//    y = Math.Pow(Math.Sin(2 * x), 2) - 5.111 * 357;
//else
//    y = 3.5 * x;

//Console.WriteLine($"y = {y}");


// 27
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите p");
//double p = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x < 0.2)
//    y = Math.Pow(a * x, 3) + Math.Sqrt(Math.Pow(b, 2)) + 1.7;
//else if (x == 0.2)
//    y = Math.Atan(Math.Pow(2, x) - p);
//else
//    y = Math.Abs(a) + 4.3 + x;

//Console.WriteLine($"y = {y}");


// 28
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите c");
//double c = Convert.ToDouble(Console.ReadLine());

//double y;
//if (a + b > x)
//    y = Math.Sin(a * c * b) + Math.Pow(x, 2);
//else if (a + b == x)
//    y = Math.Atan(a * b * c) + Math.Sqrt(x);
//else
//    y = Math.Asin(Math.Pow(Math.Cos(a), 2) / x);

//Console.WriteLine($"y = {y}");


// 29
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите k");
//double k = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите r");
//double r = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите s");
//double s = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x == 75)
//    y = 1 / Math.Tan(x * Math.Exp(1) + Math.Log(x));
//else if (x < s)
//    y = k * Math.Pow(x, 2) + Math.Pow(Math.Sin(k * x), 2);
//else
//    y = Math.Atan(k * x + Math.Tan(75));

//Console.WriteLine($"y = {y}");


// 30
//Console.WriteLine("Введите x");
//double x = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите a");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите b");
//double b = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Введите z");
//double z = Convert.ToDouble(Console.ReadLine());

//double y;
//if (x == a)
//    y = a + Math.Atan(Math.Sin(b * x)) + Math.Pow(Math.Cos(x), 2);
//else if (x > a && x < b)
//    y = Math.Sqrt(a + b * x) + 2 + Math.Sin(z * x);
//else
//    y = Math.Atan(a + b * x + z);

//Console.WriteLine($"y = {y}");