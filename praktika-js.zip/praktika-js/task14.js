﻿
function debounce(fn, delay) {
    let timer;

    return function (...args) {
        clearTimeout(timer);

        timer = setTimeout(() => {
            fn(...args);
        }, delay);
    };
}

const search = debounce((text) => {
    console.log("Поиск:", text);
}, 500);

search("М");
search("Ма");
search("Мак");
search("Максим");

setTimeout(() => {
    console.log("Готово");
}, 1000);
