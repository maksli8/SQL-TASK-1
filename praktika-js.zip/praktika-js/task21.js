﻿
async function retry(fn, attempts) {
    let lastError;

    for (let i = 1; i <= attempts; i++) {
        try {
            console.log(`Попытка ${i}`);
            return await fn();
        } catch (error) {
            lastError = error;
        }
    }

    throw lastError;
}

let count = 0;

async function unstableTask() {
    count++;

    if (count < 3) {
        throw new Error("Временная ошибка");
    }

    return "Операция выполнена успешно";
}

retry(unstableTask, 3)
    .then(result => console.log(result))
    .catch(error => console.log("Ошибка:", error.message));
