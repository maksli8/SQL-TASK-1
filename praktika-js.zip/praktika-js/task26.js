﻿
function filterUsers(users, minAge) {
    return users.filter(user => user.age >= minAge);
}

const users = [
    { name: "Максим", age: 18 },
    { name: "Алексей", age: 20 },
    { name: "Иван", age: 22 },
    { name: "Анна", age: 17 }
];

console.log("Все пользователи:", users);

const result = filterUsers(users, 20);

console.log("Пользователи от 20 лет:", result);
