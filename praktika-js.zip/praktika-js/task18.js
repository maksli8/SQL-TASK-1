﻿
function getData(name, delay) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(`${name} загружен`);
        }, delay);
    });
}

async function main() {
    console.log("Начало загрузки");

    const results = await Promise.all([
        getData("Пользователь", 1000),
        getData("Товары", 500),
        getData("Заказы", 700)
    ]);

    results.forEach(result => {
        console.log(result);
    });

    console.log("Все данные загружены");
}

main();
