﻿
function getUser(id) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({
                id: id,
                name: "Максим",
                age: 18
            });
        }, 1000);
    });
}

async function main() {
    console.log("Загрузка пользователя...");

    try {
        const user = await getUser(1);

        console.log("Пользователь получен:");
        console.log("ID:", user.id);
        console.log("Имя:", user.name);
        console.log("Возраст:", user.age);
    } catch (error) {
        console.log("Ошибка:", error.message);
    }
}

main();
