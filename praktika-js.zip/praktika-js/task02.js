﻿
function createVNode(type, props, ...children) {
    return {
        type: type,
        props: {
            ...props,
            children: children.length === 1
                ? children[0]
                : children
        },
        key: props?.key ?? null
    };
}

// Проверка 1: элемент с текстом
const node1 = createVNode("h1", {}, "Привет, мир!");

// Проверка 2: элемент с несколькими дочерними элементами
const node2 = createVNode(
    "div",
    { className: "container", key: "main" },
    "Первый текст",
    "Второй текст"
);

// Вывод результатов
console.log("Первый узел:", node1);
console.log("Второй узел:", node2);
