﻿
function checkNumber(number) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (number > 0) {
                resolve(`Число ${number} положительное`);
            } else {
                reject(new Error("Число должно быть больше нуля"));
            }
        }, 500);
    });
}

checkNumber(5)
    .then(result => {
        console.log("Успех:", result);
    })
    .catch(error => {
        console.log("Ошибка:", error.message);
    });

checkNumber(-3)
    .then(result => {
        console.log("Успех:", result);
    })
    .catch(error => {
        console.log("Ошибка:", error.message);
    });
