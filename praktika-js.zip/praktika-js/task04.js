﻿
function shallowEqual(objA, objB) {
    if (Object.is(objA, objB)) {
        return true;
    }

    if (
        objA === null ||
        objB === null ||
        typeof objA !== "object" ||
        typeof objB !== "object"
    ) {
        return false;
    }

    const keysA = Object.keys(objA);
    const keysB = Object.keys(objB);

    if (keysA.length !== keysB.length) {
        return false;
    }

    return keysA.every(key =>
        Object.hasOwn(objB, key) &&
        Object.is(objA[key], objB[key])
    );
}

function areArraysEqual(arrA, arrB) {
    if (!Array.isArray(arrA) || !Array.isArray(arrB)) {
        return false;
    }

    if (arrA.length !== arrB.length) {
        return false;
    }

    return arrA.every((value, index) =>
        shallowEqual(value, arrB[index])
    );
}

// Проверки
console.log(
    "Одинаковые массивы:",
    areArraysEqual([1, 2, 3], [1, 2, 3])
);

console.log(
    "Разные массивы:",
    areArraysEqual([1, 2, 3], [1, 2, 4])
);

console.log(
    "Массивы объектов:",
    areArraysEqual(
        [{ id: 1 }, { id: 2 }],
        [{ id: 1 }, { id: 2 }]
    )
);

console.log(
    "Разная длина:",
    areArraysEqual([1, 2], [1, 2, 3])
);
