﻿
function shallowEqual(objA, objB) {
    if (Object.is(objA, objB)) {
        return true;
    }

    if (
        objA === null ||
        objB === null ||
        typeof objA !== "object" ||
        typeof objB !== "object"
    ) {
        return false;
    }

    const keysA = Object.keys(objA);
    const keysB = Object.keys(objB);

    if (keysA.length !== keysB.length) {
        return false;
    }

    return keysA.every(key =>
        Object.hasOwn(objB, key) &&
        Object.is(objA[key], objB[key])
    );
}

// Проверка
const user1 = { name: "Максим", age: 18 };
const user2 = { name: "Максим", age: 18 };
const user3 = { name: "Максим", age: 20 };

console.log("user1 и user2:", shallowEqual(user1, user2));
console.log("user1 и user3:", shallowEqual(user1, user3));
console.log("Одинаковые значения:", shallowEqual(10, 10));
console.log("Разные объекты:", shallowEqual({}, {}));
