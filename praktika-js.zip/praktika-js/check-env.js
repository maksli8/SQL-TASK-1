﻿
const majorVersion = Number(process.version.slice(1).split(".")[0]);

console.log("Текущая версия Node.js:", process.version);

if (majorVersion < 18) {
    console.error("Ошибка: требуется Node.js версии 18 или выше.");
    process.exit(1);
}

console.log("Проверка окружения пройдена успешно!");
