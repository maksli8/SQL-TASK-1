﻿
const WebSocket = require("ws");
const fs = require("node:fs");

const server = new WebSocket.Server({ port: 8081 });

console.log("Сервер HMR запущен на порту 8081");

server.on("connection", (socket) => {
    console.log("Клиент подключён");

    socket.send(JSON.stringify({
        type: "connected"
    }));
});

fs.watch("test.js", () => {
    console.log("Файл test.js изменён");

    const message = JSON.stringify({
        type: "reload"
    });

    server.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(message);
        }
    });
});
