﻿
const users = [
    { id: 1, name: "Максим", age: 18 },
    { id: 2, name: "Алексей", age: 20 },
    { id: 3, name: "Иван", age: 22 }
];

function findUser(name) {
    return users.find(user => user.name === name);
}

console.log("Поиск: Максим");
console.log(findUser("Максим"));

console.log("Поиск: Иван");
console.log(findUser("Иван"));

console.log("Поиск: Анна");
console.log(findUser("Анна"));
