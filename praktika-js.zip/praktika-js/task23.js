﻿
function doTask(name, delay) {
    return new Promise((resolve) => {
        setTimeout(() => {
            console.log(name);
            resolve();
        }, delay);
    });
}

async function main() {
    console.log("Начало");

    await doTask("Задача 1 завершена", 1000);
    await doTask("Задача 2 завершена", 500);
    await doTask("Задача 3 завершена", 700);

    console.log("Все задачи завершены");
}

main();
