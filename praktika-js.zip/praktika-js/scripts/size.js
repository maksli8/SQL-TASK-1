﻿
const fs = require("node:fs");
const path = require("node:path");

function getSize(directory) {
    let total = 0;

    for (const item of fs.readdirSync(directory)) {
        const fullPath = path.join(directory, item);
        const stats = fs.statSync(fullPath);

        if (stats.isDirectory()) {
            total += getSize(fullPath);
        } else {
            total += stats.size;
        }
    }

    return total;
}

const distPath = path.join(__dirname, "..", "dist");

if (fs.existsSync(distPath)) {
    const bytes = getSize(distPath);
    console.log(`Размер папки dist: ${(bytes / 1024).toFixed(2)} КБ`);
} else {
    console.log("Папка dist не найдена.");
}
