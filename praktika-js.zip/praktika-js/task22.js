﻿
function withTimeout(promise, ms) {
    const timeout = new Promise((_, reject) => {
        setTimeout(() => {
            reject(new Error("Время ожидания истекло"));
        }, ms);
    });

    return Promise.race([promise, timeout]);
}

function slowTask() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve("Операция выполнена");
        }, 2000);
    });
}

withTimeout(slowTask(), 1000)
    .then(result => console.log(result))
    .catch(error => console.log("Ошибка:", error.message));
