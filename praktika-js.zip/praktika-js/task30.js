﻿
const numbers = [10, 25, 30, 45, 50, 65, 70];

const evenNumbers = numbers.filter(number => number % 2 === 0);
const oddNumbers = numbers.filter(number => number % 2 !== 0);

console.log("Все числа:", numbers);
console.log("Чётные числа:", evenNumbers);
console.log("Количество чётных чисел:", evenNumbers.length);
console.log("Нечётные числа:", oddNumbers);
console.log("Количество нечётных чисел:", oddNumbers.length);
