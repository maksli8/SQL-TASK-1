﻿
const products = [
    { name: "Ноутбук", price: 50000 },
    { name: "Мышь", price: 1500 },
    { name: "Клавиатура", price: 3000 },
    { name: "Монитор", price: 20000 }
];

const expensiveProducts = products.filter(
    product => product.price > 5000
);

console.log("Все товары:", products);
console.log("Товары дороже 5000 рублей:", expensiveProducts);
