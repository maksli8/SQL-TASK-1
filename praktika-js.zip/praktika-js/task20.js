﻿
function checkTask(name, success) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (success) {
                resolve(`${name}: выполнено`);
            } else {
                reject(new Error(`${name}: ошибка`));
            }
        }, 500);
    });
}

async function main() {
    const results = await Promise.allSettled([
        checkTask("Задача 1", true),
        checkTask("Задача 2", false),
        checkTask("Задача 3", true)
    ]);

    results.forEach((result, index) => {
        if (result.status === "fulfilled") {
            console.log(result.value);
        } else {
            console.log(`Задача ${index + 1}: ${result.reason.message}`);
        }
    });

    console.log("Проверка завершена");
}

main();
