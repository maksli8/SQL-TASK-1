﻿
function createCounter(start = 0) {
    let count = start;

    return {
        increment() {
            count++;
            return count;
        },

        decrement() {
            count--;
            return count;
        },

        getValue() {
            return count;
        }
    };
}

const counter1 = createCounter(0);
const counter2 = createCounter(10);

console.log("Счётчик 1:", counter1.increment());
console.log("Счётчик 1:", counter1.increment());

console.log("Счётчик 2:", counter2.decrement());
console.log("Значение счётчика 1:", counter1.getValue());
console.log("Значение счётчика 2:", counter2.getValue());
