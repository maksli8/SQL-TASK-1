﻿
function throttle(fn, delay) {
    let lastCall = 0;

    return function (...args) {
        const now = Date.now();

        if (now - lastCall >= delay) {
            lastCall = now;
            fn(...args);
        }
    };
}

const log = throttle((message) => {
    console.log(message);
}, 1000);

log("Вызов 1");
log("Вызов 2");
log("Вызов 3");

setTimeout(() => {
    log("Вызов 4");
}, 1100);
