﻿
function createVNode(type, props = {}, ...children) {
    return {
        type,
        props: {
            ...props,
            children
        },
        key: props.key ?? null
    };
}

const element = createVNode(
    "div",
    { id: "app", className: "container" },
    createVNode("h1", {}, "Привет!"),
    createVNode("p", {}, "Это виртуальный DOM.")
);

console.log(JSON.stringify(element, null, 2));
