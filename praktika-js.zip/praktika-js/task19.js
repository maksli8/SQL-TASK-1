﻿
function getData(name, delay) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(`${name} завершён`);
        }, delay);
    });
}

async function main() {
    console.log("Запуск операций...");

    const result = await Promise.race([
        getData("Первая операция", 1000),
        getData("Вторая операция", 500),
        getData("Третья операция", 1500)
    ]);

    console.log("Первый результат:", result);
}

main();
