﻿
import { getMessage } from "@/utils/message.js";

console.log(getMessage());
