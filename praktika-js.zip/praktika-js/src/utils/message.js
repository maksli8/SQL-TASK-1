﻿
export function getMessage() {
    return "Абсолютные импорты работают!";
}
