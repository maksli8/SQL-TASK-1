﻿
function isValidVersion(version) {
    const pattern = /^\d+\.\d+\.\d+$/;
    return pattern.test(version);
}

console.log("1.0.0:", isValidVersion("1.0.0"));
console.log("2.15.3:", isValidVersion("2.15.3"));
console.log("1.0:", isValidVersion("1.0"));
console.log("abc:", isValidVersion("abc"));
console.log("1.2.3.4:", isValidVersion("1.2.3.4"));
