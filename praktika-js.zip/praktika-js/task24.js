﻿
function normalizeEntities(entities) {
    const result = {};

    entities.forEach(entity => {
        result[entity.id] = entity;
    });

    return result;
}

function patchEntityById(entities, id, changes) {
    if (!entities[id]) {
        console.log("Объект не найден");
        return entities;
    }

    return {
        ...entities,
        [id]: {
            ...entities[id],
            ...changes
        }
    };
}

const users = [
    { id: 1, name: "Максим", age: 18 },
    { id: 2, name: "Алексей", age: 20 },
    { id: 3, name: "Иван", age: 22 }
];

const normalized = normalizeEntities(users);

console.log("Исходные данные:");
console.log(normalized);

const updated = patchEntityById(normalized, 2, {
    age: 21
});

console.log("После обновления:");
console.log(updated);

console.log("Исходный возраст:", normalized[2].age);
console.log("Новый возраст:", updated[2].age);
