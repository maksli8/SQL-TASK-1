﻿
function deepFreeze(obj, seen = new WeakSet()) {
    if (obj === null || typeof obj !== "object") {
        return obj;
    }

    if (seen.has(obj)) {
        return obj;
    }

    seen.add(obj);

    Object.values(obj).forEach(value => {
        deepFreeze(value, seen);
    });

    return Object.freeze(obj);
}

const user = {
    name: "Максим",
    address: {
        city: "Новомосковск"
    }
};

deepFreeze(user);

console.log("Объект заморожен:", Object.isFrozen(user));
console.log("Вложенный объект заморожен:",
    Object.isFrozen(user.address));
