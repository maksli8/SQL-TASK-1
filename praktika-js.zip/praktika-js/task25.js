﻿
function updateFormState(prevState, fieldName, fieldValue) {
    return {
        ...prevState,
        [fieldName]: fieldValue
    };
}

const formState = {
    name: "Максим",
    email: "old@example.com",
    age: 18
};

console.log("Исходное состояние:", formState);

const updatedState = updateFormState(
    formState,
    "email",
    "maxim@example.com"
);

console.log("Обновлённое состояние:", updatedState);
console.log("Исходное состояние осталось:", formState);
