﻿
function memoize(fn) {
    const cache = new Map();

    return function (n) {
        if (cache.has(n)) {
            console.log("Результат взят из кэша");
            return cache.get(n);
        }

        console.log("Вычисляем результат");
        const result = fn(n);
        cache.set(n, result);

        return result;
    };
}

function square(n) {
    return n * n;
}

const memoizedSquare = memoize(square);

console.log(memoizedSquare(5));
console.log(memoizedSquare(5));
console.log(memoizedSquare(10));
console.log(memoizedSquare(10));
