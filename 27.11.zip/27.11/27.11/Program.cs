﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    // Общие переменные для демонстрации
    private static int counter = 0;
    private static object lockObject = new object();
    private static Mutex mutex = new Mutex();
    private static SemaphoreSlim semaphore = new SemaphoreSlim(2, 2); // Максимум 2 потока одновременно
    private static ConcurrentDictionary<int, string> concurrentDict = new ConcurrentDictionary<int, string>();
    private static Random random = new Random();

    static async Task Main(string[] args)
    {
        Console.WriteLine("=== ДЕМОНСТРАЦИЯ МНОГОПОТОЧНОСТИ C# ===\n");

        // Категория 1: Thread Basics
        await DemoThreadBasics();

        // Категория 2: Task Basics
        await DemoTaskBasics();

        // Категория 3: Async/Await
        await DemoAsyncAwait();

        // Категория 4: Lock Synchronization
        await DemoLockSynchronization();

        // Категория 5: Mutex/Semaphore
        await DemoMutexSemaphore();

        // Категория 6: CancellationToken
        await DemoCancellationToken();

        // Категория 7: Parallel
        await DemoParallel();

        // Категория 8: Thread-Safe Collections
        await DemoThreadSafeCollections();

        Console.WriteLine("\n=== ВСЕ ДЕМОНСТРАЦИИ ЗАВЕРШЕНЫ ===");
    }

    #region Категория 1: Thread Basics
    static async Task DemoThreadBasics()
    {
        Console.WriteLine("🔹 КАТЕГОРИЯ 1: THREAD BASICS\n");

        // Задание 1: Создание потока
        Console.WriteLine("1. Создание потока:");
        Thread thread1 = new Thread(PrintHello);
        thread1.Start();
        thread1.Join();

        // Задание 2: Два потока с Join()
        Console.WriteLine("\n2. Два потока с Join():");
        Thread t1 = new Thread(() => PrintWork("Поток 1", 500));
        Thread t2 = new Thread(() => PrintWork("Поток 2", 300));

        t1.Start();
        t2.Start();

        t1.Join();
        t2.Join();
        Console.WriteLine("Оба потока завершены");

        // Задание 5: Передача параметров
        Console.WriteLine("\n5. Передача параметров в поток:");
        Thread paramThread = new Thread(PrintWithParameter);
        paramThread.Start("Привет с параметром!");
        paramThread.Join();

        // Задание 8: Фоновый поток
        Console.WriteLine("\n8. Фоновый поток:");
        Thread backgroundThread = new Thread(() =>
        {
            Thread.Sleep(1000);
            Console.WriteLine("Фоновый поток завершен");
        })
        { IsBackground = true };

        backgroundThread.Start();
        Console.WriteLine("Основной поток завершается (фоновый может не успеть)");
    }

    static void PrintHello()
    {
        Console.WriteLine("Привет из потока!");
    }

    static void PrintWork(string name, int delay)
    {
        Thread.Sleep(delay);
        Console.WriteLine($"{name} завершил работу");
    }

    static void PrintWithParameter(object message)
    {
        Console.WriteLine($"Сообщение: {message}");
    }
    #endregion

    #region Категория 2: Task Basics
    static async Task DemoTaskBasics()
    {
        Console.WriteLine("\n\n🔹 КАТЕГОРИЯ 2: TASK BASICS\n");

        // Задание 11: Создание Task
        Console.WriteLine("11. Создание Task:");
        Task task1 = Task.Run(() => Console.WriteLine("Task 1 выполнен"));
        await task1;

        // Задание 13: Task с возвратом результата
        Console.WriteLine("\n13. Task с возвратом результата:");
        Task<int> taskWithResult = Task.Run(() =>
        {
            Thread.Sleep(500);
            return 42;
        });

        int result = await taskWithResult;
        Console.WriteLine($"Результат задачи: {result}");

        // Задание 14: Task.WaitAll()
        Console.WriteLine("\n14. Task.WaitAll():");
        Task[] tasks = new Task[3];
        for (int i = 0; i < 3; i++)
        {
            int taskNum = i;
            tasks[i] = Task.Run(() =>
            {
                Thread.Sleep(100 * (taskNum + 1));
                Console.WriteLine($"Задача {taskNum} завершена");
            });
        }
        Task.WaitAll(tasks);
        Console.WriteLine("Все задачи завершены");

        // Задание 17: Task.WaitAny()
        Console.WriteLine("\n17. Task.WaitAny():");
        Task[] anyTasks = new Task[3];
        for (int i = 0; i < 3; i++)
        {
            int taskNum = i;
            anyTasks[i] = Task.Run(() =>
            {
                Thread.Sleep(1000 - (i * 200));
                Console.WriteLine($"Задача {taskNum} завершена");
            });
        }
        int firstCompleted = Task.WaitAny(anyTasks);
        Console.WriteLine($"Первой завершилась задача {firstCompleted}");
    }
    #endregion

    #region Категория 3: Async/Await
    static async Task DemoAsyncAwait()
    {
        Console.WriteLine("\n\n🔹 КАТЕГОРИЯ 3: ASYNC/AWAIT\n");

        // Задание 21: Асинхронный метод
        Console.WriteLine("21. Асинхронный метод:");
        await SimpleAsyncMethod();

        // Задание 23: Асинхронный метод с результатом
        Console.WriteLine("\n23. Асинхронный метод с результатом:");
        string data = await FetchDataAsync();
        Console.WriteLine($"Полученные данные: {data}");

        // Задание 24: Task.Delay()
        Console.WriteLine("\n24. Task.Delay():");
        Console.WriteLine("Начало задержки...");
        await Task.Delay(1000);
        Console.WriteLine("Задержка завершена");

        // Задание 27: Цепочка асинхронных операций
        Console.WriteLine("\n27. Цепочка асинхронных операций:");
        await ChainAsyncOperations();
    }

    static async Task SimpleAsyncMethod()
    {
        Console.WriteLine("Начало асинхронной работы...");
        await Task.Delay(500);
        Console.WriteLine("Асинхронная работа завершена");
    }

    static async Task<string> FetchDataAsync()
    {
        await Task.Delay(300);
        return "Данные из базы";
    }

    static async Task ChainAsyncOperations()
    {
        var result1 = await ProcessStep1Async();
        var result2 = await ProcessStep2Async(result1);
        Console.WriteLine($"Результат цепочки: {result2}");
    }

    static async Task<string> ProcessStep1Async()
    {
        await Task.Delay(200);
        return "Результат шага 1";
    }

    static async Task<string> ProcessStep2Async(string input)
    {
        await Task.Delay(200);
        return $"{input} -> Обработан в шаге 2";
    }
    #endregion

    #region Категория 4: Lock Synchronization
    static async Task DemoLockSynchronization()
    {
        Console.WriteLine("\n\n🔹 КАТЕГОРИЯ 4: LOCK SYNCHRONIZATION\n");

        // Задание 31: Lock для защиты переменной
        Console.WriteLine("31. Lock для защиты переменной:");
        await DemonstrateRaceCondition();

        // Задание 32: Критическая секция с lock
        Console.WriteLine("\n32. Критическая секция с lock:");
        await DemonstrateLock();

        // Задание 36: Потокобезопасный класс
        Console.WriteLine("\n36. Потокобезопасный класс:");
        await DemonstrateThreadSafeCounter();
    }

    static async Task DemonstrateRaceCondition()
    {
        counter = 0;
        Task[] tasks = new Task[10];

        // БЕЗ синхронизации - НЕПРАВИЛЬНО
        for (int i = 0; i < 10; i++)
        {
            tasks[i] = Task.Run(() =>
            {
                for (int j = 0; j < 1000; j++)
                {
                    counter++; // Race condition!
                }
            });
        }

        await Task.WhenAll(tasks);
        Console.WriteLine($"Без синхронизации: {counter} (должно быть 10000)");
    }

    static async Task DemonstrateLock()
    {
        counter = 0;
        Task[] tasks = new Task[10];

        // С синхронизацией - ПРАВИЛЬНО
        for (int i = 0; i < 10; i++)
        {
            tasks[i] = Task.Run(() =>
            {
                for (int j = 0; j < 1000; j++)
                {
                    lock (lockObject)
                    {
                        counter++; // Потокобезопасно
                    }
                }
            });
        }

        await Task.WhenAll(tasks);
        Console.WriteLine($"С синхронизацией: {counter}");
    }

    static async Task DemonstrateThreadSafeCounter()
    {
        var safeCounter = new ThreadSafeCounter();
        Task[] tasks = new Task[5];

        for (int i = 0; i < 5; i++)
        {
            tasks[i] = Task.Run(() =>
            {
                for (int j = 0; j < 1000; j++)
                {
                    safeCounter.Increment();
                }
            });
        }

        await Task.WhenAll(tasks);
        Console.WriteLine($"Потокобезопасный счетчик: {safeCounter.Value}");
    }
    #endregion

    #region Категория 5: Mutex/Semaphore
    static async Task DemoMutexSemaphore()
    {
        Console.WriteLine("\n\n🔹 КАТЕГОРИЯ 5: MUTEX/SEMAPHORE\n");

        // Задание 41: Mutex
        Console.WriteLine("41. Mutex для синхронизации:");
        await DemonstrateMutex();

        // Задание 43: Semaphore
        Console.WriteLine("\n43. Semaphore для ограничения потоков:");
        await DemonstrateSemaphore();
    }

    static async Task DemonstrateMutex()
    {
        int sharedValue = 0;
        Task[] tasks = new Task[3];

        for (int i = 0; i < 3; i++)
        {
            int taskNum = i;
            tasks[i] = Task.Run(() =>
            {
                mutex.WaitOne();
                try
                {
                    Console.WriteLine($"Задача {taskNum} получила Mutex");
                    sharedValue++;
                    Thread.Sleep(200);
                    Console.WriteLine($"Общее значение: {sharedValue}");
                }
                finally
                {
                    mutex.ReleaseMutex();
                    Console.WriteLine($"Задача {taskNum} освободила Mutex");
                }
            });
        }

        await Task.WhenAll(tasks);
    }

    static async Task DemonstrateSemaphore()
    {
        Task[] tasks = new Task[5];

        for (int i = 0; i < 5; i++)
        {
            int taskNum = i;
            tasks[i] = Task.Run(async () =>
            {
                Console.WriteLine($"Задача {taskNum} ждет Semaphore...");
                await semaphore.WaitAsync();
                try
                {
                    Console.WriteLine($"Задача {taskNum} вошла в критическую секцию");
                    await Task.Delay(1000);
                    Console.WriteLine($"Задача {taskNum} выходит из критической секции");
                }
                finally
                {
                    semaphore.Release();
                }
            });
        }

        await Task.WhenAll(tasks);
    }
    #endregion

    #region Категория 6: CancellationToken
    static async Task DemoCancellationToken()
    {
        Console.WriteLine("\n\n🔹 КАТЕГОРИЯ 6: CANCELLATION TOKEN\n");

        // Задание 51: CancellationToken
        Console.WriteLine("51. CancellationToken для отмены:");
        await DemonstrateCancellation();

        // Задание 54: Timeout для отмены
        Console.WriteLine("\n54. Timeout для отмены:");
        await DemonstrateTimeout();
    }

    static async Task DemonstrateCancellation()
    {
        var cts = new CancellationTokenSource();

        // Отменяем через 2 секунды
        cts.CancelAfter(2000);

        try
        {
            await LongRunningOperation(cts.Token);
            Console.WriteLine("Операция завершена успешно");
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("Операция отменена по таймауту");
        }
    }

    static async Task LongRunningOperation(CancellationToken cancellationToken)
    {
        for (int i = 0; i < 10; i++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Console.WriteLine($"Шаг {i + 1}/10");
            await Task.Delay(500, cancellationToken);
        }
    }

    static async Task DemonstrateTimeout()
    {
        var cts = new CancellationTokenSource(1500); // Таймаут 1.5 секунды

        try
        {
            await Task.Delay(3000, cts.Token);
            Console.WriteLine("Задача завершена");
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("Задача отменена по таймауту");
        }
    }
    #endregion

    #region Категория 7: Parallel
    static async Task DemoParallel()
    {
        Console.WriteLine("\n\n🔹 КАТЕГОРИЯ 7: PARALLEL\n");

        // Задание 67: Parallel.For
        Console.WriteLine("67. Parallel.For:");
        DemonstrateParallelFor();

        // Задание 68: Parallel.ForEach
        Console.WriteLine("\n68. Parallel.ForEach:");
        DemonstrateParallelForEach();

        // Задание 69: Parallel.Invoke
        Console.WriteLine("\n69. Parallel.Invoke:");
        DemonstrateParallelInvoke();
    }

    static void DemonstrateParallelFor()
    {
        var results = new int[10];

        Parallel.For(0, 10, i =>
        {
            results[i] = i * i;
            Thread.Sleep(100); // Имитация работы
        });

        Console.WriteLine($"Результаты: {string.Join(", ", results)}");
    }

    static void DemonstrateParallelForEach()
    {
        var numbers = Enumerable.Range(1, 10).ToList();
        var results = new ConcurrentBag<int>();

        Parallel.ForEach(numbers, number =>
        {
            int squared = number * number;
            results.Add(squared);
            Console.WriteLine($"Обработан {number} -> {squared}");
        });

        Console.WriteLine($"Всего обработано: {results.Count} чисел");
    }

    static void DemonstrateParallelInvoke()
    {
        Parallel.Invoke(
            () => { Thread.Sleep(300); Console.WriteLine("Задача 1 завершена"); },
            () => { Thread.Sleep(200); Console.WriteLine("Задача 2 завершена"); },
            () => { Thread.Sleep(400); Console.WriteLine("Задача 3 завершена"); }
        );
        Console.WriteLine("Все параллельные задачи завершены");
    }
    #endregion

    #region Категория 8: Thread-Safe Collections
    static async Task DemoThreadSafeCollections()
    {
        Console.WriteLine("\n\n🔹 КАТЕГОРИЯ 8: THREAD-SAFE COLLECTIONS\n");

        // Задание 83: ConcurrentDictionary
        Console.WriteLine("83. ConcurrentDictionary:");
        await DemonstrateConcurrentDictionary();

        // Задание 84: ConcurrentQueue
        Console.WriteLine("\n84. ConcurrentQueue:");
        await DemonstrateConcurrentQueue();

        // Задание 86: BlockingCollection
        Console.WriteLine("\n86. BlockingCollection:");
        await DemonstrateBlockingCollection();
    }

    static async Task DemonstrateConcurrentDictionary()
    {
        concurrentDict.Clear();
        Task[] tasks = new Task[5];

        for (int i = 0; i < 5; i++)
        {
            int taskNum = i;
            tasks[i] = Task.Run(() =>
            {
                for (int j = 0; j < 10; j++)
                {
                    int key = taskNum * 10 + j;
                    concurrentDict.TryAdd(key, $"Value_{key}");
                }
            });
        }

        await Task.WhenAll(tasks);
        Console.WriteLine($"Добавлено элементов: {concurrentDict.Count}");
        Console.WriteLine($"Пример элемента: {concurrentDict.First()}");
    }

    static async Task DemonstrateConcurrentQueue()
    {
        var queue = new ConcurrentQueue<int>();
        Task producer = Task.Run(() =>
        {
            for (int i = 0; i < 10; i++)
            {
                queue.Enqueue(i);
                Thread.Sleep(50);
            }
        });

        Task consumer = Task.Run(() =>
        {
            int count = 0;
            while (count < 10)
            {
                if (queue.TryDequeue(out int item))
                {
                    Console.WriteLine($"Извлечено: {item}");
                    count++;
                }
                Thread.Sleep(100);
            }
        });

        await Task.WhenAll(producer, consumer);
    }

    static async Task DemonstrateBlockingCollection()
    {
        var collection = new BlockingCollection<int>(boundedCapacity: 5);

        // Producer
        var producer = Task.Run(() =>
        {
            for (int i = 0; i < 10; i++)
            {
                collection.Add(i);
                Console.WriteLine($"Добавлен: {i}");
                Thread.Sleep(100);
            }
            collection.CompleteAdding();
        });

        // Consumer
        var consumer = Task.Run(() =>
        {
            foreach (var item in collection.GetConsumingEnumerable())
            {
                Console.WriteLine($"Обработан: {item}");
                Thread.Sleep(150);
            }
        });

        await Task.WhenAll(producer, consumer);
    }
    #endregion
}

// Вспомогательные классы

public class ThreadSafeCounter
{
    private int _value = 0;
    private readonly object _lockObject = new object();

    public int Value
    {
        get
        {
            lock (_lockObject)
            {
                return _value;
            }
        }
    }

    public void Increment()
    {
        lock (_lockObject)
        {
            _value++;
        }
    }

    public void Decrement()
    {
        lock (_lockObject)
        {
            _value--;
        }
    }
}