﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("=== ЗАДАЧА 3: K-D ДЕРЕВО ===");
        Console.WriteLine("Реализация K-D дерева для 2D и 3D точек\n");

        KDTreeTester.TestKDTree();

        Console.WriteLine("\nНажмите любую клавишу для выхода...");
        Console.ReadKey();
    }
}

public class Point2D
{
    public double X { get; set; }
    public double Y { get; set; }

    public Point2D(double x, double y)
    {
        X = x;
        Y = y;
    }

    public double DistanceTo(Point2D other)
    {
        double dx = X - other.X;
        double dy = Y - other.Y;
        return Math.Sqrt(dx * dx + dy * dy);
    }

    public override string ToString()
    {
        return $"({X:F2}, {Y:F2})";
    }
}

public class Point3D
{
    public double X { get; set; }
    public double Y { get; set; }
    public double Z { get; set; }

    public Point3D(double x, double y, double z)
    {
        X = x;
        Y = y;
        Z = z;
    }

    public double DistanceTo(Point3D other)
    {
        double dx = X - other.X;
        double dy = Y - other.Y;
        double dz = Z - other.Z;
        return Math.Sqrt(dx * dx + dy * dy + dz * dz);
    }

    public override string ToString()
    {
        return $"({X:F2}, {Y:F2}, {Z:F2})";
    }
}

public class KDTreeNode2D
{
    public Point2D Point { get; set; }
    public KDTreeNode2D Left { get; set; }
    public KDTreeNode2D Right { get; set; }

    public KDTreeNode2D(Point2D point)
    {
        Point = point;
    }
}

public class KDTree2D
{
    private KDTreeNode2D root;
    private int size;

    public int Size => size;
    public int Height => GetHeight(root);

    public void Insert(Point2D point)
    {
        root = InsertRecursive(root, point, 0);
        size++;
    }

    private KDTreeNode2D InsertRecursive(KDTreeNode2D node, Point2D point, int depth)
    {
        if (node == null)
            return new KDTreeNode2D(point);

        int axis = depth % 2;

        if (axis == 0) // Сравниваем по X
        {
            if (point.X < node.Point.X)
                node.Left = InsertRecursive(node.Left, point, depth + 1);
            else
                node.Right = InsertRecursive(node.Right, point, depth + 1);
        }
        else // Сравниваем по Y
        {
            if (point.Y < node.Point.Y)
                node.Left = InsertRecursive(node.Left, point, depth + 1);
            else
                node.Right = InsertRecursive(node.Right, point, depth + 1);
        }

        return node;
    }

    public bool Delete(Point2D point)
    {
        int initialSize = size;
        root = DeleteRecursive(root, point, 0);
        return size < initialSize;
    }

    private KDTreeNode2D DeleteRecursive(KDTreeNode2D node, Point2D point, int depth)
    {
        if (node == null)
            return null;

        if (node.Point.X == point.X && node.Point.Y == point.Y)
        {
            size--;
            if (node.Right != null)
            {
                var min = FindMin(node.Right, depth % 2, depth + 1);
                node.Point = min.Point;
                node.Right = DeleteRecursive(node.Right, min.Point, depth + 1);
            }
            else if (node.Left != null)
            {
                var min = FindMin(node.Left, depth % 2, depth + 1);
                node.Point = min.Point;
                node.Right = DeleteRecursive(node.Left, min.Point, depth + 1);
                node.Left = null;
            }
            else
            {
                return null;
            }
        }
        else
        {
            int axis = depth % 2;
            if (axis == 0)
            {
                if (point.X < node.Point.X)
                    node.Left = DeleteRecursive(node.Left, point, depth + 1);
                else
                    node.Right = DeleteRecursive(node.Right, point, depth + 1);
            }
            else
            {
                if (point.Y < node.Point.Y)
                    node.Left = DeleteRecursive(node.Left, point, depth + 1);
                else
                    node.Right = DeleteRecursive(node.Right, point, depth + 1);
            }
        }

        return node;
    }

    private KDTreeNode2D FindMin(KDTreeNode2D node, int axis, int depth)
    {
        if (node == null)
            return null;

        int currentAxis = depth % 2;

        if (currentAxis == axis)
        {
            if (node.Left == null)
                return node;
            return FindMin(node.Left, axis, depth + 1);
        }
        else
        {
            var leftMin = FindMin(node.Left, axis, depth + 1);
            var rightMin = FindMin(node.Right, axis, depth + 1);
            var min = node;

            if (leftMin != null && CompareByAxis(leftMin, min, axis) < 0)
                min = leftMin;
            if (rightMin != null && CompareByAxis(rightMin, min, axis) < 0)
                min = rightMin;

            return min;
        }
    }

    private int CompareByAxis(KDTreeNode2D a, KDTreeNode2D b, int axis)
    {
        if (axis == 0)
            return a.Point.X.CompareTo(b.Point.X);
        else
            return a.Point.Y.CompareTo(b.Point.Y);
    }

    public Point2D FindNearest(Point2D target)
    {
        if (root == null)
            return null;

        return FindNearestRecursive(root, target, 0, root).Point;
    }

    private KDTreeNode2D FindNearestRecursive(KDTreeNode2D node, Point2D target, int depth, KDTreeNode2D best)
    {
        if (node == null)
            return best;

        double currentDistance = node.Point.DistanceTo(target);
        double bestDistance = best.Point.DistanceTo(target);

        if (currentDistance < bestDistance)
            best = node;

        int axis = depth % 2;
        KDTreeNode2D goodSide, badSide;

        if (axis == 0)
        {
            if (target.X < node.Point.X)
            {
                goodSide = node.Left;
                badSide = node.Right;
            }
            else
            {
                goodSide = node.Right;
                badSide = node.Left;
            }
        }
        else
        {
            if (target.Y < node.Point.Y)
            {
                goodSide = node.Left;
                badSide = node.Right;
            }
            else
            {
                goodSide = node.Right;
                badSide = node.Left;
            }
        }

        best = FindNearestRecursive(goodSide, target, depth + 1, best);

        // Проверяем, нужно ли исследовать "плохую" сторону
        double axisDistance = axis == 0 ?
            Math.Abs(target.X - node.Point.X) :
            Math.Abs(target.Y - node.Point.Y);

        if (axisDistance < best.Point.DistanceTo(target))
        {
            best = FindNearestRecursive(badSide, target, depth + 1, best);
        }

        return best;
    }

    public List<Point2D> FindInRange(double minX, double maxX, double minY, double maxY)
    {
        var result = new List<Point2D>();
        FindInRangeRecursive(root, minX, maxX, minY, maxY, 0, result);
        return result;
    }

    private void FindInRangeRecursive(KDTreeNode2D node, double minX, double maxX, double minY, double maxY, int depth, List<Point2D> result)
    {
        if (node == null)
            return;

        Point2D point = node.Point;
        if (point.X >= minX && point.X <= maxX && point.Y >= minY && point.Y <= maxY)
        {
            result.Add(point);
        }

        int axis = depth % 2;

        if (axis == 0)
        {
            if (minX <= point.X)
                FindInRangeRecursive(node.Left, minX, maxX, minY, maxY, depth + 1, result);
            if (maxX >= point.X)
                FindInRangeRecursive(node.Right, minX, maxX, minY, maxY, depth + 1, result);
        }
        else
        {
            if (minY <= point.Y)
                FindInRangeRecursive(node.Left, minX, maxX, minY, maxY, depth + 1, result);
            if (maxY >= point.Y)
                FindInRangeRecursive(node.Right, minX, maxX, minY, maxY, depth + 1, result);
        }
    }

    private int GetHeight(KDTreeNode2D node)
    {
        if (node == null)
            return 0;

        return 1 + Math.Max(GetHeight(node.Left), GetHeight(node.Right));
    }
}

public class KDTree3D
{
    private class KDTreeNode3D
    {
        public Point3D Point { get; set; }
        public KDTreeNode3D Left { get; set; }
        public KDTreeNode3D Right { get; set; }

        public KDTreeNode3D(Point3D point)
        {
            Point = point;
        }
    }

    private KDTreeNode3D root;
    private int size;

    public int Size => size;

    public void Insert(Point3D point)
    {
        root = InsertRecursive(root, point, 0);
        size++;
    }

    private KDTreeNode3D InsertRecursive(KDTreeNode3D node, Point3D point, int depth)
    {
        if (node == null)
            return new KDTreeNode3D(point);

        int axis = depth % 3;

        if (axis == 0) // Сравниваем по X
        {
            if (point.X < node.Point.X)
                node.Left = InsertRecursive(node.Left, point, depth + 1);
            else
                node.Right = InsertRecursive(node.Right, point, depth + 1);
        }
        else if (axis == 1) // Сравниваем по Y
        {
            if (point.Y < node.Point.Y)
                node.Left = InsertRecursive(node.Left, point, depth + 1);
            else
                node.Right = InsertRecursive(node.Right, point, depth + 1);
        }
        else // Сравниваем по Z
        {
            if (point.Z < node.Point.Z)
                node.Left = InsertRecursive(node.Left, point, depth + 1);
            else
                node.Right = InsertRecursive(node.Right, point, depth + 1);
        }

        return node;
    }

    public Point3D FindNearest(Point3D target)
    {
        if (root == null)
            return null;

        return FindNearestRecursive(root, target, 0, root).Point;
    }

    private KDTreeNode3D FindNearestRecursive(KDTreeNode3D node, Point3D target, int depth, KDTreeNode3D best)
    {
        if (node == null)
            return best;

        double currentDistance = node.Point.DistanceTo(target);
        double bestDistance = best.Point.DistanceTo(target);

        if (currentDistance < bestDistance)
            best = node;

        int axis = depth % 3;
        KDTreeNode3D goodSide, badSide;

        if (axis == 0)
        {
            if (target.X < node.Point.X)
            {
                goodSide = node.Left;
                badSide = node.Right;
            }
            else
            {
                goodSide = node.Right;
                badSide = node.Left;
            }
        }
        else if (axis == 1)
        {
            if (target.Y < node.Point.Y)
            {
                goodSide = node.Left;
                badSide = node.Right;
            }
            else
            {
                goodSide = node.Right;
                badSide = node.Left;
            }
        }
        else
        {
            if (target.Z < node.Point.Z)
            {
                goodSide = node.Left;
                badSide = node.Right;
            }
            else
            {
                goodSide = node.Right;
                badSide = node.Left;
            }
        }

        best = FindNearestRecursive(goodSide, target, depth + 1, best);

        // Проверяем, нужно ли исследовать "плохую" сторону
        double axisDistance = axis == 0 ? Math.Abs(target.X - node.Point.X) :
                            axis == 1 ? Math.Abs(target.Y - node.Point.Y) :
                                        Math.Abs(target.Z - node.Point.Z);

        if (axisDistance < best.Point.DistanceTo(target))
        {
            best = FindNearestRecursive(badSide, target, depth + 1, best);
        }

        return best;
    }
}

public class KDTreeTester
{
    public static void TestKDTree()
    {
        Random random = new Random(42);
        int pointCount = 10000;

        Console.WriteLine("🎯 ТЕСТИРОВАНИЕ 2D K-D ДЕРЕВА");
        Console.WriteLine(new string('=', 50));

        // Тестирование 2D дерева
        var tree2D = new KDTree2D();
        var points2D = new List<Point2D>();

        // Генерация случайных 2D точек
        Console.WriteLine($"Генерация {pointCount:n0} случайных 2D точек...");
        for (int i = 0; i < pointCount; i++)
        {
            var point = new Point2D(random.NextDouble() * 1000, random.NextDouble() * 1000);
            points2D.Add(point);
            tree2D.Insert(point);
        }

        Console.WriteLine($"✅ Размер дерева: {tree2D.Size:n0}");
        Console.WriteLine($"✅ Высота дерева: {tree2D.Height}");

        // Тестирование поиска ближайшего соседа
        var testPoint2D = new Point2D(500, 500);

        Stopwatch sw1 = Stopwatch.StartNew();
        var nearestKD = tree2D.FindNearest(testPoint2D);
        sw1.Stop();

        Stopwatch sw2 = Stopwatch.StartNew();
        var nearestLinear = FindNearestLinear(points2D, testPoint2D);
        sw2.Stop();

        Console.WriteLine($"\n🔍 Поиск ближайшего соседа к точке {testPoint2D}:");
        Console.WriteLine($"   K-D дерево: {sw1.ElapsedMilliseconds} ms → {nearestKD}");
        Console.WriteLine($"   Линейный поиск: {sw2.ElapsedMilliseconds} ms → {nearestLinear}");
        Console.WriteLine($"   ⚡ Ускорение: {(double)sw2.ElapsedMilliseconds / sw1.ElapsedMilliseconds:F1}x");

        // Тестирование поиска в диапазоне
        var inRange = tree2D.FindInRange(400, 600, 400, 600);
        Console.WriteLine($"\n📊 Точек в диапазоне [400,600]x[400,600]: {inRange.Count}");

        // Тестирование удаления
        var pointToDelete = points2D[5000];
        bool deleted = tree2D.Delete(pointToDelete);
        Console.WriteLine($"\n🗑️ Удаление точки {pointToDelete}: {(deleted ? "УСПЕХ" : "НЕ УДАЛОСЬ")}");
        Console.WriteLine($"   Размер после удаления: {tree2D.Size:n0}");

        // Сравнение производительности для множественных запросов
        Console.WriteLine($"\n📈 Сравнение производительности для 1000 запросов:");
        TestMultipleQueries(tree2D, points2D, 1000);

        // Тестирование 3D дерева
        Console.WriteLine("\n\n🎯 ТЕСТИРОВАНИЕ 3D K-D ДЕРЕВА");
        Console.WriteLine(new string('=', 50));
        Test3DTree(5000);
    }

    private static Point2D FindNearestLinear(List<Point2D> points, Point2D target)
    {
        Point2D nearest = null;
        double minDistance = double.MaxValue;

        foreach (var point in points)
        {
            double distance = point.DistanceTo(target);
            if (distance < minDistance)
            {
                minDistance = distance;
                nearest = point;
            }
        }

        return nearest;
    }

    private static void TestMultipleQueries(KDTree2D tree, List<Point2D> points, int queryCount)
    {
        Random random = new Random(42);

        // Тестирование K-D дерева
        Stopwatch sw1 = Stopwatch.StartNew();
        for (int i = 0; i < queryCount; i++)
        {
            var queryPoint = new Point2D(random.NextDouble() * 1000, random.NextDouble() * 1000);
            tree.FindNearest(queryPoint);
        }
        sw1.Stop();

        // Тестирование линейного поиска
        Stopwatch sw2 = Stopwatch.StartNew();
        for (int i = 0; i < queryCount; i++)
        {
            var queryPoint = new Point2D(random.NextDouble() * 1000, random.NextDouble() * 1000);
            FindNearestLinear(points, queryPoint);
        }
        sw2.Stop();

        Console.WriteLine($"   K-D дерево: {sw1.ElapsedMilliseconds} ms");
        Console.WriteLine($"   Линейный поиск: {sw2.ElapsedMilliseconds} ms");
        Console.WriteLine($"   ⚡ Общее ускорение: {(double)sw2.ElapsedMilliseconds / sw1.ElapsedMilliseconds:F1}x");
    }

    private static void Test3DTree(int pointCount)
    {
        Random random = new Random(42);
        var tree3D = new KDTree3D();
        var points3D = new List<Point3D>();

        Console.WriteLine($"Генерация {pointCount:n0} случайных 3D точек...");
        for (int i = 0; i < pointCount; i++)
        {
            var point = new Point3D(
                random.NextDouble() * 1000,
                random.NextDouble() * 1000,
                random.NextDouble() * 1000
            );
            points3D.Add(point);
            tree3D.Insert(point);
        }

        Console.WriteLine($"✅ Размер 3D дерева: {tree3D.Size:n0}");

        var testPoint3D = new Point3D(500, 500, 500);

        Stopwatch sw1 = Stopwatch.StartNew();
        var nearest3D = tree3D.FindNearest(testPoint3D);
        sw1.Stop();

        Console.WriteLine($"🔍 Ближайшая 3D точка к {testPoint3D}:");
        Console.WriteLine($"   Результат: {nearest3D}");
        Console.WriteLine($"   Время поиска: {sw1.ElapsedMilliseconds} ms");

        Console.WriteLine($"\n💡 ВЫВОД: K-D дерево эффективно для пространственного поиска,");
        Console.WriteLine($"          особенно при множественных запросах и больших данных");
    }
}
