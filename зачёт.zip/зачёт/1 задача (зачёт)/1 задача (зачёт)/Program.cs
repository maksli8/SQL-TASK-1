﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("=== ЗАДАЧА 1: СИСТЕМА ПОИСКА ПОДСТРОК ===");
        Console.WriteLine("Реализация 3 алгоритмов поиска подстроки\n");

        SubstringSearchTester.TestAlgorithms();

        Console.WriteLine("\nНажмите любую клавишу для выхода...");
        Console.ReadKey();
    }
}

public class SubstringSearch
{
    public static (int index, int comparisons) NaiveSearch(string text, string pattern)
    {
        int comparisons = 0;
        int n = text.Length;
        int m = pattern.Length;

        for (int i = 0; i <= n - m; i++)
        {
            int j;
            for (j = 0; j < m; j++)
            {
                comparisons++;
                if (text[i + j] != pattern[j])
                    break;
            }
            if (j == m)
                return (i, comparisons);
        }
        return (-1, comparisons);
    }

    public static (int index, int comparisons) BoyerMooreSearch(string text, string pattern)
    {
        int comparisons = 0;
        int n = text.Length;
        int m = pattern.Length;

        if (m == 0) return (0, 0);

        // Таблица плохих символов
        Dictionary<char, int> badChar = new Dictionary<char, int>();
        for (int i = 0; i < m; i++)
        {
            badChar[pattern[i]] = i;
        }

        int s = 0;
        while (s <= n - m)
        {
            int j = m - 1;

            while (j >= 0 && pattern[j] == text[s + j])
            {
                comparisons++;
                j--;
            }

            if (j < 0)
            {
                return (s, comparisons);
            }
            else
            {
                comparisons++;
                char badCharValue = text[s + j];
                int shift = badChar.ContainsKey(badCharValue) ? badChar[badCharValue] : -1;
                s += Math.Max(1, j - shift);
            }
        }

        return (-1, comparisons);
    }

    public static (int index, int comparisons) KMPSearch(string text, string pattern)
    {
        int comparisons = 0;
        int n = text.Length;
        int m = pattern.Length;

        if (m == 0) return (0, 0);

        // Префикс-функция
        int[] lps = new int[m];
        int len = 0;
        int i = 1;

        while (i < m)
        {
            comparisons++;
            if (pattern[i] == pattern[len])
            {
                len++;
                lps[i] = len;
                i++;
            }
            else
            {
                if (len != 0)
                {
                    len = lps[len - 1];
                }
                else
                {
                    lps[i] = 0;
                    i++;
                }
            }
        }

        // Поиск
        i = 0;
        int j = 0;
        while (i < n)
        {
            comparisons++;
            if (pattern[j] == text[i])
            {
                j++;
                i++;
            }

            if (j == m)
            {
                return (i - j, comparisons);
            }
            else if (i < n && pattern[j] != text[i])
            {
                if (j != 0)
                    j = lps[j - 1];
                else
                    i++;
            }
        }

        return (-1, comparisons);
    }
}

public class SubstringSearchTester
{
    public static void TestAlgorithms()
    {
        string[] sizes = { "1KB", "10KB", "100KB", "1MB" };
        int[] sizeBytes = { 1024, 10240, 102400, 1048576 };

        string[] patternTypes = { "Короткий", "Средний", "Длинный" };
        int[] shortPatterns = { 3, 5 };
        int[] mediumPatterns = { 20, 35 };
        int[] longPatterns = { 100, 200 };

        Random random = new Random(42);

        foreach (var size in sizeBytes.Zip(sizes, (bytes, name) => new { bytes, name }))
        {
            Console.WriteLine($"\n📊 ТЕСТ: Размер текста = {size.name} ===");

            // Генерация текста
            string text = GenerateRandomText(size.bytes, random);

            foreach (var patternType in patternTypes)
            {
                Console.WriteLine($"\n🔍 Тип паттерна: {patternType}");

                int[] patternLengths = patternType switch
                {
                    "Короткий" => shortPatterns,
                    "Средний" => mediumPatterns,
                    "Длинный" => longPatterns,
                    _ => shortPatterns
                };

                foreach (int patternLength in patternLengths)
                {
                    string pattern = GenerateRandomText(patternLength, random);

                    Console.WriteLine($"\n   Длина паттерна: {patternLength} символов");

                    // Наивный алгоритм
                    var (naiveIndex, naiveComparisons) = SubstringSearch.NaiveSearch(text, pattern);
                    Console.WriteLine($"   ✅ Наивный алгоритм: {naiveComparisons} сравнений");

                    // Бойер-Мур
                    var (bmIndex, bmComparisons) = SubstringSearch.BoyerMooreSearch(text, pattern);
                    Console.WriteLine($"   ✅ Бойер-Мур: {bmComparisons} сравнений");

                    // КМП
                    var (kmpIndex, kmpComparisons) = SubstringSearch.KMPSearch(text, pattern);
                    Console.WriteLine($"   ✅ Кнута-Морриса-Пратта: {kmpComparisons} сравнений");

                    // Сравнение эффективности
                    Console.WriteLine($"   📈 Эффективность: Бойер-Мур в {(double)naiveComparisons / bmComparisons:F1}x лучше наивного");
                }
            }
        }

        // Демонстрационный пример
        Console.WriteLine("\n" + new string('=', 50));
        Console.WriteLine("🎯 ДЕМОНСТРАЦИОННЫЙ ПРИМЕР:");
        string demoText = "ABABDABACDABABCABAB";
        string demoPattern = "ABABCABAB";

        Console.WriteLine($"Текст: {demoText}");
        Console.WriteLine($"Паттерн: {demoPattern}");

        var (_, naiveComp) = SubstringSearch.NaiveSearch(demoText, demoPattern);
        var (_, bmComp) = SubstringSearch.BoyerMooreSearch(demoText, demoPattern);
        var (_, kmpComp) = SubstringSearch.KMPSearch(demoText, demoPattern);

        Console.WriteLine($"\nСравнения символов:");
        Console.WriteLine($"• Наивный: {naiveComp}");
        Console.WriteLine($"• Бойер-Мур: {bmComp}");
        Console.WriteLine($"• КМП: {kmpComp}");
    }

    private static string GenerateRandomText(int length, Random random)
    {
        const string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ";
        StringBuilder sb = new StringBuilder(length);

        for (int i = 0; i < length; i++)
        {
            sb.Append(chars[random.Next(chars.Length)]);
        }

        return sb.ToString();
    }
}