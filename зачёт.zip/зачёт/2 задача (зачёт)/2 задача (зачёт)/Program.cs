﻿using System;
using System.Diagnostics;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("=== ЗАДАЧА 2: ПОИСК K-ГО НАИМЕНЬШЕГО ЭЛЕМЕНТА ===");
        Console.WriteLine("Реализация 3 алгоритмов поиска k-го элемента\n");

        KthSmallestTester.TestAlgorithms();

        Console.WriteLine("\nНажмите любую клавишу для выхода...");
        Console.ReadKey();
    }
}

public class KthSmallest
{
    // Метод 1: Сортировка + индекс
    public static int SortMethod(int[] arr, int k)
    {
        int[] sorted = arr.ToArray();
        Array.Sort(sorted);
        return sorted[k - 1];
    }

    // Метод 2: QuickSelect
    public static int QuickSelect(int[] arr, int k)
    {
        int[] copy = arr.ToArray();
        return QuickSelectRecursive(copy, 0, copy.Length - 1, k - 1);
    }

    private static int QuickSelectRecursive(int[] arr, int left, int right, int k)
    {
        if (left == right) return arr[left];

        int pivotIndex = Partition(arr, left, right);

        if (k == pivotIndex)
            return arr[k];
        else if (k < pivotIndex)
            return QuickSelectRecursive(arr, left, pivotIndex - 1, k);
        else
            return QuickSelectRecursive(arr, pivotIndex + 1, right, k);
    }

    private static int Partition(int[] arr, int left, int right)
    {
        Random random = new Random();
        int pivotIndex = random.Next(left, right + 1);
        int pivotValue = arr[pivotIndex];

        Swap(arr, pivotIndex, right);

        int storeIndex = left;
        for (int i = left; i < right; i++)
        {
            if (arr[i] < pivotValue)
            {
                Swap(arr, i, storeIndex);
                storeIndex++;
            }
        }

        Swap(arr, storeIndex, right);
        return storeIndex;
    }

    private static void Swap(int[] arr, int i, int j)
    {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    // Метод 3: Медиана медиан (упрощенная и исправленная версия)
    public static int MedianOfMedians(int[] arr, int k)
    {
        int[] copy = arr.ToArray();
        return MedianOfMediansRecursive(copy, 0, copy.Length - 1, k - 1);
    }

    private static int MedianOfMediansRecursive(int[] arr, int left, int right, int k)
    {
        if (left == right)
            return arr[left];

        // Находим хороший опорный элемент через медиану медиан
        int pivotValue = GetMedianOfMedians(arr, left, right);

        // Разбиваем массив относительно опорного элемента
        int pivotIndex = PartitionAroundPivot(arr, left, right, pivotValue);

        if (k == pivotIndex)
            return arr[k];
        else if (k < pivotIndex)
            return MedianOfMediansRecursive(arr, left, pivotIndex - 1, k);
        else
            return MedianOfMediansRecursive(arr, pivotIndex + 1, right, k);
    }

    private static int GetMedianOfMedians(int[] arr, int left, int right)
    {
        int n = right - left + 1;

        // Если элементов меньше 5, просто возвращаем медиану
        if (n <= 5)
        {
            return GetMedianOfSmallArray(arr, left, right);
        }

        // Разбиваем на группы по 5 элементов и находим медианы
        int numMedians = (n + 4) / 5;
        int[] medians = new int[numMedians];

        for (int i = 0; i < numMedians; i++)
        {
            int groupLeft = left + i * 5;
            int groupRight = Math.Min(groupLeft + 4, right);
            medians[i] = GetMedianOfSmallArray(arr, groupLeft, groupRight);
        }

        // Рекурсивно находим медиану медиан
        return MedianOfMediansRecursive(medians, 0, numMedians - 1, numMedians / 2);
    }

    private static int GetMedianOfSmallArray(int[] arr, int left, int right)
    {
        // Простая сортировка вставками для маленького массива
        for (int i = left + 1; i <= right; i++)
        {
            int key = arr[i];
            int j = i - 1;

            while (j >= left && arr[j] > key)
            {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }

        // Возвращаем медиану
        return arr[left + (right - left) / 2];
    }

    private static int PartitionAroundPivot(int[] arr, int left, int right, int pivotValue)
    {
        // Находим индекс опорного элемента
        int pivotIndex = left;
        for (int i = left; i <= right; i++)
        {
            if (arr[i] == pivotValue)
            {
                pivotIndex = i;
                break;
            }
        }

        // Перемещаем опорный элемент в конец
        Swap(arr, pivotIndex, right);

        // Стандартное разбиение
        int storeIndex = left;
        for (int i = left; i < right; i++)
        {
            if (arr[i] < pivotValue)
            {
                Swap(arr, i, storeIndex);
                storeIndex++;
            }
        }

        // Возвращаем опорный элемент на правильную позицию
        Swap(arr, storeIndex, right);
        return storeIndex;
    }
}

public class KthSmallestTester
{
    public static void TestAlgorithms()
    {
        int n = 100000; // 100,000 элементов
        int[] testValues = { 10, 1000, 10000, 50000, 90000 };

        Random random = new Random(42);
        int[] arr = new int[n];

        // Заполняем массив случайными числами
        Console.WriteLine($"Создание массива из {n:n0} элементов...");
        for (int i = 0; i < n; i++)
        {
            arr[i] = random.Next(0, n * 10);
        }

        // Создаем копии для каждого алгоритма
        int[] arr1 = arr.ToArray();
        int[] arr2 = arr.ToArray();
        int[] arr3 = arr.ToArray();

        Console.WriteLine("\n📊 РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ:");
        Console.WriteLine("k\t\tSort (ms)\tQuickSelect (ms)\tMedianOfMedians (ms)");
        Console.WriteLine(new string('-', 80));

        foreach (int k in testValues)
        {
            Console.Write($"{k,8}");

            try
            {
                // Тестируем Sort метод
                Stopwatch sw1 = Stopwatch.StartNew();
                int result1 = KthSmallest.SortMethod(arr1, k);
                sw1.Stop();
                Console.Write($"\t{sw1.ElapsedMilliseconds,10}");

                // Тестируем QuickSelect
                Stopwatch sw2 = Stopwatch.StartNew();
                int result2 = KthSmallest.QuickSelect(arr2, k);
                sw2.Stop();
                Console.Write($"\t{sw2.ElapsedMilliseconds,15}");

                // Тестируем MedianOfMedians
                Stopwatch sw3 = Stopwatch.StartNew();
                int result3 = KthSmallest.MedianOfMedians(arr3, k);
                sw3.Stop();
                Console.Write($"\t{sw3.ElapsedMilliseconds,18}");

                // Проверяем корректность
                if (result1 != result2 || result2 != result3)
                {
                    Console.Write(" ⚠️ Результаты различаются");
                }
                else
                {
                    Console.Write($" ✅ k-й = {result1}");
                }
            }
            catch (Exception ex)
            {
                Console.Write($" ❌ Ошибка: {ex.Message}");
            }

            Console.WriteLine();

            // Восстанавливаем массивы для следующего теста
            Array.Copy(arr, arr1, n);
            Array.Copy(arr, arr2, n);
            Array.Copy(arr, arr3, n);
        }

        // Тестирование худшего случая
        TestWorstCase();

        // Анализ производительности
        Console.WriteLine("\n📈 АНАЛИЗ ПРОИЗВОДИТЕЛЬНОСТИ:");
        Console.WriteLine("• Sort: O(n log n) - стабильная производительность");
        Console.WriteLine("• QuickSelect: O(n) в среднем, O(n²) в худшем случае");
        Console.WriteLine("• MedianOfMedians: O(n) гарантированно, но с большей константой");
    }

    private static void TestWorstCase()
    {
        Console.WriteLine("\n🔥 ТЕСТИРОВАНИЕ ХУДШЕГО СЛУЧАЯ (отсортированный массив):");

        int size = 50000;
        int[] worstCaseArray = new int[size];
        for (int i = 0; i < size; i++)
        {
            worstCaseArray[i] = i; // Отсортированный массив - худший случай для QuickSelect
        }

        int k = size / 2;

        try
        {
            Stopwatch sw1 = Stopwatch.StartNew();
            int result1 = KthSmallest.QuickSelect(worstCaseArray.ToArray(), k);
            sw1.Stop();

            Stopwatch sw2 = Stopwatch.StartNew();
            int result2 = KthSmallest.MedianOfMedians(worstCaseArray.ToArray(), k);
            sw2.Stop();

            Console.WriteLine($"QuickSelect в худшем случае: {sw1.ElapsedMilliseconds} ms");
            Console.WriteLine($"MedianOfMedians в худшем случае: {sw2.ElapsedMilliseconds} ms");

            if (result1 == result2)
            {
                Console.WriteLine($"Оба метода нашли правильный элемент: {result1}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при тестировании худшего случая: {ex.Message}");
        }
    }
}