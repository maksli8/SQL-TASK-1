﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace DataRelationTasks
{
    class Program
    {
        static DataSet dataSet = new DataSet("MainDataSet");

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== ПРАКТИЧЕСКИЕ ЗАДАНИЯ ПО DATARELATION В ADO.NET ===");
                Console.WriteLine("Выберите задание (1-20) или 0 для выхода:");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    if (choice == 0) break;

                    Console.Clear();
                    Console.WriteLine($"=== ЗАДАНИЕ {choice} ===");

                    try
                    {
                        ExecuteTask(choice);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Ошибка: {ex.Message}");
                        Console.WriteLine(ex.StackTrace);
                    }

                    Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                    Console.ReadKey();
                }
            }
        }

        static void ExecuteTask(int taskNumber)
        {
            switch (taskNumber)
            {
                case 1: Task1(); break;
                case 2: Task2(); break;
                case 3: Task3(); break;
                case 4: Task4(); break;
                case 5: Task5(); break;
                case 6: Task6(); break;
                case 7: Task7(); break;
                case 8: Task8(); break;
                case 9: Task9(); break;
                case 10: Task10(); break;
                case 11: Task11(); break;
                case 12: Task12(); break;
                case 13: Task13(); break;
                case 14: Task14(); break;
                case 15: Task15(); break;
                case 16: Task16(); break;
                case 17: Task17(); break;
                case 18: Task18(); break;
                case 19: Task19(); break;
                case 20: Task20(); break;
                default:
                    Console.WriteLine("Неверный номер задания");
                    break;
            }
        }

        // === ЗАДАНИЕ 1 ===
        static void Task1()
        {
            Console.WriteLine("Создание простого отношения DataRelation между двумя таблицами");

            // Создаем таблицы
            DataTable categories = CreateCategoriesTable();
            DataTable products = CreateProductsTable();

            // Добавляем тестовые данные
            FillCategoriesTable(categories);
            FillProductsTable(products);

            // Создаем DataSet и добавляем таблицы
            dataSet = new DataSet("StoreDB");
            dataSet.Tables.Add(categories);
            dataSet.Tables.Add(products);

            // Создаем отношение
            try
            {
                DataRelation relation = new DataRelation(
                    "CategoryProducts",
                    categories.Columns["CategoryID"],
                    products.Columns["CategoryID"],
                    true); // createConstraints = true

                dataSet.Relations.Add(relation);

                // Выводим информацию об отношении
                Console.WriteLine("\n=== ИНФОРМАЦИЯ ОБ ОТНОШЕНИИ ===");
                Console.WriteLine($"Имя: {relation.RelationName}");
                Console.WriteLine($"Родительская таблица: {relation.ParentTable.TableName}");
                Console.WriteLine($"Дочерняя таблица: {relation.ChildTable.TableName}");
                Console.WriteLine($"Родительская колонка: {relation.ParentColumns[0].ColumnName}");
                Console.WriteLine($"Дочерняя колонка: {relation.ChildColumns[0].ColumnName}");
                Console.WriteLine($"Уникальное ограничение: {relation.ChildKeyConstraint.ConstraintName}");

                // Выводим иерархическую структуру
                Console.WriteLine("\n=== ИЕРАРХИЧЕСКАЯ СТРУКТУРА ===");
                PrintCategoryProductsHierarchy(categories, relation);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при создании отношения: {ex.Message}");
            }
        }

        // === ЗАДАНИЕ 2 ===
        static void Task2()
        {
            Console.WriteLine("Получение дочерних строк с помощью GetChildRows()");

            // Используем таблицы из задания 1
            if (!dataSet.Tables.Contains("Categories") || !dataSet.Tables.Contains("Products"))
            {
                Console.WriteLine("Сначала выполните задание 1 для создания таблиц!");
                return;
            }

            DataTable categories = dataSet.Tables["Categories"];
            DataTable products = dataSet.Tables["Products"];
            DataRelation relation = dataSet.Relations["CategoryProducts"];

            // 1. Для каждой категории получаем все связанные товары
            Console.WriteLine("\n=== ТОВАРЫ ПО КАТЕГОРИЯМ ===");
            foreach (DataRow category in categories.Rows)
            {
                Console.WriteLine($"\nКатегория: {category["CategoryName"]}");
                DataRow[] childProducts = category.GetChildRows(relation);

                if (childProducts.Length == 0)
                {
                    Console.WriteLine("  Нет товаров");
                }
                else
                {
                    Console.WriteLine("  ID   | Наименование          | Цена");
                    Console.WriteLine("  -----|----------------------|-------");
                    foreach (DataRow product in childProducts)
                    {
                        Console.WriteLine($"  {product["ProductID"],-4} | {product["ProductName"],-20} | {product["Price"],6:C}");
                    }
                }
            }

            // 2. Подсчет количества товаров в каждой категории
            Console.WriteLine("\n=== СТАТИСТИКА ПО КАТЕГОРИЯМ ===");
            Console.WriteLine("Категория          | Кол-во товаров | Общая стоимость");
            Console.WriteLine("-------------------|----------------|----------------");

            foreach (DataRow category in categories.Rows)
            {
                DataRow[] childProducts = category.GetChildRows(relation);
                int count = childProducts.Length;
                decimal totalValue = 0;

                foreach (DataRow product in childProducts)
                {
                    if (product["Price"] != DBNull.Value)
                    {
                        totalValue += Convert.ToDecimal(product["Price"]);
                    }
                }

                Console.WriteLine($"{category["CategoryName"],-18} | {count,14} | {totalValue,14:C}");
            }

            // 3. Фильтр по цене
            Console.Write("\nВведите минимальную цену для фильтрации: ");
            if (decimal.TryParse(Console.ReadLine(), out decimal minPrice))
            {
                Console.WriteLine($"\n=== КАТЕГОРИИ С ТОВАРАМИ ДОРОЖЕ {minPrice:C} ===");

                foreach (DataRow category in categories.Rows)
                {
                    DataRow[] childProducts = category.GetChildRows(relation);
                    bool hasExpensiveProducts = false;

                    foreach (DataRow product in childProducts)
                    {
                        if (product["Price"] != DBNull.Value &&
                            Convert.ToDecimal(product["Price"]) > minPrice)
                        {
                            hasExpensiveProducts = true;
                            break;
                        }
                    }

                    if (hasExpensiveProducts)
                    {
                        Console.WriteLine($"Категория: {category["CategoryName"]}");
                        foreach (DataRow product in childProducts)
                        {
                            if (product["Price"] != DBNull.Value &&
                                Convert.ToDecimal(product["Price"]) > minPrice)
                            {
                                Console.WriteLine($"  - {product["ProductName"]}: {Convert.ToDecimal(product["Price"]):C}");
                            }
                        }
                    }
                }
            }
        }

        // === ЗАДАНИЕ 3 ===
        static void Task3()
        {
            Console.WriteLine("Получение родительских строк с помощью GetParentRows()");

            if (!dataSet.Tables.Contains("Products"))
            {
                Console.WriteLine("Сначала выполните задание 1 для создания таблиц!");
                return;
            }

            DataTable products = dataSet.Tables["Products"];
            DataRelation relation = dataSet.Relations["CategoryProducts"];

            // 1. Вывод информации о товарах с их категориями
            Console.WriteLine("\n=== ТОВАРЫ С КАТЕГОРИЯМИ ===");
            Console.WriteLine("ID  | Наименование товара    | Категория         | Описание категории");
            Console.WriteLine("----|------------------------|-------------------|--------------------");

            foreach (DataRow product in products.Rows)
            {
                DataRow[] parentCategories = product.GetParentRows(relation);

                if (parentCategories.Length > 0)
                {
                    DataRow category = parentCategories[0];
                    Console.WriteLine($"{product["ProductID"],-3} | {product["ProductName"],-23} | {category["CategoryName"],-17} | {category["Description"]}");
                }
                else
                {
                    Console.WriteLine($"{product["ProductID"],-3} | {product["ProductName"],-23} | НЕТ КАТЕГОРИИ      | ");
                }
            }

            // 2. Поиск товара по ID
            Console.Write("\nВведите ID товара для поиска: ");
            if (int.TryParse(Console.ReadLine(), out int productId))
            {
                DataRow[] foundProducts = products.Select($"ProductID = {productId}");

                if (foundProducts.Length > 0)
                {
                    DataRow product = foundProducts[0];
                    DataRow[] parentCategories = product.GetParentRows(relation);

                    Console.WriteLine("\n=== РЕЗУЛЬТАТ ПОИСКА ===");
                    Console.WriteLine($"Товар: {product["ProductName"]}");
                    Console.WriteLine($"Цена: {product["Price"]:C}");

                    if (parentCategories.Length > 0)
                    {
                        DataRow category = parentCategories[0];
                        Console.WriteLine($"Категория: {category["CategoryName"]}");
                        Console.WriteLine($"Описание: {category["Description"]}");
                    }
                    else
                    {
                        Console.WriteLine("Категория: НЕ НАЗНАЧЕНА");
                    }
                }
                else
                {
                    Console.WriteLine("Товар не найден!");
                }
            }

            // 3. Проверка на orphaned records (товары без категории)
            Console.WriteLine("\n=== ПРОВЕРКА ССЫЛОЧНОЙ ЦЕЛОСТНОСТИ ===");
            int orphanedCount = 0;

            foreach (DataRow product in products.Rows)
            {
                DataRow[] parentCategories = product.GetParentRows(relation);
                if (parentCategories.Length == 0)
                {
                    orphanedCount++;
                    Console.WriteLine($"Товар без категории: ID={product["ProductID"]}, '{product["ProductName"]}'");
                }
            }

            if (orphanedCount == 0)
            {
                Console.WriteLine("Нарушений не найдено.");
            }
        }

        // === ЗАДАНИЕ 4 ===
        static void Task4()
        {
            Console.WriteLine("Создание отношения 'сам к себе' для иерархических данных");

            // Создаем таблицу сотрудников
            DataTable employees = CreateEmployeesTable();
            dataSet.Tables.Add(employees);

            // Заполняем тестовыми данными
            FillEmployeesTable(employees);

            // Создаем самоссылающееся отношение
            DataRelation selfRelation = new DataRelation(
                "EmployeeManager",
                employees.Columns["EmployeeID"],
                employees.Columns["ManagerID"],
                false);

            dataSet.Relations.Add(selfRelation);

            // Выводим иерархию сотрудников
            Console.WriteLine("\n=== ИЕРАРХИЯ СОТРУДНИКОВ ===");
            PrintEmployeeHierarchy(employees, selfRelation, 0);

            // Подсчет глубины иерархии для каждого сотрудника
            Console.WriteLine("\n=== ГЛУБИНА ИЕРАРХИИ ===");
            foreach (DataRow employee in employees.Rows)
            {
                int level = CalculateHierarchyLevel(employee, selfRelation);
                Console.WriteLine($"{employee["EmployeeName"]}: уровень {level}");
            }
        }

        // === ЗАДАНИЕ 5 ===
        static void Task5()
        {
            Console.WriteLine("Получение данных из отношения 'сам к себе' с фильтрацией");

            if (!dataSet.Tables.Contains("Employees"))
            {
                Console.WriteLine("Сначала выполните задание 4 для создания таблицы сотрудников!");
                return;
            }

            DataTable employees = dataSet.Tables["Employees"];
            DataRelation selfRelation = dataSet.Relations["EmployeeManager"];

            // 1. Поиск всех подчиненных конкретного менеджера
            Console.Write("\nВведите ID менеджера для поиска подчиненных: ");
            if (int.TryParse(Console.ReadLine(), out int managerId))
            {
                DataRow[] managerRows = employees.Select($"EmployeeID = {managerId}");

                if (managerRows.Length > 0)
                {
                    Console.WriteLine($"\nПодчиненные менеджера {managerRows[0]["EmployeeName"]}:");
                    DataRow[] subordinates = managerRows[0].GetChildRows(selfRelation);

                    if (subordinates.Length == 0)
                    {
                        Console.WriteLine("Нет прямых подчиненных");
                    }
                    else
                    {
                        foreach (DataRow subordinate in subordinates)
                        {
                            Console.WriteLine($"- {subordinate["EmployeeName"]} ({subordinate["Department"]})");
                        }
                    }
                }
            }

            // 2. Получение цепочки руководства для сотрудника
            Console.Write("\nВведите ID сотрудника для получения цепочки руководства: ");
            if (int.TryParse(Console.ReadLine(), out int employeeId))
            {
                DataRow[] employeeRows = employees.Select($"EmployeeID = {employeeId}");

                if (employeeRows.Length > 0)
                {
                    Console.WriteLine($"\nЦепочка руководства для {employeeRows[0]["EmployeeName"]}:");
                    PrintManagementChain(employeeRows[0], selfRelation);
                }
            }

            // 3. Статистика по иерархии
            Console.WriteLine("\n=== СТАТИСТИКА ПО ИЕРАРХИИ ===");

            Dictionary<int, int> levelDistribution = new Dictionary<int, int>();
            int maxLevel = 0;

            foreach (DataRow employee in employees.Rows)
            {
                int level = CalculateHierarchyLevel(employee, selfRelation);

                if (levelDistribution.ContainsKey(level))
                    levelDistribution[level]++;
                else
                    levelDistribution[level] = 1;

                if (level > maxLevel) maxLevel = level;
            }

            Console.WriteLine($"Максимальная глубина иерархии: {maxLevel}");
            Console.WriteLine("\nРаспределение сотрудников по уровням:");
            foreach (var kvp in levelDistribution.OrderBy(k => k.Key))
            {
                Console.WriteLine($"Уровень {kvp.Key}: {kvp.Value} сотрудников");
            }
        }

        // === ЗАДАНИЕ 6 ===
        static void Task6()
        {
            Console.WriteLine("Реализация отношения многие-ко-многим через промежуточную таблицу");

            // Создаем таблицы
            DataTable students = CreateStudentsTable();
            DataTable courses = CreateCoursesTable();
            DataTable registrations = CreateRegistrationsTable();

            // Заполняем данными
            FillStudentsTable(students);
            FillCoursesTable(courses);
            FillRegistrationsTable(registrations, students, courses);

            // Создаем DataSet
            dataSet = new DataSet("UniversityDB");
            dataSet.Tables.Add(students);
            dataSet.Tables.Add(courses);
            dataSet.Tables.Add(registrations);

            // Создаем отношения
            DataRelation studentRegRelation = new DataRelation(
                "StudentRegistrations",
                students.Columns["StudentID"],
                registrations.Columns["StudentID"],
                true);

            DataRelation courseRegRelation = new DataRelation(
                "CourseRegistrations",
                courses.Columns["CourseID"],
                registrations.Columns["CourseID"],
                true);

            dataSet.Relations.Add(studentRegRelation);
            dataSet.Relations.Add(courseRegRelation);

            // 1. Курсы для конкретного студента
            Console.WriteLine("\n=== КУРСЫ ПО СТУДЕНТАМ ===");
            foreach (DataRow student in students.Rows)
            {
                Console.WriteLine($"\nСтудент: {student["StudentName"]}");
                DataRow[] regs = student.GetChildRows(studentRegRelation);

                if (regs.Length == 0)
                {
                    Console.WriteLine("  Не записан на курсы");
                }
                else
                {
                    foreach (DataRow reg in regs)
                    {
                        DataRow[] courseRows = reg.GetParentRows(courseRegRelation);
                        if (courseRows.Length > 0)
                        {
                            Console.WriteLine($"  - {courseRows[0]["CourseName"]} ({reg["EnrollmentDate"]:d})");
                        }
                    }
                }
            }

            // 2. Статистика
            Console.WriteLine("\n=== СТАТИСТИКА ===");
            Console.WriteLine("Курс              | Кол-во студентов");
            Console.WriteLine("------------------|-----------------");

            foreach (DataRow course in courses.Rows)
            {
                DataRow[] regs = course.GetChildRows(courseRegRelation);
                Console.WriteLine($"{course["CourseName"],-17} | {regs.Length,15}");
            }
        }

        // === ЗАДАНИЕ 7 ===
        static void Task7()
        {
            Console.WriteLine("Навигация по отношению многие-ко-многим в обе стороны");

            if (!dataSet.Tables.Contains("Students") ||
                !dataSet.Tables.Contains("Courses") ||
                !dataSet.Tables.Contains("Registrations"))
            {
                Console.WriteLine("Сначала выполните задание 6!");
                return;
            }

            DataTable students = dataSet.Tables["Students"];
            DataTable courses = dataSet.Tables["Courses"];
            DataTable registrations = dataSet.Tables["Registrations"];

            DataRelation studentRegRelation = dataSet.Relations["StudentRegistrations"];
            DataRelation courseRegRelation = dataSet.Relations["CourseRegistrations"];

            // 1. Полная информация о студентах и их оценках
            Console.WriteLine("\n=== СТУДЕНТЫ С ОЦЕНКАМИ ===");
            foreach (DataRow student in students.Rows)
            {
                Console.WriteLine($"\nСтудент: {student["StudentName"]}");
                DataRow[] regs = student.GetChildRows(studentRegRelation);

                if (regs.Length == 0)
                {
                    Console.WriteLine("  Нет записей на курсы");
                }
                else
                {
                    decimal totalGrade = 0;
                    int gradeCount = 0;

                    foreach (DataRow reg in regs)
                    {
                        DataRow[] courseRows = reg.GetParentRows(courseRegRelation);
                        if (courseRows.Length > 0)
                        {
                            string grade = reg["Grade"] != DBNull.Value ? reg["Grade"].ToString() : "нет оценки";
                            Console.WriteLine($"  - {courseRows[0]["CourseName"]}: {grade}");

                            if (reg["Grade"] != DBNull.Value)
                            {
                                totalGrade += Convert.ToDecimal(reg["Grade"]);
                                gradeCount++;
                            }
                        }
                    }

                    if (gradeCount > 0)
                    {
                        Console.WriteLine($"  Средний балл: {totalGrade / gradeCount:F2}");
                    }
                }
            }

            // 2. Лучшие студенты
            Console.WriteLine("\n=== ЛУЧШИЕ СТУДЕНТЫ (средний балл > 4.5) ===");
            foreach (DataRow student in students.Rows)
            {
                DataRow[] regs = student.GetChildRows(studentRegRelation);
                decimal totalGrade = 0;
                int gradeCount = 0;

                foreach (DataRow reg in regs)
                {
                    if (reg["Grade"] != DBNull.Value)
                    {
                        totalGrade += Convert.ToDecimal(reg["Grade"]);
                        gradeCount++;
                    }
                }

                if (gradeCount > 0)
                {
                    decimal avgGrade = totalGrade / gradeCount;
                    if (avgGrade > 4.5m)
                    {
                        Console.WriteLine($"\n{student["StudentName"]}: средний балл {avgGrade:F2}");
                        foreach (DataRow reg in regs)
                        {
                            DataRow[] courseRows = reg.GetParentRows(courseRegRelation);
                            if (courseRows.Length > 0 && reg["Grade"] != DBNull.Value)
                            {
                                Console.WriteLine($"  - {courseRows[0]["CourseName"]}: {reg["Grade"]}");
                            }
                        }
                    }
                }
            }
        }

        // === ЗАДАНИЕ 8 ===
        static void Task8()
        {
            Console.WriteLine("Использование DataRelation для создания рассчитываемых полей");

            if (!dataSet.Tables.Contains("Categories") || !dataSet.Tables.Contains("Products"))
            {
                Console.WriteLine("Сначала выполните задание 1!");
                return;
            }

            DataTable categories = dataSet.Tables["Categories"];
            DataTable products = dataSet.Tables["Products"];
            DataRelation relation = dataSet.Relations["CategoryProducts"];

            // Добавляем рассчитываемые поля
            DataColumn productCountColumn = new DataColumn(
                "TotalProductCount",
                typeof(int),
                "Count(Child.ProductID)");

            DataColumn totalValueColumn = new DataColumn(
                "TotalCategoryValue",
                typeof(decimal),
                "Sum(Child.Price)");

            categories.Columns.Add(productCountColumn);
            categories.Columns.Add(totalValueColumn);

            // Демонстрация работы
            Console.WriteLine("\n=== РАССЧИТЫВАЕМЫЕ ПОЛЯ ===");
            Console.WriteLine("Категория          | Кол-во товаров | Общая стоимость");
            Console.WriteLine("-------------------|----------------|----------------");

            foreach (DataRow category in categories.Rows)
            {
                Console.WriteLine($"{category["CategoryName"],-18} | {category["TotalProductCount"],14} | {category["TotalCategoryValue"],14:C}");
            }

            // Добавляем новый товар и показываем обновление
            Console.WriteLine("\nДобавляем новый товар...");
            DataRow newProduct = products.NewRow();
            newProduct["ProductID"] = products.Rows.Count + 1;
            newProduct["ProductName"] = "Новый товар";
            newProduct["Price"] = 99.99m;
            newProduct["CategoryID"] = 1; // Электроника
            products.Rows.Add(newProduct);

            Console.WriteLine("\nПосле добавления товара:");
            DataRow electronics = categories.Select("CategoryID = 1").FirstOrDefault();
            if (electronics != null)
            {
                Console.WriteLine($"Электроника: {electronics["TotalProductCount"]} товаров, {electronics["TotalCategoryValue"]:C}");
            }
        }

        // === ЗАДАНИЕ 9 ===
        static void Task9()
        {
            Console.WriteLine("Использование DeleteRule для определения поведения при удалении");

            // Создаем таблицы отделов и сотрудников
            DataTable departments = CreateDepartmentsTable();
            DataTable employees = CreateDepartmentEmployeesTable();

            DataSet ds = new DataSet("CompanyDB");
            ds.Tables.Add(departments);
            ds.Tables.Add(employees);

            // Заполняем данными
            FillDepartmentsTable(departments);
            FillDepartmentEmployeesTable(employees, departments);

            // Тестируем разные DeleteRule
            TestDeleteRule(ds, departments, employees, "Cascade", Rule.Cascade);
            TestDeleteRule(ds, departments, employees, "SetNull", Rule.SetNull);
            TestDeleteRule(ds, departments, employees, "None", Rule.None);
        }

        // === ЗАДАНИЕ 10 ===
        static void Task10()
        {
            Console.WriteLine("Использование UpdateRule для определения поведения при изменении первичного ключа");

            DataTable departments = CreateDepartmentsTable();
            DataTable employees = CreateDepartmentEmployeesTable();

            DataSet ds = new DataSet("CompanyDB");
            ds.Tables.Add(departments);
            ds.Tables.Add(employees);

            FillDepartmentsTable(departments);
            FillDepartmentEmployeesTable(employees, departments);

            // Тестируем разные UpdateRule
            TestUpdateRule(ds, departments, employees, "Cascade", Rule.Cascade);
            TestUpdateRule(ds, departments, employees, "SetNull", Rule.SetNull);
            TestUpdateRule(ds, departments, employees, "None", Rule.None);
        }

        // === ЗАДАНИЕ 11 ===
        static void Task11()
        {
            Console.WriteLine("Комбинирование DeleteRule и UpdateRule в одном приложении");

            // Создаем таблицы для системы заказов
            DataTable customers = CreateCustomersTable();
            DataTable orders = CreateOrdersTable();
            DataTable orderDetails = CreateOrderDetailsTable();

            DataSet ds = new DataSet("OrderSystem");
            ds.Tables.Add(customers);
            ds.Tables.Add(orders);
            ds.Tables.Add(orderDetails);

            // Заполняем данными
            FillCustomersTable(customers);
            FillOrdersTable(orders, customers);
            FillOrderDetailsTable(orderDetails, orders);

            // Создаем отношения с Cascade для обоих правил
            ForeignKeyConstraint fk1 = new ForeignKeyConstraint(
                "FK_Customers_Orders",
                customers.Columns["CustomerID"],
                orders.Columns["CustomerID"]);
            fk1.DeleteRule = Rule.Cascade;
            fk1.UpdateRule = Rule.Cascade;

            ForeignKeyConstraint fk2 = new ForeignKeyConstraint(
                "FK_Orders_Details",
                orders.Columns["OrderID"],
                orderDetails.Columns["OrderID"]);
            fk2.DeleteRule = Rule.Cascade;
            fk2.UpdateRule = Rule.Cascade;

            ds.Relations.Add("CustomerOrders",
                customers.Columns["CustomerID"],
                orders.Columns["CustomerID"],
                true);

            ds.Relations.Add("OrderDetails",
                orders.Columns["OrderID"],
                orderDetails.Columns["OrderID"],
                true);

            // Тестируем каскадное удаление
            Console.WriteLine("\n=== ДО УДАЛЕНИЯ ===");
            Console.WriteLine($"Клиентов: {customers.Rows.Count}");
            Console.WriteLine($"Заказов: {orders.Rows.Count}");
            Console.WriteLine($"Деталей заказов: {orderDetails.Rows.Count}");

            Console.WriteLine("\nУдаляем клиента с ID=1...");
            DataRow customerToDelete = customers.Select("CustomerID = 1").FirstOrDefault();
            if (customerToDelete != null)
            {
                customerToDelete.Delete();

                Console.WriteLine("\n=== ПОСЛЕ УДАЛЕНИЯ ===");
                Console.WriteLine($"Клиентов: {customers.Rows.Count} (включая помеченные на удаление)");
                Console.WriteLine($"Заказов: {orders.Rows.Count}");
                Console.WriteLine($"Деталей заказов: {orderDetails.Rows.Count}");

                // Показываем какие строки помечены на удаление
                Console.WriteLine("\nСтроки помеченные на удаление:");
                foreach (DataRow row in customers.Rows)
                    if (row.RowState == DataRowState.Deleted)
                        Console.WriteLine($"Клиент ID={row["CustomerID", DataRowVersion.Original]}");

                foreach (DataRow row in orders.Rows)
                    if (row.RowState == DataRowState.Deleted)
                        Console.WriteLine($"Заказ ID={row["OrderID", DataRowVersion.Original]}");

                foreach (DataRow row in orderDetails.Rows)
                    if (row.RowState == DataRowState.Deleted)
                        Console.WriteLine($"Деталь заказа ID={row["DetailID", DataRowVersion.Original]}");
            }
        }

        // === ЗАДАНИЕ 12 ===
        static void Task12()
        {
            Console.WriteLine("Использование RowState для получения информации об удаляемых строках");

            if (!dataSet.Tables.Contains("Products"))
            {
                Console.WriteLine("Сначала выполните задание 1!");
                return;
            }

            DataTable products = dataSet.Tables["Products"];
            DataRelation relation = dataSet.Relations["CategoryProducts"];

            // Сохраняем исходное состояние
            products.AcceptChanges();

            // Выполняем операции
            Console.WriteLine("Выполняем операции с данными...");

            // Добавляем новые товары
            DataRow newProduct1 = products.NewRow();
            newProduct1["ProductID"] = products.Rows.Count + 1;
            newProduct1["ProductName"] = "Новый товар 1";
            newProduct1["Price"] = 100;
            newProduct1["CategoryID"] = 1;
            products.Rows.Add(newProduct1);

            DataRow newProduct2 = products.NewRow();
            newProduct2["ProductID"] = products.Rows.Count + 1;
            newProduct2["ProductName"] = "Новый товар 2";
            newProduct2["Price"] = 200;
            newProduct2["CategoryID"] = 2;
            products.Rows.Add(newProduct2);

            // Модифицируем товары
            if (products.Rows.Count > 2)
            {
                products.Rows[0]["Price"] = Convert.ToDecimal(products.Rows[0]["Price"]) * 1.1m;
                products.Rows[1]["ProductName"] = products.Rows[1]["ProductName"] + " (обновлено)";
            }

            // Помечаем на удаление
            if (products.Rows.Count > 3)
            {
                products.Rows[2].Delete();
                products.Rows[3].Delete();
                products.Rows[4].Delete();
            }

            // Отчет о изменениях
            Console.WriteLine("\n=== ОТЧЕТ ОБ ИЗМЕНЕНИЯХ ===");
            Console.WriteLine($"Всего строк: {products.Rows.Count}");

            int addedCount = 0, modifiedCount = 0, deletedCount = 0;

            foreach (DataRow row in products.Rows)
            {
                switch (row.RowState)
                {
                    case DataRowState.Added: addedCount++; break;
                    case DataRowState.Modified: modifiedCount++; break;
                    case DataRowState.Deleted: deletedCount++; break;
                }
            }

            Console.WriteLine($"Добавлено: {addedCount}");
            Console.WriteLine($"Изменено: {modifiedCount}");
            Console.WriteLine($"Помечено на удаление: {deletedCount}");

            // Информация об удаляемых товарах
            Console.WriteLine("\n=== ТОВАРЫ, ПОМЕЧЕННЫЕ НА УДАЛЕНИЕ ===");
            foreach (DataRow row in products.Rows)
            {
                if (row.RowState == DataRowState.Deleted)
                {
                    try
                    {
                        DataRow[] parentRows = row.GetParentRows(relation, DataRowVersion.Original);
                        string categoryName = parentRows.Length > 0 ?
                            parentRows[0]["CategoryName"].ToString() : "НЕТ КАТЕГОРИИ";

                        Console.WriteLine($"Товар: {row["ProductName", DataRowVersion.Original]}");
                        Console.WriteLine($"  Категория: {categoryName}");
                        Console.WriteLine($"  Цена: {row["Price", DataRowVersion.Original]:C}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Ошибка при получении информации: {ex.Message}");
                    }
                }
            }

            // Отмена изменений для некоторых строк
            Console.WriteLine("\nОтменяем удаление для первой помеченной строки...");
            bool firstDeleted = true;
            foreach (DataRow row in products.Rows)
            {
                if (row.RowState == DataRowState.Deleted && firstDeleted)
                {
                    row.RejectChanges();
                    firstDeleted = false;
                    Console.WriteLine("Удаление отменено!");
                }
            }
        }

        // === ЗАДАНИЕ 13-20 ===
        // Из-за ограничения длины, реализуем только ключевые задания
        // Полные реализации остальных заданий следуют аналогичному паттерну

        // Вспомогательные методы для создания таблиц
        static DataTable CreateCategoriesTable()
        {
            DataTable table = new DataTable("Categories");

            table.Columns.Add("CategoryID", typeof(int));
            table.Columns.Add("CategoryName", typeof(string));
            table.Columns.Add("Description", typeof(string));

            table.PrimaryKey = new DataColumn[] { table.Columns["CategoryID"] };

            return table;
        }

        static DataTable CreateProductsTable()
        {
            DataTable table = new DataTable("Products");

            table.Columns.Add("ProductID", typeof(int));
            table.Columns.Add("ProductName", typeof(string));
            table.Columns.Add("Price", typeof(decimal));
            table.Columns.Add("CategoryID", typeof(int));

            table.PrimaryKey = new DataColumn[] { table.Columns["ProductID"] };

            return table;
        }

        static void FillCategoriesTable(DataTable table)
        {
            table.Rows.Add(1, "Электроника", "Электронные устройства и гаджеты");
            table.Rows.Add(2, "Одежда", "Одежда и аксессуары");
            table.Rows.Add(3, "Книги", "Книги и литература");
            table.Rows.Add(4, "Продукты", "Продукты питания");
        }

        static void FillProductsTable(DataTable table)
        {
            table.Rows.Add(1, "Смартфон", 299.99m, 1);
            table.Rows.Add(2, "Ноутбук", 999.99m, 1);
            table.Rows.Add(3, "Наушники", 89.99m, 1);
            table.Rows.Add(4, "Футболка", 19.99m, 2);
            table.Rows.Add(5, "Джинсы", 49.99m, 2);
            table.Rows.Add(6, "Роман", 14.99m, 3);
            table.Rows.Add(7, "Учебник", 29.99m, 3);
            table.Rows.Add(8, "Яблоки", 2.99m, 4);
            table.Rows.Add(9, "Хлеб", 1.49m, 4);
            table.Rows.Add(10, "Планшет", 399.99m, 1);
        }

        static void PrintCategoryProductsHierarchy(DataTable categories, DataRelation relation)
        {
            foreach (DataRow category in categories.Rows)
            {
                Console.WriteLine($"\n[{category["CategoryID"]}] {category["CategoryName"]}");
                Console.WriteLine($"Описание: {category["Description"]}");

                DataRow[] childProducts = category.GetChildRows(relation);

                if (childProducts.Length == 0)
                {
                    Console.WriteLine("  Нет товаров");
                }
                else
                {
                    Console.WriteLine("  Товары:");
                    foreach (DataRow product in childProducts)
                    {
                        Console.WriteLine($"  - {product["ProductName"]} ({product["Price"]:C})");
                    }
                }
            }
        }

        static DataTable CreateEmployeesTable()
        {
            DataTable table = new DataTable("Employees");

            table.Columns.Add("EmployeeID", typeof(int));
            table.Columns.Add("EmployeeName", typeof(string));
            table.Columns.Add("Department", typeof(string));
            table.Columns.Add("Salary", typeof(decimal));
            table.Columns.Add("ManagerID", typeof(int));

            table.PrimaryKey = new DataColumn[] { table.Columns["EmployeeID"] };

            return table;
        }

        static void FillEmployeesTable(DataTable table)
        {
            // Руководство (ManagerID = NULL)
            table.Rows.Add(1, "Иван Петров", "Дирекция", 5000, DBNull.Value);
            table.Rows.Add(2, "Мария Сидорова", "Отдел кадров", 3000, 1);
            table.Rows.Add(3, "Алексей Иванов", "IT отдел", 4000, 1);

            // Менеджеры среднего звена
            table.Rows.Add(4, "Ольга Кузнецова", "Разработка", 3500, 3);
            table.Rows.Add(5, "Дмитрий Смирнов", "Тестирование", 3200, 3);
            table.Rows.Add(6, "Екатерина Волкова", "Бухгалтерия", 2800, 2);

            // Обычные сотрудники
            table.Rows.Add(7, "Павел Козлов", "Разработка", 2500, 4);
            table.Rows.Add(8, "Анна Новикова", "Разработка", 2400, 4);
            table.Rows.Add(9, "Сергей Морозов", "Тестирование", 2200, 5);
            table.Rows.Add(10, "Наталья Зайцева", "Бухгалтерия", 2300, 6);
        }

        static void PrintEmployeeHierarchy(DataTable employees, DataRelation relation, int indent)
        {
            // Находим корневых сотрудников (без руководителей)
            var rootEmployees = employees.Select("ManagerID IS NULL");

            foreach (DataRow employee in rootEmployees)
            {
                PrintEmployeeWithChildren(employee, relation, indent);
            }
        }

        static void PrintEmployeeWithChildren(DataRow employee, DataRelation relation, int indent)
        {
            string indentStr = new string(' ', indent * 2);
            Console.WriteLine($"{indentStr}├─ {employee["EmployeeName"]} ({employee["Department"]})");

            DataRow[] children = employee.GetChildRows(relation);
            foreach (DataRow child in children)
            {
                PrintEmployeeWithChildren(child, relation, indent + 1);
            }
        }

        static int CalculateHierarchyLevel(DataRow employee, DataRelation relation)
        {
            if (employee["ManagerID"] == DBNull.Value)
                return 0;

            DataRow[] parents = employee.GetParentRows(relation);
            if (parents.Length == 0)
                return 0;

            return 1 + CalculateHierarchyLevel(parents[0], relation);
        }

        static void PrintManagementChain(DataRow employee, DataRelation relation)
        {
            DataRow current = employee;
            int level = 0;

            while (current != null)
            {
                string indent = new string(' ', level * 2);
                Console.WriteLine($"{indent}Уровень {level}: {current["EmployeeName"]} ({current["Department"]})");

                if (current["ManagerID"] == DBNull.Value)
                    break;

                DataRow[] parents = current.GetParentRows(relation);
                current = parents.Length > 0 ? parents[0] : null;
                level++;
            }
        }

        static DataTable CreateStudentsTable()
        {
            DataTable table = new DataTable("Students");

            table.Columns.Add("StudentID", typeof(int));
            table.Columns.Add("StudentName", typeof(string));
            table.Columns.Add("Email", typeof(string));

            table.PrimaryKey = new DataColumn[] { table.Columns["StudentID"] };

            return table;
        }

        static DataTable CreateCoursesTable()
        {
            DataTable table = new DataTable("Courses");

            table.Columns.Add("CourseID", typeof(int));
            table.Columns.Add("CourseName", typeof(string));
            table.Columns.Add("Instructor", typeof(string));

            table.PrimaryKey = new DataColumn[] { table.Columns["CourseID"] };

            return table;
        }

        static DataTable CreateRegistrationsTable()
        {
            DataTable table = new DataTable("Registrations");

            table.Columns.Add("RegistrationID", typeof(int));
            table.Columns.Add("StudentID", typeof(int));
            table.Columns.Add("CourseID", typeof(int));
            table.Columns.Add("EnrollmentDate", typeof(DateTime));
            table.Columns.Add("Grade", typeof(decimal));

            table.PrimaryKey = new DataColumn[] { table.Columns["RegistrationID"] };

            return table;
        }

        static void FillStudentsTable(DataTable table)
        {
            table.Rows.Add(1, "Андрей Соколов", "andrey@email.com");
            table.Rows.Add(2, "Елена Петрова", "elena@email.com");
            table.Rows.Add(3, "Михаил Иванов", "mikhail@email.com");
            table.Rows.Add(4, "Анна Кузнецова", "anna@email.com");
        }

        static void FillCoursesTable(DataTable table)
        {
            table.Rows.Add(1, "Математика", "Проф. Сидоров");
            table.Rows.Add(2, "Физика", "Проф. Петров");
            table.Rows.Add(3, "Программирование", "Проф. Иванова");
            table.Rows.Add(4, "Базы данных", "Проф. Смирнов");
        }

        static void FillRegistrationsTable(DataTable registrations, DataTable students, DataTable courses)
        {
            Random rand = new Random();
            int regId = 1;

            foreach (DataRow student in students.Rows)
            {
                // Каждый студент записывается на 2-3 курса
                int coursesCount = rand.Next(2, 4);
                var selectedCourses = courses.AsEnumerable()
                    .OrderBy(x => rand.Next())
                    .Take(coursesCount);

                foreach (DataRow course in selectedCourses)
                {
                    registrations.Rows.Add(
                        regId++,
                        student["StudentID"],
                        course["CourseID"],
                        DateTime.Now.AddDays(-rand.Next(0, 30)),
                        rand.Next(3, 6) + rand.NextDouble() // Оценка 3.0-5.99
                    );
                }
            }
        }

        static DataTable CreateDepartmentsTable()
        {
            DataTable table = new DataTable("Departments");

            table.Columns.Add("DepartmentID", typeof(int));
            table.Columns.Add("DepartmentName", typeof(string));

            table.PrimaryKey = new DataColumn[] { table.Columns["DepartmentID"] };

            return table;
        }

        static DataTable CreateDepartmentEmployeesTable()
        {
            DataTable table = new DataTable("Employees");

            table.Columns.Add("EmployeeID", typeof(int));
            table.Columns.Add("EmployeeName", typeof(string));
            table.Columns.Add("DepartmentID", typeof(int));
            table.Columns.Add("Salary", typeof(decimal));

            table.PrimaryKey = new DataColumn[] { table.Columns["EmployeeID"] };

            return table;
        }

        static void FillDepartmentsTable(DataTable table)
        {
            table.Rows.Add(1, "IT");
            table.Rows.Add(2, "HR");
            table.Rows.Add(3, "Финансы");
        }

        static void FillDepartmentEmployeesTable(DataTable employees, DataTable departments)
        {
            employees.Rows.Add(1, "Иван Иванов", 1, 3000);
            employees.Rows.Add(2, "Петр Петров", 1, 3200);
            employees.Rows.Add(3, "Сидор Сидоров", 2, 2800);
            employees.Rows.Add(4, "Анна Аннова", 3, 3500);
            employees.Rows.Add(5, "Мария Мариева", 3, 3300);
        }

        static void TestDeleteRule(DataSet ds, DataTable departments, DataTable employees, string ruleName, Rule rule)
        {
            Console.WriteLine($"\n=== DELETE RULE: {ruleName} ===");

            // Создаем новое отношение с указанным правилом
            ds.Relations.Clear();
            ForeignKeyConstraint fk = new ForeignKeyConstraint(
                $"FK_Departments_Employees_{ruleName}",
                departments.Columns["DepartmentID"],
                employees.Columns["DepartmentID"]);
            fk.DeleteRule = rule;

            ds.Relations.Add($"DeptEmp_{ruleName}",
                departments.Columns["DepartmentID"],
                employees.Columns["DepartmentID"],
                true);

            // Сохраняем исходные данные
            departments.RejectChanges();
            employees.RejectChanges();

            Console.WriteLine("\nДо удаления:");
            Console.WriteLine($"Отделов: {departments.Rows.Count}");
            Console.WriteLine($"Сотрудников: {employees.Rows.Count}");

            Console.WriteLine("\nУдаляем отдел IT (ID=1)...");

            try
            {
                DataRow deptToDelete = departments.Select("DepartmentID = 1").FirstOrDefault();
                if (deptToDelete != null)
                {
                    deptToDelete.Delete();

                    Console.WriteLine("\nПосле удаления:");
                    Console.WriteLine($"Отделов: {departments.Rows.Count} (включая помеченные на удаление)");
                    Console.WriteLine($"Сотрудников: {employees.Rows.Count}");

                    // Проверяем состояние сотрудников
                    Console.WriteLine("\nСостояние сотрудников:");
                    foreach (DataRow emp in employees.Rows)
                    {
                        string deptId = emp["DepartmentID"] == DBNull.Value ? "NULL" : emp["DepartmentID"].ToString();
                        Console.WriteLine($"{emp["EmployeeName"]}: DepartmentID = {deptId}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }

        static void TestUpdateRule(DataSet ds, DataTable departments, DataTable employees, string ruleName, Rule rule)
        {
            Console.WriteLine($"\n=== UPDATE RULE: {ruleName} ===");

            // Создаем новое отношение с указанным правилом
            ds.Relations.Clear();
            ForeignKeyConstraint fk = new ForeignKeyConstraint(
                $"FK_Departments_Employees_Update_{ruleName}",
                departments.Columns["DepartmentID"],
                employees.Columns["DepartmentID"]);
            fk.UpdateRule = rule;

            ds.Relations.Add($"DeptEmp_Update_{ruleName}",
                departments.Columns["DepartmentID"],
                employees.Columns["DepartmentID"],
                true);

            // Сохраняем исходные данные
            departments.RejectChanges();
            employees.RejectChanges();

            Console.WriteLine("\nДо обновления:");
            Console.WriteLine("Отдел IT имеет ID=1");
            Console.WriteLine("Сотрудники отдела IT:");
            foreach (DataRow emp in employees.Select("DepartmentID = 1"))
            {
                Console.WriteLine($"- {emp["EmployeeName"]}");
            }

            Console.WriteLine("\nИзменяем ID отдела IT с 1 на 101...");

            try
            {
                DataRow deptToUpdate = departments.Select("DepartmentID = 1").FirstOrDefault();
                if (deptToUpdate != null)
                {
                    deptToUpdate["DepartmentID"] = 101;

                    Console.WriteLine("\nПосле обновления:");
                    Console.WriteLine($"Отдел IT теперь имеет ID={deptToUpdate["DepartmentID"]}");

                    Console.WriteLine("\nСостояние сотрудников:");
                    foreach (DataRow emp in employees.Rows)
                    {
                        string deptId = emp["DepartmentID"] == DBNull.Value ? "NULL" : emp["DepartmentID"].ToString();
                        Console.WriteLine($"{emp["EmployeeName"]}: DepartmentID = {deptId}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }

        static DataTable CreateCustomersTable()
        {
            DataTable table = new DataTable("Customers");

            table.Columns.Add("CustomerID", typeof(int));
            table.Columns.Add("CustomerName", typeof(string));
            table.Columns.Add("Email", typeof(string));

            table.PrimaryKey = new DataColumn[] { table.Columns["CustomerID"] };

            return table;
        }

        static DataTable CreateOrdersTable()
        {
            DataTable table = new DataTable("Orders");

            table.Columns.Add("OrderID", typeof(int));
            table.Columns.Add("OrderDate", typeof(DateTime));
            table.Columns.Add("CustomerID", typeof(int));
            table.Columns.Add("Total", typeof(decimal));

            table.PrimaryKey = new DataColumn[] { table.Columns["OrderID"] };

            return table;
        }

        static DataTable CreateOrderDetailsTable()
        {
            DataTable table = new DataTable("OrderDetails");

            table.Columns.Add("DetailID", typeof(int));
            table.Columns.Add("OrderID", typeof(int));
            table.Columns.Add("ProductID", typeof(int));
            table.Columns.Add("Quantity", typeof(int));
            table.Columns.Add("Price", typeof(decimal));

            table.PrimaryKey = new DataColumn[] { table.Columns["DetailID"] };

            return table;
        }

        static void FillCustomersTable(DataTable table)
        {
            table.Rows.Add(1, "ООО 'Ромашка'", "romashka@email.com");
            table.Rows.Add(2, "ИП Иванов", "ivanov@email.com");
            table.Rows.Add(3, "ЗАО 'Вектор'", "vector@email.com");
        }

        static void FillOrdersTable(DataTable orders, DataTable customers)
        {
            orders.Rows.Add(1, DateTime.Now.AddDays(-10), 1, 1500);
            orders.Rows.Add(2, DateTime.Now.AddDays(-5), 1, 2300);
            orders.Rows.Add(3, DateTime.Now.AddDays(-3), 2, 800);
            orders.Rows.Add(4, DateTime.Now.AddDays(-1), 3, 3200);
        }

        static void FillOrderDetailsTable(DataTable details, DataTable orders)
        {
            details.Rows.Add(1, 1, 101, 2, 500);
            details.Rows.Add(2, 1, 102, 1, 500);
            details.Rows.Add(3, 2, 103, 3, 600);
            details.Rows.Add(4, 2, 104, 2, 250);
            details.Rows.Add(5, 3, 101, 1, 500);
            details.Rows.Add(6, 3, 105, 2, 150);
            details.Rows.Add(7, 4, 106, 5, 400);
            details.Rows.Add(8, 4, 107, 2, 600);
        }

        // Заглушки для остальных заданий (13-20)
        static void Task13() { Console.WriteLine("Задание 13 - Получение связанной информации для строк со статусом Added"); }
        static void Task14() { Console.WriteLine("Задание 14 - Получение связанной информации для строк со статусом Modified"); }
        static void Task15() { Console.WriteLine("Задание 15 - Каскадное удаление с отслеживанием изменений во всех таблицах"); }
        static void Task16() { Console.WriteLine("Задание 16 - Проверка ссылочной целостности перед сохранением"); }
        static void Task17() { Console.WriteLine("Задание 17 - Использование DataRelation для фильтрации данных в DataView"); }
        static void Task18() { Console.WriteLine("Задание 18 - Экспорт иерархических данных с использованием DataRelation"); }
        static void Task19() { Console.WriteLine("Задание 19 - Комплексное приложение: управление образовательным учреждением"); }
        static void Task20() { Console.WriteLine("Задание 20 - Оптимизация и производительность при работе с DataRelation на больших объемах данных"); }
    }
}