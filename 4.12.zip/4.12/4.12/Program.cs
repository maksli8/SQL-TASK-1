﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Drawing;

namespace DataViewPracticalTasks
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("Практические задания по DataView в ADO.NET");
            Console.WriteLine("===========================================\n");

            while (true)
            {
                Console.WriteLine("\nВыберите задание (1-30) или 0 для выхода:");
                Console.WriteLine("1. Основные преимущества DataView");
                Console.WriteLine("2. Поиск по первичному ключу с Find()");
                Console.WriteLine("3. Фильтрация данных с Select()");
                Console.WriteLine("4. Создание DataView различными способами");
                Console.WriteLine("5. Сортировка и фильтрация в DataView");
                Console.WriteLine("6. DataViewRowState для фильтрации по состоянию строк");
                Console.WriteLine("7. Поиск в DataView с Find()");
                Console.WriteLine("8. Добавление данных через DataView");
                Console.WriteLine("9. Редактирование данных через DataView");
                Console.WriteLine("10. Удаление данных через DataView");
                Console.WriteLine("11. Создание новой DataTable из DataView");
                Console.WriteLine("12. Комбинированный поиск (Find, Select, DataView)");
                Console.WriteLine("13. DataView с несколькими уровнями фильтрации");
                Console.WriteLine("14. Сортировка по нескольким колонкам");
                Console.WriteLine("15. Комбинирование нескольких DataView");
                Console.WriteLine("16. Динамическое изменение фильтра");
                Console.WriteLine("17. DataView для создания графиков");
                Console.WriteLine("18. Поиск ближайших значений");
                Console.WriteLine("19. Валидация данных при редактировании");
                Console.WriteLine("20. Экспорт данных из DataView");
                Console.WriteLine("21. Иерархические представления");
                Console.WriteLine("22. Комплексная фильтрация с LIKE");
                Console.WriteLine("23. Создание отчётов с группировкой");
                Console.WriteLine("24. DataView с вычисляемыми столбцами");
                Console.WriteLine("25. Поиск дубликатов");
                Console.WriteLine("26. Синхронизация нескольких DataView");
                Console.WriteLine("27. Оптимизация производительности");
                Console.WriteLine("28. Кастомный поиск с DataView");
                Console.WriteLine("29. Пользовательские представления");
                Console.WriteLine("30. Управление проектами");
                Console.WriteLine("0. Выход");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    if (choice == 0) break;

                    Console.Clear();
                    Console.WriteLine($"=== Задание {choice} ===\n");

                    try
                    {
                        switch (choice)
                        {
                            case 1: Task1(); break;
                            case 2: Task2(); break;
                            case 3: Task3(); break;
                            case 4: Task4(); break;
                            case 5: Task5(); break;
                            case 6: Task6(); break;
                            case 7: Task7(); break;
                            case 8: Task8(); break;
                            case 9: Task9(); break;
                            case 10: Task10(); break;
                            case 11: Task11(); break;
                            case 12: Task12(); break;
                            case 13: Task13(); break;
                            case 14: Task14(); break;
                            case 15: Task15(); break;
                            case 16: Task16(); break;
                            case 17: Task17(); break;
                            case 18: Task18(); break;
                            case 19: Task19(); break;
                            case 21: Task21(); break;
                            case 22: Task22(); break;
                            case 25: Task25(); break;
                            case 27: Task27(); break;
                            case 28: Task28(); break;
                            case 29: Task29(); break;
                            case 30: Task30(); break;
                            default: Console.WriteLine("Неверный выбор!"); break;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Ошибка: {ex.Message}");
                        Console.WriteLine($"StackTrace: {ex.StackTrace}");
                    }

                    Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                    Console.ReadKey();
                    Console.Clear();
                }
            }
        }

        #region Задание 1: Основные преимущества DataView
        static void Task1()
        {
            Console.WriteLine("Задание 1: Основные преимущества DataView\n");

            // 1. Создаем DataTable с товарами
            DataTable productsTable = CreateProductsTable();
            FillProductsTable(productsTable, 20);

            Console.WriteLine($"Исходная таблица содержит {productsTable.Rows.Count} товаров");
            Console.WriteLine("Первые 5 записей:");
            PrintDataTable(productsTable, 5);

            // 2. Сравнение производительности
            Stopwatch sw = new Stopwatch();

            // Фильтрация через DataTable.Select()
            sw.Start();
            DataRow[] filteredRows = productsTable.Select("Price > 100 AND Quantity > 5");
            sw.Stop();
            long selectTime = sw.ElapsedTicks;
            Console.WriteLine($"\nDataTable.Select(): Найдено {filteredRows.Length} записей за {selectTime} тиков");

            // Фильтрация через DataView
            sw.Restart();
            DataView dataView = new DataView(productsTable);
            dataView.RowFilter = "Price > 100 AND Quantity > 5";
            sw.Stop();
            long dataViewTime = sw.ElapsedTicks;
            Console.WriteLine($"DataView с фильтром: Найдено {dataView.Count} записей за {dataViewTime} тиков");

            // 3. Преимущества DataView
            Console.WriteLine("\n=== Преимущества DataView ===");

            // 3.1. Несколько представлений одной таблицы
            DataView expensiveView = new DataView(productsTable)
            {
                RowFilter = "Price > 200",
                Sort = "Price DESC"
            };

            DataView lowStockView = new DataView(productsTable)
            {
                RowFilter = "Quantity < 10",
                Sort = "Quantity ASC"
            };

            Console.WriteLine($"\nДорогие товары (>200): {expensiveView.Count} записей");
            Console.WriteLine($"Товары с низким запасом (<10): {lowStockView.Count} записей");

            // 3.2. Динамическое изменение фильтра
            Console.WriteLine("\n--- Динамическое изменение фильтра ---");
            dataView.RowFilter = "Category = 'Electronics'";
            Console.WriteLine($"Товары категории Electronics: {dataView.Count}");

            dataView.RowFilter = "Category = 'Books'";
            Console.WriteLine($"Товары категории Books: {dataView.Count}");

            // 3.3. Сортировка без изменения исходной таблицы
            DataView sortedView = new DataView(productsTable)
            {
                Sort = "Name ASC"
            };

            Console.WriteLine("\n--- Сортировка в DataView ---");
            Console.WriteLine("Первые 5 отсортированных записей:");
            for (int i = 0; i < Math.Min(5, sortedView.Count); i++)
            {
                Console.WriteLine($"{sortedView[i]["Name"]} - {sortedView[i]["Price"]}");
            }

            // 3.4. Автоматическое отражение изменений
            Console.WriteLine("\n--- Автоматическое отражение изменений ---");
            Console.WriteLine($"Количество в DataView до изменения: {dataView.Count}");

            // Добавляем новую строку в исходную таблицу
            DataRow newRow = productsTable.NewRow();
            newRow["ProductID"] = 999;
            newRow["Name"] = "Новая книга";
            newRow["Price"] = 50;
            newRow["Quantity"] = 100;
            newRow["Category"] = "Books";
            productsTable.Rows.Add(newRow);

            Console.WriteLine($"Количество в DataView после добавления: {dataView.Count}");

            // 3.5. Сравнение производительности при изменении фильтра
            Console.WriteLine("\n--- Сравнение производительности изменения фильтра ---");

            sw.Restart();
            for (int i = 0; i < 1000; i++)
            {
                dataView.RowFilter = $"Price > {i % 100}";
            }
            sw.Stop();
            Console.WriteLine($"1000 изменений фильтра DataView: {sw.ElapsedMilliseconds} ms");

            // 4. Отчёт о преимуществах
            Console.WriteLine("\n=== Отчёт о преимуществах DataView ===");
            Console.WriteLine("1. Не изменяет исходную таблицу");
            Console.WriteLine("2. Поддерживает несколько независимых представлений");
            Console.WriteLine("3. Позволяет динамически изменять фильтры и сортировку");
            Console.WriteLine("4. Автоматически отражает изменения в исходной таблице");
            Console.WriteLine("5. Оптимизирован для повторных операций фильтрации");
        }
        #endregion

        #region Задание 2: Поиск по первичному ключу с Find()
        static void Task2()
        {
            Console.WriteLine("Задание 2: Поиск по первичному ключу с Find()\n");

            // 1. Создаем таблицу сотрудников
            DataTable employeesTable = new DataTable("Сотрудники");

            employeesTable.Columns.Add("EmployeeID", typeof(int));
            employeesTable.Columns.Add("FullName", typeof(string));
            employeesTable.Columns.Add("Email", typeof(string));
            employeesTable.Columns.Add("Department", typeof(string));
            employeesTable.Columns.Add("Salary", typeof(decimal));

            // Устанавливаем первичный ключ
            employeesTable.PrimaryKey = new DataColumn[] { employeesTable.Columns["EmployeeID"] };

            // 2. Заполняем таблицу
            Random rand = new Random();
            for (int i = 1; i <= 50; i++)
            {
                employeesTable.Rows.Add(
                    i,
                    $"Сотрудник {i}",
                    $"employee{i}@company.com",
                    rand.Next(1, 4) switch { 1 => "IT", 2 => "HR", 3 => "Finance", _ => "Sales" },
                    rand.Next(30000, 150000)
                );
            }

            Console.WriteLine($"Таблица содержит {employeesTable.Rows.Count} сотрудников");

            // 3. Поиск с использованием Find()
            Console.WriteLine("\n=== Поиск с Find() ===");

            // 3.1. Поиск существующего сотрудника
            Stopwatch sw = new Stopwatch();
            sw.Start();
            DataRow foundRow = employeesTable.Rows.Find(25);
            sw.Stop();

            if (foundRow != null)
            {
                Console.WriteLine($"Найден сотрудник ID=25 за {sw.ElapsedTicks} тиков:");
                Console.WriteLine($"  Имя: {foundRow["FullName"]}");
                Console.WriteLine($"  Email: {foundRow["Email"]}");
                Console.WriteLine($"  Отдел: {foundRow["Department"]}");
                Console.WriteLine($"  Зарплата: {foundRow["Salary"]}");
            }

            // 3.2. Поиск несуществующего ID
            DataRow notFoundRow = employeesTable.Rows.Find(999);
            Console.WriteLine($"\nПоиск несуществующего ID=999: {(notFoundRow == null ? "Не найден" : "Найден")}");

            // 4. Сравнение производительности Find() vs Select()
            Console.WriteLine("\n=== Сравнение производительности ===");

            int searchId = 42;

            sw.Restart();
            DataRow findResult = employeesTable.Rows.Find(searchId);
            sw.Stop();
            long findTime = sw.ElapsedTicks;

            sw.Restart();
            DataRow[] selectResult = employeesTable.Select($"EmployeeID = {searchId}");
            sw.Stop();
            long selectTime = sw.ElapsedTicks;

            Console.WriteLine($"Find() для ID={searchId}: {findTime} тиков");
            Console.WriteLine($"Select() для ID={searchId}: {selectTime} тиков");
            Console.WriteLine($"Разница: {selectTime - findTime} тиков (Find() быстрее на {((double)selectTime / findTime):F2}x)");

            // 5. Поиск с использованием DataView и BinarySearch
            Console.WriteLine("\n=== Поиск с DataView и BinarySearch ===");

            DataView sortedView = new DataView(employeesTable)
            {
                Sort = "EmployeeID ASC"
            };

            int index = sortedView.Find(searchId);
            if (index >= 0)
            {
                Console.WriteLine($"Найден через DataView.Find() на позиции {index}:");
                Console.WriteLine($"  Имя: {sortedView[index]["FullName"]}");
            }

            // 6. Поиск диапазона ID
            Console.WriteLine("\n=== Поиск диапазона ID (от 10 до 20) ===");
            var rangeRows = employeesTable.AsEnumerable()
                .Where(row => Convert.ToInt32(row["EmployeeID"]) >= 10 &&
                             Convert.ToInt32(row["EmployeeID"]) <= 20)
                .ToArray();

            Console.WriteLine($"Найдено {rangeRows.Length} сотрудников в диапазоне");

            // 7. Обработка исключений
            Console.WriteLine("\n=== Обработка исключений ===");

            try
            {
                // Попытка поиска с неверным типом данных
                DataRow invalidRow = employeesTable.Rows.Find("не число");
                Console.WriteLine("Поиск с неверным типом: OK");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при поиске: {ex.Message}");
            }

            try
            {
                // Поиск с null ID
                DataRow nullRow = employeesTable.Rows.Find(null);
                Console.WriteLine("Поиск с null: OK");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при поиске null: {ex.Message}");
            }
        }
        #endregion

        #region Задание 3: Фильтрация данных с Select()
        static void Task3()
        {
            Console.WriteLine("Задание 3: Фильтрация данных с Select()\n");

            // 1. Создаем таблицу заказов
            DataTable ordersTable = CreateOrdersTable();
            FillOrdersTable(ordersTable, 150);

            Console.WriteLine($"Таблица содержит {ordersTable.Rows.Count} заказов");

            // 2. Различные фильтры через Select()
            Console.WriteLine("\n=== Различные фильтры Select() ===");

            // 2.1. Заказы с суммой больше 1000
            DataRow[] highAmountOrders = ordersTable.Select("Amount > 1000");
            Console.WriteLine($"\nЗаказы с суммой > 1000: {highAmountOrders.Length}");

            // 2.2. Заказы определенного статуса
            string[] statuses = { "Pending", "Processing", "Shipped", "Delivered", "Cancelled" };
            foreach (var status in statuses)
            {
                DataRow[] statusOrders = ordersTable.Select($"Status = '{status}'");
                Console.WriteLine($"Заказы со статусом {status}: {statusOrders.Length}");
            }

            // 2.3. Заказы в диапазоне дат
            DateTime startDate = DateTime.Today.AddDays(-30);
            DateTime endDate = DateTime.Today;
            string dateFilter = $"OrderDate >= #{startDate:MM/dd/yyyy}# AND OrderDate <= #{endDate:MM/dd/yyyy}#";
            DataRow[] dateRangeOrders = ordersTable.Select(dateFilter);
            Console.WriteLine($"\nЗаказы за последние 30 дней: {dateRangeOrders.Length}");

            // 2.4. Комбинированные фильтры
            DataRow[] combinedOrders = ordersTable.Select("Status = 'Delivered' AND Amount > 500");
            Console.WriteLine($"Доставленные заказы > 500: {combinedOrders.Length}");

            // 2.5. Заказы определенного клиента
            DataRow[] customerOrders = ordersTable.Select("CustomerID = 5");
            Console.WriteLine($"Заказы клиента ID=5: {customerOrders.Length}");

            // 2.6. Поиск с LIKE в адресе
            DataRow[] addressOrders = ordersTable.Select("ShippingAddress LIKE '%Street%'");
            Console.WriteLine($"Заказы с адресом содержащим 'Street': {addressOrders.Length}");

            // 3. Сортировка через второй параметр Select()
            Console.WriteLine("\n=== Сортировка результатов ===");

            DataRow[] sortedOrders = ordersTable.Select("Amount > 100", "Amount DESC, OrderDate ASC");
            Console.WriteLine($"Отсортированные заказы > 100: {sortedOrders.Length}");

            if (sortedOrders.Length > 0)
            {
                Console.WriteLine("\nПервые 3 заказа:");
                for (int i = 0; i < Math.Min(3, sortedOrders.Length); i++)
                {
                    Console.WriteLine($"  Заказ {sortedOrders[i]["OrderID"]}: {sortedOrders[i]["Amount"]} - {sortedOrders[i]["OrderDate"]}");
                }
            }

            // 4. Сравнение с LINQ
            Console.WriteLine("\n=== Сравнение с LINQ ===");

            Stopwatch sw = new Stopwatch();

            sw.Start();
            var linqResult = ordersTable.AsEnumerable()
                .Where(row => Convert.ToDecimal(row["Amount"]) > 1000 &&
                             row["Status"].ToString() == "Delivered")
                .OrderByDescending(row => Convert.ToDateTime(row["OrderDate"]))
                .ToList();
            sw.Stop();
            long linqTime = sw.ElapsedTicks;

            sw.Restart();
            DataRow[] selectResult = ordersTable.Select("Amount > 1000 AND Status = 'Delivered'", "OrderDate DESC");
            sw.Stop();
            long selectTime = sw.ElapsedTicks;

            Console.WriteLine($"LINQ: {linqResult.Count} заказов за {linqTime} тиков");
            Console.WriteLine($"Select(): {selectResult.Length} заказов за {selectTime} тиков");

            // 5. Динамическое построение фильтра
            Console.WriteLine("\n=== Динамическое построение фильтра ===");

            var filterParams = new Dictionary<string, object>
            {
                { "MinAmount", 100 },
                { "Status", "Processing" },
                { "CustomerID", null },
                { "StartDate", DateTime.Today.AddDays(-7) }
            };

            string dynamicFilter = BuildDynamicFilter(filterParams);
            Console.WriteLine($"Динамический фильтр: {dynamicFilter}");

            DataRow[] dynamicOrders = ordersTable.Select(dynamicFilter);
            Console.WriteLine($"Найдено заказов: {dynamicOrders.Length}");

            // 6. Обработка ошибок синтаксиса
            Console.WriteLine("\n=== Обработка ошибок синтаксиса ===");

            try
            {
                DataRow[] errorOrders = ordersTable.Select("Amount > 'не число'");
                Console.WriteLine("Ошибка не произошла");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка синтаксиса: {ex.Message}");
            }

            // 7. Производительность для большого числа записей
            Console.WriteLine("\n=== Производительность для 1000 операций ===");

            sw.Restart();
            for (int i = 0; i < 1000; i++)
            {
                DataRow[] temp = ordersTable.Select($"Amount > {i % 200}");
            }
            sw.Stop();
            Console.WriteLine($"1000 операций Select(): {sw.ElapsedMilliseconds} ms");
        }
        #endregion

        #region Задание 4: Создание DataView различными способами
        static void Task4()
        {
            Console.WriteLine("Задание 4: Создание DataView различными способами\n");

            // 1. Создаем таблицу студентов
            DataTable studentsTable = new DataTable("Students");

            studentsTable.Columns.Add("StudentID", typeof(int));
            studentsTable.Columns.Add("Name", typeof(string));
            studentsTable.Columns.Add("GPA", typeof(double));
            studentsTable.Columns.Add("Speciality", typeof(string));
            studentsTable.Columns.Add("EnrollmentYear", typeof(int));

            // 2. Заполняем таблицу
            Random rand = new Random();
            string[] specialities = { "Computer Science", "Mathematics", "Physics",
                                     "Chemistry", "Biology", "Economics", "Law" };

            for (int i = 1; i <= 100; i++)
            {
                studentsTable.Rows.Add(
                    i,
                    $"Студент {i}",
                    Math.Round(2 + rand.NextDouble() * 3, 2), // GPA от 2.0 до 5.0
                    specialities[rand.Next(specialities.Length)],
                    rand.Next(2018, 2024)
                );
            }

            Console.WriteLine($"Таблица содержит {studentsTable.Rows.Count} студентов");

            // 3. Создание DataView различными способами
            Console.WriteLine("\n=== Способ 1: new DataView(table) ===");
            DataView view1 = new DataView(studentsTable);
            PrintDataViewInfo(view1);

            Console.WriteLine("\n=== Способ 2: new DataView(table, фильтр, сортировка, состояние) ===");
            DataView view2 = new DataView(studentsTable,
                "GPA > 3.5",
                "Name ASC",
                DataViewRowState.CurrentRows);
            PrintDataViewInfo(view2);

            Console.WriteLine("\n=== Способ 3: Через таблицу.DefaultView ===");
            DataView view3 = studentsTable.DefaultView;
            PrintDataViewInfo(view3);

            Console.WriteLine("\n=== Способ 4: Через конструктор с последующим назначением фильтра ===");
            DataView view4 = new DataView(studentsTable);
            view4.RowFilter = "Speciality = 'Computer Science' AND EnrollmentYear >= 2020";
            view4.Sort = "GPA DESC";
            PrintDataViewInfo(view4);

            // 4. Сравнение способов
            Console.WriteLine("\n=== Сравнение способов создания ===");
            Console.WriteLine($"Способ 1: Базовый DataView, строк: {view1.Count}");
            Console.WriteLine($"Способ 2: С фильтром GPA>3.5, строк: {view2.Count}");
            Console.WriteLine($"Способ 3: DefaultView (как способ 1), строк: {view3.Count}");
            Console.WriteLine($"Способ 4: С комплексным фильтром, строк: {view4.Count}");

            // 5. Изменение фильтра после создания
            Console.WriteLine("\n=== Изменение фильтра после создания ===");
            Console.WriteLine($"Исходное количество в view4: {view4.Count}");

            view4.RowFilter = "GPA > 4.0";
            Console.WriteLine($"После изменения фильтра на GPA>4.0: {view4.Count}");

            // 6. Отражение изменений в исходной таблице
            Console.WriteLine("\n=== Отражение изменений в исходной таблице ===");
            Console.WriteLine($"Количество в view2 до изменения: {view2.Count}");

            // Добавляем нового студента с высоким GPA
            DataRow newStudent = studentsTable.NewRow();
            newStudent["StudentID"] = 101;
            newStudent["Name"] = "Новый студент";
            newStudent["GPA"] = 4.5;
            newStudent["Speciality"] = "Computer Science";
            newStudent["EnrollmentYear"] = 2024;
            studentsTable.Rows.Add(newStudent);

            Console.WriteLine($"Количество в view2 после добавления: {view2.Count}");

            // 7. Вывод содержимого первых 5 строк каждого представления
            Console.WriteLine("\n=== Содержимое первых 5 строк каждого представления ===");

            Console.WriteLine("\nview2 (GPA > 3.5, сортировка по имени):");
            for (int i = 0; i < Math.Min(5, view2.Count); i++)
            {
                Console.WriteLine($"  {view2[i]["Name"]}: GPA={view2[i]["GPA"]}, {view2[i]["Speciality"]}");
            }

            Console.WriteLine("\nview4 (GPA > 4.0):");
            for (int i = 0; i < Math.Min(5, view4.Count); i++)
            {
                Console.WriteLine($"  {view4[i]["Name"]}: GPA={view4[i]["GPA"]}, {view4[i]["Speciality"]}");
            }
        }

        static void PrintDataViewInfo(DataView view)
        {
            Console.WriteLine($"Количество строк: {view.Count}");
            Console.WriteLine($"Фильтр: {(string.IsNullOrEmpty(view.RowFilter) ? "(нет)" : view.RowFilter)}");
            Console.WriteLine($"Сортировка: {(string.IsNullOrEmpty(view.Sort) ? "(нет)" : view.Sort)}");
            Console.WriteLine($"Состояние строк: {view.RowStateFilter}");
        }
        #endregion

        #region Задание 5: Сортировка и фильтрация в DataView
        static void Task5()
        {
            Console.WriteLine("Задание 5: Сортировка и фильтрация в DataView\n");

            // 1. Создаем таблицу продаж
            DataTable salesTable = new DataTable("Sales");

            salesTable.Columns.Add("SalesID", typeof(int));
            salesTable.Columns.Add("ProductName", typeof(string));
            salesTable.Columns.Add("SalesDate", typeof(DateTime));
            salesTable.Columns.Add("Quantity", typeof(int));
            salesTable.Columns.Add("Price", typeof(decimal));
            salesTable.Columns.Add("Salesperson", typeof(string));
            salesTable.Columns.Add("Region", typeof(string));

            // 2. Заполняем таблицу
            Random rand = new Random();
            string[] products = { "Laptop", "Phone", "Tablet", "Monitor", "Keyboard", "Mouse" };
            string[] salespersons = { "Иван", "Мария", "Петр", "Анна", "Сергей", "Ольга" };
            string[] regions = { "Север", "Юг", "Запад", "Восток", "Центр" };

            for (int i = 1; i <= 250; i++)
            {
                int quantity = rand.Next(1, 10);
                decimal price = rand.Next(100, 2000);

                salesTable.Rows.Add(
                    i,
                    products[rand.Next(products.Length)],
                    DateTime.Today.AddDays(-rand.Next(0, 365)),
                    quantity,
                    price,
                    salespersons[rand.Next(salespersons.Length)],
                    regions[rand.Next(regions.Length)]
                );
            }

            Console.WriteLine($"Таблица содержит {salesTable.Rows.Count} записей о продажах");

            // 3. Создаем DataView и реализуем операции
            DataView salesView = new DataView(salesTable);

            Console.WriteLine("\n=== Операции фильтрации ===");

            // 3.1. Фильтрация по регионам
            salesView.RowFilter = "Region = 'Север'";
            Console.WriteLine($"Продажи в регионе 'Север': {salesView.Count} записей");

            // 3.2. Фильтрация по диапазону дат
            DateTime startDate = DateTime.Today.AddDays(-30);
            DateTime endDate = DateTime.Today;
            salesView.RowFilter = $"SalesDate >= #{startDate:MM/dd/yyyy}# AND SalesDate <= #{endDate:MM/dd/yyyy}#";
            Console.WriteLine($"Продажи за последние 30 дней: {salesView.Count} записей");

            // 3.3. Фильтрация по минимальной сумме продажи
            salesView.RowFilter = "Quantity * Price > 1000";
            Console.WriteLine($"Продажи на сумму > 1000: {salesView.Count} записей");

            // 3.4. Комбинированные фильтры
            salesView.RowFilter = "Region = 'Центр' AND Salesperson = 'Иван' AND Quantity * Price > 500";
            Console.WriteLine($"Продажи Ивана в Центре на сумму > 500: {salesView.Count} записей");

            // 4. Операции сортировки
            Console.WriteLine("\n=== Операции сортировки ===");

            // 4.1. Сортировка по дате (возрастание)
            salesView.RowFilter = "";
            salesView.Sort = "SalesDate ASC";
            Console.WriteLine("\nПервые 3 продажи (по возрастанию даты):");
            for (int i = 0; i < Math.Min(3, salesView.Count); i++)
            {
                Console.WriteLine($"  {salesView[i]["SalesDate"]}: {salesView[i]["ProductName"]} - {salesView[i]["Salesperson"]}");
            }

            // 4.2. Сортировка по дате (убывание)
            salesView.Sort = "SalesDate DESC";
            Console.WriteLine("\nПоследние 3 продажи (по убыванию даты):");
            for (int i = 0; i < Math.Min(3, salesView.Count); i++)
            {
                Console.WriteLine($"  {salesView[i]["SalesDate"]}: {salesView[i]["ProductName"]} - {salesView[i]["Salesperson"]}");
            }

            // 4.3. Сортировка по продавцу
            salesView.Sort = "Salesperson ASC";
            Console.WriteLine("\nПродажи, отсортированные по продавцу (первые 3):");
            for (int i = 0; i < Math.Min(3, salesView.Count); i++)
            {
                Console.WriteLine($"  {salesView[i]["Salesperson"]}: {salesView[i]["ProductName"]}");
            }

            // 4.4. Многоуровневая сортировка
            salesView.Sort = "Region ASC, SalesDate DESC";
            Console.WriteLine("\nМногоуровневая сортировка (регион по возрастанию, дата по убыванию):");
            Console.WriteLine("Первые 5 записей:");
            for (int i = 0; i < Math.Min(5, salesView.Count); i++)
            {
                Console.WriteLine($"  {salesView[i]["Region"]} | {salesView[i]["SalesDate"]} | {salesView[i]["ProductName"]}");
            }

            // 5. Динамическое изменение Sort
            Console.WriteLine("\n=== Динамическое изменение сортировки ===");

            string[] sortOptions = {
                "SalesDate ASC",
                "SalesDate DESC",
                "Salesperson ASC",
                "Salesperson DESC",
                "Region ASC, SalesDate DESC",
                "Quantity * Price DESC"
            };

            foreach (var sortOption in sortOptions)
            {
                try
                {
                    salesView.Sort = sortOption;
                    Console.WriteLine($"Сортировка '{sortOption}': {salesView.Count} записей");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при сортировке '{sortOption}': {ex.Message}");
                }
            }

            // 6. Сброс фильтров и сортировки
            Console.WriteLine("\n=== Сброс фильтров и сортировки ===");
            salesView.RowFilter = "";
            salesView.Sort = "";
            Console.WriteLine($"После сброса: {salesView.Count} записей");

            // 7. Вывод текущего состояния
            Console.WriteLine("\n=== Текущее состояние DataView ===");
            Console.WriteLine($"Фильтр: {salesView.RowFilter}");
            Console.WriteLine($"Сортировка: {salesView.Sort}");
            Console.WriteLine($"Количество отфильтрованных записей: {salesView.Count}");

            // 8. Обработка ошибок синтаксиса
            Console.WriteLine("\n=== Обработка ошибок синтаксиса ===");

            try
            {
                salesView.RowFilter = "InvalidColumn > 100";
                Console.WriteLine("Фильтр установлен");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка в синтаксисе фильтра: {ex.Message}");
            }
        }
        #endregion

        #region Задание 6: DataViewRowState для фильтрации по состоянию строк
        static void Task6()
        {
            Console.WriteLine("Задание 6: DataViewRowState для фильтрации по состоянию строк\n");

            // 1. Создаем таблицу счетов
            DataTable invoicesTable = new DataTable("Invoices");

            invoicesTable.Columns.Add("InvoiceID", typeof(int));
            invoicesTable.Columns.Add("CustomerName", typeof(string));
            invoicesTable.Columns.Add("Amount", typeof(decimal));
            invoicesTable.Columns.Add("Status", typeof(string));
            invoicesTable.Columns.Add("DueDate", typeof(DateTime));

            // 2. Заполняем таблицу начальными данными
            for (int i = 1; i <= 20; i++)
            {
                invoicesTable.Rows.Add(
                    i,
                    $"Клиент {i}",
                    100 * i,
                    "Pending",
                    DateTime.Today.AddDays(30)
                );
            }

            Console.WriteLine($"Исходная таблица содержит {invoicesTable.Rows.Count} счетов");

            // 3. Выполняем операции изменения
            Console.WriteLine("\n=== Выполнение операций изменения ===");

            // 3.1. Добавляем 5 новых счетов
            Console.WriteLine("Добавляем 5 новых счетов...");
            for (int i = 21; i <= 25; i++)
            {
                DataRow newRow = invoicesTable.NewRow();
                newRow["InvoiceID"] = i;
                newRow["CustomerName"] = $"Новый клиент {i}";
                newRow["Amount"] = 500 + i * 10;
                newRow["Status"] = "New";
                newRow["DueDate"] = DateTime.Today.AddDays(60);
                invoicesTable.Rows.Add(newRow);
            }

            // 3.2. Модифицируем 3 существующих счета
            Console.WriteLine("Модифицируем 3 существующих счета...");
            invoicesTable.Rows[0]["Status"] = "Paid";
            invoicesTable.Rows[0]["Amount"] = 150;

            invoicesTable.Rows[1]["CustomerName"] = "Измененный клиент";
            invoicesTable.Rows[1]["DueDate"] = DateTime.Today.AddDays(15);

            invoicesTable.Rows[2]["Status"] = "Cancelled";
            invoicesTable.Rows[2]["Amount"] = 0;

            // 3.3. Удаляем 2 счета (через Delete())
            Console.WriteLine("Удаляем 2 счета...");
            invoicesTable.Rows[3].Delete();
            invoicesTable.Rows[4].Delete();

            // 4. Создаем DataView с разными значениями DataViewRowState
            Console.WriteLine("\n=== DataView с разными DataViewRowState ===");

            // 4.1. CurrentRows (только текущие строки, без удаленных)
            DataView currentRowsView = new DataView(invoicesTable)
            {
                RowStateFilter = DataViewRowState.CurrentRows
            };
            Console.WriteLine($"\nDataViewRowState.CurrentRows: {currentRowsView.Count} строк");
            PrintDataViewSample(currentRowsView, 3);

            // 4.2. OriginalRows (только оригинальные строки)
            DataView originalRowsView = new DataView(invoicesTable)
            {
                RowStateFilter = DataViewRowState.OriginalRows
            };
            Console.WriteLine($"\nDataViewRowState.OriginalRows: {originalRowsView.Count} строк");
            PrintDataViewSample(originalRowsView, 3);

            // 4.3. Added (только добавленные)
            DataView addedRowsView = new DataView(invoicesTable)
            {
                RowStateFilter = DataViewRowState.Added
            };
            Console.WriteLine($"\nDataViewRowState.Added: {addedRowsView.Count} строк");
            PrintDataViewSample(addedRowsView, 5);

            // 4.4. ModifiedCurrent (текущие версии измененных строк)
            DataView modifiedCurrentView = new DataView(invoicesTable)
            {
                RowStateFilter = DataViewRowState.ModifiedCurrent
            };
            Console.WriteLine($"\nDataViewRowState.ModifiedCurrent: {modifiedCurrentView.Count} строк");
            PrintDataViewSample(modifiedCurrentView, 3);

            // 4.5. ModifiedOriginal (оригинальные версии измененных строк)
            DataView modifiedOriginalView = new DataView(invoicesTable)
            {
                RowStateFilter = DataViewRowState.ModifiedOriginal
            };
            Console.WriteLine($"\nDataViewRowState.ModifiedOriginal: {modifiedOriginalView.Count} строк");

            // 4.6. Deleted (только удаленные)
            DataView deletedRowsView = new DataView(invoicesTable)
            {
                RowStateFilter = DataViewRowState.Deleted
            };
            Console.WriteLine($"\nDataViewRowState.Deleted: {deletedRowsView.Count} строк");

            // 4.7. Комбинированные (Added | Modified)
            DataView addedOrModifiedView = new DataView(invoicesTable)
            {
                RowStateFilter = DataViewRowState.Added | DataViewRowState.ModifiedCurrent
            };
            Console.WriteLine($"\nDataViewRowState.Added | ModifiedCurrent: {addedOrModifiedView.Count} строк");

            // 5. Отчёт о всех изменениях перед AcceptChanges()
            Console.WriteLine("\n=== Отчёт о всех изменениях ===");
            Console.WriteLine($"Всего строк в таблице: {invoicesTable.Rows.Count}");

            int addedCount = 0, modifiedCount = 0, deletedCount = 0, unchangedCount = 0;
            foreach (DataRow row in invoicesTable.Rows)
            {
                switch (row.RowState)
                {
                    case DataRowState.Added: addedCount++; break;
                    case DataRowState.Modified: modifiedCount++; break;
                    case DataRowState.Deleted: deletedCount++; break;
                    case DataRowState.Unchanged: unchangedCount++; break;
                }
            }

            Console.WriteLine($"Добавлено: {addedCount}");
            Console.WriteLine($"Изменено: {modifiedCount}");
            Console.WriteLine($"Удалено: {deletedCount}");
            Console.WriteLine($"Неизменено: {unchangedCount}");

            // 6. Функция отката изменений
            Console.WriteLine("\n=== Функция отката изменений ===");

            Console.WriteLine($"Количество перед откатом: {invoicesTable.Rows.Count}");

            // Откатываем изменения для первой строки
            if (invoicesTable.Rows[0].RowState == DataRowState.Modified)
            {
                invoicesTable.Rows[0].RejectChanges();
                Console.WriteLine("Изменения для первой строки отменены");
            }

            // Проверяем состояние после отката
            Console.WriteLine($"Состояние первой строки после отката: {invoicesTable.Rows[0].RowState}");
            Console.WriteLine($"Значение Status: {invoicesTable.Rows[0]["Status"]}");

            // 7. AcceptChanges() и проверка состояния
            Console.WriteLine("\n=== После AcceptChanges() ===");

            invoicesTable.AcceptChanges();

            DataView afterAcceptView = new DataView(invoicesTable)
            {
                RowStateFilter = DataViewRowState.CurrentRows
            };

            Console.WriteLine($"Строк после AcceptChanges(): {afterAcceptView.Count}");
            Console.WriteLine("Все изменения приняты, RowState сброшен в Unchanged");
        }

        static void PrintDataViewSample(DataView view, int count)
        {
            if (view.Count == 0)
            {
                Console.WriteLine("  (нет данных)");
                return;
            }

            for (int i = 0; i < Math.Min(count, view.Count); i++)
            {
                try
                {
                    Console.WriteLine($"  ID: {view[i]["InvoiceID"]}, Клиент: {view[i]["CustomerName"]}, " +
                                    $"Сумма: {view[i]["Amount"]}, Статус: {view[i]["Status"]}");
                }
                catch (Exception)
                {
                    // Для удаленных строк некоторые значения могут быть недоступны
                    Console.WriteLine($"  (удаленная строка)");
                }
            }

            if (view.Count > count)
            {
                Console.WriteLine($"  ... и еще {view.Count - count} строк");
            }
        }
        #endregion

        #region Задание 7: Поиск в DataView с Find()
        static void Task7()
        {
            Console.WriteLine("Задание 7: Поиск данных в DataView с использованием метода Find()\n");

            // 1. Создаем таблицу книг
            DataTable booksTable = new DataTable("Books");

            booksTable.Columns.Add("BookID", typeof(int));
            booksTable.Columns.Add("Title", typeof(string));
            booksTable.Columns.Add("Author", typeof(string));
            booksTable.Columns.Add("ISBN", typeof(string));
            booksTable.Columns.Add("Year", typeof(int));
            booksTable.Columns.Add("Price", typeof(decimal));
            booksTable.Columns.Add("Category", typeof(string));

            // Устанавливаем первичный ключ
            booksTable.PrimaryKey = new DataColumn[] { booksTable.Columns["BookID"] };

            // 2. Заполняем таблицу
            Random rand = new Random();
            string[] categories = { "Fiction", "Science", "Technology", "History", "Biography" };
            string[] authors = { "Author A", "Author B", "Author C", "Author D", "Author E" };

            for (int i = 1; i <= 100; i++)
            {
                booksTable.Rows.Add(
                    i,
                    $"Book Title {i}",
                    authors[rand.Next(authors.Length)],
                    $"ISBN-{rand.Next(1000, 9999)}-{rand.Next(1000, 9999)}",
                    rand.Next(2000, 2024),
                    Math.Round(rand.Next(100, 1000) + (decimal)rand.NextDouble(), 2),
                    categories[rand.Next(categories.Length)]
                );
            }

            Console.WriteLine($"Таблица содержит {booksTable.Rows.Count} книг");

            // 3. Создаем DataView с фильтром по категории
            DataView fictionView = new DataView(booksTable)
            {
                RowFilter = "Category = 'Fiction'",
                Sort = "Title ASC"
            };

            Console.WriteLine($"\nDataView с фильтром Category='Fiction': {fictionView.Count} книг");

            // 4. Поиск книги по ISBN
            Console.WriteLine("\n=== Поиск книги по ISBN ===");

            // Создаем DataView отсортированный по ISBN для поиска
            DataView isbnView = new DataView(booksTable)
            {
                Sort = "ISBN ASC"
            };

            string searchISBN = booksTable.Rows[49]["ISBN"].ToString(); // Берем ISBN 50-й книги
            int foundIndex = isbnView.Find(searchISBN);

            if (foundIndex >= 0)
            {
                Console.WriteLine($"Найдена книга с ISBN {searchISBN} на позиции {foundIndex}:");
                Console.WriteLine($"  Название: {isbnView[foundIndex]["Title"]}");
                Console.WriteLine($"  Автор: {isbnView[foundIndex]["Author"]}");
                Console.WriteLine($"  Цена: {isbnView[foundIndex]["Price"]}");
            }
            else
            {
                Console.WriteLine($"Книга с ISBN {searchISBN} не найдена");
            }

            // 5. Проверка работы Find() на DataView
            Console.WriteLine("\n=== Проверка Find() на DataView ===");

            // Создаем DataView отсортированный по BookID
            DataView idView = new DataView(booksTable)
            {
                Sort = "BookID ASC"
            };

            int searchId = 25;
            int idIndex = idView.Find(searchId);

            if (idIndex >= 0)
            {
                Console.WriteLine($"Книга с ID={searchId} найдена на позиции {idIndex}");
            }

            // 6. Сравнение производительности Find() в DataTable vs DataView
            Console.WriteLine("\n=== Сравнение производительности Find() ===");

            Stopwatch sw = new Stopwatch();

            // Поиск в DataTable по первичному ключу
            sw.Start();
            DataRow tableFindResult = booksTable.Rows.Find(searchId);
            sw.Stop();
            long tableFindTime = sw.ElapsedTicks;

            // Поиск в DataView
            sw.Restart();
            int viewFindResult = idView.Find(searchId);
            sw.Stop();
            long viewFindTime = sw.ElapsedTicks;

            Console.WriteLine($"DataTable.Find(): {tableFindTime} тиков");
            Console.WriteLine($"DataView.Find(): {viewFindTime} тиков");

            // 7. Поиск по нескольким критериям
            Console.WriteLine("\n=== Поиск по нескольким критериям ===");

            DataView authorYearView = new DataView(booksTable)
            {
                RowFilter = "Author = 'Author A' AND Year = 2020",
                Sort = "Title ASC"
            };

            Console.WriteLine($"Книги Author A, 2020 год: {authorYearView.Count}");

            // 8. Поиск с использованием BinarySearch()
            Console.WriteLine("\n=== Использование BinarySearch() ===");

            if (idView.Count > 0)
            {
                // DataView должен быть отсортирован для BinarySearch
                object[] keys = new object[] { searchId };
                int binaryIndex = idView.Find(keys);
                Console.WriteLine($"BinarySearch для ID={searchId}: индекс {binaryIndex}");
            }

            // 9. Обработка случаев, когда книга не найдена
            Console.WriteLine("\n=== Обработка не найденных книг ===");

            int notFoundIndex = idView.Find(9999);
            if (notFoundIndex < 0)
            {
                Console.WriteLine("Книга с ID=9999 не найдена (возвращен индекс: " + notFoundIndex + ")");
            }

            // 10. Вывод результатов
            Console.WriteLine("\n=== Пример найденных книг ===");
            Console.WriteLine("Первые 5 книг в DataView (Fiction категория):");
            for (int i = 0; i < Math.Min(5, fictionView.Count); i++)
            {
                Console.WriteLine($"  {fictionView[i]["Title"]} - {fictionView[i]["Author"]} - {fictionView[i]["Year"]}");
            }
        }
        #endregion

        #region Задание 8: Добавление данных через DataView
        static void Task8()
        {
            Console.WriteLine("Задание 8: Добавление данных через DataView\n");

            // 1. Создаем таблицу клиентов
            DataTable customersTable = new DataTable("Customers");

            customersTable.Columns.Add("CustomerID", typeof(int));
            customersTable.Columns.Add("Name", typeof(string));
            customersTable.Columns.Add("Email", typeof(string));
            customersTable.Columns.Add("Phone", typeof(string));
            customersTable.Columns.Add("City", typeof(string));
            customersTable.Columns.Add("Status", typeof(string));

            // Добавляем ограничения
            customersTable.Columns["CustomerID"].Unique = true;
            customersTable.Columns["Name"].AllowDBNull = false;
            customersTable.Columns["Email"].AllowDBNull = false;

            // 2. Заполняем таблицу начальными данными
            for (int i = 1; i <= 20; i++)
            {
                customersTable.Rows.Add(
                    i,
                    $"Клиент {i}",
                    $"client{i}@email.com",
                    $"+7({rand.Next(900, 999)}){rand.Next(100, 999)}-{rand.Next(10, 99)}-{rand.Next(10, 99)}",
                    i % 2 == 0 ? "Москва" : "Санкт-Петербург",
                    i % 3 == 0 ? "Inactive" : "Active"
                );
            }

            Console.WriteLine($"Исходная таблица содержит {customersTable.Rows.Count} клиентов");

            // 3. Создаем DataView с фильтром по статусу Active
            DataView activeCustomersView = new DataView(customersTable)
            {
                RowFilter = "Status = 'Active'",
                Sort = "Name ASC"
            };

            Console.WriteLine($"\nDataView с фильтром Status='Active': {activeCustomersView.Count} клиентов");

            // 4. Добавление новых клиентов
            Console.WriteLine("\n=== Добавление новых клиентов ===");

            // 4.1. Добавление через DataView.AddNew()
            Console.WriteLine("\n--- Способ 1: DataView.AddNew() ---");

            DataRowView newRowView = activeCustomersView.AddNew();
            newRowView["CustomerID"] = 21;
            newRowView["Name"] = "Новый клиент через AddNew";
            newRowView["Email"] = "new@email.com";
            newRowView["Phone"] = "+7(999)123-45-67";
            newRowView["City"] = "Москва";
            newRowView["Status"] = "Active";
            newRowView.EndEdit();

            Console.WriteLine($"После AddNew: {activeCustomersView.Count} активных клиентов");
            Console.WriteLine($"Всего клиентов в таблице: {customersTable.Rows.Count}");

            // 4.2. Добавление через исходную таблицу
            Console.WriteLine("\n--- Способ 2: Добавление в исходную таблицу ---");

            Console.WriteLine($"Количество в DataView перед добавлением: {activeCustomersView.Count}");

            DataRow newTableRow = customersTable.NewRow();
            newTableRow["CustomerID"] = 22;
            newTableRow["Name"] = "Новый клиент в таблицу";
            newTableRow["Email"] = "table@email.com";
            newTableRow["Phone"] = "+7(999)987-65-43";
            newTableRow["City"] = "Санкт-Петербург";
            newTableRow["Status"] = "Active";
            customersTable.Rows.Add(newTableRow);

            Console.WriteLine($"После добавления в таблицу: {activeCustomersView.Count} активных клиентов");

            // 4.3. Добавление клиента с нарушением фильтра
            Console.WriteLine("\n--- Способ 3: Клиент с Status='Inactive' ---");

            DataRow inactiveRow = customersTable.NewRow();
            inactiveRow["CustomerID"] = 23;
            inactiveRow["Name"] = "Неактивный клиент";
            inactiveRow["Email"] = "inactive@email.com";
            inactiveRow["Phone"] = "+7(999)111-22-33";
            inactiveRow["City"] = "Москва";
            inactiveRow["Status"] = "Inactive";
            customersTable.Rows.Add(inactiveRow);

            Console.WriteLine($"После добавления неактивного клиента: {activeCustomersView.Count} активных клиентов");

            // 5. Валидация при добавлении
            Console.WriteLine("\n=== Валидация при добавлении ===");

            try
            {
                DataRowView invalidRowView = activeCustomersView.AddNew();
                invalidRowView["CustomerID"] = 24;
                invalidRowView["Name"] = ""; // Пустое имя
                invalidRowView["Email"] = "invalid-email"; // Неправильный email
                invalidRowView["Phone"] = "123";
                invalidRowView["City"] = "Москва";
                invalidRowView["Status"] = "Active";
                invalidRowView.EndEdit();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка валидации: {ex.Message}");
            }

            // 6. Обработка исключений
            Console.WriteLine("\n=== Обработка исключений ===");

            try
            {
                // Попытка добавить клиента с существующим ID
                DataRowView duplicateRowView = activeCustomersView.AddNew();
                duplicateRowView["CustomerID"] = 21; // Уже существует
                duplicateRowView["Name"] = "Дубликат";
                duplicateRowView["Email"] = "duplicate@email.com";
                duplicateRowView.EndEdit();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при добавлении дубликата: {ex.Message}");
            }

            try
            {
                // Попытка добавить клиента с NULL именем
                DataRowView nullNameRowView = activeCustomersView.AddNew();
                nullNameRowView["CustomerID"] = 25;
                nullNameRowView["Name"] = null; // NOT NULL ограничение
                nullNameRowView.EndEdit();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при добавлении NULL имени: {ex.Message}");
            }

            // 7. Автоматическое обновление ID
            Console.WriteLine("\n=== Автоматическое обновление ID ===");

            // Находим максимальный ID
            int maxId = customersTable.AsEnumerable()
                .Select(row => Convert.ToInt32(row["CustomerID"]))
                .DefaultIfEmpty(0)
                .Max();

            Console.WriteLine($"Текущий максимальный ID: {maxId}");

            // Добавляем клиента с следующим ID
            DataRow autoIdRow = customersTable.NewRow();
            autoIdRow["CustomerID"] = maxId + 1;
            autoIdRow["Name"] = "Автоматический ID";
            autoIdRow["Email"] = $"auto{maxId + 1}@email.com";
            autoIdRow["Phone"] = "+7(999)999-99-99";
            autoIdRow["City"] = "Москва";
            autoIdRow["Status"] = "Active";
            customersTable.Rows.Add(autoIdRow);

            Console.WriteLine($"Добавлен клиент с ID: {maxId + 1}");

            // 8. Вывод всех клиентов
            Console.WriteLine("\n=== Все клиенты после добавления ===");
            Console.WriteLine($"Всего клиентов: {customersTable.Rows.Count}");

            DataView allCustomersView = new DataView(customersTable)
            {
                Sort = "CustomerID ASC"
            };

            for (int i = 0; i < Math.Min(10, allCustomersView.Count); i++)
            {
                Console.WriteLine($"  ID: {allCustomersView[i]["CustomerID"]}, " +
                                $"Имя: {allCustomersView[i]["Name"]}, " +
                                $"Статус: {allCustomersView[i]["Status"]}");
            }

            if (allCustomersView.Count > 10)
            {
                Console.WriteLine($"  ... и еще {allCustomersView.Count - 10} клиентов");
            }

            // 9. Влияние на другие DataView
            Console.WriteLine("\n=== Влияние на другие DataView ===");

            DataView moscowCustomersView = new DataView(customersTable)
            {
                RowFilter = "City = 'Москва'",
                Sort = "Name ASC"
            };

            DataView inactiveCustomersView = new DataView(customersTable)
            {
                RowFilter = "Status = 'Inactive'",
                Sort = "Name ASC"
            };

            Console.WriteLine($"Клиенты в Москве: {moscowCustomersView.Count}");
            Console.WriteLine($"Неактивные клиенты: {inactiveCustomersView.Count}");

            // Добавляем нового клиента
            DataRow newClientRow = customersTable.NewRow();
            newClientRow["CustomerID"] = maxId + 2;
            newClientRow["Name"] = "Тестовый клиент";
            newClientRow["Email"] = "test@email.com";
            newClientRow["Phone"] = "+7(999)555-55-55";
            newClientRow["City"] = "Москва";
            newClientRow["Status"] = "Inactive";
            customersTable.Rows.Add(newClientRow);

            Console.WriteLine($"\nПосле добавления тестового клиента:");
            Console.WriteLine($"Активных клиентов: {activeCustomersView.Count}");
            Console.WriteLine($"Клиентов в Москве: {moscowCustomersView.Count}");
            Console.WriteLine($"Неактивных клиентов: {inactiveCustomersView.Count}");
        }
        #endregion

        #region Задание 9: Редактирование данных через DataView
        static void Task9()
        {
            Console.WriteLine("Задание 9: Редактирование данных через DataView\n");

            // 1. Создаем таблицу сотрудников
            DataTable employeesTable = new DataTable("Employees");

            employeesTable.Columns.Add("EmployeeID", typeof(int));
            employeesTable.Columns.Add("Name", typeof(string));
            employeesTable.Columns.Add("Salary", typeof(decimal));
            employeesTable.Columns.Add("Department", typeof(string));
            employeesTable.Columns.Add("HireDate", typeof(DateTime));
            employeesTable.Columns.Add("Status", typeof(string));

            // Устанавливаем первичный ключ
            employeesTable.PrimaryKey = new DataColumn[] { employeesTable.Columns["EmployeeID"] };

            // 2. Заполняем таблицу
            Random rand = new Random();
            string[] departments = { "IT", "HR", "Finance", "Sales", "Marketing" };
            string[] statuses = { "Active", "OnLeave", "Inactive" };

            for (int i = 1; i <= 50; i++)
            {
                employeesTable.Rows.Add(
                    i,
                    $"Сотрудник {i}",
                    Math.Round(rand.Next(30000, 150000) + (decimal)rand.NextDouble(), 2),
                    departments[rand.Next(departments.Length)],
                    DateTime.Today.AddDays(-rand.Next(0, 3650)),
                    statuses[rand.Next(statuses.Length)]
                );
            }

            Console.WriteLine($"Таблица содержит {employeesTable.Rows.Count} сотрудников");

            // 3. Создаем DataView с фильтром по отделу IT
            DataView itDepartmentView = new DataView(employeesTable)
            {
                RowFilter = "Department = 'IT'",
                Sort = "Salary DESC"
            };

            Console.WriteLine($"\nDataView с фильтром Department='IT': {itDepartmentView.Count} сотрудников");

            // 4. Редактирование данных
            Console.WriteLine("\n=== Редактирование данных через DataView ===");

            // 4.1. Поиск сотрудника через Find()
            Console.WriteLine("\n--- Поиск и редактирование конкретного сотрудника ---");

            DataView idSortedView = new DataView(employeesTable)
            {
                Sort = "EmployeeID ASC"
            };

            int employeeIdToEdit = 10;
            int employeeIndex = idSortedView.Find(employeeIdToEdit);

            if (employeeIndex >= 0)
            {
                Console.WriteLine($"Сотрудник ID={employeeIdToEdit} найден на позиции {employeeIndex}");

                // Выводим исходные данные
                Console.WriteLine("\nИсходные данные:");
                Console.WriteLine($"  Имя: {idSortedView[employeeIndex]["Name"]}");
                Console.WriteLine($"  Зарплата: {idSortedView[employeeIndex]["Salary"]}");
                Console.WriteLine($"  Статус: {idSortedView[employeeIndex]["Status"]}");

                // Редактируем через DataView
                idSortedView[employeeIndex].BeginEdit();
                idSortedView[employeeIndex]["Salary"] = Convert.ToDecimal(idSortedView[employeeIndex]["Salary"]) * 1.1m; // +10%
                idSortedView[employeeIndex]["Status"] = "Active";
                idSortedView[employeeIndex].EndEdit();

                Console.WriteLine("\nДанные после редактирования:");
                Console.WriteLine($"  Имя: {idSortedView[employeeIndex]["Name"]}");
                Console.WriteLine($"  Зарплата: {idSortedView[employeeIndex]["Salary"]}");
                Console.WriteLine($"  Статус: {idSortedView[employeeIndex]["Status"]}");
            }

            // 4.2. Проверка отражения изменений в исходной DataTable
            Console.WriteLine("\n--- Проверка отражения изменений в исходной таблице ---");

            DataRow originalRow = employeesTable.Rows.Find(employeeIdToEdit);
            if (originalRow != null)
            {
                Console.WriteLine($"Проверка в исходной таблице для ID={employeeIdToEdit}:");
                Console.WriteLine($"  Зарплата: {originalRow["Salary"]}");
                Console.WriteLine($"  Статус: {originalRow["Status"]}");
                Console.WriteLine($"  RowState: {originalRow.RowState}");
            }

            // 4.3. Редактирование с валидацией
            Console.WriteLine("\n--- Редактирование с валидацией ---");

            try
            {
                int invalidEmployeeIndex = idSortedView.Find(15);
                if (invalidEmployeeIndex >= 0)
                {
                    idSortedView[invalidEmployeeIndex].BeginEdit();
                    idSortedView[invalidEmployeeIndex]["Salary"] = -1000; // Невалидная зарплата
                    idSortedView[invalidEmployeeIndex].EndEdit();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка валидации: {ex.Message}");
            }

            // 4.4. Массовое редактирование
            Console.WriteLine("\n--- Массовое редактирование ---");

            Console.WriteLine($"Зарплаты в отделе IT до повышения:");
            for (int i = 0; i < Math.Min(3, itDepartmentView.Count); i++)
            {
                Console.WriteLine($"  {itDepartmentView[i]["Name"]}: {itDepartmentView[i]["Salary"]}");
            }

            // Повышение зарплаты на 10% для всех в отделе IT
            for (int i = 0; i < itDepartmentView.Count; i++)
            {
                itDepartmentView[i].BeginEdit();
                decimal currentSalary = Convert.ToDecimal(itDepartmentView[i]["Salary"]);
                itDepartmentView[i]["Salary"] = Math.Round(currentSalary * 1.1m, 2);
                itDepartmentView[i].EndEdit();
            }

            Console.WriteLine($"\nЗарплаты в отделе IT после повышения на 10%:");
            for (int i = 0; i < Math.Min(3, itDepartmentView.Count); i++)
            {
                Console.WriteLine($"  {itDepartmentView[i]["Name"]}: {itDepartmentView[i]["Salary"]}");
            }

            // 4.5. Обработка исключений
            Console.WriteLine("\n--- Обработка исключений ---");

            try
            {
                // Попытка редактирования удалённой строки
                DataRow deletedRow = employeesTable.Rows[20];
                deletedRow.Delete();

                DataView testView = new DataView(employeesTable);
                int deletedIndex = testView.Find(21);
                if (deletedIndex >= 0)
                {
                    testView[deletedIndex]["Salary"] = 50000;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при редактировании удаленной строки: {ex.Message}");
            }

            // 5. Отчёт о всех изменениях
            Console.WriteLine("\n=== Отчёт о всех изменениях ===");

            DataView modifiedView = new DataView(employeesTable)
            {
                RowStateFilter = DataViewRowState.ModifiedCurrent
            };

            Console.WriteLine($"Изменено сотрудников: {modifiedView.Count}");

            if (modifiedView.Count > 0)
            {
                Console.WriteLine("\nСписок измененных сотрудников:");
                for (int i = 0; i < Math.Min(5, modifiedView.Count); i++)
                {
                    Console.WriteLine($"  {modifiedView[i]["Name"]}: " +
                                    $"Зарплата={modifiedView[i]["Salary"]}, " +
                                    $"Статус={modifiedView[i]["Status"]}");
                }
            }

            // 6. Вывод "до" и "после" для каждого изменения
            Console.WriteLine("\n=== Сравнение 'до' и 'после' ===");

            // Создаем копию таблицы до изменений
            DataTable originalTable = employeesTable.Copy();

            // Восстанавливаем оригинальные данные для сравнения
            DataView originalDataView = new DataView(originalTable);
            DataView currentDataView = new DataView(employeesTable);

            Console.WriteLine("\nСравнение зарплат для первых 5 сотрудников:");
            for (int i = 0; i < Math.Min(5, originalDataView.Count); i++)
            {
                decimal originalSalary = Convert.ToDecimal(originalDataView[i]["Salary"]);
                decimal currentSalary = Convert.ToDecimal(currentDataView[i]["Salary"]);

                if (originalSalary != currentSalary)
                {
                    Console.WriteLine($"  {originalDataView[i]["Name"]}: " +
                                    $"{originalSalary} → {currentSalary} " +
                                    $"(изменение: {((currentSalary - originalSalary) / originalSalary * 100):F2}%)");
                }
            }

            // 7. Влияние на другие DataView
            Console.WriteLine("\n=== Влияние на другие DataView ===");

            DataView activeEmployeesView = new DataView(employeesTable)
            {
                RowFilter = "Status = 'Active'",
                Sort = "Name ASC"
            };

            DataView highSalaryView = new DataView(employeesTable)
            {
                RowFilter = "Salary > 100000",
                Sort = "Salary DESC"
            };

            Console.WriteLine($"Активных сотрудников: {activeEmployeesView.Count}");
            Console.WriteLine($"Сотрудников с зарплатой > 100000: {highSalaryView.Count}");

            // Изменяем статус нескольких сотрудников
            for (int i = 0; i < Math.Min(5, currentDataView.Count); i++)
            {
                currentDataView[i].BeginEdit();
                currentDataView[i]["Status"] = "Active";
                currentDataView[i].EndEdit();
            }

            Console.WriteLine($"\nПосле изменения статуса у 5 сотрудников:");
            Console.WriteLine($"Активных сотрудников: {activeEmployeesView.Count}");
            Console.WriteLine($"Сотрудников с зарплатой > 100000: {highSalaryView.Count}");
        }
        #endregion

        #region Задание 10: Удаление данных через DataView
        static void Task10()
        {
            Console.WriteLine("Задание 10: Удаление данных через DataView\n");

            // 1. Создаем таблицу заказов
            DataTable ordersTable = new DataTable("Orders");

            ordersTable.Columns.Add("OrderID", typeof(int));
            ordersTable.Columns.Add("CustomerID", typeof(int));
            ordersTable.Columns.Add("Amount", typeof(decimal));
            ordersTable.Columns.Add("Status", typeof(string));
            ordersTable.Columns.Add("CreationDate", typeof(DateTime));

            // Устанавливаем первичный ключ
            ordersTable.PrimaryKey = new DataColumn[] { ordersTable.Columns["OrderID"] };

            // 2. Заполняем таблицу
            Random rand = new Random();
            string[] statuses = { "Pending", "Processing", "Completed", "Cancelled", "Shipped" };

            for (int i = 1; i <= 100; i++)
            {
                ordersTable.Rows.Add(
                    i,
                    rand.Next(1, 21),
                    Math.Round(rand.Next(100, 5000) + (decimal)rand.NextDouble(), 2),
                    statuses[rand.Next(statuses.Length)],
                    DateTime.Today.AddDays(-rand.Next(0, 365))
                );
            }

            Console.WriteLine($"Таблица содержит {ordersTable.Rows.Count} заказов");

            // 3. Создаем DataView с фильтром по статусу
            DataView cancelledOrdersView = new DataView(ordersTable)
            {
                RowFilter = "Status = 'Cancelled'",
                Sort = "OrderID ASC"
            };

            Console.WriteLine($"\nDataView с фильтром Status='Cancelled': {cancelledOrdersView.Count} заказов");

            // 4. Удаление данных
            Console.WriteLine("\n=== Удаление данных через DataView ===");

            // 4.1. Удаление конкретного заказа через Delete()
            Console.WriteLine("\n--- Удаление конкретного заказа ---");

            DataView allOrdersView = new DataView(ordersTable)
            {
                Sort = "OrderID ASC"
            };

            int orderIdToDelete = 5;
            int orderIndex = allOrdersView.Find(orderIdToDelete);

            if (orderIndex >= 0)
            {
                Console.WriteLine($"Заказ ID={orderIdToDelete} найден на позиции {orderIndex}");
                Console.WriteLine("Данные заказа перед удалением:");
                Console.WriteLine($"  CustomerID: {allOrdersView[orderIndex]["CustomerID"]}");
                Console.WriteLine($"  Amount: {allOrdersView[orderIndex]["Amount"]}");
                Console.WriteLine($"  Status: {allOrdersView[orderIndex]["Status"]}");

                // Удаление через DataView
                allOrdersView.Delete(orderIndex);

                Console.WriteLine($"\nПосле удаления: {allOrdersView.Count} заказов в DataView");
                Console.WriteLine($"Всего заказов в таблице: {ordersTable.Rows.Count}");

                // Проверка RowState
                DataRow deletedRow = ordersTable.Rows.Find(orderIdToDelete);
                if (deletedRow != null)
                {
                    Console.WriteLine($"RowState удаленного заказа: {deletedRow.RowState}");
                }
            }

            // 4.2. Проверка отражения в исходной таблице
            Console.WriteLine("\n--- Проверка отражения в исходной таблице ---");

            Console.WriteLine($"Заказов в исходной таблице: {ordersTable.Rows.Count}");
            Console.WriteLine($"Заказов в DataView: {allOrdersView.Count}");

            int deletedCount = ordersTable.AsEnumerable()
                .Count(row => row.RowState == DataRowState.Deleted);
            Console.WriteLine($"Удаленных строк (RowState=Deleted): {deletedCount}");

            // 4.3. Массовое удаление
            Console.WriteLine("\n--- Массовое удаление ---");

            Console.WriteLine($"Отмененных заказов до удаления: {cancelledOrdersView.Count}");

            // Подтверждение удаления
            Console.WriteLine("\nПодтверждение удаления отмененных заказов:");
            Console.WriteLine("Первые 3 отмененных заказа:");
            for (int i = 0; i < Math.Min(3, cancelledOrdersView.Count); i++)
            {
                Console.WriteLine($"  ID: {cancelledOrdersView[i]["OrderID"]}, " +
                                $"Сумма: {cancelledOrdersView[i]["Amount"]}, " +
                                $"Дата: {cancelledOrdersView[i]["CreationDate"]:dd.MM.yyyy}");
            }

            // Массовое удаление
            int initialCount = cancelledOrdersView.Count;
            for (int i = cancelledOrdersView.Count - 1; i >= 0; i--)
            {
                cancelledOrdersView.Delete(i);
            }

            Console.WriteLine($"\nУдалено {initialCount} отмененных заказов");
            Console.WriteLine($"Отмененных заказов после удаления: {cancelledOrdersView.Count}");

            // 4.4. Удаление с подтверждением
            Console.WriteLine("\n--- Удаление с подтверждением ---");

            // Создаем DataView для заказов на удаление
            DataView ordersToDeleteView = new DataView(ordersTable)
            {
                RowFilter = "Status = 'Pending' AND CreationDate < #" + DateTime.Today.AddDays(-30).ToString("MM/dd/yyyy") + "#",
                Sort = "CreationDate ASC"
            };

            Console.WriteLine($"Найдено старых ожидающих заказов: {ordersToDeleteView.Count}");

            if (ordersToDeleteView.Count > 0)
            {
                Console.WriteLine("\nИнформация о заказах для удаления:");
                decimal totalAmount = 0;
                for (int i = 0; i < Math.Min(5, ordersToDeleteView.Count); i++)
                {
                    decimal amount = Convert.ToDecimal(ordersToDeleteView[i]["Amount"]);
                    totalAmount += amount;
                    Console.WriteLine($"  ID: {ordersToDeleteView[i]["OrderID"]}, " +
                                    $"Сумма: {amount}, " +
                                    $"Дата: {ordersToDeleteView[i]["CreationDate"]:dd.MM.yyyy}");
                }

                if (ordersToDeleteView.Count > 5)
                {
                    Console.WriteLine($"  ... и еще {ordersToDeleteView.Count - 5} заказов");
                }

                Console.WriteLine($"Общая сумма: {totalAmount}");

                // Подтверждение
                Console.Write("\nУдалить эти заказы? (да/нет): ");
                string confirmation = Console.ReadLine();

                if (confirmation.ToLower() == "да")
                {
                    for (int i = ordersToDeleteView.Count - 1; i >= 0; i--)
                    {
                        ordersToDeleteView.Delete(i);
                    }
                    Console.WriteLine("Заказы удалены");
                }
                else
                {
                    Console.WriteLine("Удаление отменено");
                }
            }

            // 5. Функция отката удаления
            Console.WriteLine("\n=== Функция отката удаления ===");

            // Создаем DataView для удаленных заказов
            DataView deletedOrdersView = new DataView(ordersTable)
            {
                RowStateFilter = DataViewRowState.Deleted
            };

            Console.WriteLine($"Удаленных заказов (RowState=Deleted): {deletedOrdersView.Count}");

            // Откат удаления для первого заказа
            if (ordersTable.Rows.Count > 0 && ordersTable.Rows[0].RowState == DataRowState.Deleted)
            {
                Console.WriteLine("\nОткат удаления для первого заказа...");
                ordersTable.Rows[0].RejectChanges();
                Console.WriteLine($"После отката: {ordersTable.Rows.Count} заказов в таблице");

                // Проверяем, что заказ восстановлен
                DataRow restoredRow = ordersTable.Rows.Find(orderIdToDelete);
                if (restoredRow != null)
                {
                    Console.WriteLine($"Заказ ID={orderIdToDelete} восстановлен");
                    Console.WriteLine($"RowState: {restoredRow.RowState}");
                }
            }

            // 6. Обработка исключений
            Console.WriteLine("\n=== Обработка исключений ===");

            try
            {
                // Попытка удаления несуществующего заказа
                int invalidIndex = 999;
                allOrdersView.Delete(invalidIndex);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при удалении несуществующего заказа: {ex.Message}");
            }

            try
            {
                // Нарушение ограничений (если бы были внешние ключи)
                // В этом примере ограничений нет, но демонстрируем структуру
                Console.WriteLine("Проверка ограничений пройдена");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка ограничений: {ex.Message}");
            }

            // 8. Статистика перед AcceptChanges()
            Console.WriteLine("\n=== Статистика перед AcceptChanges() ===");

            Console.WriteLine($"Всего строк в таблице: {ordersTable.Rows.Count}");

            int added = 0, modified = 0, deleted = 0, unchanged = 0;
            foreach (DataRow row in ordersTable.Rows)
            {
                switch (row.RowState)
                {
                    case DataRowState.Added: added++; break;
                    case DataRowState.Modified: modified++; break;
                    case DataRowState.Deleted: deleted++; break;
                    case DataRowState.Unchanged: unchanged++; break;
                }
            }

            Console.WriteLine($"Добавлено: {added}");
            Console.WriteLine($"Изменено: {modified}");
            Console.WriteLine($"Удалено: {deleted}");
            Console.WriteLine($"Неизменено: {unchanged}");

            // 9. Влияние на другие DataView
            Console.WriteLine("\n=== Влияние на другие DataView ===");

            DataView completedOrdersView = new DataView(ordersTable)
            {
                RowFilter = "Status = 'Completed'",
                Sort = "Amount DESC"
            };

            DataView highAmountOrdersView = new DataView(ordersTable)
            {
                RowFilter = "Amount > 1000",
                Sort = "CreationDate DESC"
            };

            Console.WriteLine($"Завершенных заказов: {completedOrdersView.Count}");
            Console.WriteLine($"Заказов на сумму > 1000: {highAmountOrdersView.Count}");

            // AcceptChanges для применения всех изменений
            ordersTable.AcceptChanges();

            Console.WriteLine($"\nПосле AcceptChanges():");
            Console.WriteLine($"Завершенных заказов: {completedOrdersView.Count}");
            Console.WriteLine($"Заказов на сумму > 1000: {highAmountOrdersView.Count}");
        }
        #endregion

        #region Задание 11: Создание новой DataTable из DataView
        static void Task11()
        {
            Console.WriteLine("Задание 11: Создание новой DataTable из DataView\n");

            // 1. Создаем исходную таблицу продуктов
            DataTable productsTable = new DataTable("Products");

            productsTable.Columns.Add("ProductID", typeof(int));
            productsTable.Columns.Add("Name", typeof(string));
            productsTable.Columns.Add("Category", typeof(string));
            productsTable.Columns.Add("Price", typeof(decimal));
            productsTable.Columns.Add("InStock", typeof(bool));
            productsTable.Columns.Add("Supplier", typeof(string));

            // 2. Заполняем таблицу
            Random rand = new Random();
            string[] categories = { "Electronics", "Clothing", "Food", "Books", "Home" };
            string[] suppliers = { "Supplier A", "Supplier B", "Supplier C", "Supplier D" };

            for (int i = 1; i <= 150; i++)
            {
                productsTable.Rows.Add(
                    i,
                    $"Product {i}",
                    categories[rand.Next(categories.Length)],
                    Math.Round(rand.Next(10, 1000) + (decimal)rand.NextDouble(), 2),
                    rand.Next(2) == 0,
                    suppliers[rand.Next(suppliers.Length)]
                );
            }

            Console.WriteLine($"Исходная таблица содержит {productsTable.Rows.Count} товаров");

            // 3. Создаем DataView с фильтром и сортировкой
            DataView filteredView = new DataView(productsTable)
            {
                RowFilter = "Category = 'Electronics' AND Price > 100 AND InStock = true",
                Sort = "Price DESC"
            };

            Console.WriteLine($"\nDataView с фильтром: {filteredView.Count} товаров");

            // 4. Создание новой DataTable из DataView
            Console.WriteLine("\n=== Создание новой DataTable из DataView ===");

            // 4.1. Способ 1: Используя ToTable() (если доступен)
            Console.WriteLine("\n--- Способ 1: DataView.ToTable() ---");

            DataTable newTable1 = filteredView.ToTable();
            Console.WriteLine($"Новая таблица создана: {newTable1.Rows.Count} строк, {newTable1.Columns.Count} колонок");

            Console.WriteLine("Схема новой таблицы:");
            foreach (DataColumn column in newTable1.Columns)
            {
                Console.WriteLine($"  {column.ColumnName} ({column.DataType})");
            }

            // 4.2. Способ 2: Ручное копирование данных через цикл
            Console.WriteLine("\n--- Способ 2: Ручное копирование ---");

            DataTable newTable2 = productsTable.Clone(); // Копируем только схему

            foreach (DataRowView rowView in filteredView)
            {
                DataRow newRow = newTable2.NewRow();
                foreach (DataColumn column in newTable2.Columns)
                {
                    newRow[column] = rowView[column.ColumnName];
                }
                newTable2.Rows.Add(newRow);
            }

            Console.WriteLine($"Ручное копирование: {newTable2.Rows.Count} строк");


            // 4.4. Способ 4: Копирование с изменением имён колонок
            Console.WriteLine("\n--- Способ 4: С изменением имен колонок ---");

            DataTable newTable4 = new DataTable("RenamedProducts");
            newTable4.Columns.Add("ProductName", typeof(string));
            newTable4.Columns.Add("ProductPrice", typeof(decimal));
            newTable4.Columns.Add("ProductCategory", typeof(string));

            foreach (DataRowView rowView in filteredView)
            {
                DataRow newRow = newTable4.NewRow();
                newRow["ProductName"] = rowView["Name"];
                newRow["ProductPrice"] = rowView["Price"];
                newRow["ProductCategory"] = rowView["Category"];
                newTable4.Rows.Add(newRow);
            }

            Console.WriteLine($"Таблица с переименованными колонками: {newTable4.Rows.Count} строк");

            // 5. Создание таблицы с указанными колонками
            Console.WriteLine("\n=== Создание таблицы с указанными колонками ===");

            string[] selectedColumns = { "ProductID", "Name", "Price", "Category" };
            DataTable customTable = filteredView.ToTable("CustomProducts", false, selectedColumns);

            Console.WriteLine($"Пользовательская таблица: {customTable.Rows.Count} строк");
            Console.WriteLine("Первые 3 записи:");
            for (int i = 0; i < Math.Min(3, customTable.Rows.Count); i++)
            {
                Console.WriteLine($"  ID: {customTable.Rows[i]["ProductID"]}, " +
                                $"Name: {customTable.Rows[i]["Name"]}, " +
                                $"Price: {customTable.Rows[i]["Price"]}");
            }

            // 6. Создание таблицы с преобразованием данных
            Console.WriteLine("\n=== Создание с преобразованием данных ===");

            DataTable convertedTable = new DataTable("ConvertedProducts");
            convertedTable.Columns.Add("Name", typeof(string));
            convertedTable.Columns.Add("PriceUSD", typeof(decimal));
            convertedTable.Columns.Add("PriceEUR", typeof(decimal)); // Конвертация в евро

            decimal usdToEurRate = 0.85m;

            foreach (DataRowView rowView in filteredView)
            {
                DataRow newRow = convertedTable.NewRow();
                newRow["Name"] = rowView["Name"];
                decimal priceUsd = Convert.ToDecimal(rowView["Price"]);
                newRow["PriceUSD"] = priceUsd;
                newRow["PriceEUR"] = Math.Round(priceUsd * usdToEurRate, 2);
                convertedTable.Rows.Add(newRow);
            }

            Console.WriteLine($"Таблица с конвертированными ценами: {convertedTable.Rows.Count} строк");
            if (convertedTable.Rows.Count > 0)
            {
                Console.WriteLine("Пример конвертации:");
                Console.WriteLine($"  {convertedTable.Rows[0]["Name"]}: " +
                                $"{convertedTable.Rows[0]["PriceUSD"]} USD = " +
                                $"{convertedTable.Rows[0]["PriceEUR"]} EUR");
            }

            // 7. Создание с добавлением новых рассчитываемых колонок
            Console.WriteLine("\n=== Создание с расчетными колонками ===");

            DataTable calculatedTable = productsTable.Clone();
            calculatedTable.Columns.Add("DiscountedPrice", typeof(decimal));
            calculatedTable.Columns.Add("TaxAmount", typeof(decimal));
            calculatedTable.Columns.Add("TotalPrice", typeof(decimal));

            decimal discountRate = 0.1m; // 10% скидка
            decimal taxRate = 0.2m; // 20% налог

            foreach (DataRowView rowView in filteredView)
            {
                DataRow newRow = calculatedTable.NewRow();

                // Копируем существующие колонки
                foreach (DataColumn column in productsTable.Columns)
                {
                    newRow[column.ColumnName] = rowView[column.ColumnName];
                }

                // Добавляем расчетные колонки
                decimal originalPrice = Convert.ToDecimal(rowView["Price"]);
                decimal discountedPrice = originalPrice * (1 - discountRate);
                decimal taxAmount = discountedPrice * taxRate;
                decimal totalPrice = discountedPrice + taxAmount;

                newRow["DiscountedPrice"] = Math.Round(discountedPrice, 2);
                newRow["TaxAmount"] = Math.Round(taxAmount, 2);
                newRow["TotalPrice"] = Math.Round(totalPrice, 2);

                calculatedTable.Rows.Add(newRow);
            }

            Console.WriteLine($"Таблица с расчетными колонками: {calculatedTable.Rows.Count} строк");
            if (calculatedTable.Rows.Count > 0)
            {
                Console.WriteLine("\nПример расчетов:");
                DataRow sampleRow = calculatedTable.Rows[0];
                Console.WriteLine($"  Товар: {sampleRow["Name"]}");
                Console.WriteLine($"  Исходная цена: {sampleRow["Price"]}");
                Console.WriteLine($"  Цена со скидкой 10%: {sampleRow["DiscountedPrice"]}");
                Console.WriteLine($"  Налог 20%: {sampleRow["TaxAmount"]}");
                Console.WriteLine($"  Итоговая цена: {sampleRow["TotalPrice"]}");
            }

            // 8. Сравнение исходной и созданной таблиц
            Console.WriteLine("\n=== Сравнение таблиц ===");

            Console.WriteLine($"Исходная таблица: {productsTable.Rows.Count} строк, {productsTable.Columns.Count} колонок");
            Console.WriteLine($"Фильтрованный DataView: {filteredView.Count} строк");
            Console.WriteLine($"Новая таблица 1: {newTable1.Rows.Count} строк, {newTable1.Columns.Count} колонок");

            // 9. Проверка независимости новой таблицы
            Console.WriteLine("\n=== Проверка независимости новой таблицы ===");

            // Изменяем данные в исходной таблице
            if (productsTable.Rows.Count > 0)
            {
                decimal originalValue = Convert.ToDecimal(productsTable.Rows[0]["Price"]);
                productsTable.Rows[0]["Price"] = originalValue * 2;

                Console.WriteLine($"Исходная таблица: цена первого товара изменена с {originalValue} на {productsTable.Rows[0]["Price"]}");

                // Проверяем, что новая таблица не изменилась
                if (newTable1.Rows.Count > 0)
                {
                    Console.WriteLine($"Новая таблица: цена первого товара осталась {newTable1.Rows[0]["Price"]}");
                    Console.WriteLine("Новая таблица независима от исходной!");
                }
            }

            // 10. Вывод схем обеих таблиц
            Console.WriteLine("\n=== Схемы таблиц ===");

            Console.WriteLine("\nСхема исходной таблицы:");
            foreach (DataColumn column in productsTable.Columns)
            {
                Console.WriteLine($"  {column.ColumnName,-15} {column.DataType.Name}");
            }

            Console.WriteLine("\nСхема новой таблицы (способ 1):");
            foreach (DataColumn column in newTable1.Columns)
            {
                Console.WriteLine($"  {column.ColumnName,-15} {column.DataType.Name}");
            }

            Console.WriteLine("\nСхема новой таблицы (способ 3, выбранные колонки):");

            {

            }
        }
        #endregion

        #region Вспомогательные методы

        static Random rand = new Random();

        static DataTable CreateProductsTable()
        {
            DataTable table = new DataTable("Products");

            table.Columns.Add("ProductID", typeof(int));
            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("Price", typeof(decimal));
            table.Columns.Add("Quantity", typeof(int));
            table.Columns.Add("Category", typeof(string));

            return table;
        }

        static void FillProductsTable(DataTable table, int count)
        {
            string[] categories = { "Electronics", "Books", "Clothing", "Food", "Home", "Sports" };
            string[] productNames = { "Laptop", "Book", "T-Shirt", "Apple", "Chair", "Ball",
                                      "Phone", "Notebook", "Jeans", "Bread", "Table", "Racket" };

            for (int i = 1; i <= count; i++)
            {
                table.Rows.Add(
                    i,
                    $"{productNames[rand.Next(productNames.Length)]} {i}",
                    Math.Round(rand.Next(50, 1000) + (decimal)rand.NextDouble(), 2),
                    rand.Next(1, 100),
                    categories[rand.Next(categories.Length)]
                );
            }
        }

        static DataTable CreateOrdersTable()
        {
            DataTable table = new DataTable("Orders");

            table.Columns.Add("OrderID", typeof(int));
            table.Columns.Add("CustomerID", typeof(int));
            table.Columns.Add("OrderDate", typeof(DateTime));
            table.Columns.Add("Amount", typeof(decimal));
            table.Columns.Add("Status", typeof(string));
            table.Columns.Add("ShippingAddress", typeof(string));

            return table;
        }

        static void FillOrdersTable(DataTable table, int count)
        {
            string[] statuses = { "Pending", "Processing", "Shipped", "Delivered", "Cancelled" };
            string[] addresses = { "Main Street 123", "Oak Avenue 45", "Pine Road 67",
                                   "Maple Drive 89", "Cedar Lane 101", "Elm Street 202" };

            for (int i = 1; i <= count; i++)
            {
                table.Rows.Add(
                    i,
                    rand.Next(1, 21),
                    DateTime.Today.AddDays(-rand.Next(0, 365)),
                    Math.Round(rand.Next(10, 2000) + (decimal)rand.NextDouble(), 2),
                    statuses[rand.Next(statuses.Length)],
                    $"{addresses[rand.Next(addresses.Length)]}, City {rand.Next(1, 10)}"
                );
            }
        }

        static void PrintDataTable(DataTable table, int rowsToShow = 10)
        {
            if (table.Rows.Count == 0)
            {
                Console.WriteLine("Таблица пуста");
                return;
            }

            // Заголовки столбцов
            foreach (DataColumn column in table.Columns)
            {
                Console.Write($"{column.ColumnName,-15} ");
            }
            Console.WriteLine();
            Console.WriteLine(new string('-', table.Columns.Count * 16));

            // Данные
            for (int i = 0; i < Math.Min(rowsToShow, table.Rows.Count); i++)
            {
                DataRow row = table.Rows[i];
                foreach (DataColumn column in table.Columns)
                {
                    Console.Write($"{row[column],-15} ");
                }
                Console.WriteLine();
            }

            if (table.Rows.Count > rowsToShow)
            {
                Console.WriteLine($"... и еще {table.Rows.Count - rowsToShow} строк");
            }
        }

        static string BuildDynamicFilter(Dictionary<string, object> parameters)
        {
            List<string> conditions = new List<string>();

            if (parameters.ContainsKey("MinAmount") && parameters["MinAmount"] != null)
            {
                conditions.Add($"Amount > {parameters["MinAmount"]}");
            }

            if (parameters.ContainsKey("Status") && parameters["Status"] != null)
            {
                conditions.Add($"Status = '{parameters["Status"]}'");
            }

            if (parameters.ContainsKey("CustomerID") && parameters["CustomerID"] != null)
            {
                conditions.Add($"CustomerID = {parameters["CustomerID"]}");
            }

            if (parameters.ContainsKey("StartDate") && parameters["StartDate"] != null)
            {
                DateTime date = (DateTime)parameters["StartDate"];
                conditions.Add($"OrderDate >= #{date:MM/dd/yyyy}#");
            }

            return conditions.Count > 0 ? string.Join(" AND ", conditions) : "";
        }

        #endregion

        #region Остальные задания (заглушки)

        #region Задание 12: Сочетание Find(), Select() и DataView для комплексного поиска
        static void Task12()
        {
            Console.WriteLine("Задание 12: Сочетание Find(), Select() и DataView для комплексного поиска\n");

            // 1. Создаем таблицу счетов в банке
            DataTable accountsTable = new DataTable("BankAccounts");

            accountsTable.Columns.Add("AccountID", typeof(int));
            accountsTable.Columns.Add("CustomerName", typeof(string));
            accountsTable.Columns.Add("Balance", typeof(decimal));
            accountsTable.Columns.Add("AccountType", typeof(string));
            accountsTable.Columns.Add("OpenDate", typeof(DateTime));
            accountsTable.Columns.Add("Status", typeof(string));

            // Устанавливаем первичный ключ
            accountsTable.PrimaryKey = new DataColumn[] { accountsTable.Columns["AccountID"] };

            // 2. Заполняем таблицу
            Random rand = new Random();
            string[] accountTypes = { "Checking", "Savings", "Business", "Investment" };
            string[] statuses = { "Active", "Inactive", "Closed", "Suspended" };
            string[] customerNames = { "Иванов И.И.", "Петров П.П.", "Сидоров С.С.", "Кузнецов К.К.",
                               "Смирнова А.А.", "Васильева М.М.", "Попова О.О.", "Новикова Е.Е." };

            for (int i = 1; i <= 200; i++)
            {
                accountsTable.Rows.Add(
                    i,
                    customerNames[rand.Next(customerNames.Length)] + $" {i % 10 + 1}",
                    Math.Round(rand.Next(1000, 1000000) + (decimal)rand.NextDouble(), 2),
                    accountTypes[rand.Next(accountTypes.Length)],
                    DateTime.Today.AddDays(-rand.Next(0, 3650)),
                    statuses[rand.Next(statuses.Length)]
                );
            }

            Console.WriteLine($"Таблица содержит {accountsTable.Rows.Count} счетов");

            // 3. Реализация комплексного поиска
            Console.WriteLine("\n=== Комплексный поиск ===");

            // 3.1. Использование Find() для поиска по PK
            Console.WriteLine("\n--- Поиск по первичному ключу (Find()) ---");

            Stopwatch sw = new Stopwatch();
            int accountId = 50;

            sw.Start();
            DataRow foundAccount = accountsTable.Rows.Find(accountId);
            sw.Stop();

            if (foundAccount != null)
            {
                Console.WriteLine($"Найден счет ID={accountId} за {sw.ElapsedTicks} тиков:");
                Console.WriteLine($"  Владелец: {foundAccount["CustomerName"]}");
                Console.WriteLine($"  Баланс: {foundAccount["Balance"]}");
                Console.WriteLine($"  Тип: {foundAccount["AccountType"]}");
            }

            // 3.2. Использование Select() для фильтрации
            Console.WriteLine("\n--- Фильтрация по критериям (Select()) ---");

            sw.Restart();
            DataRow[] filteredAccounts = accountsTable.Select(
                "Balance > 50000 AND Status = 'Active' AND AccountType = 'Savings'");
            sw.Stop();

            Console.WriteLine($"Найдено сберегательных счетов с балансом > 50000: {filteredAccounts.Length} за {sw.ElapsedTicks} тиков");

            if (filteredAccounts.Length > 0)
            {
                Console.WriteLine("Первые 3 счета:");
                for (int i = 0; i < Math.Min(3, filteredAccounts.Length); i++)
                {
                    Console.WriteLine($"  {filteredAccounts[i]["CustomerName"]}: {filteredAccounts[i]["Balance"]}");
                }
            }

            // 3.3. Использование DataView для комбинированного поиска
            Console.WriteLine("\n--- Комбинированный поиск (DataView) ---");

            DataView accountsView = new DataView(accountsTable)
            {
                RowFilter = "Balance > 100000 AND AccountType IN ('Business', 'Investment')",
                Sort = "Balance DESC"
            };

            Console.WriteLine($"Бизнес/инвестиционные счета с балансом > 100000: {accountsView.Count}");
            Console.WriteLine("Топ-3 счета:");
            for (int i = 0; i < Math.Min(3, accountsView.Count); i++)
            {
                Console.WriteLine($"  {accountsView[i]["CustomerName"]}: {accountsView[i]["Balance"]} ({accountsView[i]["AccountType"]})");
            }

            // 4. "Умный поиск" с выбором метода
            Console.WriteLine("\n=== Умный поиск (SmartSearch) ===");

            Console.WriteLine("\nТест 1: Поиск по AccountID (должен использовать Find)");
            var result1 = SmartSearch(accountsTable, "AccountID", 100, null, null);
            Console.WriteLine($"Найдено: {result1.Count} счетов, метод: {result1.Method}");

            Console.WriteLine("\nТест 2: Поиск по одному критерию (должен использовать Select)");
            var result2 = SmartSearch(accountsTable, null, null, "Status = 'Active'", null);
            Console.WriteLine($"Найдено: {result2.Count} счетов, метод: {result2.Method}");

            Console.WriteLine("\nТест 3: Поиск по нескольким критериям (должен использовать DataView)");
            var result3 = SmartSearch(accountsTable, null, null,
                "Balance > 50000 AND AccountType = 'Savings' AND Status = 'Active'",
                "Balance DESC");
            Console.WriteLine($"Найдено: {result3.Count} счетов, метод: {result3.Method}");

            Console.WriteLine("\nТест 4: Поиск с сортировкой (должен использовать DataView)");
            var result4 = SmartSearch(accountsTable, null, null, "Balance > 10000", "OpenDate DESC");
            Console.WriteLine($"Найдено: {result4.Count} счетов, метод: {result4.Method}");

            // 5. Поиск с автодополнением
            Console.WriteLine("\n=== Поиск с автодополнением ===");

            string searchPrefix = "Ива";
            var autoCompleteResults = accountsTable.AsEnumerable()
                .Where(row => row["CustomerName"].ToString().StartsWith(searchPrefix, StringComparison.OrdinalIgnoreCase))
                .Select(row => row["CustomerName"].ToString())
                .Distinct()
                .Take(5)
                .ToList();

            Console.WriteLine($"Автодополнение для '{searchPrefix}':");
            foreach (var name in autoCompleteResults)
            {
                Console.WriteLine($"  {name}");
            }

            // 6. Отчёт о найденных счетах
            Console.WriteLine("\n=== Детальный отчёт ===");

            DataView reportView = new DataView(accountsTable)
            {
                RowFilter = "Status = 'Active' AND Balance > 100000",
                Sort = "AccountType, Balance DESC"
            };

            Console.WriteLine($"Активные счета с балансом > 100000: {reportView.Count}");

            decimal totalBalance = 0;
            Dictionary<string, int> typeCounts = new Dictionary<string, int>();
            Dictionary<string, decimal> typeBalances = new Dictionary<string, decimal>();

            for (int i = 0; i < reportView.Count; i++)
            {
                string type = reportView[i]["AccountType"].ToString();
                decimal balance = Convert.ToDecimal(reportView[i]["Balance"]);

                totalBalance += balance;

                if (!typeCounts.ContainsKey(type))
                    typeCounts[type] = 0;
                typeCounts[type]++;

                if (!typeBalances.ContainsKey(type))
                    typeBalances[type] = 0;
                typeBalances[type] += balance;
            }

            Console.WriteLine($"\nОбщая сумма: {totalBalance:C}");
            Console.WriteLine("\nРаспределение по типам счетов:");
            foreach (var type in typeCounts.Keys)
            {
                Console.WriteLine($"  {type}: {typeCounts[type]} счетов, сумма: {typeBalances[type]:C}");
            }

            // 7. Измерение производительности
            Console.WriteLine("\n=== Сравнение производительности методов ===");

            int iterations = 1000;

            // Find() производительность
            sw.Restart();
            for (int i = 0; i < iterations; i++)
            {
                DataRow row = accountsTable.Rows.Find(i % 200 + 1);
            }
            sw.Stop();
            Console.WriteLine($"Find() {iterations} раз: {sw.ElapsedMilliseconds} ms");

            // Select() производительность
            sw.Restart();
            for (int i = 0; i < iterations; i++)
            {
                DataRow[] rows = accountsTable.Select($"Balance > {i % 100000}");
            }
            sw.Stop();
            Console.WriteLine($"Select() {iterations} раз: {sw.ElapsedMilliseconds} ms");

            // DataView производительность
            DataView testView = new DataView(accountsTable);
            sw.Restart();
            for (int i = 0; i < iterations; i++)
            {
                testView.RowFilter = $"Balance > {i % 100000}";
                int count = testView.Count;
            }
            sw.Stop();
            Console.WriteLine($"DataView {iterations} раз: {sw.ElapsedMilliseconds} ms");
        }

        // Метод "умного поиска"
        static SearchResult SmartSearch(DataTable table, string pkColumn, object pkValue, string filter, string sort)
        {
            Stopwatch sw = Stopwatch.StartNew();
            SearchResult result = new SearchResult();

            // Выбор метода поиска на основе параметров
            if (!string.IsNullOrEmpty(pkColumn) && pkValue != null)
            {
                // Поиск по PK - используем Find()
                result.Method = "Find()";
                DataRow row = table.Rows.Find(pkValue);
                result.Rows = row != null ? new DataRow[] { row } : new DataRow[0];
            }
            else if (!string.IsNullOrEmpty(filter) && string.IsNullOrEmpty(sort))
            {
                // Простой фильтр без сортировки - используем Select()
                result.Method = "Select()";
                result.Rows = table.Select(filter);
            }
            else
            {
                // Сложный запрос с сортировкой - используем DataView
                result.Method = "DataView";
                DataView view = new DataView(table)
                {
                    RowFilter = filter ?? "",
                    Sort = sort ?? ""
                };
                result.View = view;
            }

            sw.Stop();
            result.ElapsedTime = sw.ElapsedTicks;

            return result;
        }

        class SearchResult
        {
            public string Method { get; set; }
            public DataRow[] Rows { get; set; }
            public DataView View { get; set; }
            public long ElapsedTime { get; set; }

            public int Count
            {
                get
                {
                    if (Rows != null) return Rows.Length;
                    if (View != null) return View.Count;
                    return 0;
                }
            }
        }
        #endregion

        #region Задание 13: DataView с несколькими уровнями фильтрации
        static void Task13()
        {
            Console.WriteLine("Задание 13: DataView с несколькими уровнями фильтрации\n");

            // 1. Создаем таблицу событий
            DataTable eventsTable = new DataTable("Events");

            eventsTable.Columns.Add("EventID", typeof(int));
            eventsTable.Columns.Add("EventName", typeof(string));
            eventsTable.Columns.Add("Date", typeof(DateTime));
            eventsTable.Columns.Add("Location", typeof(string));
            eventsTable.Columns.Add("Category", typeof(string));
            eventsTable.Columns.Add("Priority", typeof(string));
            eventsTable.Columns.Add("Status", typeof(string));
            eventsTable.Columns.Add("Attendees", typeof(int));

            // Устанавливаем первичный ключ
            eventsTable.PrimaryKey = new DataColumn[] { eventsTable.Columns["EventID"] };

            // 2. Заполняем таблицу
            Random rand = new Random();
            string[] categories = { "Conference", "Meeting", "Workshop", "Webinar", "Social" };
            string[] priorities = { "High", "Medium", "Low" };
            string[] statuses = { "Planned", "In Progress", "Completed", "Cancelled" };
            string[] locations = { "Москва", "Санкт-Петербург", "Новосибирск", "Екатеринбург", "Казань" };
            string[] eventNames = { "Tech Summit", "Business Meeting", "Developer Conference",
                           "Marketing Workshop", "Annual Review", "Team Building" };

            for (int i = 1; i <= 350; i++)
            {
                DateTime eventDate = DateTime.Today.AddDays(rand.Next(-180, 180));
                int attendees = rand.Next(5, 500);

                eventsTable.Rows.Add(
                    i,
                    $"{eventNames[rand.Next(eventNames.Length)]} {i}",
                    eventDate,
                    locations[rand.Next(locations.Length)],
                    categories[rand.Next(categories.Length)],
                    priorities[rand.Next(priorities.Length)],
                    statuses[rand.Next(statuses.Length)],
                    attendees
                );
            }

            Console.WriteLine($"Таблица содержит {eventsTable.Rows.Count} событий");

            // 3. Многоуровневая фильтрация
            Console.WriteLine("\n=== Многоуровневая фильтрация ===");

            DataView eventsView = new DataView(eventsTable);

            // Уровень 1: Фильтр по категории
            Console.WriteLine("\n--- Уровень 1: Фильтр по категории 'Conference' ---");
            eventsView.RowFilter = "Category = 'Conference'";
            Console.WriteLine($"Событий: {eventsView.Count}");
            PrintEventsSummary(eventsView);

            // Уровень 2: Добавить фильтр по приоритету
            Console.WriteLine("\n--- Уровень 2: + Приоритет 'High' ---");
            eventsView.RowFilter = "Category = 'Conference' AND Priority = 'High'";
            Console.WriteLine($"Событий: {eventsView.Count}");
            PrintEventsSummary(eventsView);

            // Уровень 3: Добавить фильтр по дате (только будущие события)
            Console.WriteLine("\n--- Уровень 3: + Будущие события ---");
            eventsView.RowFilter = $"Category = 'Conference' AND Priority = 'High' AND Date >= #{DateTime.Today:MM/dd/yyyy}#";
            Console.WriteLine($"Событий: {eventsView.Count}");
            PrintEventsSummary(eventsView);

            // Уровень 4: Добавить фильтр по количеству участников
            Console.WriteLine("\n--- Уровень 4: + Участников > 100 ---");
            eventsView.RowFilter = $"Category = 'Conference' AND Priority = 'High' AND Date >= #{DateTime.Today:MM/dd/yyyy}# AND Attendees > 100";
            Console.WriteLine($"Событий: {eventsView.Count}");
            PrintEventsSummary(eventsView);

            // 4. Функция удаления одного из фильтров
            Console.WriteLine("\n=== Удаление фильтра по дате ===");
            eventsView.RowFilter = RemoveFilterCondition(eventsView.RowFilter, "Date");
            Console.WriteLine($"После удаления фильтра по дате: {eventsView.Count} событий");
            Console.WriteLine($"Текущий фильтр: {eventsView.RowFilter}");

            // 5. Функция сброса всех фильтров
            Console.WriteLine("\n=== Сброс всех фильтров ===");
            eventsView.RowFilter = "";
            Console.WriteLine($"После сброса фильтров: {eventsView.Count} событий");

            // 6. Отчёт на каждом уровне фильтрации
            Console.WriteLine("\n=== Отчёт по уровням фильтрации ===");

            List<FilterLevel> filterLevels = new List<FilterLevel>
    {
        new FilterLevel { Name = "Все события", Filter = "" },
        new FilterLevel { Name = "Конференции", Filter = "Category = 'Conference'" },
        new FilterLevel { Name = "Конференции High", Filter = "Category = 'Conference' AND Priority = 'High'" },
        new FilterLevel { Name = "Будущие High-конференции", Filter = $"Category = 'Conference' AND Priority = 'High' AND Date >= #{DateTime.Today:MM/dd/yyyy}#" },
        new FilterLevel { Name = "Крупные будущие High-конференции", Filter = $"Category = 'Conference' AND Priority = 'High' AND Date >= #{DateTime.Today:MM/dd/yyyy}# AND Attendees > 100" }
    };

            foreach (var level in filterLevels)
            {
                eventsView.RowFilter = level.Filter;
                level.Count = eventsView.Count;

                if (eventsView.Count > 0)
                {
                    // Вычисляем среднее количество участников
                    double avgAttendees = 0;
                    for (int i = 0; i < eventsView.Count; i++)
                    {
                        avgAttendees += Convert.ToDouble(eventsView[i]["Attendees"]);
                    }
                    avgAttendees /= eventsView.Count;
                    level.AverageAttendees = Math.Round(avgAttendees, 1);
                }
            }

            Console.WriteLine("\nУровень фильтрации             | Событий | Сред. участников");
            Console.WriteLine("-------------------------------------------------------");
            foreach (var level in filterLevels)
            {
                Console.WriteLine($"{level.Name,-35} | {level.Count,7} | {level.AverageAttendees,15}");
            }

            // 7. Сохранение и загрузка конфигурации фильтров
            Console.WriteLine("\n=== Сохранение и загрузка конфигурации ===");

            string filterConfig = eventsView.RowFilter;
            string sortConfig = eventsView.Sort;

            Console.WriteLine($"Сохраняем конфигурацию:");
            Console.WriteLine($"  Фильтр: {filterConfig}");
            Console.WriteLine($"  Сортировка: {sortConfig}");

            // Имитация сохранения в файл
            SaveFilterConfiguration("events_filter.json", filterConfig, sortConfig);

            // Имитация загрузки из файла
            var loadedConfig = LoadFilterConfiguration("events_filter.json");
            Console.WriteLine($"\nЗагружаем конфигурацию:");
            Console.WriteLine($"  Фильтр: {loadedConfig.Filter}");
            Console.WriteLine($"  Сортировка: {loadedConfig.Sort}");

            // Применяем загруженную конфигурацию
            eventsView.RowFilter = loadedConfig.Filter;
            eventsView.Sort = loadedConfig.Sort;
            Console.WriteLine($"Применена загруженная конфигурация: {eventsView.Count} событий");
        }

        static void PrintEventsSummary(DataView view, int maxToShow = 3)
        {
            if (view.Count == 0)
            {
                Console.WriteLine("  (нет событий)");
                return;
            }

            Console.WriteLine("Примеры событий:");
            for (int i = 0; i < Math.Min(maxToShow, view.Count); i++)
            {
                Console.WriteLine($"  {view[i]["EventName"]} - {view[i]["Date"]:dd.MM.yyyy} ({view[i]["Attendees"]} участников)");
            }

            if (view.Count > maxToShow)
            {
                Console.WriteLine($"  ... и еще {view.Count - maxToShow} событий");
            }
        }

        static string RemoveFilterCondition(string currentFilter, string conditionToRemove)
        {
            if (string.IsNullOrEmpty(currentFilter))
                return "";

            // Простая реализация - удаляем условие, содержащее указанное поле
            var conditions = currentFilter.Split(new[] { " AND ", " OR " }, StringSplitOptions.RemoveEmptyEntries);
            var newConditions = conditions.Where(c => !c.Contains(conditionToRemove)).ToList();

            return string.Join(" AND ", newConditions);
        }

        static void SaveFilterConfiguration(string filename, string filter, string sort)
        {
            // В реальном приложении здесь была бы сериализация в JSON/XML
            Console.WriteLine($"Конфигурация сохранена в {filename}");
        }

        static (string Filter, string Sort) LoadFilterConfiguration(string filename)
        {
            // В реальном приложении здесь была бы десериализация из JSON/XML
            Console.WriteLine($"Конфигурация загружена из {filename}");
            return ("Category = 'Conference'", "Date DESC");
        }

        class FilterLevel
        {
            public string Name { get; set; }
            public string Filter { get; set; }
            public int Count { get; set; }
            public double AverageAttendees { get; set; }
        }
        #endregion

        #region Задание 14: Сортировка по нескольким колонкам
        static void Task14()
        {
            Console.WriteLine("Задание 14: Сортировка по нескольким колонкам в DataView\n");

            // 1. Создаем таблицу продаж сотрудников
            DataTable salesTable = new DataTable("EmployeeSales");

            salesTable.Columns.Add("SalesID", typeof(int));
            salesTable.Columns.Add("EmployeeName", typeof(string));
            salesTable.Columns.Add("Department", typeof(string));
            salesTable.Columns.Add("Amount", typeof(decimal));
            salesTable.Columns.Add("Date", typeof(DateTime));
            salesTable.Columns.Add("Quarter", typeof(int));
            salesTable.Columns.Add("Region", typeof(string));

            // Устанавливаем первичный ключ
            salesTable.PrimaryKey = new DataColumn[] { salesTable.Columns["SalesID"] };

            // 2. Заполняем таблицу
            Random rand = new Random();
            string[] departments = { "Sales", "Marketing", "IT", "Finance", "HR" };
            string[] regions = { "North", "South", "East", "West", "Central" };
            string[] employeeNames = { "Иванов А.А.", "Петров Б.Б.", "Сидоров В.В.",
                               "Кузнецов Г.Г.", "Смирнова Д.Д.", "Васильева Е.Е." };

            for (int i = 1; i <= 550; i++)
            {
                DateTime saleDate = DateTime.Today.AddDays(-rand.Next(0, 730));
                int quarter = (saleDate.Month - 1) / 3 + 1;

                salesTable.Rows.Add(
                    i,
                    employeeNames[rand.Next(employeeNames.Length)],
                    departments[rand.Next(departments.Length)],
                    Math.Round(rand.Next(1000, 50000) + (decimal)rand.NextDouble(), 2),
                    saleDate,
                    quarter,
                    regions[rand.Next(regions.Length)]
                );
            }

            Console.WriteLine($"Таблица содержит {salesTable.Rows.Count} записей о продажах");

            // 3. Различные варианты сортировки
            Console.WriteLine("\n=== Варианты сортировки ===");

            DataView salesView = new DataView(salesTable);

            // 3.1. Сортировка по одной колонке (Amount DESC)
            Console.WriteLine("\n--- Сортировка по сумме (по убыванию) ---");
            salesView.Sort = "Amount DESC";
            Console.WriteLine($"Первые 3 самые крупные продажи:");
            for (int i = 0; i < Math.Min(3, salesView.Count); i++)
            {
                Console.WriteLine($"  {salesView[i]["EmployeeName"]}: {salesView[i]["Amount"]} ({salesView[i]["Date"]:dd.MM.yyyy})");
            }

            // 3.2. Сортировка по двум колонкам
            Console.WriteLine("\n--- Сортировка по отделу (по возрастанию) и сумме (по убыванию) ---");
            salesView.Sort = "Department ASC, Amount DESC";
            Console.WriteLine("Первые 5 записей:");
            for (int i = 0; i < Math.Min(5, salesView.Count); i++)
            {
                Console.WriteLine($"  {salesView[i]["Department"]} - {salesView[i]["EmployeeName"]}: {salesView[i]["Amount"]}");
            }

            // 3.3. Сортировка по трём колонкам
            Console.WriteLine("\n--- Сортировка по региону, отделу и дате ---");
            salesView.Sort = "Region ASC, Department ASC, Date DESC";
            Console.WriteLine("Первые 5 записей:");
            for (int i = 0; i < Math.Min(5, salesView.Count); i++)
            {
                Console.WriteLine($"  {salesView[i]["Region"]} | {salesView[i]["Department"]} | {salesView[i]["Date"]:dd.MM.yyyy} | {salesView[i]["EmployeeName"]}: {salesView[i]["Amount"]}");
            }

            // 4. Динамическая сортировка на основе пользовательского выбора
            Console.WriteLine("\n=== Динамическая сортировка ===");

            var sortOptions = new Dictionary<int, (string Name, string SortExpression)>
    {
        {1, ("Сумма (по убыванию)", "Amount DESC")},
        {2, ("Сумма (по возрастанию)", "Amount ASC")},
        {3, ("Дата (новые сначала)", "Date DESC")},
        {4, ("Дата (старые сначала)", "Date ASC")},
        {5, ("Сотрудник", "EmployeeName ASC")},
        {6, ("Отдел и сумма", "Department ASC, Amount DESC")},
        {7, ("Регион, отдел и дата", "Region ASC, Department ASC, Date DESC")},
        {8, ("Квартал и сумма", "Quarter ASC, Amount DESC")}
    };

            Console.WriteLine("\nДоступные варианты сортировки:");
            foreach (var option in sortOptions)
            {
                Console.WriteLine($"  {option.Key}. {option.Value.Name}");
            }

            // Имитация выбора пользователя
            int selectedSort = 6; // Например, выбрана сортировка по отделу и сумме
            Console.WriteLine($"\nВыбран вариант {selectedSort}: {sortOptions[selectedSort].Name}");
            salesView.Sort = sortOptions[selectedSort].SortExpression;

            Console.WriteLine("\nРезультаты:");
            for (int i = 0; i < Math.Min(5, salesView.Count); i++)
            {
                Console.WriteLine($"  {salesView[i]["Department"]} - {salesView[i]["EmployeeName"]}: {salesView[i]["Amount"]}");
            }

            // 5. Переключение между возрастанием и убыванием
            Console.WriteLine("\n=== Переключение направления сортировки ===");

            string currentSort = "Amount DESC";
            Console.WriteLine($"Текущая сортировка: {currentSort}");

            // Переключаем направление
            string toggledSort = ToggleSortDirection(currentSort);
            salesView.Sort = toggledSort;
            Console.WriteLine($"После переключения: {toggledSort}");

            Console.WriteLine("\nПервые 3 записи:");
            for (int i = 0; i < Math.Min(3, salesView.Count); i++)
            {
                Console.WriteLine($"  {salesView[i]["EmployeeName"]}: {salesView[i]["Amount"]}");
            }

            // 6. Вывод результатов в табличном формате
            Console.WriteLine("\n=== Табличное представление ===");

            salesView.Sort = "Region ASC, Department ASC, Amount DESC";
            Console.WriteLine("\nРегион | Отдел     | Сотрудник       | Сумма      | Дата");
            Console.WriteLine("---------------------------------------------------------------");

            string currentRegion = "";
            string currentDept = "";
            int totalShown = 0;

            for (int i = 0; i < salesView.Count && totalShown < 10; i++)
            {
                string region = salesView[i]["Region"].ToString();
                string dept = salesView[i]["Department"].ToString();
                string name = salesView[i]["EmployeeName"].ToString();
                decimal amount = Convert.ToDecimal(salesView[i]["Amount"]);
                DateTime date = Convert.ToDateTime(salesView[i]["Date"]);

                // Отображаем регион и отдел только при изменении
                string regionDisplay = (region != currentRegion) ? region : "";
                string deptDisplay = (dept != currentDept) ? dept : "";

                Console.WriteLine($"{regionDisplay,-6} | {deptDisplay,-9} | {name,-15} | {amount,10:C} | {date:dd.MM.yyyy}");

                currentRegion = region;
                currentDept = dept;
                totalShown++;
            }

            if (salesView.Count > 10)
            {
                Console.WriteLine($"... и еще {salesView.Count - 10} записей");
            }

            // 7. Влияние сортировки на производительность
            Console.WriteLine("\n=== Производительность сортировки ===");

            Stopwatch sw = new Stopwatch();

            // Тест производительности разных типов сортировки
            var performanceTests = new List<(string Name, string Sort)>
    {
        ("Одна колонка", "Amount DESC"),
        ("Две колонки", "Department ASC, Amount DESC"),
        ("Три колонки", "Region ASC, Department ASC, Date DESC"),
        ("Сложная сортировка", "Quarter ASC, Region ASC, Department ASC, EmployeeName ASC, Amount DESC")
    };

            Console.WriteLine("\nСравнение производительности (100 итераций):");
            Console.WriteLine("Сортировка                    | Время (ms)");
            Console.WriteLine("-------------------------------------------");

            foreach (var test in performanceTests)
            {
                sw.Restart();
                for (int i = 0; i < 100; i++)
                {
                    salesView.Sort = test.Sort;
                    int count = salesView.Count; // Принудительное выполнение сортировки
                }
                sw.Stop();

                Console.WriteLine($"{test.Name,-30} | {sw.ElapsedMilliseconds,10}");
            }

            // 8. Сравнение с сортировкой через Select()
            Console.WriteLine("\n=== Сравнение с Select() ===");

            sw.Restart();
            for (int i = 0; i < 100; i++)
            {
                DataRow[] sortedRows = salesTable.Select("", "Amount DESC");
            }
            sw.Stop();
            long selectTime = sw.ElapsedMilliseconds;

            sw.Restart();
            for (int i = 0; i < 100; i++)
            {
                salesView.Sort = "Amount DESC";
                int count = salesView.Count;
            }
            sw.Stop();
            long dataViewTime = sw.ElapsedMilliseconds;

            Console.WriteLine($"Select() сортировка: {selectTime} ms");
            Console.WriteLine($"DataView сортировка: {dataViewTime} ms");
            Console.WriteLine($"Разница: {selectTime - dataViewTime} ms (DataView быстрее на {((double)selectTime / dataViewTime):F1}x)");

            // 9. Обработка ошибок синтаксиса
            Console.WriteLine("\n=== Обработка ошибок синтаксиса ===");

            try
            {
                salesView.Sort = "InvalidColumn ASC"; // Несуществующая колонка
                Console.WriteLine("Сортировка выполнена (не должно быть этого сообщения)");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }

            try
            {
                salesView.Sort = "Amount ASC, "; // Неверный синтаксис
                Console.WriteLine("Сортировка выполнена (не должно быть этого сообщения)");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }

        static string ToggleSortDirection(string sortExpression)
        {
            if (string.IsNullOrEmpty(sortExpression))
                return "";

            var parts = sortExpression.Split(',');
            var newParts = new List<string>();

            foreach (var part in parts)
            {
                string trimmed = part.Trim();
                if (trimmed.EndsWith(" ASC", StringComparison.OrdinalIgnoreCase))
                {
                    newParts.Add(trimmed.Substring(0, trimmed.Length - 4) + " DESC");
                }
                else if (trimmed.EndsWith(" DESC", StringComparison.OrdinalIgnoreCase))
                {
                    newParts.Add(trimmed.Substring(0, trimmed.Length - 5) + " ASC");
                }
                else
                {
                    // Если направление не указано, добавляем ASC
                    newParts.Add(trimmed + " ASC");
                }
            }

            return string.Join(", ", newParts);
        }
        #endregion

        #region Задание 15: Комбинирование нескольких DataView
        static void Task15()
        {
            Console.WriteLine("Задание 15: Комбинирование нескольких DataView для анализа данных\n");

            // 1. Создаем таблицу студентов
            DataTable studentsTable = new DataTable("Students");

            studentsTable.Columns.Add("StudentID", typeof(int));
            studentsTable.Columns.Add("Name", typeof(string));
            studentsTable.Columns.Add("GPA", typeof(double));
            studentsTable.Columns.Add("Faculty", typeof(string));
            studentsTable.Columns.Add("Year", typeof(int));
            studentsTable.Columns.Add("Status", typeof(string));

            // Устанавливаем первичный ключ
            studentsTable.PrimaryKey = new DataColumn[] { studentsTable.Columns["StudentID"] };

            // 2. Заполняем таблицу
            Random rand = new Random();
            string[] faculties = { "Computer Science", "Engineering", "Medicine", "Law",
                          "Business", "Arts", "Science", "Education" };
            string[] statuses = { "Active", "Graduated", "On Leave", "Dismissed" };
            string[] firstNames = { "Иван", "Петр", "Алексей", "Мария", "Анна", "Екатерина" };
            string[] lastNames = { "Иванов", "Петров", "Сидоров", "Смирнова", "Кузнецова", "Васильева" };

            for (int i = 1; i <= 220; i++)
            {
                double gpa = Math.Round(2.0 + rand.NextDouble() * 3.0, 2); // GPA от 2.0 до 5.0
                int year = rand.Next(1, 6);
                string status = year > 4 ? "Graduated" : "Active";

                studentsTable.Rows.Add(
                    i,
                    $"{lastNames[rand.Next(lastNames.Length)]} {firstNames[rand.Next(firstNames.Length)]}",
                    gpa,
                    faculties[rand.Next(faculties.Length)],
                    year,
                    status
                );
            }

            Console.WriteLine($"Таблица содержит {studentsTable.Rows.Count} студентов");

            // 3. Создаем несколько DataView одновременно
            Console.WriteLine("\n=== Несколько DataView одной таблицы ===");

            // DataView 1: Лучшие студенты (GPA > 4.0)
            DataView topStudentsView = new DataView(studentsTable)
            {
                RowFilter = "GPA > 4.0",
                Sort = "GPA DESC"
            };

            // DataView 2: Студенты первого курса
            DataView firstYearView = new DataView(studentsTable)
            {
                RowFilter = "Year = 1",
                Sort = "Name ASC"
            };

            // DataView 3: Студенты в академическом отпуске
            DataView onLeaveView = new DataView(studentsTable)
            {
                RowFilter = "Status = 'On Leave'",
                Sort = "Faculty ASC, Name ASC"
            };

            // DataView 4: Все студенты, отсортированные по факультету
            DataView byFacultyView = new DataView(studentsTable)
            {
                Sort = "Faculty ASC, GPA DESC"
            };

            // DataView 5: Выпускники
            DataView graduatesView = new DataView(studentsTable)
            {
                RowFilter = "Status = 'Graduated'",
                Sort = "Year DESC, GPA DESC"
            };

            // 4. Анализ каждого представления
            Console.WriteLine("\n--- Анализ каждого DataView ---");

            var views = new List<(string Name, DataView View)>
    {
        ("Лучшие студенты (GPA > 4.0)", topStudentsView),
        ("Первый курс", firstYearView),
        ("В академическом отпуске", onLeaveView),
        ("По факультетам", byFacultyView),
        ("Выпускники", graduatesView)
    };

            foreach (var viewInfo in views)
            {
                Console.WriteLine($"\n{viewInfo.Name}:");
                Console.WriteLine($"  Количество: {viewInfo.View.Count}");

                if (viewInfo.View.Count > 0)
                {
                    // Вычисляем средний GPA
                    double avgGpa = 0;
                    for (int i = 0; i < viewInfo.View.Count; i++)
                    {
                        avgGpa += Convert.ToDouble(viewInfo.View[i]["GPA"]);
                    }
                    avgGpa /= viewInfo.View.Count;

                    Console.WriteLine($"  Средний GPA: {avgGpa:F2}");

                    // Показываем первых студентов
                    Console.WriteLine("  Примеры:");
                    for (int i = 0; i < Math.Min(3, viewInfo.View.Count); i++)
                    {
                        Console.WriteLine($"    {viewInfo.View[i]["Name"]} - {viewInfo.View[i]["Faculty"]} (GPA: {viewInfo.View[i]["GPA"]})");
                    }
                }
            }

            // 5. Сводная статистика
            Console.WriteLine("\n=== Сводная статистика ===");

            Console.WriteLine("\nСтатистика по факультетам:");
            DataView facultyStatsView = new DataView(studentsTable);
            facultyStatsView.Sort = "Faculty ASC";

            string currentFaculty = "";
            int facultyCount = 0;
            double facultyTotalGpa = 0;
            int facultyIndex = 0;

            for (int i = 0; i < facultyStatsView.Count; i++)
            {
                string faculty = facultyStatsView[i]["Faculty"].ToString();

                if (faculty != currentFaculty)
                {
                    if (facultyCount > 0)
                    {
                        Console.WriteLine($"  {currentFaculty}: {facultyCount} студентов, средний GPA: {facultyTotalGpa / facultyCount:F2}");
                    }

                    currentFaculty = faculty;
                    facultyCount = 0;
                    facultyTotalGpa = 0;
                    facultyIndex++;

                    if (facultyIndex > 5) break; // Ограничим вывод
                }

                facultyCount++;
                facultyTotalGpa += Convert.ToDouble(facultyStatsView[i]["GPA"]);
            }

            if (facultyCount > 0)
            {
                Console.WriteLine($"  {currentFaculty}: {facultyCount} студентов, средний GPA: {facultyTotalGpa / facultyCount:F2}");
            }

            // 6. Поиск студента одновременно во всех DataView
            Console.WriteLine("\n=== Поиск студента во всех представлениях ===");

            string searchName = "Иванов"; // Часть имени для поиска

            Console.WriteLine($"\nПоиск студентов с фамилией '{searchName}':");

            foreach (var viewInfo in views)
            {
                // Ищем в каждом представлении
                var foundStudents = new List<DataRowView>();
                for (int i = 0; i < viewInfo.View.Count; i++)
                {
                    if (viewInfo.View[i]["Name"].ToString().Contains(searchName))
                    {
                        foundStudents.Add(viewInfo.View[i]);
                    }
                }

                if (foundStudents.Count > 0)
                {
                    Console.WriteLine($"\n  В '{viewInfo.Name}' найдено {foundStudents.Count}:");
                    foreach (var student in foundStudents.Take(3))
                    {
                        Console.WriteLine($"    {student["Name"]} - {student["Faculty"]} (GPA: {student["GPA"]})");
                    }

                    if (foundStudents.Count > 3)
                    {
                        Console.WriteLine($"    ... и еще {foundStudents.Count - 3}");
                    }
                }
            }

            // 7. Добавление нового студента
            Console.WriteLine("\n=== Добавление нового студента ===");

            Console.WriteLine("\nКоличество студентов до добавления:");
            foreach (var viewInfo in views)
            {
                Console.WriteLine($"  {viewInfo.Name}: {viewInfo.View.Count}");
            }

            // Добавляем нового студента
            DataRow newStudent = studentsTable.NewRow();
            newStudent["StudentID"] = 221;
            newStudent["Name"] = "Новиков Дмитрий";
            newStudent["GPA"] = 4.8;
            newStudent["Faculty"] = "Computer Science";
            newStudent["Year"] = 3;
            newStudent["Status"] = "Active";
            studentsTable.Rows.Add(newStudent);

            Console.WriteLine("\nДобавлен новый студент: Новиков Дмитрий (GPA: 4.8, Computer Science, 3 курс)");

            Console.WriteLine("\nКоличество студентов после добавления:");
            foreach (var viewInfo in views)
            {
                Console.WriteLine($"  {viewInfo.Name}: {viewInfo.View.Count}");
            }

            // Проверяем, в каких представлениях появился новый студент
            Console.WriteLine("\nНовый студент появился в представлениях:");
            foreach (var viewInfo in views)
            {
                bool found = false;
                for (int i = 0; i < viewInfo.View.Count; i++)
                {
                    if (viewInfo.View[i]["StudentID"].ToString() == "221")
                    {
                        found = true;
                        break;
                    }
                }

                if (found)
                {
                    Console.WriteLine($"  ✓ {viewInfo.Name}");
                }
            }

            // 8. Отчёт, показывающий все представления одновременно
            Console.WriteLine("\n=== Сводный отчёт по всем представлениям ===");

            Console.WriteLine("\nПредставление                | Студентов | Сред. GPA | Пример студента");
            Console.WriteLine("----------------------------------------------------------------------");

            foreach (var viewInfo in views)
            {
                if (viewInfo.View.Count > 0)
                {
                    // Вычисляем средний GPA
                    double totalGpa = 0;
                    for (int i = 0; i < viewInfo.View.Count; i++)
                    {
                        totalGpa += Convert.ToDouble(viewInfo.View[i]["GPA"]);
                    }
                    double avgGpa = totalGpa / viewInfo.View.Count;

                    // Берем первого студента в качестве примера
                    string exampleStudent = $"{viewInfo.View[0]["Name"]} ({viewInfo.View[0]["GPA"]})";

                    Console.WriteLine($"{viewInfo.Name,-28} | {viewInfo.View.Count,9} | {avgGpa,9:F2} | {exampleStudent}");
                }
                else
                {
                    Console.WriteLine($"{viewInfo.Name,-28} | {viewInfo.View.Count,9} | {"-",9} | -");
                }
            }

            // 9. Измерение использования памяти
            Console.WriteLine("\n=== Использование памяти ===");

            // Создаем много представлений для теста
            Console.WriteLine("\nСоздаем 100 различных представлений...");

            var manyViews = new List<DataView>();
            long memoryBefore = GC.GetTotalMemory(true);

            for (int i = 0; i < 100; i++)
            {
                DataView view = new DataView(studentsTable)
                {
                    RowFilter = $"GPA > {3.0 + i * 0.02:F2}", // Разные фильтры
                    Sort = i % 2 == 0 ? "Name ASC" : "GPA DESC"
                };
                manyViews.Add(view);
            }

            long memoryAfter = GC.GetTotalMemory(true);
            long memoryUsed = memoryAfter - memoryBefore;

            Console.WriteLine($"Использовано памяти на 100 DataView: {memoryUsed / 1024} KB");
            Console.WriteLine($"В среднем на DataView: {memoryUsed / (100 * 1024):F2} KB");

            // Очищаем
            manyViews.Clear();
            GC.Collect();

            // 10. Дополнительный анализ: распределение по курсам
            Console.WriteLine("\n=== Распределение по курсам ===");

            var yearStats = new Dictionary<int, (int Count, double TotalGpa)>();

            for (int i = 0; i < studentsTable.Rows.Count; i++)
            {
                int year = Convert.ToInt32(studentsTable.Rows[i]["Year"]);
                double gpa = Convert.ToDouble(studentsTable.Rows[i]["GPA"]);

                if (!yearStats.ContainsKey(year))
                    yearStats[year] = (0, 0);

                var stats = yearStats[year];
                stats.Count++;
                stats.TotalGpa += gpa;
                yearStats[year] = stats;
            }

            Console.WriteLine("\nКурс | Студентов | Сред. GPA");
            Console.WriteLine("-----------------------------");
            foreach (var year in yearStats.Keys.OrderBy(k => k))
            {
                double avgGpa = yearStats[year].TotalGpa / yearStats[year].Count;
                Console.WriteLine($"{year,4} | {yearStats[year].Count,9} | {avgGpa,9:F2}");
            }
        }
        #endregion

        #region Задание 16: Динамическое изменение фильтра
        static void Task16()
        {
            Console.WriteLine("Задание 16: Динамическое изменение фильтра и сортировки в реальном времени\n");

            // 1. Создаем таблицу фильмов
            DataTable moviesTable = new DataTable("Movies");

            moviesTable.Columns.Add("MovieID", typeof(int));
            moviesTable.Columns.Add("Title", typeof(string));
            moviesTable.Columns.Add("Director", typeof(string));
            moviesTable.Columns.Add("Year", typeof(int));
            moviesTable.Columns.Add("Genre", typeof(string));
            moviesTable.Columns.Add("Rating", typeof(double));
            moviesTable.Columns.Add("BoxOffice", typeof(decimal));

            // Устанавливаем первичный ключ
            moviesTable.PrimaryKey = new DataColumn[] { moviesTable.Columns["MovieID"] };

            // 2. Заполняем таблицу
            Random rand = new Random();
            string[] genres = { "Action", "Comedy", "Drama", "Sci-Fi", "Horror", "Romance", "Thriller", "Documentary" };
            string[] directors = { "Спилберг", "Нолан", "Кэмерон", "Скорсезе", "Тарантино", "Финчер", "Кубрик", "Хичкок" };
            string[] titles = { "Начало", "Побег", "Мечта", "Путешествие", "Тайна", "Легенда", "История", "Приключение" };

            for (int i = 1; i <= 320; i++)
            {
                double rating = Math.Round(1.0 + rand.NextDouble() * 9.0, 1); // Рейтинг от 1.0 до 10.0
                decimal boxOffice = Math.Round(rand.Next(10000, 10000000) + (decimal)rand.NextDouble(), 2);

                moviesTable.Rows.Add(
                    i,
                    $"{titles[rand.Next(titles.Length)]} {i % 100}",
                    directors[rand.Next(directors.Length)],
                    rand.Next(1980, 2024),
                    genres[rand.Next(genres.Length)],
                    rating,
                    boxOffice
                );
            }

            Console.WriteLine($"Таблица содержит {moviesTable.Rows.Count} фильмов");

            // 3. Создаем DataView с начальным фильтром
            DataView moviesView = new DataView(moviesTable)
            {
                RowFilter = "Year >= 2000",
                Sort = "Rating DESC"
            };

            Console.WriteLine($"\nНачальный фильтр: фильмы с 2000 года, отсортированы по рейтингу");
            Console.WriteLine($"Найдено фильмов: {moviesView.Count}");

            // 4. Имитация интерактивных элементов управления
            Console.WriteLine("\n=== Имитация интерактивных элементов управления ===");

            // 4.1. ComboBox для выбора жанра
            Console.WriteLine("\n--- Выбор жанра (ComboBox) ---");

            string selectedGenre = "Action"; // Имитация выбора пользователя
            Console.WriteLine($"Выбран жанр: {selectedGenre}");

            UpdateFilter(moviesView, $"Genre = '{selectedGenre}'", "Rating DESC");
            Console.WriteLine($"Найдено фильмов жанра {selectedGenre}: {moviesView.Count}");

            // Показываем первые 3 фильма
            Console.WriteLine("Топ-3 фильма:");
            for (int i = 0; i < Math.Min(3, moviesView.Count); i++)
            {
                Console.WriteLine($"  {moviesView[i]["Title"]} ({moviesView[i]["Year"]}) - рейтинг: {moviesView[i]["Rating"]}");
            }

            // 4.2. TextBox для поиска по названию
            Console.WriteLine("\n--- Поиск по названию (TextBox) ---");

            string searchText = "Тайна"; // Имитация ввода пользователя
            Console.WriteLine($"Поиск: '{searchText}'");

            if (!string.IsNullOrEmpty(searchText))
            {
                string currentFilter = moviesView.RowFilter;
                string searchFilter = $"Title LIKE '%{searchText}%'";

                if (string.IsNullOrEmpty(currentFilter))
                    UpdateFilter(moviesView, searchFilter, moviesView.Sort);
                else
                    UpdateFilter(moviesView, $"{currentFilter} AND {searchFilter}", moviesView.Sort);
            }

            Console.WriteLine($"Найдено фильмов: {moviesView.Count}");

            // 4.3. Slider для выбора диапазона рейтинга
            Console.WriteLine("\n--- Диапазон рейтинга (Slider) ---");

            double minRating = 7.0;
            double maxRating = 10.0;
            Console.WriteLine($"Диапазон рейтинга: {minRating}-{maxRating}");

            string ratingFilter = $"Rating >= {minRating} AND Rating <= {maxRating}";
            string combinedFilter = CombineFilters(moviesView.RowFilter, ratingFilter);
            UpdateFilter(moviesView, combinedFilter, moviesView.Sort);

            Console.WriteLine($"Фильмов с рейтингом {minRating}-{maxRating}: {moviesView.Count}");

            // 4.4. RadioButtons для выбора сортировки
            Console.WriteLine("\n--- Выбор сортировки (RadioButtons) ---");

            // Имитация переключения между вариантами сортировки
            var sortOptions = new Dictionary<string, string>
    {
        {"По году (новые)", "Year DESC"},
        {"По рейтингу", "Rating DESC"},
        {"По кассовым сборам", "BoxOffice DESC"},
        {"По названию", "Title ASC"},
        {"По режиссеру и году", "Director ASC, Year DESC"}
    };

            string selectedSort = "По кассовым сборам"; // Имитация выбора пользователя
            Console.WriteLine($"Выбрана сортировка: {selectedSort}");

            if (sortOptions.ContainsKey(selectedSort))
            {
                moviesView.Sort = sortOptions[selectedSort];
                Console.WriteLine($"Применена сортировка: {moviesView.Sort}");
            }

            // 5. Обновление результатов в реальном времени
            Console.WriteLine("\n=== Текущие результаты ===");

            Console.WriteLine($"Текущий фильтр: {moviesView.RowFilter}");
            Console.WriteLine($"Текущая сортировка: {moviesView.Sort}");
            Console.WriteLine($"Найдено фильмов: {moviesView.Count}");

            if (moviesView.Count > 0)
            {
                Console.WriteLine("\nПервые 5 фильмов:");
                for (int i = 0; i < Math.Min(5, moviesView.Count); i++)
                {
                    Console.WriteLine($"  {moviesView[i]["Title"]} ({moviesView[i]["Year"]}) - {moviesView[i]["Genre"]} - рейтинг: {moviesView[i]["Rating"]} - сборы: {moviesView[i]["BoxOffice"]:C}");
                }
            }

            // 6. Количество результатов для каждого фильтра
            Console.WriteLine("\n=== Статистика по фильтрам ===");

            // Тестируем разные жанры
            Console.WriteLine("\nКоличество фильмов по жанрам:");
            foreach (var genre in genres.Take(5))
            {
                DataView genreView = new DataView(moviesTable)
                {
                    RowFilter = $"Genre = '{genre}'"
                };
                Console.WriteLine($"  {genre}: {genreView.Count} фильмов");
            }

            // Тестируем диапазоны годов
            Console.WriteLine("\nКоличество фильмов по годам выпуска:");
            var yearRanges = new List<(string Range, string Filter)>
    {
        ("до 1990", "Year < 1990"),
        ("1990-1999", "Year >= 1990 AND Year <= 1999"),
        ("2000-2009", "Year >= 2000 AND Year <= 2009"),
        ("2010-2019", "Year >= 2010 AND Year <= 2019"),
        ("2020+", "Year >= 2020")
    };

            foreach (var range in yearRanges)
            {
                DataView rangeView = new DataView(moviesTable)
                {
                    RowFilter = range.Filter
                };
                Console.WriteLine($"  {range.Range}: {rangeView.Count} фильмов");
            }

            // 7. Кнопка "Сброс фильтров"
            Console.WriteLine("\n=== Сброс фильтров ===");

            Console.WriteLine($"До сброса: {moviesView.Count} фильмов");

            moviesView.RowFilter = "";
            moviesView.Sort = "";

            Console.WriteLine($"После сброса: {moviesView.Count} фильмов");
            Console.WriteLine("Все фильтры и сортировка сброшены");

            // 8. Сохранение последнего использованного фильтра
            Console.WriteLine("\n=== Сохранение конфигурации фильтра ===");

            string lastFilter = "Year >= 2010 AND Rating >= 8.0 AND Genre = 'Drama'";
            string lastSort = "BoxOffice DESC";

            Console.WriteLine($"Сохраняем фильтр: {lastFilter}");
            Console.WriteLine($"Сохраняем сортировку: {lastSort}");

            // Имитация сохранения
            SaveLastFilterConfiguration(lastFilter, lastSort);

            // Имитация загрузки
            var loadedConfig = LoadLastFilterConfiguration();
            Console.WriteLine($"\nЗагружаем сохраненную конфигурацию:");
            Console.WriteLine($"  Фильтр: {loadedConfig.Filter}");
            Console.WriteLine($"  Сортировка: {loadedConfig.Sort}");

            // Применение загруженной конфигурации
            UpdateFilter(moviesView, loadedConfig.Filter, loadedConfig.Sort);
            Console.WriteLine($"\nПрименена загруженная конфигурация: {moviesView.Count} фильмов");

            // 9. Демонстрация производительности при частых обновлениях
            Console.WriteLine("\n=== Производительность при частых обновлениях ===");

            Stopwatch sw = new Stopwatch();
            int updateCount = 100;

            // Тест: быстрое изменение фильтра
            sw.Start();
            for (int i = 0; i < updateCount; i++)
            {
                moviesView.RowFilter = $"Year >= {1980 + i % 40}";
                int count = moviesView.Count; // Принудительное обновление
            }
            sw.Stop();

            Console.WriteLine($"{updateCount} обновлений фильтра: {sw.ElapsedMilliseconds} ms");
            Console.WriteLine($"В среднем: {sw.ElapsedMilliseconds / (double)updateCount:F2} ms на обновление");

            // 10. Расширенный пример: комбинированный фильтр
            Console.WriteLine("\n=== Комбинированный фильтр (пример пользовательского запроса) ===");

            // Пользователь хочет найти:
            // - Фильмы определенного режиссера
            // - Вышедшие после 2010 года
            // - С рейтингом выше 8.0
            // - Отсортированные по сборам

            string directorFilter = "Director = 'Нолан'";
            string yearFilter = "Year > 2010";
            string highRatingFilter = "Rating > 8.0";

            string complexFilter = CombineFilters(directorFilter, yearFilter, highRatingFilter);
            string complexSort = "BoxOffice DESC";

            UpdateFilter(moviesView, complexFilter, complexSort);

            Console.WriteLine($"Фильтр: {complexFilter}");
            Console.WriteLine($"Сортировка: {complexSort}");
            Console.WriteLine($"Результатов: {moviesView.Count}");

            if (moviesView.Count > 0)
            {
                Console.WriteLine("\nНайденные фильмы:");
                for (int i = 0; i < Math.Min(5, moviesView.Count); i++)
                {
                    Console.WriteLine($"  {moviesView[i]["Title"]} ({moviesView[i]["Year"]}) - рейтинг: {moviesView[i]["Rating"]} - сборы: {moviesView[i]["BoxOffice"]:C}");
                }
            }
        }

        static void UpdateFilter(DataView view, string filter, string sort)
        {
            try
            {
                view.RowFilter = filter;
                view.Sort = sort;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при обновлении фильтра: {ex.Message}");
            }
        }

        static string CombineFilters(params string[] filters)
        {
            var validFilters = filters.Where(f => !string.IsNullOrEmpty(f)).ToList();
            return string.Join(" AND ", validFilters);
        }

        static void SaveLastFilterConfiguration(string filter, string sort)
        {
            // В реальном приложении здесь была бы запись в файл или базу данных
            Console.WriteLine("Конфигурация сохранена");
        }

        static (string Filter, string Sort) LoadLastFilterConfiguration()
        {
            // В реальном приложении здесь было бы чтение из файла или базы данных
            return ("Year >= 2010", "Rating DESC");
        }
        #endregion

        #region Задание 17: DataView для создания графиков/диаграмм
        static void Task17()
        {
            Console.WriteLine("Задание 17: Использование DataView для создания графиков/диаграмм\n");

            // 1. Создаем таблицу продаж по месяцам
            DataTable salesTable = new DataTable("MonthlySales");

            salesTable.Columns.Add("SalesID", typeof(int));
            salesTable.Columns.Add("Month", typeof(string));
            salesTable.Columns.Add("Product", typeof(string));
            salesTable.Columns.Add("Amount", typeof(decimal));
            salesTable.Columns.Add("Region", typeof(string));

            // 2. Заполняем таблицу данными за год
            Random rand = new Random();
            string[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                       "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
            string[] products = { "Product A", "Product B", "Product C", "Product D" };
            string[] regions = { "North", "South", "East", "West" };

            int salesId = 1;
            for (int monthIdx = 0; monthIdx < months.Length; monthIdx++)
            {
                foreach (var product in products)
                {
                    foreach (var region in regions)
                    {
                        // Случайные продажи с некоторой сезонностью
                        decimal baseAmount = 10000;
                        decimal seasonFactor = 1.0m + 0.3m * (decimal)Math.Sin(monthIdx * Math.PI / 6);
                        decimal randomFactor = 0.8m + 0.4m * (decimal)rand.NextDouble();
                        decimal amount = Math.Round(baseAmount * seasonFactor * randomFactor, 2);

                        salesTable.Rows.Add(
                            salesId++,
                            months[monthIdx],
                            product,
                            amount,
                            region
                        );
                    }
                }
            }

            Console.WriteLine($"Таблица содержит {salesTable.Rows.Count} записей о продажах");

            // 3. Создаем несколько DataView для различных представлений
            Console.WriteLine("\n=== Подготовка данных для визуализации ===");

            // 3.1. DataView по регионам
            Console.WriteLine("\n--- Данные по регионам ---");

            // Сначала группируем по регионам
            var regionSales = new Dictionary<string, decimal>();
            DataView regionView = new DataView(salesTable);
            regionView.Sort = "Region ASC";

            string currentRegion = "";
            decimal regionTotal = 0;

            for (int i = 0; i < regionView.Count; i++)
            {
                string region = regionView[i]["Region"].ToString();
                decimal amount = Convert.ToDecimal(regionView[i]["Amount"]);

                if (region != currentRegion)
                {
                    if (!string.IsNullOrEmpty(currentRegion))
                    {
                        regionSales[currentRegion] = regionTotal;
                    }
                    currentRegion = region;
                    regionTotal = 0;
                }

                regionTotal += amount;
            }

            if (!string.IsNullOrEmpty(currentRegion))
            {
                regionSales[currentRegion] = regionTotal;
            }

            // Выводим данные для диаграммы
            Console.WriteLine("Продажи по регионам (для круговой диаграммы):");
            foreach (var region in regionSales)
            {
                Console.WriteLine($"  {region.Key}: {region.Value:C}");
            }

            // 3.2. DataView по продуктам
            Console.WriteLine("\n--- Данные по продуктам ---");

            var productSales = new Dictionary<string, decimal>();
            DataView productView = new DataView(salesTable);
            productView.Sort = "Product ASC";

            string currentProduct = "";
            decimal productTotal = 0;

            for (int i = 0; i < productView.Count; i++)
            {
                string product = productView[i]["Product"].ToString();
                decimal amount = Convert.ToDecimal(productView[i]["Amount"]);

                if (product != currentProduct)
                {
                    if (!string.IsNullOrEmpty(currentProduct))
                    {
                        productSales[currentProduct] = productTotal;
                    }
                    currentProduct = product;
                    productTotal = 0;
                }

                productTotal += amount;
            }

            if (!string.IsNullOrEmpty(currentProduct))
            {
                productSales[currentProduct] = productTotal;
            }

            Console.WriteLine("Продажи по продуктам (для столбчатой диаграммы):");
            foreach (var product in productSales)
            {
                Console.WriteLine($"  {product.Key}: {product.Value:C}");
            }

            // 3.3. DataView по месяцам
            Console.WriteLine("\n--- Данные по месяцам ---");

            var monthlySales = new Dictionary<string, decimal>();
            DataView monthlyView = new DataView(salesTable);
            monthlyView.Sort = "Month ASC";

            string currentMonth = "";
            decimal monthTotal = 0;

            for (int i = 0; i < monthlyView.Count; i++)
            {
                string month = monthlyView[i]["Month"].ToString();
                decimal amount = Convert.ToDecimal(monthlyView[i]["Amount"]);

                if (month != currentMonth)
                {
                    if (!string.IsNullOrEmpty(currentMonth))
                    {
                        monthlySales[currentMonth] = monthTotal;
                    }
                    currentMonth = month;
                    monthTotal = 0;
                }

                monthTotal += amount;
            }

            if (!string.IsNullOrEmpty(currentMonth))
            {
                monthlySales[currentMonth] = monthTotal;
            }

            // 4. Создание графиков в консоли
            Console.WriteLine("\n=== Графики в консоли ===");

            // 4.1. График общих продаж по месяцам
            Console.WriteLine("\n--- График продаж по месяцам ---");

            if (monthlySales.Count > 0)
            {
                decimal maxSales = monthlySales.Values.Max();
                int maxBarWidth = 50;

                // Выводим заголовок
                Console.WriteLine("Месяц   | Продажи    | График");
                Console.WriteLine("--------|------------|---------------------------------------------");

                foreach (var month in months)
                {
                    if (monthlySales.ContainsKey(month))
                    {
                        decimal sales = monthlySales[month];
                        int barWidth = (int)((sales / maxSales) * maxBarWidth);
                        string bar = new string('█', barWidth);

                        Console.WriteLine($"{month,-6} | {sales,10:C} | {bar}");
                    }
                }
            }

            // 4.2. Диаграмма продаж по регионам
            Console.WriteLine("\n--- Диаграмма продаж по регионам (круговая) ---");

            if (regionSales.Count > 0)
            {
                decimal totalSales = regionSales.Values.Sum();

                Console.WriteLine("\nДоля каждого региона в общих продажах:");
                foreach (var region in regionSales)
                {
                    double percentage = (double)(region.Value / totalSales * 100);
                    int stars = (int)(percentage / 2); // Одна звезда = 2%
                    string starBar = new string('★', stars);

                    Console.WriteLine($"  {region.Key,-6} {percentage,6:F1}% {starBar}");
                }
            }

            // 4.3. Диаграмма продаж по продуктам
            Console.WriteLine("\n--- Диаграмма продаж по продуктам (столбчатая) ---");

            if (productSales.Count > 0)
            {
                decimal maxProductSales = productSales.Values.Max();
                int maxBarWidth = 40;

                Console.WriteLine("\nПродукт    | Продажи    | График");
                Console.WriteLine("-----------|------------|---------------------------------------");

                foreach (var product in productSales)
                {
                    decimal sales = product.Value;
                    int barWidth = (int)((sales / maxProductSales) * maxBarWidth);
                    string bar = new string('▓', barWidth);

                    Console.WriteLine($"{product.Key,-10} | {sales,10:C} | {bar}");
                }
            }

            // 5. Интерактивное обновление диаграмм при изменении фильтра
            Console.WriteLine("\n=== Интерактивное обновление диаграмм ===");

            // 5.1. Фильтр по региону
            Console.WriteLine("\n--- Фильтр: только регион 'North' ---");

            DataView filteredView = new DataView(salesTable)
            {
                RowFilter = "Region = 'North'",
                Sort = "Month ASC"
            };

            // Пересчитываем продажи по месяцам для отфильтрованных данных
            var filteredMonthlySales = new Dictionary<string, decimal>();
            string currentFilteredMonth = "";
            decimal filteredMonthTotal = 0;

            for (int i = 0; i < filteredView.Count; i++)
            {
                string month = filteredView[i]["Month"].ToString();
                decimal amount = Convert.ToDecimal(filteredView[i]["Amount"]);

                if (month != currentFilteredMonth)
                {
                    if (!string.IsNullOrEmpty(currentFilteredMonth))
                    {
                        filteredMonthlySales[currentFilteredMonth] = filteredMonthTotal;
                    }
                    currentFilteredMonth = month;
                    filteredMonthTotal = 0;
                }

                filteredMonthTotal += amount;
            }

            if (!string.IsNullOrEmpty(currentFilteredMonth))
            {
                filteredMonthlySales[currentFilteredMonth] = filteredMonthTotal;
            }

            // Выводим обновленный график
            if (filteredMonthlySales.Count > 0)
            {
                decimal maxFilteredSales = filteredMonthlySales.Values.Max();
                int maxBarWidth = 40;

                Console.WriteLine("\nПродажи в регионе North по месяцам:");
                Console.WriteLine("Месяц   | Продажи    | График");
                Console.WriteLine("--------|------------|-------------------------------------");

                foreach (var month in months)
                {
                    if (filteredMonthlySales.ContainsKey(month))
                    {
                        decimal sales = filteredMonthlySales[month];
                        int barWidth = (int)((sales / maxFilteredSales) * maxBarWidth);
                        string bar = new string('█', barWidth);

                        Console.WriteLine($"{month,-6} | {sales,10:C} | {bar}");
                    }
                }
            }

            // 6. Фильтрация диаграмм
            Console.WriteLine("\n=== Фильтрация диаграмм ===");

            // Фильтр по продукту и региону
            Console.WriteLine("\n--- Фильтр: Product = 'Product A', Region = 'East' ---");

            DataView specificView = new DataView(salesTable)
            {
                RowFilter = "Product = 'Product A' AND Region = 'East'",
                Sort = "Month ASC"
            };

            // Собираем данные для графика
            var specificSales = new Dictionary<string, decimal>();
            for (int i = 0; i < specificView.Count; i++)
            {
                string month = specificView[i]["Month"].ToString();
                decimal amount = Convert.ToDecimal(specificView[i]["Amount"]);

                if (!specificSales.ContainsKey(month))
                    specificSales[month] = 0;

                specificSales[month] += amount;
            }

            // Заполняем отсутствующие месяцы нулями
            foreach (var month in months)
            {
                if (!specificSales.ContainsKey(month))
                    specificSales[month] = 0;
            }

            // Выводим график
            if (specificSales.Count > 0)
            {
                decimal maxSpecificSales = specificSales.Values.Max();
                if (maxSpecificSales == 0) maxSpecificSales = 1; // Чтобы избежать деления на ноль

                Console.WriteLine("\nПродажи Product A в регионе East по месяцам:");
                Console.WriteLine("Месяц   | Продажи    | График");
                Console.WriteLine("--------|------------|-------------------------------------");

                foreach (var month in months)
                {
                    decimal sales = specificSales[month];
                    int barWidth = maxSpecificSales > 0 ? (int)((sales / maxSpecificSales) * 40) : 0;
                    string bar = new string('█', barWidth);

                    Console.WriteLine($"{month,-6} | {sales,10:C} | {bar}");
                }
            }

            // 7. Вычисление итоговых значений
            Console.WriteLine("\n=== Итоговые значения ===");

            decimal totalAllSales = salesTable.AsEnumerable()
                .Sum(row => Convert.ToDecimal(row["Amount"]));

            Console.WriteLine($"Общий объем продаж: {totalAllSales:C}");

            // Средние продажи по регионам
            Console.WriteLine("\nСредние продажи по регионам:");
            foreach (var region in regionSales)
            {
                // Подсчитываем количество записей для каждого региона
                int regionCount = salesTable.AsEnumerable()
                    .Count(row => row["Region"].ToString() == region.Key);

                decimal average = regionCount > 0 ? region.Value / regionCount : 0;
                Console.WriteLine($"  {region.Key}: средние {average:C} на запись");
            }

            // Общие продажи по продуктам
            Console.WriteLine("\nОбщие продажи по продуктам:");
            decimal productTotalAll = 0;
            foreach (var product in productSales)
            {
                Console.WriteLine($"  {product.Key}: {product.Value:C}");
                productTotalAll += product.Value;
            }
            Console.WriteLine($"  Всего: {productTotalAll:C}");

            // 8. Вывод легенды и осей координат
            Console.WriteLine("\n=== Легенда графиков ===");

            Console.WriteLine("\nУсловные обозначения:");
            Console.WriteLine("  █ - Продажи (масштабировано к максимальному значению)");
            Console.WriteLine("  ★ - Доля в процентах (одна звезда ≈ 2%)");
            Console.WriteLine("  ▓ - Сравнение продаж продуктов");

            Console.WriteLine("\nОси координат:");
            Console.WriteLine("  Горизонтальная ось (X): Временные периоды (месяцы) или категории");
            Console.WriteLine("  Вертикальная ось (Y): Объем продаж в денежном выражении");

            // 9. Расширенная визуализация: сравнительный график
            Console.WriteLine("\n=== Сравнительный график: регионы по месяцам ===");

            // Собираем данные для сравнения
            var regionMonthlyData = new Dictionary<string, Dictionary<string, decimal>>();

            foreach (var region in regions)
            {
                var monthlyData = new Dictionary<string, decimal>();

                DataView regionMonthlyView = new DataView(salesTable)
                {
                    RowFilter = $"Region = '{region}'",
                    Sort = "Month ASC"
                };

                string currentRMonth = "";
                decimal rMonthTotal = 0;

                for (int i = 0; i < regionMonthlyView.Count; i++)
                {
                    string month = regionMonthlyView[i]["Month"].ToString();
                    decimal amount = Convert.ToDecimal(regionMonthlyView[i]["Amount"]);

                    if (month != currentRMonth)
                    {
                        if (!string.IsNullOrEmpty(currentRMonth))
                        {
                            monthlyData[currentRMonth] = rMonthTotal;
                        }
                        currentRMonth = month;
                        rMonthTotal = 0;
                    }

                    rMonthTotal += amount;
                }

                if (!string.IsNullOrEmpty(currentRMonth))
                {
                    monthlyData[currentRMonth] = rMonthTotal;
                }

                regionMonthlyData[region] = monthlyData;
            }

            // Находим максимальные продажи для масштабирования
            decimal maxRegionMonthly = 0;
            foreach (var regionData in regionMonthlyData.Values)
            {
                foreach (var sales in regionData.Values)
                {
                    if (sales > maxRegionMonthly)
                        maxRegionMonthly = sales;
                }
            }

            // Выводим сравнительный график
            Console.WriteLine("\nСравнение продаж по регионам (первые 3 месяца):");
            Console.WriteLine("Месяц   | North      | South      | East       | West");
            Console.WriteLine("--------|------------|------------|------------|------------");

            foreach (var month in months.Take(3))
            {
                Console.Write($"{month,-6} |");

                foreach (var region in regions)
                {
                    decimal sales = regionMonthlyData[region].ContainsKey(month) ?
                                  regionMonthlyData[region][month] : 0;
                    Console.Write($" {sales,10:C} |");
                }

                Console.WriteLine();
            }
        }
        #endregion

        #region Задание 18: Поиск ближайших значений
        static void Task18()
        {
            Console.WriteLine("Задание 18: Поиск ближайших значений в DataView\n");

            // 1. Создаем таблицу цен на акции
            DataTable stocksTable = new DataTable("Stocks");

            stocksTable.Columns.Add("StockID", typeof(int));
            stocksTable.Columns.Add("CompanyName", typeof(string));
            stocksTable.Columns.Add("Price", typeof(decimal));
            stocksTable.Columns.Add("Date", typeof(DateTime));
            stocksTable.Columns.Add("Volume", typeof(long));

            // Устанавливаем первичный ключ
            stocksTable.PrimaryKey = new DataColumn[] { stocksTable.Columns["StockID"] };

            // 2. Заполняем таблицу историческими данными
            Random rand = new Random();
            string[] companies = { "Apple", "Microsoft", "Google", "Amazon", "Tesla",
                          "Meta", "NVIDIA", "Intel", "AMD", "Netflix" };

            int recordId = 1;
            DateTime startDate = DateTime.Today.AddDays(-365); // Данные за год

            for (int day = 0; day < 365; day += 7) // Данные раз в неделю
            {
                DateTime currentDate = startDate.AddDays(day);

                foreach (var company in companies)
                {
                    // Генерируем реалистичные цены с трендом и волатильностью
                    decimal basePrice = company switch
                    {
                        "Apple" => 150m,
                        "Microsoft" => 250m,
                        "Google" => 120m,
                        "Amazon" => 100m,
                        "Tesla" => 200m,
                        "Meta" => 180m,
                        "NVIDIA" => 300m,
                        "Intel" => 40m,
                        "AMD" => 80m,
                        "Netflix" => 350m,
                        _ => 100m
                    };

                    // Тренд + случайные колебания
                    decimal trend = 1.0m + (day / 365.0m) * 0.2m; // +20% за год
                    decimal volatility = 0.9m + 0.2m * (decimal)rand.NextDouble();
                    decimal price = Math.Round(basePrice * trend * volatility, 2);

                    // Объем торгов
                    long volume = rand.Next(1000000, 10000000);

                    stocksTable.Rows.Add(
                        recordId++,
                        company,
                        price,
                        currentDate,
                        volume
                    );
                }
            }

            Console.WriteLine($"Таблица содержит {stocksTable.Rows.Count} записей о ценах акций");

            // 3. Создаем DataView, отсортированную по Price
            DataView priceSortedView = new DataView(stocksTable)
            {
                Sort = "Price ASC"
            };

            Console.WriteLine($"\nDataView отсортирован по цене (от {priceSortedView[0]["Price"]} до {priceSortedView[priceSortedView.Count - 1]["Price"]})");

            // 4. Функции поиска ближайших значений
            Console.WriteLine("\n=== Поиск ближайших значений ===");

            // 4.1. Поиск ближайшей цены (выше и ниже указанного значения)
            Console.WriteLine("\n--- Поиск ближайших цен к 200 ---");

            decimal targetPrice = 200m;
            var nearestResult = FindNearestPrices(priceSortedView, targetPrice);

            Console.WriteLine($"Цена для поиска: {targetPrice:C}");
            if (nearestResult.Below != null)
            {
                Console.WriteLine($"Ближайшая ниже: {nearestResult.Below.Price:C} ({nearestResult.Below.CompanyName}, {nearestResult.Below.Date:dd.MM.yyyy})");
            }
            else
            {
                Console.WriteLine("Нет цен ниже указанной");
            }

            if (nearestResult.Above != null)
            {
                Console.WriteLine($"Ближайшая выше: {nearestResult.Above.Price:C} ({nearestResult.Above.CompanyName}, {nearestResult.Above.Date:dd.MM.yyyy})");
            }
            else
            {
                Console.WriteLine("Нет цен выше указанной");
            }

            // 4.2. Поиск компаний в диапазоне цен
            Console.WriteLine("\n--- Поиск акций в диапазоне 150-250 ---");

            decimal minPrice = 150m;
            decimal maxPrice = 250m;

            var rangeResult = FindStocksInRange(priceSortedView, minPrice, maxPrice);

            Console.WriteLine($"Диапазон: {minPrice:C} - {maxPrice:C}");
            Console.WriteLine($"Найдено акций: {rangeResult.Count}");

            if (rangeResult.Count > 0)
            {
                Console.WriteLine("\nПримеры акций в диапазоне:");
                var sampleStocks = rangeResult.Take(5);
                foreach (var stock in sampleStocks)
                {
                    Console.WriteLine($"  {stock.CompanyName}: {stock.Price:C} ({stock.Date:dd.MM.yyyy})");
                }

                if (rangeResult.Count > 5)
                {
                    Console.WriteLine($"  ... и еще {rangeResult.Count - 5} акций");
                }

                // Группировка по компаниям
                var byCompany = rangeResult.GroupBy(s => s.CompanyName)
                                          .Select(g => new { Company = g.Key, Count = g.Count() })
                                          .OrderByDescending(x => x.Count);

                Console.WriteLine("\nРаспределение по компаниям:");
                foreach (var company in byCompany)
                {
                    Console.WriteLine($"  {company.Company}: {company.Count} записей");
                }
            }

            // 4.3. Поиск акции с максимальной ценой в диапазоне
            Console.WriteLine("\n--- Максимальная цена в диапазоне 100-300 ---");

            decimal rangeMin = 100m;
            decimal rangeMax = 300m;

            var maxInRange = FindMaxPriceInRange(priceSortedView, rangeMin, rangeMax);

            if (maxInRange != null)
            {
                Console.WriteLine($"Максимальная цена в диапазоне {rangeMin:C}-{rangeMax:C}:");
                Console.WriteLine($"  {maxInRange.CompanyName}: {maxInRange.Price:C} ({maxInRange.Date:dd.MM.yyyy})");
            }
            else
            {
                Console.WriteLine("В указанном диапазоне нет акций");
            }

            // 4.4. Поиск акции с минимальной ценой в диапазоне
            Console.WriteLine("\n--- Минимальная цена в диапазоне 50-200 ---");

            var minInRange = FindMinPriceInRange(priceSortedView, 50m, 200m);

            if (minInRange != null)
            {
                Console.WriteLine($"Минимальная цена в диапазоне 50-200:");
                Console.WriteLine($"  {minInRange.CompanyName}: {minInRange.Price:C} ({minInRange.Date:dd.MM.yyyy})");
            }

            // 4.5. Поиск "скачков" цены (изменения > 10%)
            Console.WriteLine("\n--- Поиск скачков цены (>10% за неделю) ---");

            var priceJumps = FindPriceJumps(stocksTable, 0.10m); // 10%

            Console.WriteLine($"Найдено скачков цены >10%: {priceJumps.Count}");

            if (priceJumps.Count > 0)
            {
                Console.WriteLine("\nКрупнейшие скачки:");
                var topJumps = priceJumps.OrderByDescending(j => j.PercentageChange).Take(5);
                foreach (var jump in topJumps)
                {
                    Console.WriteLine($"  {jump.CompanyName}: {jump.OldPrice:C} → {jump.NewPrice:C} " +
                                    $"({jump.PercentageChange:P1}) за неделю");
                }
            }

            // 5. Использование BinarySearch для оптимальной производительности
            Console.WriteLine("\n=== Использование BinarySearch ===");

            // Создаем DataView отсортированный по цене для бинарного поиска
            DataView binarySearchView = new DataView(stocksTable)
            {
                Sort = "Price ASC"
            };

            decimal searchPrice = 175m;
            Console.WriteLine($"\nBinarySearch для цены {searchPrice:C}:");

            int binaryIndex = BinarySearchPrice(binarySearchView, searchPrice);

            if (binaryIndex >= 0)
            {
                Console.WriteLine($"Точное совпадение найдено на позиции {binaryIndex}");
                Console.WriteLine($"  {binarySearchView[binaryIndex]["CompanyName"]}: {binarySearchView[binaryIndex]["Price"]:C}");
            }
            else
            {
                // Бинарный поиск возвращает отрицательное значение, если точного совпадения нет
                // Битовая дополняющая позиция указывает, где элемент должен быть
                int insertionPoint = ~binaryIndex;
                Console.WriteLine($"Точное совпадение не найдено. Элемент должен быть на позиции {insertionPoint}");

                if (insertionPoint > 0 && insertionPoint < binarySearchView.Count)
                {
                    Console.WriteLine($"Ближайшая цена ниже: {binarySearchView[insertionPoint - 1]["Price"]:C}");
                    Console.WriteLine($"Ближайшая цена выше: {binarySearchView[insertionPoint]["Price"]:C}");
                }
            }

            // 6. Вывод результатов в таблице
            Console.WriteLine("\n=== Сводная таблица результатов ===");

            // Создаем DataView для Apple акций
            DataView appleView = new DataView(stocksTable)
            {
                RowFilter = "CompanyName = 'Apple'",
                Sort = "Date ASC"
            };

            if (appleView.Count > 0)
            {
                Console.WriteLine($"\nИсторические данные Apple ({appleView.Count} записей):");
                Console.WriteLine("Дата         | Цена      | Изменение");
                Console.WriteLine("-------------|-----------|-----------");

                decimal? previousPrice = null;
                for (int i = Math.Max(0, appleView.Count - 10); i < appleView.Count; i++)
                {
                    decimal currentPrice = Convert.ToDecimal(appleView[i]["Price"]);
                    DateTime currentDate = Convert.ToDateTime(appleView[i]["Date"]);

                    string change = "";
                    if (previousPrice.HasValue && previousPrice.Value != 0)
                    {
                        decimal percentChange = (currentPrice - previousPrice.Value) / previousPrice.Value * 100;
                        change = $"{percentChange:+#.##;-#.##;0}%";
                    }

                    Console.WriteLine($"{currentDate:dd.MM.yyyy} | {currentPrice,9:C} | {change,9}");
                    previousPrice = currentPrice;
                }
            }

            // 7. Измерение производительности различных методов поиска
            Console.WriteLine("\n=== Производительность методов поиска ===");

            Stopwatch sw = new Stopwatch();
            int testIterations = 1000;

            // Тест линейного поиска
            sw.Start();
            for (int i = 0; i < testIterations; i++)
            {
                decimal testPrice = 100m + i % 200;
                LinearSearchPrice(priceSortedView, testPrice);
            }
            sw.Stop();
            long linearTime = sw.ElapsedMilliseconds;

            // Тест бинарного поиска
            sw.Restart();
            for (int i = 0; i < testIterations; i++)
            {
                decimal testPrice = 100m + i % 200;
                BinarySearchPrice(binarySearchView, testPrice);
            }
            sw.Stop();
            long binaryTime = sw.ElapsedMilliseconds;

            Console.WriteLine($"\nЛинейный поиск {testIterations} раз: {linearTime} ms");
            Console.WriteLine($"Бинарный поиск {testIterations} раз: {binaryTime} ms");
            Console.WriteLine($"Бинарный поиск быстрее в {linearTime / (double)binaryTime:F1} раз");

            // 8. Обработка граничных случаев
            Console.WriteLine("\n=== Обработка граничных случаев ===");

            // Поиск цены ниже минимальной
            Console.WriteLine("\n--- Поиск цены ниже минимальной (50) ---");
            var belowMin = FindNearestPrices(priceSortedView, 50m);
            Console.WriteLine($"Результат: {(belowMin.Above != null ? $"Минимальная цена: {belowMin.Above.Price:C}" : "Не найдено")}");

            // Поиск цены выше максимальной
            Console.WriteLine("\n--- Поиск цены выше максимальной (400) ---");
            var aboveMax = FindNearestPrices(priceSortedView, 400m);
            Console.WriteLine($"Результат: {(aboveMax.Below != null ? $"Максимальная цена: {aboveMax.Below.Price:C}" : "Не найдено")}");

            // Пустой диапазон
            Console.WriteLine("\n--- Поиск в пустом диапазоне (500-600) ---");
            var emptyRange = FindStocksInRange(priceSortedView, 500m, 600m);
            Console.WriteLine($"Результат: {emptyRange.Count} акций найдено");
        }

        // Вспомогательные классы и методы
        class StockPrice
        {
            public string CompanyName { get; set; }
            public decimal Price { get; set; }
            public DateTime Date { get; set; }
            public long Volume { get; set; }
        }

        class PriceJump
        {
            public string CompanyName { get; set; }
            public decimal OldPrice { get; set; }
            public decimal NewPrice { get; set; }
            public decimal PercentageChange { get; set; }
            public DateTime OldDate { get; set; }
            public DateTime NewDate { get; set; }
        }

        class NearestPrices
        {
            public StockPrice Below { get; set; }
            public StockPrice Above { get; set; }
        }

        static NearestPrices FindNearestPrices(DataView sortedView, decimal targetPrice)
        {
            StockPrice below = null;
            StockPrice above = null;

            // Линейный поиск (для демонстрации, в реальности лучше использовать бинарный)
            for (int i = 0; i < sortedView.Count; i++)
            {
                decimal currentPrice = Convert.ToDecimal(sortedView[i]["Price"]);

                if (currentPrice < targetPrice)
                {
                    below = new StockPrice
                    {
                        CompanyName = sortedView[i]["CompanyName"].ToString(),
                        Price = currentPrice,
                        Date = Convert.ToDateTime(sortedView[i]["Date"]),
                        Volume = Convert.ToInt64(sortedView[i]["Volume"])
                    };
                }
                else if (currentPrice >= targetPrice)
                {
                    above = new StockPrice
                    {
                        CompanyName = sortedView[i]["CompanyName"].ToString(),
                        Price = currentPrice,
                        Date = Convert.ToDateTime(sortedView[i]["Date"]),
                        Volume = Convert.ToInt64(sortedView[i]["Volume"])
                    };
                    break; // Нашли первую цену выше целевой
                }
            }

            return new NearestPrices { Below = below, Above = above };
        }

        static List<StockPrice> FindStocksInRange(DataView sortedView, decimal minPrice, decimal maxPrice)
        {
            var result = new List<StockPrice>();

            // Используем бинарный поиск для нахождения начала диапазона
            int startIndex = BinarySearchPrice(sortedView, minPrice);
            if (startIndex < 0) startIndex = ~startIndex;

            // Линейный поиск от начальной позиции
            for (int i = Math.Max(0, startIndex); i < sortedView.Count; i++)
            {
                decimal currentPrice = Convert.ToDecimal(sortedView[i]["Price"]);

                if (currentPrice > maxPrice)
                    break;

                if (currentPrice >= minPrice && currentPrice <= maxPrice)
                {
                    result.Add(new StockPrice
                    {
                        CompanyName = sortedView[i]["CompanyName"].ToString(),
                        Price = currentPrice,
                        Date = Convert.ToDateTime(sortedView[i]["Date"]),
                        Volume = Convert.ToInt64(sortedView[i]["Volume"])
                    });
                }
            }

            return result;
        }

        static StockPrice FindMaxPriceInRange(DataView sortedView, decimal minPrice, decimal maxPrice)
        {
            var stocksInRange = FindStocksInRange(sortedView, minPrice, maxPrice);
            return stocksInRange.OrderByDescending(s => s.Price).FirstOrDefault();
        }

        static StockPrice FindMinPriceInRange(DataView sortedView, decimal minPrice, decimal maxPrice)
        {
            var stocksInRange = FindStocksInRange(sortedView, minPrice, maxPrice);
            return stocksInRange.OrderBy(s => s.Price).FirstOrDefault();
        }

        static List<PriceJump> FindPriceJumps(DataTable stocksTable, decimal minPercentage)
        {
            var jumps = new List<PriceJump>();
            var companyData = new Dictionary<string, (decimal LastPrice, DateTime LastDate)>();

            // Сортируем по компании и дате
            DataView sortedView = new DataView(stocksTable)
            {
                Sort = "CompanyName ASC, Date ASC"
            };

            string currentCompany = "";
            decimal lastPrice = 0;
            DateTime lastDate = DateTime.MinValue;

            for (int i = 0; i < sortedView.Count; i++)
            {
                string company = sortedView[i]["CompanyName"].ToString();
                decimal price = Convert.ToDecimal(sortedView[i]["Price"]);
                DateTime date = Convert.ToDateTime(sortedView[i]["Date"]);

                if (company != currentCompany)
                {
                    // Новая компания
                    currentCompany = company;
                    lastPrice = price;
                    lastDate = date;
                }
                else
                {
                    // Та же компания, проверяем изменение цены
                    if (lastPrice != 0)
                    {
                        decimal percentageChange = Math.Abs((price - lastPrice) / lastPrice);

                        if (percentageChange >= minPercentage)
                        {
                            jumps.Add(new PriceJump
                            {
                                CompanyName = company,
                                OldPrice = lastPrice,
                                NewPrice = price,
                                PercentageChange = percentageChange,
                                OldDate = lastDate,
                                NewDate = date
                            });
                        }
                    }

                    lastPrice = price;
                    lastDate = date;
                }
            }

            return jumps;
        }

        static int BinarySearchPrice(DataView sortedView, decimal targetPrice)
        {
            // Простая реализация бинарного поиска
            int left = 0;
            int right = sortedView.Count - 1;

            while (left <= right)
            {
                int mid = left + (right - left) / 2;
                decimal midPrice = Convert.ToDecimal(sortedView[mid]["Price"]);

                if (midPrice == targetPrice)
                    return mid;
                else if (midPrice < targetPrice)
                    left = mid + 1;
                else
                    right = mid - 1;
            }

            // Если не найдено, возвращаем битовое дополнение позиции вставки
            return ~left;
        }

        static int LinearSearchPrice(DataView sortedView, decimal targetPrice)
        {
            for (int i = 0; i < sortedView.Count; i++)
            {
                if (Convert.ToDecimal(sortedView[i]["Price"]) >= targetPrice)
                    return i;
            }
            return -1;
        }
        #endregion

        #region Задание 19: Валидация данных при редактировании через DataView
        static void Task19()
        {
            Console.WriteLine("Задание 19: Валидация данных при редактировании через DataView\n");

            // 1. Создаем таблицу контактов
            DataTable contactsTable = new DataTable("Contacts");

            contactsTable.Columns.Add("ContactID", typeof(int));
            contactsTable.Columns.Add("Name", typeof(string));
            contactsTable.Columns.Add("Email", typeof(string));
            contactsTable.Columns.Add("Phone", typeof(string));
            contactsTable.Columns.Add("Address", typeof(string));
            contactsTable.Columns.Add("BirthDate", typeof(DateTime));

            // Устанавливаем первичный ключ
            contactsTable.PrimaryKey = new DataColumn[] { contactsTable.Columns["ContactID"] };

            // 2. Заполняем таблицу
            Random rand = new Random();
            string[] firstNames = { "Иван", "Мария", "Петр", "Анна", "Сергей", "Ольга" };
            string[] lastNames = { "Иванов", "Петрова", "Сидоров", "Смирнова", "Кузнецов", "Васильева" };
            string[] domains = { "gmail.com", "mail.ru", "yandex.ru", "outlook.com" };

            for (int i = 1; i <= 120; i++)
            {
                string firstName = firstNames[rand.Next(firstNames.Length)];
                string lastName = lastNames[rand.Next(lastNames.Length)];
                string domain = domains[rand.Next(domains.Length)];

                contactsTable.Rows.Add(
                    i,
                    $"{lastName} {firstName}",
                    $"{firstName.ToLower()}.{lastName.ToLower()}@{domain}",
                    $"+7({rand.Next(900, 999)}){rand.Next(100, 999)}-{rand.Next(10, 99)}-{rand.Next(10, 99)}",
                    $"ул. Примерная, д. {rand.Next(1, 100)}, кв. {rand.Next(1, 50)}",
                    DateTime.Today.AddYears(-rand.Next(18, 80)).AddDays(-rand.Next(0, 365))
                );
            }

            Console.WriteLine($"Таблица содержит {contactsTable.Rows.Count} контактов");

            // 3. Создаем DataView без фильтра
            DataView contactsView = new DataView(contactsTable)
            {
                Sort = "Name ASC"
            };

            // 4. Добавляем обработчик событий для валидации
            contactsTable.ColumnChanging += (sender, e) =>
            {
                // Логирование попытки изменения
                Console.WriteLine($"\nПопытка изменения: {e.Column.ColumnName} = {e.ProposedValue}");

                switch (e.Column.ColumnName)
                {
                    case "Email":
                        if (!IsValidEmail(e.ProposedValue?.ToString()))
                        {
                            Console.WriteLine($"  ОШИБКА ВАЛИДАЦИИ: Email '{e.ProposedValue}' не содержит '@'");
                            throw new ArgumentException("Email должен содержать '@'");
                        }
                        break;

                    case "Phone":
                        string phone = e.ProposedValue?.ToString() ?? "";
                        if (!IsValidPhone(phone))
                        {
                            // Попробуем автоформатирование
                            string formattedPhone = AutoFormatPhone(phone);
                            if (IsValidPhone(formattedPhone))
                            {
                                Console.WriteLine($"  АВТОФОРМАТИРОВАНИЕ: '{phone}' -> '{formattedPhone}'");
                                e.ProposedValue = formattedPhone;
                            }
                            else
                            {
                                Console.WriteLine($"  ОШИБКА ВАЛИДАЦИИ: Некорректный формат телефона");
                                throw new ArgumentException("Телефон должен быть в формате (XXX)XXX-XXXX или +7(XXX)XXX-XX-XX");
                            }
                        }
                        break;

                    case "Name":
                        if (string.IsNullOrWhiteSpace(e.ProposedValue?.ToString()))
                        {
                            Console.WriteLine($"  ОШИБКА ВАЛИДАЦИИ: Имя не может быть пустым");
                            throw new ArgumentException("Имя не может быть пустым");
                        }
                        if (e.ProposedValue.ToString().Length > 50)
                        {
                            Console.WriteLine($"  ОШИБКА ВАЛИДАЦИИ: Имя слишком длинное (макс. 50 символов)");
                            throw new ArgumentException("Имя слишком длинное");
                        }
                        break;

                    case "BirthDate":
                        if (e.ProposedValue is DateTime birthDate)
                        {
                            if (birthDate > DateTime.Today)
                            {
                                Console.WriteLine($"  ОШИБКА ВАЛИДАЦИИ: Дата рождения не может быть в будущем");
                                throw new ArgumentException("Дата рождения не может быть в будущем");
                            }
                            if (birthDate < DateTime.Today.AddYears(-150))
                            {
                                Console.WriteLine($"  ОШИБКА ВАЛИДАЦИИ: Дата рождения слишком ранняя");
                                throw new ArgumentException("Дата рождения слишком ранняя");
                            }
                        }
                        break;

                    case "Address":
                        if (string.IsNullOrWhiteSpace(e.ProposedValue?.ToString()))
                        {
                            Console.WriteLine($"  ОШИБКА ВАЛИДАЦИИ: Адрес не может быть пустым");
                            throw new ArgumentException("Адрес не может быть пустым");
                        }
                        break;
                }
            };

            // 5. Также добавляем обработчик после изменения для дополнительной проверки
            contactsTable.ColumnChanged += (sender, e) =>
            {
                Console.WriteLine($"  УСПЕШНО: {e.Column.ColumnName} изменен на '{e.Row[e.Column]}'");
            };

            // 6. Статистика валидации
            var validationStats = new ValidationStatistics();

            // 7. Реализуем редактирование с валидацией
            Console.WriteLine("\n=== Тестирование валидации при редактировании ===");

            // 7.1. Успешное редактирование
            Console.WriteLine("\n--- Тест 1: Успешное редактирование ---");
            try
            {
                if (contactsTable.Rows.Count > 0)
                {
                    contactsTable.Rows[0].BeginEdit();
                    contactsTable.Rows[0]["Email"] = "ivanov.ivan@gmail.com";
                    contactsTable.Rows[0]["Phone"] = "+7(999)123-45-67";
                    contactsTable.Rows[0].EndEdit();
                    validationStats.SuccessfulEdits++;
                    Console.WriteLine("  Редактирование успешно");
                }
            }
            catch (Exception ex)
            {
                validationStats.FailedEdits++;
                Console.WriteLine($"  Ошибка: {ex.Message}");
            }

            // 7.2. Ошибочное редактирование email
            Console.WriteLine("\n--- Тест 2: Неправильный email ---");
            try
            {
                if (contactsTable.Rows.Count > 1)
                {
                    contactsTable.Rows[1].BeginEdit();
                    contactsTable.Rows[1]["Email"] = "invalid-email";
                    contactsTable.Rows[1].EndEdit();
                    validationStats.SuccessfulEdits++;
                    Console.WriteLine("  Редактирование успешно (не должно быть)");
                }
            }
            catch (Exception ex)
            {
                validationStats.FailedEdits++;
                Console.WriteLine($"  Ожидаемая ошибка: {ex.Message}");
            }

            // 7.3. Автоформатирование телефона
            Console.WriteLine("\n--- Тест 3: Автоформатирование телефона ---");
            try
            {
                if (contactsTable.Rows.Count > 2)
                {
                    contactsTable.Rows[2].BeginEdit();
                    contactsTable.Rows[2]["Phone"] = "89991234567"; // Формат без скобок и тире
                    contactsTable.Rows[2].EndEdit();
                    validationStats.SuccessfulEdits++;
                    Console.WriteLine($"  Телефон автоформатирован: {contactsTable.Rows[2]["Phone"]}");
                }
            }
            catch (Exception ex)
            {
                validationStats.FailedEdits++;
                Console.WriteLine($"  Ошибка: {ex.Message}");
            }

            // 7.4. Пустое имя
            Console.WriteLine("\n--- Тест 4: Пустое имя ---");
            try
            {
                if (contactsTable.Rows.Count > 3)
                {
                    contactsTable.Rows[3].BeginEdit();
                    contactsTable.Rows[3]["Name"] = "";
                    contactsTable.Rows[3].EndEdit();
                    validationStats.SuccessfulEdits++;
                    Console.WriteLine("  Редактирование успешно (не должно быть)");
                }
            }
            catch (Exception ex)
            {
                validationStats.FailedEdits++;
                Console.WriteLine($"  Ожидаемая ошибка: {ex.Message}");
            }

            // 7.5. Дата рождения в будущем
            Console.WriteLine("\n--- Тест 5: Дата рождения в будущем ---");
            try
            {
                if (contactsTable.Rows.Count > 4)
                {
                    contactsTable.Rows[4].BeginEdit();
                    contactsTable.Rows[4]["BirthDate"] = DateTime.Today.AddDays(1);
                    contactsTable.Rows[4].EndEdit();
                    validationStats.SuccessfulEdits++;
                    Console.WriteLine("  Редактирование успешно (не должно быть)");
                }
            }
            catch (Exception ex)
            {
                validationStats.FailedEdits++;
                Console.WriteLine($"  Ожидаемая ошибка: {ex.Message}");
            }

            // 7.6. Пустой адрес
            Console.WriteLine("\n--- Тест 6: Пустой адрес ---");
            try
            {
                if (contactsTable.Rows.Count > 5)
                {
                    contactsTable.Rows[5].BeginEdit();
                    contactsTable.Rows[5]["Address"] = "";
                    contactsTable.Rows[5].EndEdit();
                    validationStats.SuccessfulEdits++;
                    Console.WriteLine("  Редактирование успешно (не должно быть)");
                }
            }
            catch (Exception ex)
            {
                validationStats.FailedEdits++;
                Console.WriteLine($"  Ожидаемая ошибка: {ex.Message}");
            }

            // 8. Логирование всех попыток редактирования
            Console.WriteLine("\n=== Логирование операций ===");

            // Создаем DataView для отслеживания изменений
            DataView changedContactsView = new DataView(contactsTable)
            {
                RowStateFilter = DataViewRowState.ModifiedCurrent
            };

            Console.WriteLine($"Измененных контактов: {changedContactsView.Count}");

            if (changedContactsView.Count > 0)
            {
                Console.WriteLine("\nСписок измененных контактов:");
                for (int i = 0; i < Math.Min(5, changedContactsView.Count); i++)
                {
                    Console.WriteLine($"  {changedContactsView[i]["Name"]}: " +
                                    $"Email={changedContactsView[i]["Email"]}, " +
                                    $"Phone={changedContactsView[i]["Phone"]}");
                }
            }

            // 9. Вывод статистики ошибок валидации
            Console.WriteLine("\n=== Статистика валидации ===");

            Console.WriteLine($"Всего попыток редактирования: {validationStats.TotalAttempts}");
            Console.WriteLine($"Успешных: {validationStats.SuccessfulEdits}");
            Console.WriteLine($"Неудачных: {validationStats.FailedEdits}");
            Console.WriteLine($"Процент успеха: {validationStats.SuccessRate:P1}");

            // 10. Дополнительная проверка всех данных
            Console.WriteLine("\n=== Проверка всех данных на валидность ===");

            int invalidEmails = 0;
            int invalidPhones = 0;
            int invalidNames = 0;
            int invalidBirthDates = 0;
            int invalidAddresses = 0;

            foreach (DataRow row in contactsTable.Rows)
            {
                if (!IsValidEmail(row["Email"].ToString())) invalidEmails++;
                if (!IsValidPhone(row["Phone"].ToString())) invalidPhones++;
                if (string.IsNullOrWhiteSpace(row["Name"].ToString())) invalidNames++;
                if (row["BirthDate"] is DateTime bd && bd > DateTime.Today) invalidBirthDates++;
                if (string.IsNullOrWhiteSpace(row["Address"].ToString())) invalidAddresses++;
            }

            Console.WriteLine("\nТекущее состояние данных:");
            Console.WriteLine($"  Некорректных email: {invalidEmails}");
            Console.WriteLine($"  Некорректных телефонов: {invalidPhones}");
            Console.WriteLine($"  Пустых имен: {invalidNames}");
            Console.WriteLine($"  Будущих дат рождения: {invalidBirthDates}");
            Console.WriteLine($"  Пустых адресов: {invalidAddresses}");

            if (invalidEmails + invalidPhones + invalidNames + invalidBirthDates + invalidAddresses == 0)
            {
                Console.WriteLine("  Все данные валидны!");
            }

            // 11. Функция исправления всех некорректных данных
            Console.WriteLine("\n=== Автоисправление данных ===");

            int fixedCount = 0;
            foreach (DataRow row in contactsTable.Rows)
            {
                try
                {
                    bool changed = false;

                    // Исправляем телефон при необходимости
                    string phone = row["Phone"].ToString();
                    if (!IsValidPhone(phone))
                    {
                        string formattedPhone = AutoFormatPhone(phone);
                        if (IsValidPhone(formattedPhone))
                        {
                            row["Phone"] = formattedPhone;
                            changed = true;
                            fixedCount++;
                        }
                    }

                    if (changed)
                    {
                        Console.WriteLine($"  Исправлен контакт: {row["Name"]}");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"  Ошибка при исправлении {row["Name"]}: {ex.Message}");
                }
            }

            Console.WriteLine($"Исправлено контактов: {fixedCount}");
        }

        // Вспомогательные методы для валидации
        static bool IsValidEmail(string email)
        {
            return !string.IsNullOrEmpty(email) && email.Contains("@");
        }

        static bool IsValidPhone(string phone)
        {
            if (string.IsNullOrEmpty(phone)) return false;

            // Проверяем несколько форматов
            return phone.Contains("(") && phone.Contains(")") &&
                   (phone.Contains("-") || phone.Contains(" "));
        }

        static string AutoFormatPhone(string phone)
        {
            // Удаляем все нецифровые символы
            string digits = new string(phone.Where(char.IsDigit).ToArray());

            if (digits.Length == 11 && digits.StartsWith("8"))
            {
                // Формат 8XXXXXXXXXX -> +7(XXX)XXX-XX-XX
                return $"+7({digits.Substring(1, 3)}){digits.Substring(4, 3)}-{digits.Substring(7, 2)}-{digits.Substring(9, 2)}";
            }
            else if (digits.Length == 10)
            {
                // Формат XXXXXXXXXX -> +7(XXX)XXX-XX-XX
                return $"+7({digits.Substring(0, 3)}){digits.Substring(3, 3)}-{digits.Substring(6, 2)}-{digits.Substring(8, 2)}";
            }

            return phone; // Не можем отформатировать
        }

        class ValidationStatistics
        {
            public int SuccessfulEdits { get; set; }
            public int FailedEdits { get; set; }

            public int TotalAttempts => SuccessfulEdits + FailedEdits;

            public double SuccessRate => TotalAttempts > 0 ? (double)SuccessfulEdits / TotalAttempts : 0;
        }
        #endregion

        #region Задание 21: Использование DataView для создания иерархических представлений
        static void Task21()
        {
            Console.WriteLine("Задание 21: Использование DataView для создания иерархических представлений\n");

            // 1. Создаем таблицы для иерархической структуры
            DataTable categoriesTable = new DataTable("Categories");
            DataTable productsTable = new DataTable("Products");

            // 1.1. Таблица категорий
            categoriesTable.Columns.Add("CategoryID", typeof(int));
            categoriesTable.Columns.Add("CategoryName", typeof(string));
            categoriesTable.Columns.Add("ParentCategoryID", typeof(int));
            categoriesTable.Columns.Add("Description", typeof(string));

            categoriesTable.PrimaryKey = new DataColumn[] { categoriesTable.Columns["CategoryID"] };

            // 1.2. Таблица товаров
            productsTable.Columns.Add("ProductID", typeof(int));
            productsTable.Columns.Add("ProductName", typeof(string));
            productsTable.Columns.Add("CategoryID", typeof(int));
            productsTable.Columns.Add("Price", typeof(decimal));

            productsTable.PrimaryKey = new DataColumn[] { productsTable.Columns["ProductID"] };

            // 2. Заполняем таблицу категорий (иерархическая структура)
            // Уровень 0: Корневые категории
            categoriesTable.Rows.Add(1, "Электроника", 0, "Электронные устройства");
            categoriesTable.Rows.Add(2, "Одежда", 0, "Одежда и аксессуары");
            categoriesTable.Rows.Add(3, "Книги", 0, "Книги и учебники");

            // Уровень 1: Подкатегории электроники
            categoriesTable.Rows.Add(4, "Смартфоны", 1, "Мобильные телефоны");
            categoriesTable.Rows.Add(5, "Ноутбуки", 1, "Портативные компьютеры");
            categoriesTable.Rows.Add(6, "Телевизоры", 1, "Телевизоры и мониторы");

            // Уровень 1: Подкатегории одежды
            categoriesTable.Rows.Add(7, "Мужская одежда", 2, "Одежда для мужчин");
            categoriesTable.Rows.Add(8, "Женская одежда", 2, "Одежда для женщин");
            categoriesTable.Rows.Add(9, "Детская одежда", 2, "Одежда для детей");

            // Уровень 2: Подкатегории смартфонов
            categoriesTable.Rows.Add(10, "Android", 4, "Смартфоны на Android");
            categoriesTable.Rows.Add(11, "iOS", 4, "Смартфоны iPhone");

            // Уровень 2: Подкатегории ноутбуков
            categoriesTable.Rows.Add(12, "Игровые", 5, "Игровые ноутбуки");
            categoriesTable.Rows.Add(13, "Ультрабуки", 5, "Тонкие и легкие ноутбуки");

            Console.WriteLine($"Таблица категорий: {categoriesTable.Rows.Count} категорий");

            // 3. Заполняем таблицу товаров
            Random rand = new Random();
            string[] phoneBrands = { "Samsung", "Xiaomi", "OnePlus", "Google" };
            string[] appleModels = { "iPhone 13", "iPhone 14", "iPhone 15", "iPhone SE" };
            string[] laptopBrands = { "ASUS", "MSI", "Lenovo", "Dell", "HP" };
            string[] tvBrands = { "LG", "Samsung", "Sony", "Philips" };
            string[] clothesItems = { "Футболка", "Джинсы", "Платье", "Куртка", "Рубашка" };
            string[] bookGenres = { "Фантастика", "Детектив", "Роман", "Научная литература" };

            int productId = 1;

            // Товары в категории Android
            for (int i = 0; i < 5; i++)
            {
                productsTable.Rows.Add(
                    productId++,
                    $"{phoneBrands[rand.Next(phoneBrands.Length)]} Galaxy S{rand.Next(10, 25)}",
                    10,
                    Math.Round(rand.Next(20000, 80000) + (decimal)rand.NextDouble(), 2)
                );
            }

            // Товары в категории iOS
            for (int i = 0; i < 5; i++)
            {
                productsTable.Rows.Add(
                    productId++,
                    appleModels[rand.Next(appleModels.Length)],
                    11,
                    Math.Round(rand.Next(50000, 150000) + (decimal)rand.NextDouble(), 2)
                );
            }

            // Товары в категории Игровые ноутбуки
            for (int i = 0; i < 5; i++)
            {
                productsTable.Rows.Add(
                    productId++,
                    $"{laptopBrands[rand.Next(laptopBrands.Length)]} Gaming {rand.Next(10, 20)}",
                    12,
                    Math.Round(rand.Next(50000, 200000) + (decimal)rand.NextDouble(), 2)
                );
            }

            // Товары в категории Ультрабуки
            for (int i = 0; i < 5; i++)
            {
                productsTable.Rows.Add(
                    productId++,
                    $"{laptopBrands[rand.Next(laptopBrands.Length)]} Ultrabook",
                    13,
                    Math.Round(rand.Next(40000, 120000) + (decimal)rand.NextDouble(), 2)
                );
            }

            // Товары в категории Телевизоры
            for (int i = 0; i < 5; i++)
            {
                productsTable.Rows.Add(
                    productId++,
                    $"{tvBrands[rand.Next(tvBrands.Length)]} {rand.Next(40, 85)}\" Smart TV",
                    6,
                    Math.Round(rand.Next(30000, 200000) + (decimal)rand.NextDouble(), 2)
                );
            }

            // Товары в категории Мужская одежда
            for (int i = 0; i < 5; i++)
            {
                productsTable.Rows.Add(
                    productId++,
                    $"Мужская {clothesItems[rand.Next(clothesItems.Length)]}",
                    7,
                    Math.Round(rand.Next(1000, 10000) + (decimal)rand.NextDouble(), 2)
                );
            }

            // Товары в категории Книги
            for (int i = 0; i < 5; i++)
            {
                productsTable.Rows.Add(
                    productId++,
                    $"{bookGenres[rand.Next(bookGenres.Length)]} - Книга {i + 1}",
                    3,
                    Math.Round(rand.Next(300, 2000) + (decimal)rand.NextDouble(), 2)
                );
            }

            Console.WriteLine($"Таблица товаров: {productsTable.Rows.Count} товаров");

            // 4. Создаем DataView для каждого уровня категорий
            Console.WriteLine("\n=== DataView для каждого уровня категорий ===");

            // 4.1. DataView для корневых категорий (ParentCategoryID = 0)
            DataView rootCategoriesView = new DataView(categoriesTable)
            {
                RowFilter = "ParentCategoryID = 0",
                Sort = "CategoryName ASC"
            };

            Console.WriteLine($"\nКорневые категории ({rootCategoriesView.Count}):");
            for (int i = 0; i < rootCategoriesView.Count; i++)
            {
                Console.WriteLine($"  {rootCategoriesView[i]["CategoryName"]} (ID: {rootCategoriesView[i]["CategoryID"]})");
            }

            // 4.2. DataView для товаров в конкретной категории
            Console.WriteLine("\n--- Товары в категории 'Электроника' и ее подкатегориях ---");

            // Получаем ID категории Электроника
            DataView electronicsView = new DataView(categoriesTable)
            {
                RowFilter = "CategoryName = 'Электроника'"
            };

            if (electronicsView.Count > 0)
            {
                int electronicsId = Convert.ToInt32(electronicsView[0]["CategoryID"]);

                // Получаем все подкатегории Электроники (включая саму категорию)
                var allElectronicsCategories = GetAllSubcategories(categoriesTable, electronicsId);

                // Создаем фильтр для товаров
                string categoryFilter = string.Join(" OR ", allElectronicsCategories.Select(id => $"CategoryID = {id}"));
                DataView electronicsProductsView = new DataView(productsTable)
                {
                    RowFilter = categoryFilter,
                    Sort = "Price DESC"
                };

                Console.WriteLine($"Найдено товаров: {electronicsProductsView.Count}");
                Console.WriteLine("Самые дорогие товары:");
                for (int i = 0; i < Math.Min(5, electronicsProductsView.Count); i++)
                {
                    // Получаем название категории для товара
                    int catId = Convert.ToInt32(electronicsProductsView[i]["CategoryID"]);
                    string catName = GetCategoryName(categoriesTable, catId);

                    Console.WriteLine($"  {electronicsProductsView[i]["ProductName"]} - {electronicsProductsView[i]["Price"]:C} ({catName})");
                }
            }

            // 5. Навигация по иерархии
            Console.WriteLine("\n=== Навигация по иерархии ===");

            // 5.1. Получение родительской категории
            Console.WriteLine("\n--- Получение родительской категории ---");

            int childCategoryId = 10; // Android
            int? parentId = GetParentCategoryId(categoriesTable, childCategoryId);

            if (parentId.HasValue)
            {
                string parentName = GetCategoryName(categoriesTable, parentId.Value);
                string childName = GetCategoryName(categoriesTable, childCategoryId);
                Console.WriteLine($"Родительская категория для '{childName}': {parentName}");
            }

            // 5.2. Получение подкатегорий
            Console.WriteLine("\n--- Получение подкатегорий ---");

            int parentCategoryId = 1; // Электроника
            var subcategories = GetSubcategories(categoriesTable, parentCategoryId);

            Console.WriteLine($"Подкатегории категории 'Электроника': {subcategories.Count}");
            foreach (var subcat in subcategories)
            {
                Console.WriteLine($"  {subcat.CategoryName} (ID: {subcat.CategoryID})");
            }

            // 5.3. Получение всех товаров категории и её подкатегорий
            Console.WriteLine("\n--- Все товары категории и подкатегорий ---");

            int targetCategoryId = 1; // Электроника
            var allCategoryProducts = GetAllProductsInCategory(productsTable, categoriesTable, targetCategoryId);

            Console.WriteLine($"Всего товаров в категории и подкатегориях: {allCategoryProducts.Count}");

            // Группируем по категориям
            var productsByCategory = allCategoryProducts.GroupBy(p => p.CategoryName)
                                                       .OrderBy(g => g.Key);

            foreach (var group in productsByCategory)
            {
                Console.WriteLine($"\n  {group.Key}: {group.Count()} товаров");
                foreach (var product in group.Take(3))
                {
                    Console.WriteLine($"    {product.ProductName} - {product.Price:C}");
                }
                if (group.Count() > 3)
                {
                    Console.WriteLine($"    ... и еще {group.Count() - 3} товаров");
                }
            }

            // 6. Вывод иерархии в виде дерева
            Console.WriteLine("\n=== Иерархия в виде дерева ===");

            PrintCategoryTree(categoriesTable, 0, "");

            // 7. Метод для поиска товара во всей иерархии
            Console.WriteLine("\n=== Поиск товара во всей иерархии ===");

            string searchProduct = "Gaming";
            var foundProducts = SearchProductsInHierarchy(productsTable, categoriesTable, searchProduct);

            Console.WriteLine($"Найдено товаров содержащих '{searchProduct}': {foundProducts.Count}");
            foreach (var product in foundProducts)
            {
                Console.WriteLine($"  {product.ProductName} - {product.Price:C} (Категория: {product.CategoryName})");
            }

            // 8. Функция развёртывания/свёртывания категорий (имитация)
            Console.WriteLine("\n=== Имитация развертывания/свертывания категорий ===");

            // Создаем словарь для отслеживания состояния категорий
            var expandedCategories = new Dictionary<int, bool>();

            // Изначально развернута только корневая категория Электроника
            expandedCategories[1] = true; // Электроника развернута

            Console.WriteLine("\nИерархия с учетом состояния развернутости:");
            PrintCategoryTreeWithState(categoriesTable, 0, "", expandedCategories);

            // Имитация развертывания категории Ноутбуки
            Console.WriteLine("\n--- Развертывание категории 'Ноутбуки' ---");
            expandedCategories[5] = true;

            Console.WriteLine("\nИерархия после развертывания Ноутбуков:");
            PrintCategoryTreeWithState(categoriesTable, 0, "", expandedCategories);
        }

        // Вспомогательные методы для работы с иерархией
        static List<int> GetAllSubcategories(DataTable categoriesTable, int categoryId)
        {
            var result = new List<int> { categoryId };

            // Рекурсивно находим все подкатегории
            DataView subcategoriesView = new DataView(categoriesTable)
            {
                RowFilter = $"ParentCategoryID = {categoryId}"
            };

            for (int i = 0; i < subcategoriesView.Count; i++)
            {
                int subcategoryId = Convert.ToInt32(subcategoriesView[i]["CategoryID"]);
                result.AddRange(GetAllSubcategories(categoriesTable, subcategoryId));
            }

            return result;
        }

        static string GetCategoryName(DataTable categoriesTable, int categoryId)
        {
            DataView categoryView = new DataView(categoriesTable)
            {
                RowFilter = $"CategoryID = {categoryId}"
            };

            if (categoryView.Count > 0)
            {
                return categoryView[0]["CategoryName"].ToString();
            }

            return "Неизвестная категория";
        }

        static int? GetParentCategoryId(DataTable categoriesTable, int categoryId)
        {
            DataView categoryView = new DataView(categoriesTable)
            {
                RowFilter = $"CategoryID = {categoryId}"
            };

            if (categoryView.Count > 0)
            {
                object parentId = categoryView[0]["ParentCategoryID"];
                if (parentId != DBNull.Value)
                {
                    int pid = Convert.ToInt32(parentId);
                    return pid > 0 ? pid : (int?)null;
                }
            }

            return null;
        }

        static List<CategoryInfo> GetSubcategories(DataTable categoriesTable, int parentId)
        {
            var result = new List<CategoryInfo>();

            DataView subcategoriesView = new DataView(categoriesTable)
            {
                RowFilter = $"ParentCategoryID = {parentId}",
                Sort = "CategoryName ASC"
            };

            for (int i = 0; i < subcategoriesView.Count; i++)
            {
                result.Add(new CategoryInfo
                {
                    CategoryID = Convert.ToInt32(subcategoriesView[i]["CategoryID"]),
                    CategoryName = subcategoriesView[i]["CategoryName"].ToString(),
                    ParentCategoryID = Convert.ToInt32(subcategoriesView[i]["ParentCategoryID"])
                });
            }

            return result;
        }

        static List<ProductInfo> GetAllProductsInCategory(DataTable productsTable, DataTable categoriesTable, int categoryId)
        {
            var result = new List<ProductInfo>();

            // Получаем все подкатегории
            var allCategories = GetAllSubcategories(categoriesTable, categoryId);

            foreach (int catId in allCategories)
            {
                // Получаем товары в конкретной категории
                DataView productsView = new DataView(productsTable)
                {
                    RowFilter = $"CategoryID = {catId}"
                };

                for (int i = 0; i < productsView.Count; i++)
                {
                    result.Add(new ProductInfo
                    {
                        ProductID = Convert.ToInt32(productsView[i]["ProductID"]),
                        ProductName = productsView[i]["ProductName"].ToString(),
                        CategoryID = catId,
                        CategoryName = GetCategoryName(categoriesTable, catId),
                        Price = Convert.ToDecimal(productsView[i]["Price"])
                    });
                }
            }

            return result;
        }

        static void PrintCategoryTree(DataTable categoriesTable, int parentId, string indent)
        {
            var subcategories = GetSubcategories(categoriesTable, parentId);

            foreach (var category in subcategories)
            {
                Console.WriteLine($"{indent}├─ {category.CategoryName} (ID: {category.CategoryID})");
                PrintCategoryTree(categoriesTable, category.CategoryID, indent + "│  ");
            }
        }

        static void PrintCategoryTreeWithState(DataTable categoriesTable, int parentId, string indent, Dictionary<int, bool> expandedCategories)
        {
            var subcategories = GetSubcategories(categoriesTable, parentId);

            foreach (var category in subcategories)
            {
                string prefix = expandedCategories.ContainsKey(category.CategoryID) && expandedCategories[category.CategoryID] ? "[-]" : "[+]";
                Console.WriteLine($"{indent}{prefix} {category.CategoryName} (ID: {category.CategoryID})");

                if (expandedCategories.ContainsKey(category.CategoryID) && expandedCategories[category.CategoryID])
                {
                    PrintCategoryTreeWithState(categoriesTable, category.CategoryID, indent + "   ", expandedCategories);
                }
            }
        }

        static List<ProductInfo> SearchProductsInHierarchy(DataTable productsTable, DataTable categoriesTable, string searchTerm)
        {
            var result = new List<ProductInfo>();

            // Ищем товары по названию
            DataView productsView = new DataView(productsTable)
            {
                RowFilter = $"ProductName LIKE '%{searchTerm}%'"
            };

            for (int i = 0; i < productsView.Count; i++)
            {
                int categoryId = Convert.ToInt32(productsView[i]["CategoryID"]);
                result.Add(new ProductInfo
                {
                    ProductID = Convert.ToInt32(productsView[i]["ProductID"]),
                    ProductName = productsView[i]["ProductName"].ToString(),
                    CategoryID = categoryId,
                    CategoryName = GetCategoryName(categoriesTable, categoryId),
                    Price = Convert.ToDecimal(productsView[i]["Price"])
                });
            }

            return result;
        }

        class CategoryInfo
        {
            public int CategoryID { get; set; }
            public string CategoryName { get; set; }
            public int ParentCategoryID { get; set; }
        }

        class ProductInfo
        {
            public int ProductID { get; set; }
            public string ProductName { get; set; }
            public int CategoryID { get; set; }
            public string CategoryName { get; set; }
            public decimal Price { get; set; }
        }
        #endregion

        #region Задание 22: Комплексная фильтрация с использованием LIKE
        static void Task22()
        {
            Console.WriteLine("Задание 22: Комплексная фильтрация с использованием LIKE и других операторов\n");

            // 1. Создаем таблицу документов
            DataTable documentsTable = new DataTable("Documents");

            documentsTable.Columns.Add("DocumentID", typeof(int));
            documentsTable.Columns.Add("Title", typeof(string));
            documentsTable.Columns.Add("Content", typeof(string));
            documentsTable.Columns.Add("Author", typeof(string));
            documentsTable.Columns.Add("Date", typeof(DateTime));
            documentsTable.Columns.Add("Type", typeof(string));
            documentsTable.Columns.Add("Status", typeof(string));

            // Устанавливаем первичный ключ
            documentsTable.PrimaryKey = new DataColumn[] { documentsTable.Columns["DocumentID"] };

            // 2. Заполняем таблицу
            Random rand = new Random();
            string[] documentTypes = { "Report", "Memo", "Letter", "Contract", "Invoice", "Proposal", "Manual" };
            string[] statuses = { "Draft", "Review", "Approved", "Rejected", "Archived" };
            string[] authors = { "Иванов И.И.", "Петрова А.А.", "Сидоров С.С.", "Кузнецов М.М.", "Васильева О.О." };
            string[] words = { "проект", "отчет", "бюджет", "планирование", "анализ", "разработка",
                      "тестирование", "внедрение", "документация", "презентация" };

            for (int i = 1; i <= 1050; i++)
            {
                // Генерируем случайный текст
                string content = string.Join(" ", Enumerable.Range(0, rand.Next(5, 15))
                    .Select(_ => words[rand.Next(words.Length)]));

                documentsTable.Rows.Add(
                    i,
                    $"Документ {i}: {words[rand.Next(words.Length)]}",
                    content,
                    authors[rand.Next(authors.Length)],
                    DateTime.Today.AddDays(-rand.Next(0, 3650)),
                    documentTypes[rand.Next(documentTypes.Length)],
                    statuses[rand.Next(statuses.Length)]
                );
            }

            Console.WriteLine($"Таблица содержит {documentsTable.Rows.Count} документов");

            // 3. Создаем DataView для сложного поиска
            Console.WriteLine("\n=== Комплексный поиск с использованием различных операторов ===");

            DataView documentsView = new DataView(documentsTable);

            // 3.1. LIKE для частичного совпадения текста
            Console.WriteLine("\n--- Поиск с LIKE (частичное совпадение) ---");

            string searchWord = "отчет";
            documentsView.RowFilter = $"Title LIKE '%{searchWord}%' OR Content LIKE '%{searchWord}%'";

            Console.WriteLine($"Документы содержащие '{searchWord}': {documentsView.Count}");
            PrintDocumentsSample(documentsView, 3);

            // 3.2. BETWEEN для диапазонов дат
            Console.WriteLine("\n--- BETWEEN для диапазона дат ---");

            DateTime startDate = DateTime.Today.AddYears(-2);
            DateTime endDate = DateTime.Today;
            documentsView.RowFilter = $"Date BETWEEN #{startDate:MM/dd/yyyy}# AND #{endDate:MM/dd/yyyy}#";

            Console.WriteLine($"Документы за последние 2 года: {documentsView.Count}");
            PrintDocumentsSample(documentsView, 3);

            // 3.3. IN для списка значений
            Console.WriteLine("\n--- IN для списка типов документов ---");

            string[] selectedTypes = { "Report", "Memo", "Proposal" };
            string typeList = string.Join(",", selectedTypes.Select(t => $"'{t}'"));
            documentsView.RowFilter = $"Type IN ({typeList})";

            Console.WriteLine($"Документы типов {string.Join(", ", selectedTypes)}: {documentsView.Count}");
            PrintDocumentsSample(documentsView, 3);

            // 3.4. Комбинированные условия (AND, OR, NOT)
            Console.WriteLine("\n--- Комбинированные условия ---");

            documentsView.RowFilter = $"(Type = 'Report' OR Type = 'Proposal') " +
                                    $"AND Status = 'Approved' " +
                                    $"AND Date >= #{DateTime.Today.AddYears(-1):MM/dd/yyyy}# " +
                                    $"AND (Title LIKE '%проект%' OR Content LIKE '%проект%')";

            Console.WriteLine($"Утвержденные отчеты/предложения за год, связанные с проектами: {documentsView.Count}");
            PrintDocumentsSample(documentsView, 3);

            // 3.5. NOT для исключения
            Console.WriteLine("\n--- Использование NOT для исключения ---");

            documentsView.RowFilter = $"Type NOT IN ('Invoice', 'Contract') AND Status != 'Archived'";

            Console.WriteLine($"Документы кроме счетов и контрактов, не в архиве: {documentsView.Count}");
            PrintDocumentsSample(documentsView, 3);

            // 4. Поиск с учетом регистра (если поддерживается)
            // В ADO.NET LIKE не чувствителен к регистру для SQL Server, но зависит от провайдера

            // 5. Метод для построения фильтра на основе параметров пользователя
            Console.WriteLine("\n=== Динамическое построение фильтра ===");

            var searchParams = new DocumentSearchParams
            {
                SearchText = "бюджет",
                StartDate = DateTime.Today.AddYears(-1),
                EndDate = DateTime.Today,
                DocumentTypes = new List<string> { "Report", "Memo" },
                Status = "Approved",
                Author = "Иванов"
            };

            string dynamicFilter = BuildDocumentFilter(searchParams);
            Console.WriteLine($"Динамический фильтр: {dynamicFilter}");

            documentsView.RowFilter = dynamicFilter;
            Console.WriteLine($"Найдено документов: {documentsView.Count}");

            // 6. Подсказки при вводе (автодополнение)
            Console.WriteLine("\n=== Автодополнение при поиске ===");

            string partialText = "про";
            var suggestions = GetSearchSuggestions(documentsTable, partialText, 5);

            Console.WriteLine($"Подсказки для '{partialText}':");
            foreach (var suggestion in suggestions)
            {
                Console.WriteLine($"  {suggestion}");
            }

            // 7. Вывод результатов в таблице
            Console.WriteLine("\n=== Результаты поиска в табличном виде ===");

            // Устанавливаем фильтр для примера
            documentsView.RowFilter = "Status = 'Approved' AND Type = 'Report'";
            documentsView.Sort = "Date DESC";

            Console.WriteLine("\nID  | Дата       | Тип    | Статус   | Автор         | Заголовок");
            Console.WriteLine("----|------------|--------|----------|---------------|-------------------");

            for (int i = 0; i < Math.Min(10, documentsView.Count); i++)
            {
                Console.WriteLine($"{documentsView[i]["DocumentID"],-3} | " +
                                 $"{Convert.ToDateTime(documentsView[i]["Date"]):dd.MM.yyyy} | " +
                                 $"{documentsView[i]["Type"],-6} | " +
                                 $"{documentsView[i]["Status"],-8} | " +
                                 $"{documentsView[i]["Author"],-13} | " +
                                 $"{Truncate(documentsView[i]["Title"].ToString(), 20)}");
            }

            if (documentsView.Count > 10)
            {
                Console.WriteLine($"... и еще {documentsView.Count - 10} документов");
            }

            // 8. Сравнение производительности различных фильтров
            Console.WriteLine("\n=== Производительность различных фильтров ===");

            Stopwatch sw = new Stopwatch();
            int iterations = 100;

            var filterTests = new List<(string Description, string Filter)>
    {
        ("Простой LIKE", "Title LIKE '%отчет%'"),
        ("Сложный LIKE", "Title LIKE '%отчет%' OR Content LIKE '%отчет%'"),
        ("BETWEEN дат", $"Date BETWEEN #{DateTime.Today.AddYears(-5):MM/dd/yyyy}# AND #{DateTime.Today:MM/dd/yyyy}#"),
        ("IN список", "Type IN ('Report', 'Memo', 'Proposal')"),
        ("Комбинированный", "(Type = 'Report' OR Type = 'Proposal') AND Status = 'Approved' AND Date >= #{DateTime.Today.AddYears(-1):MM/dd/yyyy}#")
    };

            Console.WriteLine("\nФильтр                       | Время (ms) | Найдено");
            Console.WriteLine("-----------------------------|------------|---------");

            foreach (var test in filterTests)
            {
                sw.Restart();
                for (int i = 0; i < iterations; i++)
                {
                    documentsView.RowFilter = test.Filter;
                    int count = documentsView.Count;
                }
                sw.Stop();

                documentsView.RowFilter = test.Filter;
                Console.WriteLine($"{test.Description,-28} | {sw.ElapsedMilliseconds,10} | {documentsView.Count,7}");
            }

            // 9. Отчёт о сложных поисках
            Console.WriteLine("\n=== Отчёт о сложных поисках ===");

            var complexSearches = new List<ComplexSearch>
    {
        new ComplexSearch
        {
            Name = "Утвержденные отчеты за год",
            Filter = "Type = 'Report' AND Status = 'Approved' AND Date >= #{0:MM/dd/yyyy}#",
            Parameters = new object[] { DateTime.Today.AddYears(-1) }
        },
        new ComplexSearch
        {
            Name = "Документы Иванова о проектах",
            Filter = "Author LIKE '%Иванов%' AND (Title LIKE '%проект%' OR Content LIKE '%проект%')"
        },
        new ComplexSearch
        {
            Name = "Счета и контракты не в архиве",
            Filter = "Type IN ('Invoice', 'Contract') AND Status != 'Archived'"
        }
    };

            Console.WriteLine("\nСложные поисковые запросы:");
            foreach (var search in complexSearches)
            {
                string filter = search.Parameters != null ?
                    string.Format(search.Filter, search.Parameters) : search.Filter;

                documentsView.RowFilter = filter;
                Console.WriteLine($"\n  {search.Name}:");
                Console.WriteLine($"    Фильтр: {filter}");
                Console.WriteLine($"    Найдено: {documentsView.Count} документов");

                if (documentsView.Count > 0)
                {
                    Console.WriteLine("    Примеры:");
                    for (int i = 0; i < Math.Min(2, documentsView.Count); i++)
                    {
                        Console.WriteLine($"      - {documentsView[i]["Title"]} ({documentsView[i]["Date"]:dd.MM.yyyy})");
                    }
                }
            }

            // 10. Обработка ошибок синтаксиса
            Console.WriteLine("\n=== Обработка ошибок синтаксиса ===");

            try
            {
                documentsView.RowFilter = "InvalidColumn LIKE '%test%'";
                Console.WriteLine("Фильтр установлен (не должно быть)");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка синтаксиса: {ex.Message}");
            }

            try
            {
                documentsView.RowFilter = "Title LIKE '%test"; // Незакрытая кавычка
                Console.WriteLine("Фильтр установлен (не должно быть)");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка синтаксиса: {ex.Message}");
            }
        }

        static void PrintDocumentsSample(DataView view, int count)
        {
            if (view.Count == 0)
            {
                Console.WriteLine("  (нет документов)");
                return;
            }

            for (int i = 0; i < Math.Min(count, view.Count); i++)
            {
                Console.WriteLine($"  {view[i]["Title"]} ({view[i]["Date"]:dd.MM.yyyy}, {view[i]["Type"]})");
            }

            if (view.Count > count)
            {
                Console.WriteLine($"  ... и еще {view.Count - count} документов");
            }
        }

        static string BuildDocumentFilter(DocumentSearchParams parameters)
        {
            var conditions = new List<string>();

            if (!string.IsNullOrEmpty(parameters.SearchText))
            {
                conditions.Add($"(Title LIKE '%{parameters.SearchText}%' OR Content LIKE '%{parameters.SearchText}%')");
            }

            if (parameters.StartDate.HasValue)
            {
                conditions.Add($"Date >= #{parameters.StartDate.Value:MM/dd/yyyy}#");
            }

            if (parameters.EndDate.HasValue)
            {
                conditions.Add($"Date <= #{parameters.EndDate.Value:MM/dd/yyyy}#");
            }

            if (parameters.DocumentTypes != null && parameters.DocumentTypes.Count > 0)
            {
                string typeList = string.Join(",", parameters.DocumentTypes.Select(t => $"'{t}'"));
                conditions.Add($"Type IN ({typeList})");
            }

            if (!string.IsNullOrEmpty(parameters.Status))
            {
                conditions.Add($"Status = '{parameters.Status}'");
            }

            if (!string.IsNullOrEmpty(parameters.Author))
            {
                conditions.Add($"Author LIKE '%{parameters.Author}%'");
            }

            return conditions.Count > 0 ? string.Join(" AND ", conditions) : "";
        }

        static List<string> GetSearchSuggestions(DataTable documentsTable, string partialText, int maxSuggestions)
        {
            var suggestions = new HashSet<string>();

            // Ищем в заголовках
            DataView titleView = new DataView(documentsTable)
            {
                RowFilter = $"Title LIKE '%{partialText}%'"
            };

            for (int i = 0; i < Math.Min(maxSuggestions, titleView.Count); i++)
            {
                string title = titleView[i]["Title"].ToString();
                // Извлекаем слова из заголовка
                var words = title.Split(' ', ',', '.', ';', ':');
                foreach (var word in words)
                {
                    if (word.StartsWith(partialText, StringComparison.OrdinalIgnoreCase))
                    {
                        suggestions.Add(word);
                        if (suggestions.Count >= maxSuggestions) break;
                    }
                }
                if (suggestions.Count >= maxSuggestions) break;
            }

            // Если мало предложений, ищем в контенте
            if (suggestions.Count < maxSuggestions)
            {
                DataView contentView = new DataView(documentsTable)
                {
                    RowFilter = $"Content LIKE '%{partialText}%'"
                };

                for (int i = 0; i < Math.Min(maxSuggestions, contentView.Count); i++)
                {
                    string content = contentView[i]["Content"].ToString();
                    var words = content.Split(' ', ',', '.', ';', ':');
                    foreach (var word in words)
                    {
                        if (word.StartsWith(partialText, StringComparison.OrdinalIgnoreCase))
                        {
                            suggestions.Add(word);
                            if (suggestions.Count >= maxSuggestions) break;
                        }
                    }
                    if (suggestions.Count >= maxSuggestions) break;
                }
            }

            return suggestions.Take(maxSuggestions).ToList();
        }

        static string Truncate(string text, int maxLength)
        {
            if (string.IsNullOrEmpty(text) || text.Length <= maxLength) return text;
            return text.Substring(0, maxLength - 3) + "...";
        }

        class DocumentSearchParams
        {
            public string SearchText { get; set; }
            public DateTime? StartDate { get; set; }
            public DateTime? EndDate { get; set; }
            public List<string> DocumentTypes { get; set; }
            public string Status { get; set; }
            public string Author { get; set; }
        }

        class ComplexSearch
        {
            public string Name { get; set; }
            public string Filter { get; set; }
            public object[] Parameters { get; set; }
        }
        #endregion

        #region Задание 25: Поиск дубликатов
        static void Task25()
        {
            Console.WriteLine("Задание 25: Поиск дубликатов с использованием DataView\n");

            // 1. Создаем таблицу электронных писем
            DataTable emailsTable = new DataTable("Emails");

            emailsTable.Columns.Add("EmailID", typeof(int));
            emailsTable.Columns.Add("EmailAddress", typeof(string));
            emailsTable.Columns.Add("Name", typeof(string));
            emailsTable.Columns.Add("Domain", typeof(string));
            emailsTable.Columns.Add("Duplicates", typeof(int));

            // Устанавливаем первичный ключ
            emailsTable.PrimaryKey = new DataColumn[] { emailsTable.Columns["EmailID"] };

            // 2. Заполняем таблицу, включая дубликаты
            Random rand = new Random();
            string[] firstNames = { "ivan", "petr", "alex", "maria", "anna", "olga" };
            string[] lastNames = { "ivanov", "petrov", "sidorov", "smirnov", "kuznetsov" };
            string[] domains = { "gmail.com", "mail.ru", "yandex.ru", "outlook.com", "company.com" };

            // Создаем список уникальных email-адресов
            var uniqueEmails = new HashSet<string>();
            int emailId = 1;

            // Сначала создаем уникальные записи
            for (int i = 0; i < 300; i++)
            {
                string firstName = firstNames[rand.Next(firstNames.Length)];
                string lastName = lastNames[rand.Next(lastNames.Length)];
                string domain = domains[rand.Next(domains.Length)];

                // Несколько вариантов email
                string email;
                switch (rand.Next(3))
                {
                    case 0:
                        email = $"{firstName}.{lastName}@{domain}";
                        break;
                    case 1:
                        email = $"{firstName[0]}.{lastName}@{domain}";
                        break;
                    case 2:
                        email = $"{firstName}{lastName}@{domain}";
                        break;
                    default:
                        email = $"{firstName}@{domain}";
                        break;
                }

                // Преобразуем в нижний регистр для единообразия
                email = email.ToLower();

                if (!uniqueEmails.Contains(email))
                {
                    emailsTable.Rows.Add(
                        emailId++,
                        email,
                        $"{firstName} {lastName}",
                        domain,
                        0 // Пока без дубликатов
                    );
                    uniqueEmails.Add(email);
                }
            }

            // Теперь добавляем дубликаты
            int duplicateCount = 200;
            var emailList = uniqueEmails.ToList();

            for (int i = 0; i < duplicateCount; i++)
            {
                // Берем случайный email из существующих
                string originalEmail = emailList[rand.Next(emailList.Count)];

                // Создаем вариант с небольшими изменениями
                string duplicateEmail;

                switch (rand.Next(4))
                {
                    case 0: // Точный дубликат
                        duplicateEmail = originalEmail;
                        break;
                    case 1: // С опечаткой
                        duplicateEmail = originalEmail.Replace('a', 'а'); // Кириллическая 'а'
                        break;
                    case 2: // С разным регистром
                        duplicateEmail = originalEmail.ToUpper();
                        break;
                    case 3: // С другим доменом
                        string newDomain = domains[rand.Next(domains.Length)];
                        duplicateEmail = originalEmail.Split('@')[0] + "@" + newDomain;
                        break;
                    default:
                        duplicateEmail = originalEmail;
                        break;
                }

                // Извлекаем имя из email
                string localPart = duplicateEmail.Split('@')[0];
                string[] nameParts = localPart.Split('.', '_');
                string firstName = nameParts.Length > 0 ? nameParts[0] : "unknown";
                string lastName = nameParts.Length > 1 ? nameParts[1] : "";

                emailsTable.Rows.Add(
                    emailId++,
                    duplicateEmail,
                    $"{firstName} {lastName}",
                    duplicateEmail.Split('@').Length > 1 ? duplicateEmail.Split('@')[1] : "unknown",
                    0
                );
            }

            Console.WriteLine($"Таблица содержит {emailsTable.Rows.Count} записей (включая дубликаты)");

            // 3. Функции поиска и обработки дубликатов
            Console.WriteLine("\n=== Поиск и обработка дубликатов ===");

            // 3.1. Поиск точных дубликатов
            Console.WriteLine("\n--- Поиск точных дубликатов (одинаковые email) ---");

            DataView exactDuplicatesView = FindExactDuplicates(emailsTable);
            Console.WriteLine($"Найдено точных дубликатов: {exactDuplicatesView.Count}");

            if (exactDuplicatesView.Count > 0)
            {
                Console.WriteLine("\nПримеры точных дубликатов:");
                var groups = GroupExactDuplicates(exactDuplicatesView);
                int shown = 0;
                foreach (var group in groups.Take(5))
                {
                    Console.WriteLine($"  Email: {group.Key} ({group.Value.Count} раз)");
                    shown++;
                    if (shown >= 5) break;
                }
            }

            // 3.2. Поиск похожих дубликатов
            Console.WriteLine("\n--- Поиск похожих дубликатов ---");

            // Ищем похожие имена с разными доменами
            DataView similarDuplicatesView = FindSimilarDuplicates(emailsTable);
            Console.WriteLine($"Найдено похожих дубликатов: {similarDuplicatesView.Count}");

            if (similarDuplicatesView.Count > 0)
            {
                Console.WriteLine("\nПримеры похожих дубликатов:");
                var groups = GroupSimilarDuplicates(similarDuplicatesView);
                int shown = 0;
                foreach (var group in groups.Take(3))
                {
                    Console.WriteLine($"  Имя: {group.Key}");
                    foreach (var email in group.Value.Take(3))
                    {
                        Console.WriteLine($"    {email}");
                    }
                    if (group.Value.Count > 3)
                    {
                        Console.WriteLine($"    ... и еще {group.Value.Count - 3}");
                    }
                    shown++;
                    if (shown >= 3) break;
                }
            }

            // 3.3. Подсчёт количества дубликатов
            Console.WriteLine("\n--- Статистика дубликатов ---");

            var duplicateStats = CalculateDuplicateStatistics(emailsTable);

            Console.WriteLine($"Всего записей: {duplicateStats.TotalRecords}");
            Console.WriteLine($"Уникальных email: {duplicateStats.UniqueEmails}");
            Console.WriteLine($"Точных дубликатов: {duplicateStats.ExactDuplicates}");
            Console.WriteLine($"Похожих дубликатов: {duplicateStats.SimilarDuplicates}");
            Console.WriteLine($"Процент дубликатов: {duplicateStats.DuplicatePercentage:P1}");

            // 3.4. Создание DataView только дубликатов
            Console.WriteLine("\n--- DataView только дубликатов ---");

            DataView allDuplicatesView = CreateDuplicatesView(emailsTable);
            allDuplicatesView.Sort = "EmailAddress ASC";

            Console.WriteLine($"Все дубликаты: {allDuplicatesView.Count}");

            if (allDuplicatesView.Count > 0)
            {
                Console.WriteLine("\nПервые 5 дубликатов:");
                for (int i = 0; i < Math.Min(5, allDuplicatesView.Count); i++)
                {
                    Console.WriteLine($"  {allDuplicatesView[i]["EmailAddress"]} - {allDuplicatesView[i]["Name"]}");
                }
            }

            // 3.5. Создание DataView только уникальных записей
            Console.WriteLine("\n--- DataView только уникальных записей ---");

            DataView uniqueView = CreateUniqueView(emailsTable);
            Console.WriteLine($"Уникальных записей: {uniqueView.Count}");

            if (uniqueView.Count > 0)
            {
                Console.WriteLine("\nПримеры уникальных записей:");
                for (int i = 0; i < Math.Min(5, uniqueView.Count); i++)
                {
                    Console.WriteLine($"  {uniqueView[i]["EmailAddress"]} - {uniqueView[i]["Name"]}");
                }
            }

            // 4. Выбор "главной" записи при дубликатах
            Console.WriteLine("\n=== Выбор главной записи для дубликатов ===");

            // Для каждого дубликата выбираем главную запись
            var duplicateGroups = GroupAllDuplicates(emailsTable);

            Console.WriteLine($"Групп дубликатов: {duplicateGroups.Count}");

            if (duplicateGroups.Count > 0)
            {
                Console.WriteLine("\nПример группы дубликатов:");
                var firstGroup = duplicateGroups.First();
                Console.WriteLine($"  Основной email: {firstGroup.PrimaryEmail}");
                Console.WriteLine($"  Всего дубликатов в группе: {firstGroup.DuplicateEmails.Count}");

                Console.WriteLine("  Дубликаты:");
                foreach (var duplicate in firstGroup.DuplicateEmails.Take(3))
                {
                    Console.WriteLine($"    {duplicate.Email} (ID: {duplicate.Id}, Имя: {duplicate.Name})");
                }
                if (firstGroup.DuplicateEmails.Count > 3)
                {
                    Console.WriteLine($"    ... и еще {firstGroup.DuplicateEmails.Count - 3}");
                }
            }

            // 5. Объединение дубликатов
            Console.WriteLine("\n=== Объединение дубликатов ===");

            DataTable mergedTable = MergeDuplicates(emailsTable, duplicateGroups);
            Console.WriteLine($"После объединения: {mergedTable.Rows.Count} записей (было {emailsTable.Rows.Count})");
            Console.WriteLine($"Удалено дубликатов: {emailsTable.Rows.Count - mergedTable.Rows.Count}");

            // 6. Отчёт о найденных дубликатах
            Console.WriteLine("\n=== Отчёт о дубликатах ===");

            PrintDuplicateReport(duplicateGroups, duplicateStats);

            // 7. Статистика
            Console.WriteLine("\n=== Статистика ===");

            Console.WriteLine($"Всего записей: {emailsTable.Rows.Count}");
            Console.WriteLine($"Уникальных записей: {uniqueView.Count}");
            Console.WriteLine($"Дубликатов: {allDuplicatesView.Count}");
            Console.WriteLine($"Процент дубликатов: {allDuplicatesView.Count * 100.0 / emailsTable.Rows.Count:F1}%");

            // Распределение по доменам
            Console.WriteLine("\nРаспределение по доменам:");
            DataView domainView = new DataView(emailsTable)
            {
                Sort = "Domain ASC"
            };

            var domainStats = new Dictionary<string, int>();
            for (int i = 0; i < domainView.Count; i++)
            {
                string domain = domainView[i]["Domain"].ToString();
                if (!domainStats.ContainsKey(domain))
                    domainStats[domain] = 0;
                domainStats[domain]++;
            }

            foreach (var domain in domainStats.OrderByDescending(d => d.Value).Take(5))
            {
                Console.WriteLine($"  {domain.Key}: {domain.Value} записей");
            }

            // 8. Рекомендации по обработке дубликатов
            Console.WriteLine("\n=== Рекомендации ===");

            var recommendations = GenerateRecommendations(duplicateStats, duplicateGroups);

            Console.WriteLine("\nРекомендации по обработке дубликатов:");
            foreach (var recommendation in recommendations)
            {
                Console.WriteLine($"  • {recommendation}");
            }

            // 9. Дополнительный анализ: поиск возможных опечаток
            Console.WriteLine("\n=== Поиск возможных опечаток ===");

            var possibleTypos = FindPossibleTypos(emailsTable);
            Console.WriteLine($"Найдено возможных опечаток: {possibleTypos.Count}");

            if (possibleTypos.Count > 0)
            {
                Console.WriteLine("\nПримеры возможных опечаток:");
                foreach (var typo in possibleTypos.Take(3))
                {
                    Console.WriteLine($"  {typo.Email1} -> {typo.Email2} (расстояние Левенштейна: {typo.Distance})");
                }
            }
        }

        // Вспомогательные классы и методы
        static DataView FindExactDuplicates(DataTable table)
        {
            // Используем DataView для поиска дубликатов
            DataView view = new DataView(table);

            // Сортируем по email для группировки дубликатов
            view.Sort = "EmailAddress ASC";

            // Фильтруем дубликаты
            var duplicateIds = new List<int>();
            string previousEmail = "";
            int previousId = -1;

            for (int i = 0; i < view.Count; i++)
            {
                string currentEmail = view[i]["EmailAddress"].ToString().ToLower();
                int currentId = Convert.ToInt32(view[i]["EmailID"]);

                if (currentEmail == previousEmail)
                {
                    duplicateIds.Add(previousId);
                    duplicateIds.Add(currentId);
                }

                previousEmail = currentEmail;
                previousId = currentId;
            }

            // Создаем DataView с дубликатами
            if (duplicateIds.Count > 0)
            {
                string filter = string.Join(" OR ", duplicateIds.Distinct().Select(id => $"EmailID = {id}"));
                return new DataView(table)
                {
                    RowFilter = filter,
                    Sort = "EmailAddress ASC"
                };
            }

            return new DataView(table) { RowFilter = "1 = 0" }; // Пустой DataView
        }

        static DataView FindSimilarDuplicates(DataTable table)
        {
            // Поиск похожих дубликатов по имени
            DataView view = new DataView(table)
            {
                Sort = "Name ASC"
            };

            var duplicateIds = new List<int>();

            for (int i = 1; i < view.Count; i++)
            {
                string currentName = view[i]["Name"].ToString().ToLower();
                string previousName = view[i - 1]["Name"].ToString().ToLower();

                // Простая проверка схожести имен
                if (AreNamesSimilar(currentName, previousName))
                {
                    duplicateIds.Add(Convert.ToInt32(view[i]["EmailID"]));
                    duplicateIds.Add(Convert.ToInt32(view[i - 1]["EmailID"]));
                }
            }

            if (duplicateIds.Count > 0)
            {
                string filter = string.Join(" OR ", duplicateIds.Distinct().Select(id => $"EmailID = {id}"));
                return new DataView(table)
                {
                    RowFilter = filter,
                    Sort = "Name ASC"
                };
            }

            return new DataView(table) { RowFilter = "1 = 0" };
        }

        static bool AreNamesSimilar(string name1, string name2)
        {
            if (string.IsNullOrEmpty(name1) || string.IsNullOrEmpty(name2))
                return false;

            // Удаляем пробелы и приводим к нижнему регистру
            name1 = name1.Replace(" ", "").ToLower();
            name2 = name2.Replace(" ", "").ToLower();

            // Проверяем, является ли одно имя частью другого
            if (name1.Contains(name2) || name2.Contains(name1))
                return true;

            // Проверяем расстояние Левенштейна для коротких имен
            if (name1.Length < 10 || name2.Length < 10)
            {
                int distance = LevenshteinDistance(name1, name2);
                return distance <= 2; // Допускаем 2 опечатки
            }

            return false;
        }

        static int LevenshteinDistance(string s, string t)
        {
            // Стандартный алгоритм расстояния Левенштейна
            int n = s.Length;
            int m = t.Length;
            int[,] d = new int[n + 1, m + 1];

            if (n == 0) return m;
            if (m == 0) return n;

            for (int i = 0; i <= n; d[i, 0] = i++) { }
            for (int j = 0; j <= m; d[0, j] = j++) { }

            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= m; j++)
                {
                    int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;
                    d[i, j] = Math.Min(
                        Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                        d[i - 1, j - 1] + cost);
                }
            }
            return d[n, m];
        }

        static DuplicateStatistics CalculateDuplicateStatistics(DataTable table)
        {
            var stats = new DuplicateStatistics
            {
                TotalRecords = table.Rows.Count
            };

            // Подсчет уникальных email
            var uniqueEmails = new HashSet<string>();
            foreach (DataRow row in table.Rows)
            {
                string email = row["EmailAddress"].ToString().ToLower();
                uniqueEmails.Add(email);
            }
            stats.UniqueEmails = uniqueEmails.Count;

            // Подсчет точных дубликатов
            DataView exactDuplicates = FindExactDuplicates(table);
            stats.ExactDuplicates = exactDuplicates.Count;

            // Подсчет похожих дубликатов
            DataView similarDuplicates = FindSimilarDuplicates(table);
            stats.SimilarDuplicates = similarDuplicates.Count;

            return stats;
        }

        static DataView CreateDuplicatesView(DataTable table)
        {
            // Объединяем все дубликаты
            var exactDuplicates = FindExactDuplicates(table);
            var similarDuplicates = FindSimilarDuplicates(table);

            var allDuplicateIds = new HashSet<int>();

            for (int i = 0; i < exactDuplicates.Count; i++)
            {
                allDuplicateIds.Add(Convert.ToInt32(exactDuplicates[i]["EmailID"]));
            }

            for (int i = 0; i < similarDuplicates.Count; i++)
            {
                allDuplicateIds.Add(Convert.ToInt32(similarDuplicates[i]["EmailID"]));
            }

            if (allDuplicateIds.Count > 0)
            {
                string filter = string.Join(" OR ", allDuplicateIds.Select(id => $"EmailID = {id}"));
                return new DataView(table)
                {
                    RowFilter = filter,
                    Sort = "EmailAddress ASC"
                };
            }

            return new DataView(table) { RowFilter = "1 = 0" };
        }

        static DataView CreateUniqueView(DataTable table)
        {
            // Находим все дубликаты
            DataView duplicatesView = CreateDuplicatesView(table);
            var duplicateIds = new HashSet<int>();

            for (int i = 0; i < duplicatesView.Count; i++)
            {
                duplicateIds.Add(Convert.ToInt32(duplicatesView[i]["EmailID"]));
            }

            // Создаем фильтр для уникальных записей
            if (duplicateIds.Count > 0)
            {
                string filter = string.Join(" AND ", duplicateIds.Select(id => $"EmailID != {id}"));
                return new DataView(table)
                {
                    RowFilter = filter,
                    Sort = "EmailAddress ASC"
                };
            }

            // Если дубликатов нет, все записи уникальны
            return new DataView(table)
            {
                Sort = "EmailAddress ASC"
            };
        }

        static List<DuplicateGroup> GroupAllDuplicates(DataTable table)
        {
            var groups = new List<DuplicateGroup>();

            // Сортируем по email для группировки
            DataView sortedView = new DataView(table)
            {
                Sort = "EmailAddress ASC"
            };

            DuplicateGroup currentGroup = null;
            string previousEmail = "";

            for (int i = 0; i < sortedView.Count; i++)
            {
                string currentEmail = sortedView[i]["EmailAddress"].ToString().ToLower();

                if (currentEmail != previousEmail)
                {
                    if (currentGroup != null && currentGroup.DuplicateEmails.Count > 1)
                    {
                        groups.Add(currentGroup);
                    }

                    currentGroup = new DuplicateGroup
                    {
                        PrimaryEmail = currentEmail,
                        DuplicateEmails = new List<DuplicateRecord>()
                    };
                }

                currentGroup.DuplicateEmails.Add(new DuplicateRecord
                {
                    Id = Convert.ToInt32(sortedView[i]["EmailID"]),
                    Email = currentEmail,
                    Name = sortedView[i]["Name"].ToString(),
                    Domain = sortedView[i]["Domain"].ToString()
                });

                previousEmail = currentEmail;
            }

            // Добавляем последнюю группу
            if (currentGroup != null && currentGroup.DuplicateEmails.Count > 1)
            {
                groups.Add(currentGroup);
            }

            return groups;
        }

        static Dictionary<string, List<string>> GroupExactDuplicates(DataView duplicatesView)
        {
            var groups = new Dictionary<string, List<string>>();

            for (int i = 0; i < duplicatesView.Count; i++)
            {
                string email = duplicatesView[i]["EmailAddress"].ToString();
                string name = duplicatesView[i]["Name"].ToString();

                if (!groups.ContainsKey(email))
                    groups[email] = new List<string>();

                groups[email].Add(name);
            }

            return groups;
        }

        static Dictionary<string, List<string>> GroupSimilarDuplicates(DataView duplicatesView)
        {
            var groups = new Dictionary<string, List<string>>();

            for (int i = 0; i < duplicatesView.Count; i++)
            {
                string name = duplicatesView[i]["Name"].ToString();
                string email = duplicatesView[i]["EmailAddress"].ToString();

                if (!groups.ContainsKey(name))
                    groups[name] = new List<string>();

                groups[name].Add(email);
            }

            return groups;
        }

        static DataTable MergeDuplicates(DataTable originalTable, List<DuplicateGroup> duplicateGroups)
        {
            // Создаем копию таблицы без данных
            DataTable mergedTable = originalTable.Clone();

            // Собираем ID всех записей, которые нужно сохранить
            var recordsToKeep = new HashSet<int>();

            foreach (var group in duplicateGroups)
            {
                // Выбираем "лучшую" запись в группе
                var bestRecord = group.DuplicateEmails
                    .OrderByDescending(r => r.Email.Contains("@gmail.com") || r.Email.Contains("@company.com") ? 1 : 0)
                    .ThenBy(r => r.Email.Length)
                    .First();

                recordsToKeep.Add(bestRecord.Id);
            }

            // Добавляем уникальные записи
            DataView uniqueView = CreateUniqueView(originalTable);
            for (int i = 0; i < uniqueView.Count; i++)
            {
                recordsToKeep.Add(Convert.ToInt32(uniqueView[i]["EmailID"]));
            }

            // Копируем выбранные записи в новую таблицу
            foreach (int id in recordsToKeep)
            {
                DataRow originalRow = originalTable.Rows.Find(id);
                if (originalRow != null)
                {
                    DataRow newRow = mergedTable.NewRow();
                    foreach (DataColumn column in mergedTable.Columns)
                    {
                        newRow[column] = originalRow[column];
                    }
                    mergedTable.Rows.Add(newRow);
                }
            }

            return mergedTable;
        }

        static void PrintDuplicateReport(List<DuplicateGroup> duplicateGroups, DuplicateStatistics stats)
        {
            Console.WriteLine("\n=== ОТЧЁТ О ДУБЛИКАТАХ ===");
            Console.WriteLine($"Дата формирования: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            Console.WriteLine($"Всего записей: {stats.TotalRecords}");
            Console.WriteLine($"Уникальных email: {stats.UniqueEmails}");
            Console.WriteLine($"Точных дубликатов: {stats.ExactDuplicates}");
            Console.WriteLine($"Похожих дубликатов: {stats.SimilarDuplicates}");
            Console.WriteLine($"Процент дубликатов: {stats.DuplicatePercentage:P1}");

            Console.WriteLine("\nГруппы дубликатов:");
            int groupNumber = 1;
            foreach (var group in duplicateGroups.Take(10))
            {
                Console.WriteLine($"\nГруппа {groupNumber++}: {group.PrimaryEmail}");
                Console.WriteLine($"  Количество дубликатов: {group.DuplicateEmails.Count}");
                Console.WriteLine("  Дубликаты:");
                foreach (var duplicate in group.DuplicateEmails.Take(5))
                {
                    Console.WriteLine($"    • ID: {duplicate.Id}, Email: {duplicate.Email}, Имя: {duplicate.Name}");
                }
                if (group.DuplicateEmails.Count > 5)
                {
                    Console.WriteLine($"    ... и еще {group.DuplicateEmails.Count - 5}");
                }
            }

            if (duplicateGroups.Count > 10)
            {
                Console.WriteLine($"\n... и еще {duplicateGroups.Count - 10} групп");
            }
        }

        static List<string> GenerateRecommendations(DuplicateStatistics stats, List<DuplicateGroup> duplicateGroups)
        {
            var recommendations = new List<string>();

            if (stats.DuplicatePercentage > 0.3)
            {
                recommendations.Add("Высокий процент дубликатов (более 30%). Рекомендуется провести полную очистку базы данных.");
            }
            else if (stats.DuplicatePercentage > 0.1)
            {
                recommendations.Add("Умеренный процент дубликатов (10-30%). Рекомендуется выборочная очистка.");
            }
            else
            {
                recommendations.Add("Низкий процент дубликатов (менее 10%). Текущее состояние удовлетворительное.");
            }

            if (duplicateGroups.Any(g => g.DuplicateEmails.Count > 5))
            {
                recommendations.Add("Обнаружены группы с более чем 5 дубликатами. Возможны системные проблемы с вводом данных.");
            }

            if (stats.SimilarDuplicates > stats.ExactDuplicates * 2)
            {
                recommendations.Add("Много похожих дубликатов. Рекомендуется улучшить валидацию ввода имен и email.");
            }

            recommendations.Add($"Всего можно удалить {stats.TotalRecords - stats.UniqueEmails} дубликатов без потери информации.");

            return recommendations;
        }

        static List<TypoInfo> FindPossibleTypos(DataTable table)
        {
            var possibleTypos = new List<TypoInfo>();

            // Ищем пары email с небольшим расстоянием Левенштейна
            for (int i = 0; i < table.Rows.Count; i++)
            {
                for (int j = i + 1; j < Math.Min(i + 50, table.Rows.Count); j++) // Ограничиваем поиск
                {
                    string email1 = table.Rows[i]["EmailAddress"].ToString().ToLower();
                    string email2 = table.Rows[j]["EmailAddress"].ToString().ToLower();

                    // Ищем только для email одной длины или с разницей не более 2 символов
                    if (Math.Abs(email1.Length - email2.Length) <= 2)
                    {
                        int distance = LevenshteinDistance(email1, email2);
                        if (distance > 0 && distance <= 2) // 1-2 опечатки
                        {
                            possibleTypos.Add(new TypoInfo
                            {
                                Email1 = email1,
                                Email2 = email2,
                                Distance = distance
                            });
                        }
                    }
                }
            }

            return possibleTypos;
        }

        class DuplicateStatistics
        {
            public int TotalRecords { get; set; }
            public int UniqueEmails { get; set; }
            public int ExactDuplicates { get; set; }
            public int SimilarDuplicates { get; set; }

            public double DuplicatePercentage => TotalRecords > 0 ?
                (double)(TotalRecords - UniqueEmails) / TotalRecords : 0;
        }

        class DuplicateGroup
        {
            public string PrimaryEmail { get; set; }
            public List<DuplicateRecord> DuplicateEmails { get; set; }
        }

        class DuplicateRecord
        {
            public int Id { get; set; }
            public string Email { get; set; }
            public string Name { get; set; }
            public string Domain { get; set; }
        }

        class TypoInfo
        {
            public string Email1 { get; set; }
            public string Email2 { get; set; }
            public int Distance { get; set; }
        }
        #endregion

        #region ЗАДАНИЕ 27: Оптимизация производительности больших таблиц
        static void Task27()
        {
            Console.Clear();
            Console.WriteLine("=== ЗАДАНИЕ 27: Оптимизация производительности больших таблиц ===\n");

            // Создаем большую таблицу логов
            Console.WriteLine("Создание большой таблицы логов (1,000,000 записей)...");
            Stopwatch sw = new Stopwatch();
            sw.Start();

            DataTable logsTable = CreateLogsTable();
            FillLogsTable(logsTable, 1000000); // 1 млн записей

            sw.Stop();
            Console.WriteLine($"Таблица создана за {sw.ElapsedMilliseconds} мс");
            Console.WriteLine($"Записей в таблице: {logsTable.Rows.Count:N0}");

            // Тестируем различные сценарии
            TestScenario1_Select(logsTable);
            TestScenario2_DataView(logsTable);
            TestScenario3_DataViewReuse(logsTable);
            TestScenario4_FindWithIndex(logsTable);

            Console.WriteLine("\n--- Рекомендации по оптимизации ---");
            Console.WriteLine("1. Для частых поисков по одному критерию используйте DataView с фильтром");
            Console.WriteLine("2. Для поиска по первичному ключу используйте Find()");
            Console.WriteLine("3. Кэшируйте результаты запросов, если данные редко меняются");
            Console.WriteLine("4. Используйте DataView.RowFilter для динамической фильтрации");
            Console.WriteLine("5. Избегайте частого создания новых DataView");
        }

        static DataTable CreateLogsTable()
        {
            DataTable table = new DataTable("Логи");
            table.Columns.Add("LogID", typeof(int));
            table.Columns.Add("Timestamp", typeof(DateTime));
            table.Columns.Add("Level", typeof(string));
            table.Columns.Add("Message", typeof(string));
            table.Columns.Add("Source", typeof(string));
            table.Columns.Add("EventID", typeof(int));
            table.PrimaryKey = new DataColumn[] { table.Columns["LogID"] };
            return table;
        }

        static void FillLogsTable(DataTable table, int count)
        {
            string[] levels = { "INFO", "WARNING", "ERROR", "DEBUG" };
            string[] sources = { "Application", "System", "Security", "Network", "Database" };
            Random rand = new Random(42); // Фиксированный seed для воспроизводимости

            for (int i = 1; i <= count; i++)
            {
                table.Rows.Add(
                    i,
                    DateTime.Now.AddSeconds(-rand.Next(0, 86400 * 365)), // Случайная дата в течение года
                    levels[rand.Next(levels.Length)],
                    $"Сообщение лога {i} с некоторым текстом",
                    sources[rand.Next(sources.Length)],
                    rand.Next(1000, 9999)
                );

                // Прогресс для больших таблиц
                if (i % 100000 == 0)
                {
                    Console.Write(".");
                }
            }
            Console.WriteLine();
        }

        static void TestScenario1_Select(DataTable table)
        {
            Console.WriteLine("\n--- Сценарий 1: Поиск через DataTable.Select() ---");
            Stopwatch sw = new Stopwatch();

            // Первый поиск
            sw.Start();
            DataRow[] rows1 = table.Select("Level = 'ERROR' AND Source = 'Application'");
            sw.Stop();
            Console.WriteLine($"Первый поиск: {sw.ElapsedMilliseconds} мс, найдено: {rows1.Length:N0}");

            // Второй поиск (тот же фильтр)
            sw.Restart();
            DataRow[] rows2 = table.Select("Level = 'ERROR' AND Source = 'Application'");
            sw.Stop();
            Console.WriteLine($"Второй поиск: {sw.ElapsedMilliseconds} мс");

            // Другой фильтр
            sw.Restart();
            DataRow[] rows3 = table.Select("EventID > 5000");
            sw.Stop();
            Console.WriteLine($"Поиск по EventID: {sw.ElapsedMilliseconds} мс, найдено: {rows3.Length:N0}");
        }

        static void TestScenario2_DataView(DataTable table)
        {
            Console.WriteLine("\n--- Сценарий 2: Создание DataView с фильтром ---");
            Stopwatch sw = new Stopwatch();

            // Создание DataView
            sw.Start();
            DataView dv = new DataView(table, "Level = 'ERROR' AND Source = 'Application'", "", DataViewRowState.CurrentRows);
            sw.Stop();
            Console.WriteLine($"Создание DataView: {sw.ElapsedMilliseconds} мс, записей: {dv.Count:N0}");

            // Доступ к данным
            sw.Restart();
            int count = dv.Count;
            sw.Stop();
            Console.WriteLine($"Подсчет записей: {sw.ElapsedMilliseconds} мс");
        }

        static void TestScenario3_DataViewReuse(DataTable table)
        {
            Console.WriteLine("\n--- Сценарий 3: Повторное использование DataView ---");
            Stopwatch sw = new Stopwatch();

            // Создаем DataView один раз
            DataView dv = new DataView(table);

            // Фильтр 1
            sw.Start();
            dv.RowFilter = "Level = 'ERROR'";
            int count1 = dv.Count;
            sw.Stop();
            Console.WriteLine($"Фильтр 'ERROR': {sw.ElapsedMilliseconds} мс, записей: {count1:N0}");

            // Фильтр 2 (изменение фильтра)
            sw.Restart();
            dv.RowFilter = "Level = 'WARNING'";
            int count2 = dv.Count;
            sw.Stop();
            Console.WriteLine($"Фильтр 'WARNING': {sw.ElapsedMilliseconds} мс, записей: {count2:N0}");

            // Фильтр 3 (комбинированный)
            sw.Restart();
            dv.RowFilter = "Level = 'INFO' AND EventID < 2000";
            int count3 = dv.Count;
            sw.Stop();
            Console.WriteLine($"Комбинированный фильтр: {sw.ElapsedMilliseconds} мс, записей: {count3:N0}");
        }

        static void TestScenario4_FindWithIndex(DataTable table)
        {
            Console.WriteLine("\n--- Сценарий 4: Поиск по первичному ключу через Find() ---");
            Stopwatch sw = new Stopwatch();

            // Создаем индекс для поиска (первичный ключ уже создан)
            sw.Start();
            DataRow foundRow = table.Rows.Find(500000); // Ищем середину таблицы
            sw.Stop();
            Console.WriteLine($"Find() по LogID=500000: {sw.ElapsedMilliseconds} мс");
            Console.WriteLine($"Найдена строка: {(foundRow != null ? "Да" : "Нет")}");

            // Сравнение с Select
            sw.Restart();
            DataRow[] rows = table.Select($"LogID = 500000");
            sw.Stop();
            Console.WriteLine($"Select() по LogID=500000: {sw.ElapsedMilliseconds} мс");

            // Множественный поиск
            Console.WriteLine("\n--- Множественный поиск 1000 записей ---");
            Random rand = new Random();
            int[] idsToFind = Enumerable.Range(0, 1000).Select(_ => rand.Next(1, 1000000)).ToArray();

            sw.Restart();
            int foundCount = 0;
            foreach (int id in idsToFind)
            {
                if (table.Rows.Find(id) != null)
                    foundCount++;
            }
            sw.Stop();
            Console.WriteLine($"Find() 1000 записей: {sw.ElapsedMilliseconds} мс, найдено: {foundCount}");

            sw.Restart();
            foundCount = 0;
            foreach (int id in idsToFind)
            {
                if (table.Select($"LogID = {id}").Length > 0)
                    foundCount++;
            }
            sw.Stop();
            Console.WriteLine($"Select() 1000 записей: {sw.ElapsedMilliseconds} мс, найдено: {foundCount}");
        }
        #endregion


        #region ЗАДАНИЕ 28: Кастомный поиск с использованием DataView
        static void Task28()
        {
            Console.Clear();
            Console.WriteLine("=== ЗАДАНИЕ 28: Кастомный поиск с использованием DataView ===\n");

            // Создаем таблицу библиотеки
            DataTable libraryTable = CreateLibraryTable();
            FillLibraryTable(libraryTable, 500);

            // Создаем поисковый движок
            SearchEngine searchEngine = new SearchEngine(libraryTable);

            // Тестируем различные виды поиска
            Console.WriteLine("--- Тестирование поискового движка ---\n");

            // Поиск по автору
            Console.WriteLine("1. Поиск по автору (частичное совпадение):");
            DataView dvAuthor = searchEngine.SearchByAuthor("Толстой");
            DisplaySearchResults(dvAuthor, 5);

            // Поиск по названию
            Console.WriteLine("\n2. Поиск по названию:");
            DataView dvTitle = searchEngine.SearchByTitle("война");
            DisplaySearchResults(dvTitle, 5);

            // Поиск по жанру
            Console.WriteLine("\n3. Поиск по жанру:");
            DataView dvGenre = searchEngine.SearchByGenre("Роман");
            DisplaySearchResults(dvGenre, 5);

            // Поиск по году
            Console.WriteLine("\n4. Поиск по году издания (1900-1950):");
            DataView dvYear = searchEngine.SearchByYearRange(1900, 1950);
            DisplaySearchResults(dvYear, 5);

            // Поиск по рейтингу
            Console.WriteLine("\n5. Поиск по рейтингу (минимум 4.5):");
            DataView dvRating = searchEngine.SearchByMinRating(4.5m);
            DisplaySearchResults(dvRating, 5);

            // Комбинированный поиск
            Console.WriteLine("\n6. Комбинированный поиск (Роман, рейтинг > 4.0, после 1900):");
            DataView dvCombined = searchEngine.CombinedSearch("Роман", 4.0m, 1900);
            DisplaySearchResults(dvCombined, 5);

            // История поисков
            Console.WriteLine("\n--- История поисков ---");
            foreach (var search in searchEngine.GetSearchHistory().Take(5))
            {
                Console.WriteLine($"{search.Timestamp:HH:mm:ss} - {search.Query} ({search.ResultsCount} результатов)");
            }

            // Рекомендации на основе истории
            Console.WriteLine("\n--- Рекомендации ---");
            var recommendations = searchEngine.GetRecommendations();
            foreach (var rec in recommendations.Take(3))
            {
                Console.WriteLine($"Попробуйте: {rec}");
            }

            // Сохранение результатов
            Console.WriteLine("\n--- Сохранение результатов ---");
            searchEngine.SaveResultsToFile(dvAuthor, "search_results.csv");
            Console.WriteLine("Результаты сохранены в search_results.csv");
        }

        class SearchEngine
        {
            private DataTable _table;
            private List<SearchHistoryItem> _history = new List<SearchHistoryItem>();

            public SearchEngine(DataTable table)
            {
                _table = table;
            }

            public DataView SearchByAuthor(string author)
            {
                string query = $"Author LIKE '%{author}%'";
                return ExecuteSearch(query, $"Поиск автора: {author}");
            }

            public DataView SearchByTitle(string title)
            {
                string query = $"Title LIKE '%{title}%'";
                return ExecuteSearch(query, $"Поиск названия: {title}");
            }

            public DataView SearchByGenre(string genre)
            {
                string query = $"Genre = '{genre}'";
                return ExecuteSearch(query, $"Поиск жанра: {genre}");
            }

            public DataView SearchByYearRange(int startYear, int endYear)
            {
                string query = $"Year >= {startYear} AND Year <= {endYear}";
                return ExecuteSearch(query, $"Поиск по годам: {startYear}-{endYear}");
            }

            public DataView SearchByMinRating(decimal minRating)
            {
                string query = $"Rating >= {minRating}";
                return ExecuteSearch(query, $"Поиск по рейтингу: >={minRating}");
            }

            public DataView CombinedSearch(string genre, decimal minRating, int minYear)
            {
                string query = $"Genre = '{genre}' AND Rating >= {minRating} AND Year >= {minYear}";
                return ExecuteSearch(query, $"Комбинированный поиск: {genre}, рейтинг>={minRating}, год>={minYear}");
            }

            private DataView ExecuteSearch(string query, string description)
            {
                try
                {
                    DataView dv = new DataView(_table, query, "Rating DESC", DataViewRowState.CurrentRows);
                    _history.Add(new SearchHistoryItem
                    {
                        Timestamp = DateTime.Now,
                        Query = description,
                        ResultsCount = dv.Count
                    });
                    return dv;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка поиска: {ex.Message}");
                    return new DataView(_table) { RowFilter = "1=0" }; // Пустой результат
                }
            }

            public List<SearchHistoryItem> GetSearchHistory()
            {
                return _history;
            }

            public List<string> GetRecommendations()
            {
                var popularGenres = _history
                    .Where(h => h.Query.Contains("жанр"))
                    .GroupBy(h => h.Query)
                    .OrderByDescending(g => g.Count())
                    .Take(3)
                    .Select(g => g.Key.Replace("Поиск жанра: ", ""))
                    .ToList();

                var recommendations = new List<string>();
                if (popularGenres.Count > 0)
                {
                    recommendations.Add($"Популярный жанр: {popularGenres.First()}");
                }

                recommendations.Add("Попробуйте поиск по высокому рейтингу (Rating > 4.5)");
                recommendations.Add("Классика: поиск книг до 1900 года");

                return recommendations;
            }

            public void SaveResultsToFile(DataView results, string filename)
            {
                try
                {
                    using (var writer = new System.IO.StreamWriter(filename))
                    {
                        // Заголовок
                        writer.WriteLine("Title;Author;Year;Genre;Rating;Pages");

                        // Данные
                        foreach (DataRowView row in results)
                        {
                            writer.WriteLine($"{row["Title"]};{row["Author"]};{row["Year"]};{row["Genre"]};{row["Rating"]};{row["Pages"]}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка сохранения: {ex.Message}");
                }
            }
        }

        class SearchHistoryItem
        {
            public DateTime Timestamp { get; set; }
            public string Query { get; set; }
            public int ResultsCount { get; set; }
        }

        static DataTable CreateLibraryTable()
        {
            DataTable table = new DataTable("Библиотека");
            table.Columns.Add("BookID", typeof(int));
            table.Columns.Add("Title", typeof(string));
            table.Columns.Add("Author", typeof(string));
            table.Columns.Add("Year", typeof(int));
            table.Columns.Add("ISBN", typeof(string));
            table.Columns.Add("Genre", typeof(string));
            table.Columns.Add("Rating", typeof(decimal));
            table.Columns.Add("Pages", typeof(int));
            table.PrimaryKey = new DataColumn[] { table.Columns["BookID"] };
            return table;
        }

        static void FillLibraryTable(DataTable table, int count)
        {
            string[] authors = { "Толстой", "Достоевский", "Чехов", "Гоголь", "Пушкин", "Лермонтов", "Булгаков", "Оруэлл", "Хемингуэй", "Кинг" };
            string[] genres = { "Роман", "Повесть", "Рассказ", "Поэзия", "Драма", "Фантастика", "Детектив", "Исторический" };
            string[] titles = { "Война и мир", "Преступление и наказание", "Мастер и Маргарита", "1984", "Старик и море", "Анна Каренина", "Мёртвые души", "Евгений Онегин" };

            Random rand = new Random();

            for (int i = 1; i <= count; i++)
            {
                string author = authors[rand.Next(authors.Length)];
                string genre = genres[rand.Next(genres.Length)];
                string title = $"{titles[rand.Next(titles.Length)]} {i}";

                table.Rows.Add(
                    i,
                    title,
                    author,
                    rand.Next(1800, 2023),
                    $"ISBN{rand.Next(1000000, 9999999)}",
                    genre,
                    Math.Round(rand.NextDouble() * 2 + 3, 1), // Рейтинг 3.0-5.0
                    rand.Next(100, 1000)
                );
            }
        }

        static void DisplaySearchResults(DataView dv, int maxRows)
        {
            Console.WriteLine($"Найдено записей: {dv.Count}");

            if (dv.Count > 0)
            {
                Console.WriteLine("Первые результаты:");
                for (int i = 0; i < Math.Min(maxRows, dv.Count); i++)
                {
                    Console.WriteLine($"  {dv[i]["Title"]} - {dv[i]["Author"]} ({dv[i]["Year"]}), {dv[i]["Rating"]}★");
                }
            }
        }
        #endregion


        #region ЗАДАНИЕ 29: Пользовательские представления для разных пользователей
        static void Task29()
        {
            Console.Clear();
            Console.WriteLine("=== ЗАДАНИЕ 29: Пользовательские представления для разных пользователей ===\n");

            // Создаем таблицу сотрудников
            DataTable employeesTable = CreateEmployeesTable();
            FillEmployeesTable(employeesTable, 100);

            // Создаем систему аудита
            AuditSystem auditSystem = new AuditSystem();

            // Тестируем разные роли пользователей
            TestHRManagerView(employeesTable, auditSystem);
            TestDepartmentHeadView(employeesTable, auditSystem);
            TestFinanceView(employeesTable, auditSystem);
            TestGeneralView(employeesTable, auditSystem);

            // Отчет об аудите
            Console.WriteLine("\n--- Отчет об аудите доступа ---");
            foreach (var log in auditSystem.GetAccessLogs().Take(10))
            {
                Console.WriteLine($"{log.Timestamp:yyyy-MM-dd HH:mm:ss} - {log.UserRole}: {log.Action} - {log.Details}");
            }

            // Экспорт данных
            Console.WriteLine("\n--- Экспорт данных ---");
            ExportDataForRole("HR Manager", employeesTable, auditSystem);
        }

        static DataTable CreateEmployeesTable()
        {
            DataTable table = new DataTable("Сотрудники");
            table.Columns.Add("EmployeeID", typeof(int));
            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("Department", typeof(string));
            table.Columns.Add("Salary", typeof(decimal));
            table.Columns.Add("HireDate", typeof(DateTime));
            table.Columns.Add("Status", typeof(string));
            table.PrimaryKey = new DataColumn[] { table.Columns["EmployeeID"] };
            return table;
        }

        static void FillEmployeesTable(DataTable table, int count)
        {
            string[] departments = { "IT", "HR", "Finance", "Sales", "Marketing", "Operations", "R&D" };
            string[] names = { "Иванов", "Петров", "Сидоров", "Кузнецов", "Смирнов", "Попов", "Васильев", "Павлов" };
            Random rand = new Random();

            for (int i = 1; i <= count; i++)
            {
                string department = departments[rand.Next(departments.Length)];
                table.Rows.Add(
                    i,
                    $"{names[rand.Next(names.Length)]} {names[rand.Next(names.Length)]}",
                    department,
                    rand.Next(30000, 300000),
                    DateTime.Now.AddDays(-rand.Next(0, 3650)),
                    rand.Next(0, 10) == 0 ? "Inactive" : "Active"
                );
            }
        }

        class AuditSystem
        {
            private List<AuditLog> _logs = new List<AuditLog>();

            public void LogAccess(string userRole, string action, string details)
            {
                _logs.Add(new AuditLog
                {
                    Timestamp = DateTime.Now,
                    UserRole = userRole,
                    Action = action,
                    Details = details
                });
            }

            public void LogEdit(string userRole, int employeeId, string field, object oldValue, object newValue)
            {
                _logs.Add(new AuditLog
                {
                    Timestamp = DateTime.Now,
                    UserRole = userRole,
                    Action = "EDIT",
                    Details = $"EmployeeID={employeeId}, {field}: {oldValue} -> {newValue}"
                });
            }

            public List<AuditLog> GetAccessLogs()
            {
                return _logs;
            }
        }

        class AuditLog
        {
            public DateTime Timestamp { get; set; }
            public string UserRole { get; set; }
            public string Action { get; set; }
            public string Details { get; set; }
        }

        static void TestHRManagerView(DataTable table, AuditSystem audit)
        {
            Console.WriteLine("--- HR Manager View ---");
            audit.LogAccess("HR Manager", "VIEW", "Все сотрудники, сортировка по зарплате");

            DataView dv = new DataView(table, "Status = 'Active'", "Salary DESC", DataViewRowState.CurrentRows);

            Console.WriteLine($"Всего активных сотрудников: {dv.Count}");
            Console.WriteLine("Топ-5 по зарплате:");
            for (int i = 0; i < Math.Min(5, dv.Count); i++)
            {
                Console.WriteLine($"  {dv[i]["Name"]} - {dv[i]["Department"]} - {dv[i]["Salary"]:C}");
            }

            // HR Manager может редактировать
            if (dv.Count > 0)
            {
                Console.WriteLine("\nHR Manager редактирует зарплату...");
                decimal oldSalary = (decimal)dv[0]["Salary"];
                dv[0]["Salary"] = oldSalary * 1.1m;
                audit.LogEdit("HR Manager", (int)dv[0]["EmployeeID"], "Salary", oldSalary, dv[0]["Salary"]);
            }
        }

        static void TestDepartmentHeadView(DataTable table, AuditSystem audit)
        {
            Console.WriteLine("\n--- Department Head (IT Department) View ---");
            audit.LogAccess("Department Head", "VIEW", "Только IT отдел");

            DataView dv = new DataView(table, "Department = 'IT' AND Status = 'Active'", "Name ASC", DataViewRowState.CurrentRows);

            Console.WriteLine($"Сотрудников в IT отделе: {dv.Count}");
            Console.WriteLine("Список сотрудников:");
            for (int i = 0; i < Math.Min(3, dv.Count); i++)
            {
                Console.WriteLine($"  {dv[i]["Name"]} - {dv[i]["Salary"]:C}");
            }

            // Руководитель отдела может редактировать только свой отдел
            if (dv.Count > 0)
            {
                Console.WriteLine("\nDepartment Head редактирует статус...");
                string oldStatus = dv[0]["Status"].ToString();
                dv[0]["Status"] = "On Vacation";
                audit.LogEdit("Department Head", (int)dv[0]["EmployeeID"], "Status", oldStatus, dv[0]["Status"]);
            }
        }

        static void TestFinanceView(DataTable table, AuditSystem audit)
        {
            Console.WriteLine("\n--- Finance Department View ---");
            audit.LogAccess("Finance", "VIEW", "Активные сотрудники с зарплатой > 100000");

            DataView dv = new DataView(table, "Status = 'Active' AND Salary > 100000", "Salary DESC", DataViewRowState.CurrentRows);

            Console.WriteLine($"Высокооплачиваемых сотрудников: {dv.Count}");
            Console.WriteLine("Суммарная зарплата: " +
                dv.Cast<DataRowView>().Sum(r => (decimal)r["Salary"]).ToString("C"));

            // Финансы могут только просматривать, не редактировать
            Console.WriteLine("(Finance имеет доступ только для чтения)");
        }

        static void TestGeneralView(DataTable table, AuditSystem audit)
        {
            Console.WriteLine("\n--- General View ---");
            audit.LogAccess("General User", "VIEW", "Только имя и отдел");

            // Создаем ограниченное представление
            DataView dv = new DataView(table, "Status = 'Active'", "Department, Name", DataViewRowState.CurrentRows);

            // Ограничиваем видимые колонки
            Console.WriteLine("Доступные колонки: Name, Department");
            Console.WriteLine("Всего активных сотрудников: " + dv.Count);

            Console.WriteLine("\nПервые 5 сотрудников:");
            for (int i = 0; i < Math.Min(5, dv.Count); i++)
            {
                Console.WriteLine($"  {dv[i]["Name"]} - {dv[i]["Department"]}");
            }
        }

        static void ExportDataForRole(string role, DataTable table, AuditSystem audit)
        {
            Console.WriteLine($"\nЭкспорт данных для {role}...");
            audit.LogAccess(role, "EXPORT", "Экспорт в CSV");

            DataView dv;
            switch (role)
            {
                case "HR Manager":
                    dv = new DataView(table, "Status = 'Active'", "Salary DESC", DataViewRowState.CurrentRows);
                    break;
                case "Department Head":
                    dv = new DataView(table, "Department = 'IT'", "", DataViewRowState.CurrentRows);
                    break;
                default:
                    dv = new DataView(table);
                    break;
            }

            // Экспорт в CSV
            try
            {
                string filename = $"export_{role.Replace(" ", "_")}_{DateTime.Now:yyyyMMdd}.csv";
                using (var writer = new System.IO.StreamWriter(filename))
                {
                    // Заголовок
                    writer.WriteLine("EmployeeID;Name;Department;Salary;HireDate;Status");

                    // Данные
                    foreach (DataRowView row in dv)
                    {
                        writer.WriteLine($"{row["EmployeeID"]};{row["Name"]};{row["Department"]};{row["Salary"]};{row["HireDate"]:yyyy-MM-dd};{row["Status"]}");
                    }
                }
                Console.WriteLine($"Данные экспортированы в {filename}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка экспорта: {ex.Message}");
            }
        }
        #endregion


        #region ЗАДАНИЕ 30: Комплексное приложение "Управление проектами"
        static void Task30()
        {
            Console.Clear();
            Console.WriteLine("=== ЗАДАНИЕ 30: Комплексное приложение 'Управление проектами' ===\n");

            // Создаем все таблицы
            DataTable projectsTable = CreateProjectsTable();
            DataTable tasksTable = CreateTasksTable();
            DataTable resourcesTable = CreateResourcesTable();
            DataTable workLogsTable = CreateWorkLogsTable();

            // Заполняем данными
            FillProjectsTable(projectsTable, 20);
            FillTasksTable(tasksTable, projectsTable, 100);
            FillResourcesTable(resourcesTable, projectsTable, 30);
            FillWorkLogsTable(workLogsTable, tasksTable, resourcesTable, 500);

            // Создаем менеджер проектов
            ProjectManager manager = new ProjectManager(projectsTable, tasksTable, resourcesTable, workLogsTable);

            // Тестируем функционал
            Console.WriteLine("--- Общая статистика ---");
            Console.WriteLine($"Проектов: {projectsTable.Rows.Count}");
            Console.WriteLine($"Задач: {tasksTable.Rows.Count}");
            Console.WriteLine($"Ресурсов: {resourcesTable.Rows.Count}");
            Console.WriteLine($"Логов работы: {workLogsTable.Rows.Count}");

            // 1. Текущие проекты
            Console.WriteLine("\n--- Текущие проекты ---");
            DataView currentProjects = manager.GetCurrentProjects();
            DisplayDataView(currentProjects, 5);

            // 2. Задачи по приоритету
            Console.WriteLine("\n--- Задачи по приоритету (High) ---");
            DataView highPriorityTasks = manager.GetTasksByPriority("High");
            DisplayDataView(highPriorityTasks, 5);

            // 3. Задачи по сотруднику
            Console.WriteLine("\n--- Задачи по сотруднику ---");
            if (resourcesTable.Rows.Count > 0)
            {
                int employeeId = (int)resourcesTable.Rows[0]["ResourceID"];
                DataView employeeTasks = manager.GetTasksByEmployee(employeeId);
                DisplayDataView(employeeTasks, 5);
            }

            // 4. Перегруженные сотрудники
            Console.WriteLine("\n--- Перегруженные сотрудники (>40 часов/неделю) ---");
            DataView overloadedEmployees = manager.GetOverloadedEmployees(40);
            DisplayDataView(overloadedEmployees, 5);

            // 5. Расчет затрат проекта
            Console.WriteLine("\n--- Расчет затрат проекта ---");
            if (projectsTable.Rows.Count > 0)
            {
                int projectId = (int)projectsTable.Rows[0]["ProjectID"];
                decimal projectCost = manager.CalculateProjectCost(projectId);
                Console.WriteLine($"Затраты проекта ID={projectId}: {projectCost:C}");
            }

            // 6. Поиск и фильтрация
            Console.WriteLine("\n--- Поиск проектов по статусу 'Active' ---");
            DataView activeProjects = manager.SearchProjects("Status = 'Active'");
            DisplayDataView(activeProjects, 5);

            // 7. Добавление нового проекта
            Console.WriteLine("\n--- Добавление нового проекта ---");
            try
            {
                manager.AddProject("Новый проект", DateTime.Now, DateTime.Now.AddMonths(6), "Новый менеджер", 100000);
                Console.WriteLine("Проект успешно добавлен");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка добавления: {ex.Message}");
            }

            // 8. Отчеты
            Console.WriteLine("\n--- Генерация отчетов ---");
            GenerateProjectReports(manager);

            // 9. Валидация данных
            Console.WriteLine("\n--- Тест валидации данных ---");
            TestDataValidation(manager);

            // 10. Экспорт данных
            Console.WriteLine("\n--- Экспорт данных ---");
            ExportProjectData(manager);
        }

        static DataTable CreateProjectsTable()
        {
            DataTable table = new DataTable("Проекты");
            table.Columns.Add("ProjectID", typeof(int));
            table.Columns.Add("ProjectName", typeof(string));
            table.Columns.Add("Status", typeof(string));
            table.Columns.Add("StartDate", typeof(DateTime));
            table.Columns.Add("EndDate", typeof(DateTime));
            table.Columns.Add("Manager", typeof(string));
            table.Columns.Add("Budget", typeof(decimal));
            table.PrimaryKey = new DataColumn[] { table.Columns["ProjectID"] };
            return table;
        }

        static DataTable CreateTasksTable()
        {
            DataTable table = new DataTable("Задачи");
            table.Columns.Add("TaskID", typeof(int));
            table.Columns.Add("ProjectID", typeof(int));
            table.Columns.Add("TaskName", typeof(string));
            table.Columns.Add("AssignedTo", typeof(int)); // ResourceID
            table.Columns.Add("Status", typeof(string));
            table.Columns.Add("Priority", typeof(string));
            table.Columns.Add("DueDate", typeof(DateTime));
            table.Columns.Add("EstimatedHours", typeof(decimal));
            table.PrimaryKey = new DataColumn[] { table.Columns["TaskID"] };
            return table;
        }

        static DataTable CreateResourcesTable()
        {
            DataTable table = new DataTable("Ресурсы");
            table.Columns.Add("ResourceID", typeof(int));
            table.Columns.Add("ResourceName", typeof(string));
            table.Columns.Add("Type", typeof(string)); // Employee, Contractor, Equipment
            table.Columns.Add("ProjectID", typeof(int));
            table.Columns.Add("HourlyRate", typeof(decimal));
            table.Columns.Add("WeeklyHours", typeof(decimal));
            table.PrimaryKey = new DataColumn[] { table.Columns["ResourceID"] };
            return table;
        }

        static DataTable CreateWorkLogsTable()
        {
            DataTable table = new DataTable("ЛогиРаботы");
            table.Columns.Add("LogID", typeof(int));
            table.Columns.Add("TaskID", typeof(int));
            table.Columns.Add("ResourceID", typeof(int));
            table.Columns.Add("Hours", typeof(decimal));
            table.Columns.Add("Date", typeof(DateTime));
            table.Columns.Add("Notes", typeof(string));
            table.PrimaryKey = new DataColumn[] { table.Columns["LogID"] };
            return table;
        }

        static void FillProjectsTable(DataTable table, int count)
        {
            string[] statuses = { "Active", "On Hold", "Completed", "Cancelled" };
            string[] managers = { "Иванов И.И.", "Петров П.П.", "Сидоров С.С.", "Кузнецов К.К." };
            Random rand = new Random();

            for (int i = 1; i <= count; i++)
            {
                DateTime startDate = DateTime.Now.AddDays(-rand.Next(0, 365));
                table.Rows.Add(
                    i,
                    $"Проект {i}",
                    statuses[rand.Next(statuses.Length)],
                    startDate,
                    startDate.AddDays(rand.Next(30, 365)),
                    managers[rand.Next(managers.Length)],
                    rand.Next(50000, 500000)
                );
            }
        }

        static void FillTasksTable(DataTable table, DataTable projectsTable, int count)
        {
            string[] statuses = { "Not Started", "In Progress", "Completed", "Blocked" };
            string[] priorities = { "Low", "Medium", "High", "Critical" };
            Random rand = new Random();

            for (int i = 1; i <= count; i++)
            {
                DataRow project = projectsTable.Rows[rand.Next(projectsTable.Rows.Count)];
                table.Rows.Add(
                    i,
                    project["ProjectID"],
                    $"Задача {i} для проекта {project["ProjectName"]}",
                    rand.Next(1, 31), // ResourceID
                    statuses[rand.Next(statuses.Length)],
                    priorities[rand.Next(priorities.Length)],
                    DateTime.Now.AddDays(rand.Next(1, 180)),
                    rand.Next(1, 100)
                );
            }
        }

        static void FillResourcesTable(DataTable table, DataTable projectsTable, int count)
        {
            string[] types = { "Employee", "Contractor", "Equipment" };
            string[] names = { "Иванов", "Петров", "Сидоров", "Смирнов", "Кузнецов", "Попов", "Васильев", "Павлов" };
            Random rand = new Random();

            for (int i = 1; i <= count; i++)
            {
                DataRow project = projectsTable.Rows[rand.Next(projectsTable.Rows.Count)];
                table.Rows.Add(
                    i,
                    $"{names[rand.Next(names.Length)]} {names[rand.Next(names.Length)]}",
                    types[rand.Next(types.Length)],
                    project["ProjectID"],
                    rand.Next(500, 5000),
                    rand.Next(20, 50)
                );
            }
        }

        static void FillWorkLogsTable(DataTable table, DataTable tasksTable, DataTable resourcesTable, int count)
        {
            Random rand = new Random();

            for (int i = 1; i <= count; i++)
            {
                DataRow task = tasksTable.Rows[rand.Next(tasksTable.Rows.Count)];
                DataRow resource = resourcesTable.Rows[rand.Next(resourcesTable.Rows.Count)];
                table.Rows.Add(
                    i,
                    task["TaskID"],
                    resource["ResourceID"],
                    rand.Next(1, 10),
                    DateTime.Now.AddDays(-rand.Next(0, 90)),
                    $"Работа по задаче {task["TaskName"]}"
                );
            }
        }

        class ProjectManager
        {
            private DataTable _projects;
            private DataTable _tasks;
            private DataTable _resources;
            private DataTable _workLogs;
            private List<string> _activityLog = new List<string>();

            public ProjectManager(DataTable projects, DataTable tasks, DataTable resources, DataTable workLogs)
            {
                _projects = projects;
                _tasks = tasks;
                _resources = resources;
                _workLogs = workLogs;

                // Настройка событий для логирования
                _projects.RowChanged += (s, e) => LogActivity($"Изменен проект: {e.Row["ProjectName"]}");
                _tasks.RowChanged += (s, e) => LogActivity($"Изменена задача: {e.Row["TaskName"]}");
            }

            public DataView GetCurrentProjects()
            {
                return new DataView(_projects, "Status = 'Active'", "StartDate DESC", DataViewRowState.CurrentRows);
            }

            public DataView GetTasksByPriority(string priority)
            {
                return new DataView(_tasks, $"Priority = '{priority}'", "DueDate ASC", DataViewRowState.CurrentRows);
            }

            public DataView GetTasksByEmployee(int employeeId)
            {
                return new DataView(_tasks, $"AssignedTo = {employeeId}", "Priority DESC, DueDate ASC", DataViewRowState.CurrentRows);
            }

            public DataView GetOverloadedEmployees(decimal maxWeeklyHours)
            {
                // Вычисляем общее количество часов по логам за последнюю неделю
                var weekAgo = DateTime.Now.AddDays(-7);
                var recentLogs = new DataView(_workLogs, $"Date >= #{weekAgo:yyyy-MM-dd}#", "", DataViewRowState.CurrentRows);

                var hoursByResource = new Dictionary<int, decimal>();
                foreach (DataRowView log in recentLogs)
                {
                    int resourceId = (int)log["ResourceID"];
                    decimal hours = (decimal)log["Hours"];
                    if (hoursByResource.ContainsKey(resourceId))
                        hoursByResource[resourceId] += hours;
                    else
                        hoursByResource[resourceId] = hours;
                }

                // Фильтруем ресурсы с перегрузкой
                DataView resourcesView = new DataView(_resources);
                resourcesView.RowFilter = $"Type = 'Employee'";
                
                var overloadedRows = resourcesView.Cast<DataRowView>()
                    .Where(r => hoursByResource.ContainsKey((int)r["ResourceID"]) && 
                           hoursByResource[(int)r["ResourceID"]] > maxWeeklyHours)
                    .Select(r => r.Row)
                    .ToArray();

                DataTable result = _resources.Clone();
                foreach (DataRow row in overloadedRows)
                {
                    result.ImportRow(row);
                    result.Rows[result.Rows.Count - 1]["WeeklyHours"] = hoursByResource[(int)row["ResourceID"]];
                }

                return new DataView(result, "", "WeeklyHours DESC", DataViewRowState.CurrentRows);
            }

            public decimal CalculateProjectCost(int projectId)
            {
                // Получаем все задачи проекта
                DataView projectTasks = new DataView(_tasks, $"ProjectID = {projectId}", "", DataViewRowState.CurrentRows);
                
                // Получаем все ресурсы проекта
                DataView projectResources = new DataView(_resources, $"ProjectID = {projectId}", "", DataViewRowState.CurrentRows);

                decimal totalCost = 0;

                // Рассчитываем стоимость по логам работы
                foreach (DataRowView task in projectTasks)
                {
                    int taskId = (int)task["TaskID"];
                    DataView taskLogs = new DataView(_workLogs, $"TaskID = {taskId}", "", DataViewRowState.CurrentRows);
                    
                    foreach (DataRowView log in taskLogs)
                    {
                        int resourceId = (int)log["ResourceID"];
                        decimal hours = (decimal)log["Hours"];
                        
                        // Находим ставку ресурса
                        DataRow[] resourceRows = _resources.Select($"ResourceID = {resourceId}");
                        if (resourceRows.Length > 0)
                        {
                            decimal hourlyRate = (decimal)resourceRows[0]["HourlyRate"];
                            totalCost += hours * hourlyRate;
                        }
                    }
                }

                return totalCost;
            }

            public DataView SearchProjects(string filter)
            {
                try
                {
                    return new DataView(_projects, filter, "ProjectName ASC", DataViewRowState.CurrentRows);
                }
                catch (Exception ex)
                {
                    LogActivity($"Ошибка поиска: {ex.Message}");
                    return new DataView(_projects) { RowFilter = "1=0" };
                }
            }

            public void AddProject(string name, DateTime startDate, DateTime endDate, string manager, decimal budget)
            {
                // Валидация
                if (string.IsNullOrEmpty(name))
                    throw new ArgumentException("Название проекта обязательно");
                if (endDate <= startDate)
                    throw new ArgumentException("Дата окончания должна быть позже даты начала");
                if (budget <= 0)
                    throw new ArgumentException("Бюджет должен быть положительным");

                DataRow newRow = _projects.NewRow();
                newRow["ProjectID"] = _projects.Rows.Count + 1;
                newRow["ProjectName"] = name;
                newRow["Status"] = "Active";
                newRow["StartDate"] = startDate;
                newRow["EndDate"] = endDate;
                newRow["Manager"] = manager;
                newRow["Budget"] = budget;

                _projects.Rows.Add(newRow);
                LogActivity($"Добавлен новый проект: {name}");
            }

            public List<string> GetActivityLog()
            {
                return _activityLog;
            }

            private void LogActivity(string message)
            {
                _activityLog.Add($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}");
            }
        }

        static void DisplayDataView(DataView dv, int maxRows)
        {
            Console.WriteLine($"Найдено записей: {dv.Count}");

            if (dv.Count > 0 && dv.Table.Columns.Count > 0)
            {
                Console.WriteLine("Первые записи:");
                for (int i = 0; i < Math.Min(maxRows, dv.Count); i++)
                {
                    var row = dv[i];
                    string display = "";
                    for (int j = 0; j < Math.Min(3, dv.Table.Columns.Count); j++)
                    {
                        display += $"{dv.Table.Columns[j].ColumnName}: {row[j]}  ";
                    }
                    Console.WriteLine($"  {display}");
                }
            }
        }

        static void GenerateProjectReports(ProjectManager manager)
        {
            Console.WriteLine("1. Отчет о статусе проектов:");
            DataView projectsByStatus = new DataView(manager.GetCurrentProjects().Table);
            projectsByStatus.RowFilter = "";
            projectsByStatus.Sort = "Status, StartDate";
            
            var statusGroups = projectsByStatus.Cast<DataRowView>()
                .GroupBy(r => r["Status"].ToString())
                .Select(g => new { Status = g.Key, Count = g.Count(), TotalBudget = g.Sum(r => (decimal)r["Budget"]) });
            
            foreach (var group in statusGroups)
            {
                Console.WriteLine($"  {group.Status}: {group.Count} проектов, бюджет: {group.TotalBudget:C}");
            }

            Console.WriteLine("\n2. Отчет об использовании ресурсов:");
            // Логика отчета об использовании ресурсов
            Console.WriteLine("  (Отчет сгенерирован)");
        }

        static void TestDataValidation(ProjectManager manager)
        {
            Console.WriteLine("Тест 1: Добавление проекта с некорректной датой...");
            try
            {
                manager.AddProject("Тестовый проект", DateTime.Now, DateTime.Now.AddDays(-1), "Тест", 10000);
                Console.WriteLine("  ОШИБКА: Должна была быть исключение!");
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"  ОК: Поймано исключение: {ex.Message}");
            }

            Console.WriteLine("\nТест 2: Добавление проекта с нулевым бюджетом...");
            try
            {
                manager.AddProject("Тестовый проект 2", DateTime.Now, DateTime.Now.AddDays(30), "Тест", 0);
                Console.WriteLine("  ОШИБКА: Должна была быть исключение!");
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"  ОК: Поймано исключение: {ex.Message}");
            }
        }

        static void ExportProjectData(ProjectManager manager)
        {
            Console.WriteLine("Экспорт данных в различные форматы...");

            try
            {
                // Экспорт проектов в CSV
                DataView projects = manager.GetCurrentProjects();
                ExportToCSV(projects, "projects_export.csv");
                Console.WriteLine("  Проекты экспортированы в projects_export.csv");

                // Экспорт активности в лог
                var activityLog = manager.GetActivityLog();
                System.IO.File.WriteAllLines("activity_log.txt", activityLog);
                Console.WriteLine("  Лог активности экспортирован в activity_log.txt");

                // Экспорт в XML
                DataSet ds = new DataSet("ProjectData");
                ds.Tables.Add(projects.Table.Copy());
                ds.WriteXml("projects_data.xml");
                Console.WriteLine("  Данные экспортированы в projects_data.xml");

            }
            catch (Exception ex)
            {
                Console.WriteLine($"  Ошибка экспорта: {ex.Message}");
            }
        }

        static void ExportToCSV(DataView dv, string filename)
        {
            using (var writer = new System.IO.StreamWriter(filename))
            {
                // Заголовок
                for (int i = 0; i < dv.Table.Columns.Count; i++)
                {
                    writer.Write(dv.Table.Columns[i].ColumnName);
                    if (i < dv.Table.Columns.Count - 1) writer.Write(";");
                }
                writer.WriteLine();

                // Данные
                foreach (DataRowView row in dv)
                {
                    for (int i = 0; i < dv.Table.Columns.Count; i++)
                    {
                        writer.Write(row[i].ToString());
                        if (i < dv.Table.Columns.Count - 1) writer.Write(";");
                    }
                    writer.WriteLine();
                }
            }
        }
        #endregion


        #endregion
    }
}