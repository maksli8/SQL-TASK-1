﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variant8_CS
{
    // ==================== Задача 8.1 ====================
    class Fibonacci
    {
        private static Dictionary<int, long> memo = new Dictionary<int, long>();

        // Итеративный метод (оптимальный по времени O(n), памяти O(1))
        public static long Iterative(int n)
        {
            if (n <= 1) return n;

            long a = 0, b = 1, c;
            for (int i = 2; i <= n; i++)
            {
                c = a + b;
                a = b;
                b = c;
            }
            return b;
        }

        // Рекурсивный метод с мемоизацией (оптимальный по времени O(n))
        public static long RecursiveMemo(int n)
        {
            if (n <= 1) return n;

            if (memo.ContainsKey(n))
            {
                return memo[n];
            }

            memo[n] = RecursiveMemo(n - 1) + RecursiveMemo(n - 2);
            return memo[n];
        }

        // Обычный рекурсивный метод (неоптимальный, для сравнения)
        public static long Recursive(int n)
        {
            if (n <= 1) return n;
            return Recursive(n - 1) + Recursive(n - 2);
        }
    }

    // ==================== Задача 8.2 ====================
    class BracketChecker
    {
        public static bool IsBalanced(string expression)
        {
            Stack<char> stack = new Stack<char>();

            foreach (char c in expression)
            {
                if (IsOpenBracket(c))
                {
                    stack.Push(c);
                }
                else if (IsCloseBracket(c))
                {
                    if (stack.Count == 0 || !IsMatchingPair(stack.Peek(), c))
                    {
                        return false;
                    }
                    stack.Pop();
                }
            }

            return stack.Count == 0;
        }

        private static bool IsOpenBracket(char c)
        {
            return c == '(' || c == '[' || c == '{';
        }

        private static bool IsCloseBracket(char c)
        {
            return c == ')' || c == ']' || c == '}';
        }

        private static bool IsMatchingPair(char open, char close)
        {
            return (open == '(' && close == ')') ||
                   (open == '[' && close == ']') ||
                   (open == '{' && close == '}');
        }
    }

    // ==================== Задача 8.3 ====================
    class Circle
    {
        private double x;      // Координата X центра
        private double y;      // Координата Y центра
        private double radius;

        public double X => x;
        public double Y => y;
        public double Radius => radius;

        public Circle(double centerX = 0, double centerY = 0, double r = 1)
        {
            if (r <= 0)
            {
                throw new ArgumentException("Радиус должен быть положительным числом");
            }

            x = centerX;
            y = centerY;
            radius = r;
        }

        // Площадь круга
        public double GetArea()
        {
            return Math.PI * radius * radius;
        }

        // Длина окружности
        public double GetCircumference()
        {
            return 2 * Math.PI * radius;
        }

        // Определение положения точки относительно окружности
        // Возвращает: -1 - внутри, 0 - на окружности, 1 - снаружи
        public int PointPosition(double px, double py)
        {
            double distanceSquared = (px - x) * (px - x) + (py - y) * (py - y);
            double radiusSquared = radius * radius;

            const double epsilon = 1e-9; // Для учёта погрешностей

            if (Math.Abs(distanceSquared - radiusSquared) < epsilon)
            {
                return 0; // На окружности
            }
            else if (distanceSquared < radiusSquared)
            {
                return -1; // Внутри
            }
            else
            {
                return 1; // Снаружи
            }
        }

        // Дополнительный метод: расстояние между центрами двух окружностей
        public double DistanceTo(Circle other)
        {
            return Math.Sqrt((x - other.x) * (x - other.x) +
                            (y - other.y) * (y - other.y));
        }

        // Дополнительный метод: проверка пересечения с другой окружностью
        public bool IntersectsWith(Circle other)
        {
            double distance = DistanceTo(other);
            return distance <= radius + other.radius &&
                   distance >= Math.Abs(radius - other.radius);
        }
    }

    // ==================== Задача 8.4 ====================
    class ArrayRotator
    {
        // Поворот массива на k позиций вправо
        public static void Rotate(int[] arr, int k)
        {
            if (arr == null || arr.Length == 0) return;

            int n = arr.Length;
            k = k % n; // Если k > n

            if (k == 0) return;

            // Реверс всего массива
            Reverse(arr, 0, n - 1);
            // Реверс первых k элементов
            Reverse(arr, 0, k - 1);
            // Реверс оставшихся элементов
            Reverse(arr, k, n - 1);
        }

        // Поворот с использованием List для удобства
        public static List<int> RotateList(List<int> list, int k)
        {
            if (list == null || list.Count == 0) return list;

            int n = list.Count;
            k = k % n;

            if (k == 0) return list;

            List<int> result = new List<int>();

            // Добавляем элементы от индекса n-k до конца
            result.AddRange(list.GetRange(n - k, k));
            // Добавляем элементы от начала до n-k
            result.AddRange(list.GetRange(0, n - k));

            return result;
        }

        private static void Reverse(int[] arr, int start, int end)
        {
            while (start < end)
            {
                int temp = arr[start];
                arr[start] = arr[end];
                arr[end] = temp;
                start++;
                end--;
            }
        }
    }

    // ==================== Задача 8.5 ====================
    class TextIndexer
    {
        private Dictionary<string, HashSet<int>> wordIndex = new Dictionary<string, HashSet<int>>();

        // Очистка слова от знаков препинания и приведение к нижнему регистру
        private string CleanWord(string word)
        {
            StringBuilder result = new StringBuilder();
            foreach (char c in word)
            {
                if (char.IsLetter(c) || c == '-')
                {
                    result.Append(char.ToLower(c));
                }
            }
            return result.ToString();
        }

        // Создание индекса из файла
        public void CreateIndex(string filename)
        {
            wordIndex.Clear();

            try
            {
                string[] lines = File.ReadAllLines(filename);

                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i];
                    string[] words = line.Split(new char[] { ' ', '\t', ',', '.', '!', '?', ';', ':', '"', '(', ')', '[', ']', '{', '}' },
                                                StringSplitOptions.RemoveEmptyEntries);

                    foreach (string word in words)
                    {
                        string cleaned = CleanWord(word);
                        if (!string.IsNullOrEmpty(cleaned))
                        {
                            if (!wordIndex.ContainsKey(cleaned))
                            {
                                wordIndex[cleaned] = new HashSet<int>();
                            }
                            wordIndex[cleaned].Add(i + 1); // +1 потому что строки обычно нумеруются с 1
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new IOException($"Не удалось открыть файл: {filename}. Ошибка: {ex.Message}");
            }
        }

        // Вывод индекса
        public void PrintIndex()
        {
            foreach (var entry in wordIndex.OrderBy(e => e.Key))
            {
                Console.Write($"{entry.Key}: ");
                Console.WriteLine(string.Join(", ", entry.Value.OrderBy(v => v)));
            }
        }

        // Получение индекса
        public Dictionary<string, HashSet<int>> GetIndex()
        {
            return wordIndex;
        }

        // Поиск слова в индексе
        public HashSet<int> FindWord(string word)
        {
            string cleaned = CleanWord(word);
            if (wordIndex.ContainsKey(cleaned))
            {
                return wordIndex[cleaned];
            }
            return new HashSet<int>();
        }

        // Сохранение индекса в файл
        public void SaveIndexToFile(string filename)
        {
            using (StreamWriter writer = new StreamWriter(filename))
            {
                foreach (var entry in wordIndex.OrderBy(e => e.Key))
                {
                    writer.Write($"{entry.Key}: ");
                    writer.WriteLine(string.Join(", ", entry.Value.OrderBy(v => v)));
                }
            }
        }
    }

    // ==================== Главная программа ====================
    class Program
    {
        static void DemoTask8_1()
        {
            Console.WriteLine("=== Задача 8.1: Числа Фибоначчи ===");

            int n = 10;
            Console.WriteLine($"Число Фибоначчи для n={n}:");
            Console.WriteLine($"Итеративный метод: {Fibonacci.Iterative(n)}");
            Console.WriteLine($"Рекурсивный с мемоизацией: {Fibonacci.RecursiveMemo(n)}");

            // Для больших значений покажем только итеративный
            n = 45;
            Console.WriteLine($"\nДля n={n}:");
            Console.WriteLine($"Итеративный метод: {Fibonacci.Iterative(n)}");
            Console.WriteLine($"Рекурсивный с мемоизацией: {Fibonacci.RecursiveMemo(n)}");

            // Тест производительности
            Console.WriteLine("\nСравнение производительности для n=40:");
            var watch = System.Diagnostics.Stopwatch.StartNew();
            long result1 = Fibonacci.Iterative(40);
            watch.Stop();
            Console.WriteLine($"Итеративный: {result1}, время: {watch.ElapsedTicks} тиков");

            Fibonacci.RecursiveMemo(40); // Сбросим кеш
            watch.Restart();
            long result2 = Fibonacci.RecursiveMemo(40);
            watch.Stop();
            Console.WriteLine($"Рекурсивный с мемоизацией: {result2}, время: {watch.ElapsedTicks} тиков");

            Console.WriteLine();
        }

        static void DemoTask8_2()
        {
            Console.WriteLine("=== Задача 8.2: Проверка скобок ===");

            string[] tests = {
                "{(a + b) * [c - d]}",
                "({[]})",
                "([)]",
                "{[(])}",
                "((()))",
                "{[()]}",
                "no brackets",
                "({)}",
                "",
                "function test() { return [1, 2, 3]; }"
            };

            foreach (string test in tests)
            {
                bool balanced = BracketChecker.IsBalanced(test);
                Console.WriteLine($"Выражение: \"{test}\" - {(balanced ? "сбалансировано" : "несбалансировано")}");
            }

            Console.WriteLine();
        }

        static void DemoTask8_3()
        {
            Console.WriteLine("=== Задача 8.3: Класс Circle ===");

            try
            {
                Circle circle = new Circle(0, 0, 5);

                Console.WriteLine($"Окружность с центром ({circle.X}, {circle.Y}) и радиусом {circle.Radius}:");
                Console.WriteLine($"Площадь: {circle.GetArea():F2}");
                Console.WriteLine($"Длина окружности: {circle.GetCircumference():F2}");

                // Тестируем положение точек
                var points = new List<Tuple<double, double, string>>
                {
                    Tuple.Create(0.0, 0.0, "Центр"),
                    Tuple.Create(5.0, 0.0, "На оси X"),
                    Tuple.Create(6.0, 0.0, "За пределами по X"),
                    Tuple.Create(3.0, 4.0, "Точка на окружности"),
                    Tuple.Create(2.0, 2.0, "Внутри"),
                    Tuple.Create(-3.0, -4.0, "Диаметрально противоположная")
                };

                foreach (var point in points)
                {
                    int position = circle.PointPosition(point.Item1, point.Item2);
                    string posStr = position switch
                    {
                        -1 => "внутри",
                        0 => "на окружности",
                        1 => "снаружи",
                        _ => "неопределено"
                    };
                    Console.WriteLine($"Точка ({point.Item1}, {point.Item2}) [{point.Item3}] находится {posStr} окружности");
                }

                // Тест пересечения с другой окружностью
                Circle circle2 = new Circle(8, 0, 4);
                Console.WriteLine($"\nВторая окружность: центр ({circle2.X}, {circle2.Y}), радиус {circle2.Radius}");
                Console.WriteLine($"Расстояние между центрами: {circle.DistanceTo(circle2):F2}");
                Console.WriteLine($"Окружности пересекаются: {(circle.IntersectsWith(circle2) ? "Да" : "Нет")}");

                // Проверка исключения
                // Circle invalid = new Circle(0, 0, -1); // Раскомментировать для теста исключения

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }

            Console.WriteLine();
        }

        static void DemoTask8_4()
        {
            Console.WriteLine("=== Задача 8.4: Поворот массива ===");

            // Пример 1: массив чисел
            int[] arr = { 1, 2, 3, 4, 5, 6, 7 };
            int k = 3;

            Console.WriteLine("Исходный массив: " + string.Join(", ", arr));
            ArrayRotator.Rotate(arr, k);
            Console.WriteLine($"После поворота на {k} позиций вправо: " + string.Join(", ", arr));

            // Пример 2: List с отрицательным k (поворот влево)
            List<int> list = new List<int> { 1, 2, 3, 4, 5 };
            k = -2; // Эквивалентно повороту на 3 вправо

            Console.WriteLine("\nИсходный список: " + string.Join(", ", list));
            List<int> rotatedList = ArrayRotator.RotateList(list, k);
            Console.WriteLine($"После поворота на {k} позиций: " + string.Join(", ", rotatedList));

            // Пример 3: поворот на большее количество, чем размер массива
            int[] arr2 = { 10, 20, 30, 40, 50 };
            k = 7; // 7 % 5 = 2

            Console.WriteLine("\nИсходный массив: " + string.Join(", ", arr2));
            ArrayRotator.Rotate(arr2, k);
            Console.WriteLine($"После поворота на {k} позиций (7 % 5 = 2): " + string.Join(", ", arr2));

            Console.WriteLine();
        }

        static void DemoTask8_5()
        {
            Console.WriteLine("=== Задача 8.5: Индекс слов ===");

            // Создаем тестовый файл
            string filename = "test_text.txt";
            string[] lines = {
                "Hello world! This is a test file.",
                "World is beautiful and amazing.",
                "Hello again! Test, test, test...",
                "The quick brown fox jumps over the lazy dog.",
                "This is the final test line.",
                "Programming in C# is fun and challenging.",
                "C# is a modern object-oriented language.",
                "Test: one, two, three test!"
            };

            File.WriteAllLines(filename, lines);
            Console.WriteLine($"Создан тестовый файл: {filename}");

            // Создаем индекс
            TextIndexer indexer = new TextIndexer();
            try
            {
                indexer.CreateIndex(filename);

                Console.WriteLine("\nИндекс слов (первые 15 слов):");
                var index = indexer.GetIndex();
                int count = 0;
                foreach (var entry in index.OrderBy(e => e.Key))
                {
                    if (count++ >= 15) break;
                    Console.WriteLine($"  {entry.Key}: {string.Join(", ", entry.Value.OrderBy(v => v))}");
                }

                Console.WriteLine($"\nВсего уникальных слов: {index.Count}");

                // Поиск конкретных слов
                Console.WriteLine("\nПоиск слов:");
                string[] searchWords = { "hello", "test", "world", "fox", "c#", "nonexistent", "programming" };

                foreach (string word in searchWords)
                {
                    HashSet<int> linesFound = indexer.FindWord(word);
                    if (linesFound.Count > 0)
                    {
                        Console.WriteLine($"  Слово '{word}' найдено в строках: {string.Join(", ", linesFound.OrderBy(v => v))}");
                    }
                    else
                    {
                        Console.WriteLine($"  Слово '{word}' не найдено");
                    }
                }

                // Сохраняем полный индекс в файл
                string indexFile = "word_index.txt";
                indexer.SaveIndexToFile(indexFile);
                Console.WriteLine($"\nПолный индекс сохранен в файл: {indexFile}");

                // Статистика
                Console.WriteLine("\nСтатистика:");
                var wordsByFrequency = index.OrderByDescending(e => e.Value.Count).Take(5);
                foreach (var entry in wordsByFrequency)
                {
                    Console.WriteLine($"  '{entry.Key}' встречается в {entry.Value.Count} строках");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }

            Console.WriteLine();
        }

        static void ShowMenu()
        {
            Console.Clear();
            Console.WriteLine("========================================");
            Console.WriteLine("          ВАРИАНТ 8 - Задачи на C#");
            Console.WriteLine("========================================");
            Console.WriteLine("1. Задача 8.1 - Числа Фибоначчи");
            Console.WriteLine("2. Задача 8.2 - Проверка скобок");
            Console.WriteLine("3. Задача 8.3 - Класс Circle");
            Console.WriteLine("4. Задача 8.4 - Поворот массива");
            Console.WriteLine("5. Задача 8.5 - Индекс слов");
            Console.WriteLine("6. Все задачи");
            Console.WriteLine("0. Выход");
            Console.WriteLine("========================================");
            Console.Write("Выберите задачу: ");
        }

        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            bool running = true;

            while (running)
            {
                ShowMenu();
                string input = Console.ReadLine();

                if (int.TryParse(input, out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            DemoTask8_1();
                            break;
                        case 2:
                            DemoTask8_2();
                            break;
                        case 3:
                            DemoTask8_3();
                            break;
                        case 4:
                            DemoTask8_4();
                            break;
                        case 5:
                            DemoTask8_5();
                            break;
                        case 6:
                            DemoTask8_1();
                            DemoTask8_2();
                            DemoTask8_3();
                            DemoTask8_4();
                            DemoTask8_5();
                            break;
                        case 0:
                            running = false;
                            Console.WriteLine("Выход из программы.");
                            break;
                        default:
                            Console.WriteLine("Неверный выбор. Попробуйте снова.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Неверный ввод. Введите число.");
                }

                if (running && choice != 0)
                {
                    Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                    Console.ReadKey();
                }
            }
        }
    }
}