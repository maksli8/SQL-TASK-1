﻿// 1
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - e");
//double e = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - l");
//double l = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - c");
//double c = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"L = {Math.Sqrt(Math.Exp(x) - Math.Pow(Math.Cos(Math.Pow(x, 2) * Math.Pow(a, 5)), 4) + Math.Pow(Math.Atan(a - Math.Pow(x, 5)), 4)) / (e * l * Math.Sqrt(Math.Abs(a + x * Math.Pow(c, 4))))}");

// 2
//Console.WriteLine("Введите значение переменной - c");
//double c = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - t");
//double t = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"L = {Math.Pow(1.0/Math.Tan(c), 2) + (2 * Math.Pow(x, 2) + 5) / Math.Sqrt(c + t)}");

// 3
//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - h");
//double h = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"A = {Math.Tan(Math.Pow(y, 3) - Math.Pow(h, 4)) + Math.Pow(h, 2)} / {Math.Pow(Math.Sin(h), 3) + y}");

// 4
//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"F = {Math.Sqrt(Math.Pow(2 + y, 2) + Math.Sqrt(Math.Sin(y + 5))) / (Math.Log(x + 1) - Math.Pow(y, 3))}");

// 5
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - z");
//double z = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - c");
//double c = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"G = {(Math.Tan(Math.Pow(x, 4) - 6) - Math.Pow(Math.Cos(z + x * y), 3)) / (Math.Pow(Math.Cos(x), 4) * Math.Pow(x, 3) * Math.Pow(c, 2))}");

// 6
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - b");
//double b = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"K = {Math.Sqrt(x + b - a + Math.Log(y)) / Math.Atan(b + a)}");

// 7
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"D = {(Math.Cos(Math.Pow(x, 3) + 6) - Math.Sin(y - a)) / (Math.Log(Math.Pow(x, 4)) - 2 * Math.Pow(Math.Sin(x), 5))}");

// 8
//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - c");
//double c = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"P = {(Math.Pow(a, 3) + Math.Pow(Math.Sin(y - c), 4)) / (Math.Pow(Math.Sin(x + y), 3) + Math.Abs(x - y))}");

// 9
//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - d");
//double d = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"R = {(Math.Pow(Math.Cos(y), 3) + Math.Pow(2, d)) / (Math.Exp(y) + Math.Log(Math.Pow(Math.Sin(x), 2) + 7.4))}");

// 10
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"U = {(Math.Exp(x) + Math.Pow(Math.Cos(x - 4), 2)) / (Math.Atan(x) + 5.2 * y)}");

// 11
//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"I = {2.33 * Math.Log(Math.Sqrt(1 + Math.Pow(Math.Cos(y), 2))) / (Math.Exp(y) + Math.Pow(Math.Sin(x), 2))}");

// 12
//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"G = {(Math.Pow(Math.Cos(Math.Abs(y + x)), 3) - (x + y)) / (Math.Pow(Math.Atan(x + a), 4) * Math.Pow(x, 5))}");

// 13
//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - b");
//double b = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"R = {a / (x - a) + (Math.Pow(b, x) + Math.Pow(Math.Cos(x), 3)) / (Math.Pow(Math.Log(a), 3) + 4.5)}");

// 14
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"R = {(Math.Pow(Math.Sin(Math.Pow(x, 2) + 4), 3) + 4.3) / (Math.Pow(Math.Sin(x), 3) * Math.Pow(x, 4))}");

// 15
//Console.WriteLine("Введите значение переменной - m");
//double m = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"N = {(Math.Pow(m, 2) + 2.8 * m + 0.355) / (Math.Pow(Math.Cos(2 * y), 2) + 3.6)}");

// 16
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - t");
//double t = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - e");
//double e = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"P = {(Math.Pow(Math.Sin(x), 3) + Math.Log(2 * y + 3 * x)) / (Math.Pow(t, e) + Math.Sqrt(x))}");

// 17
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - b");
//double b = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"T = {Math.Sqrt(x + b - a + Math.Log(y)) / Math.Atan(b + a)}");

// 18
//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - t");
//double t = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"S = {(4.351 * Math.Pow(y, 3) + 2 * t * Math.Log(t)) / Math.Sqrt(Math.Cos(2 * y) + 4.351)}");

// 19
//Console.WriteLine("Введите значение переменной - K");
//double K = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - r");
//double r = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - b");
//double b = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"D = {Math.Pow(K, -a * r * x) - a * Math.Sqrt(6 - Math.Cos(3 * a * b))} / {Math.Pow(Math.Sin(a * Math.Asin(x) + Math.Log(y)), 2)}");

// 20
//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - b");
//double b = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - c");
//double c = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"U = {(Math.Pow(Math.Tan(y), 3) + Math.Pow(Math.Sin(x), 3) * Math.Sqrt(b - c)) / Math.Sqrt(a - b + c)}");

// 21
//Console.WriteLine("Введите значение переменной - z");
//double z = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"N = {Math.Cbrt(z + Math.Sqrt(2 * x)) / (Math.Exp(x) + Math.Pow(a, 5) * Math.Atan(x))}");

// 22
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"F = {Math.Cos(Math.Pow(x, 2) + 2) + (3.5 * Math.Pow(x, 2) + 1) / Math.Pow(Math.Cos(y), 2)}");

// 23
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - z");
//double z = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - b");
//double b = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"F = {Math.Sqrt(Math.Abs(x) + Math.Pow(Math.Cos(x), 3) + Math.Pow(z, 4)) / (Math.Log(x) - Math.Asin(b * x - a))}");

// 24
//Console.WriteLine("Введите значение переменной - b");
//double b = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - z");
//double z = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"f = {(Math.Pow(Math.Cos(b), 7) * Math.Pow(x, 5) - (Math.Sin(Math.Pow(a, 2)) + Math.Cos(Math.Pow(x, 3) + Math.Pow(z, 2) - Math.Pow(a, 2)))) / (Math.Asin(Math.Pow(a, 2)) + Math.Acos(Math.Pow(x, 7) - Math.Pow(a, 2)))}");

// 25
//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"J = {(Math.Pow(1.0/Math.Tan(a), 3) + Math.Pow(Math.Atan(a), 2)) / Math.Sqrt(Math.Pow(y, 5 * x))}");

// 26
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - k");
//double k = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"U = {(Math.Log(Math.Pow(x, 3) + y) - Math.Pow(y, 4)) / (Math.Exp(y) + 5.4 * Math.Pow(k, 3))}");

// 27
//Console.WriteLine("Введите значение переменной - a");
//double a = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - c");
//double c = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"P = {(Math.Pow(a, 3) + Math.Acos(a + Math.Pow(x, 3)) - Math.Pow(Math.Sin(y - c), 4)) / (Math.Pow(Math.Sin(x + y), 3) + Math.Abs(x - y))}");

// 28
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - z");
//double z = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - c");
//double c = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"G = {(Math.Tan(Math.Pow(x, 4) - 6) - Math.Pow(Math.Cos(z + Math.Pow(x, 3) * y), 3)) / (Math.Pow(Math.Cos(x), 2) * Math.Pow(x, 3) * Math.Pow(c, 2))}");

// 29
//Console.WriteLine("Введите значение переменной - y");
//double y = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - d");
//double d = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"R = {(Math.Pow(Math.Cos(y), 2) + 2.4 * d) / (Math.Exp(y) + Math.Log(Math.Pow(Math.Sin(x), 2) + 6))}");

// 30
//Console.WriteLine("Введите значение переменной - x");
//double x = Convert.ToDouble(Console.ReadLine());

//Console.WriteLine($"K = {(Math.Sqrt(Math.Pow(3 + x, 6)) - Math.Log(x)) / (Math.Exp(0) + Math.Asin(6 * Math.Pow(x, 2)))}");