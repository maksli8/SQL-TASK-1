﻿using System;

namespace OOP_Concepts
{
    // Задача 1: Наследование и вызов конструктора базового класса
    class Person
    {
        protected string name;
        public Person(string name)
        {
            this.name = name;
        }

        public void PrintInfo() => Console.WriteLine($"Имя: {name}");
    }

    class Student : Person
    {
        public int grade;
        public Student(string name, int grade) : base(name)
        {
            this.grade = grade;
        }

        public void PrintStudentInfo()
        {
            PrintInfo();
            Console.WriteLine($"Оценка: {grade}");
        }
    }

    // Задача 2: Модификаторы доступа
    class Example
    {
        private int x = 1;
        protected int y = 2;
        internal int z = 3;
        public int w = 4;

        public void ShowAccess()
        {
            Console.WriteLine($"\nДоступ из того же класса:");
            Console.WriteLine($"Private x: {x}");
            Console.WriteLine($"Protected y: {y}");
            Console.WriteLine($"Internal z: {z}");
            Console.WriteLine($"Public w: {w}");
        }
    }

    class DerivedExample : Example
    {
        public void ShowDerivedAccess()
        {
            Console.WriteLine($"\nДоступ из производного класса:");
            // Доступно только protected и public
            Console.WriteLine($"Protected y: {y}");
            Console.WriteLine($"Internal z: {z}");
            Console.WriteLine($"Public w: {w}");
        }
    }

    // Задача 3: Upcast и Downcast
    class Animal
    {
        public void Eat() => Console.WriteLine("Животное ест");
    }

    class Dog : Animal
    {
        public void Bark() => Console.WriteLine("Гав!");
    }

    // Задача 4: Полиморфизм
    class Shape
    {
        public virtual void Draw()
        {
            Console.WriteLine("Рисую фигуру");
        }
    }

    class Circle : Shape
    {
        public override void Draw()
        {
            Console.WriteLine("Рисую круг");
        }
    }

    class Rectangle : Shape
    {
        public override void Draw()
        {
            Console.WriteLine("Рисую прямоугольник");
        }
    }

    // Задача 5: Sealed класс
    sealed class Logger
    {
        public void Write(string message)
        {
            Console.WriteLine($"Лог: {message}");
        }
    }

    // class MyLogger : Logger {} // Ошибка компиляции!

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Задача 1: Наследование ===");
            Student st = new Student("Иван", 8);
            st.PrintStudentInfo();

            Console.WriteLine("\n=== Задача 2: Модификаторы доступа ===");
            Example ex = new Example();
            ex.ShowAccess();
            ex.w = 10; // public доступен
            ex.z = 30; // internal доступен в той же сборке

            DerivedExample de = new DerivedExample();
            de.ShowDerivedAccess();

            Console.WriteLine("\n=== Задача 3: Приведение типов ===");
            Animal animal = new Dog(); // Upcast
            animal.Eat();

            // Проверка с is
            if (animal is Dog d)
            {
                d.Bark();
            }

            // Приведение с as
            Dog dog = animal as Dog;
            dog?.Bark();

            Console.WriteLine("\n=== Задача 4: Полиморфизм ===");
            Shape[] shapes = new Shape[]
            {
                new Circle(),
                new Rectangle(),
                new Shape()
            };

            foreach (var shape in shapes)
            {
                shape.Draw();
            }

            Console.WriteLine("\n=== Задача 5: Sealed класс ===");
            Logger log = new Logger();
            log.Write("Тестовое сообщение");

            Console.ReadLine();
        }
    }
}