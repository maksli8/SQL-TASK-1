﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;

namespace BoxingDateTimeVarianceEnums
{
    class Program
    {
        #region Раздел 1: Упаковка и распаковка (1-20)

        // Задание 1: Упаковка int в object и демонстрация потери производительности
        static void BoxingPerformanceDemo()
        {
            Console.WriteLine("=== Задание 1: Упаковка и производительность ===\n");

            const int iterations = 1000000;
            Stopwatch sw = new Stopwatch();

            // Без упаковки
            sw.Start();
            int sum1 = 0;
            for (int i = 0; i < iterations; i++)
            {
                sum1 += i; // Нет упаковки
            }
            sw.Stop();
            Console.WriteLine($"Без упаковки: {sw.ElapsedTicks} тиков");

            // С упаковкой
            sw.Restart();
            object sum2 = 0;
            for (int i = 0; i < iterations; i++)
            {
                sum2 = (int)sum2 + i; // Упаковка и распаковка
            }
            sw.Stop();
            Console.WriteLine($"С упаковкой: {sw.ElapsedTicks} тиков");
        }

        // Задание 2: Безопасная распаковка с проверкой типа
        static void SafeUnboxing()
        {
            Console.WriteLine("\n=== Задание 2: Безопасная распаковка ===\n");

            object boxedValue = 42;

            // Безопасная распаковка
            if (boxedValue is int intValue)
            {
                Console.WriteLine($"Успешная распаковка int: {intValue}");
            }

            // Опасная распаковка (может вызвать InvalidCastException)
            try
            {
                double wrongUnbox = (double)boxedValue;
            }
            catch (InvalidCastException ex)
            {
                Console.WriteLine($"Ошибка распаковки: {ex.Message}");
            }
        }

        // Задание 5: ArrayList с упаковкой
        static void ArrayListBoxingDemo()
        {
            Console.WriteLine("\n=== Задание 5: ArrayList и упаковка ===\n");

            ArrayList arrayList = new ArrayList();

            // Упаковка различных типов
            arrayList.Add(42);           // int -> boxing
            arrayList.Add(3.14);         // double -> boxing  
            arrayList.Add(true);         // bool -> boxing
            arrayList.Add(DateTime.Now); // DateTime -> boxing

            Console.WriteLine("Содержимое ArrayList:");
            foreach (object item in arrayList)
            {
                Console.WriteLine($"Тип: {item.GetType().Name}, Значение: {item}");
            }
        }

        // Задание 7: Сравнение производительности List vs ArrayList
        static void ListVsArrayListPerformance()
        {
            Console.WriteLine("\n=== Задание 7: List vs ArrayList ===\n");

            const int count = 100000;
            Stopwatch sw = new Stopwatch();

            // ArrayList с упаковкой
            sw.Start();
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < count; i++)
            {
                arrayList.Add(i); // Упаковка
            }
            sw.Stop();
            Console.WriteLine($"ArrayList: {sw.ElapsedMilliseconds} мс");

            // List<int> без упаковки
            sw.Restart();
            List<int> list = new List<int>();
            for (int i = 0; i < count; i++)
            {
                list.Add(i); // Без упаковки
            }
            sw.Stop();
            Console.WriteLine($"List<int>: {sw.ElapsedMilliseconds} мс");
        }

        // Задание 9: params object[] с упаковкой
        static void ProcessParamsObjects(params object[] values)
        {
            Console.WriteLine("\n=== Задание 9: params object[] ===\n");

            foreach (object value in values)
            {
                switch (value)
                {
                    case int i:
                        Console.WriteLine($"[INT] {i} * 2 = {i * 2}");
                        break;
                    case double d:
                        Console.WriteLine($"[DOUBLE] {d:F2} ^ 2 = {d * d:F4}");
                        break;
                    case string s:
                        Console.WriteLine($"[STRING] '{s}' длина: {s.Length}");
                        break;
                    default:
                        Console.WriteLine($"[OTHER] {value.GetType().Name}: {value}");
                        break;
                }
            }
        }

        #endregion

        #region Раздел 2: Виды упаковки (21-40)

        // Задание 21: Явная и неявная упаковка
        static void ExplicitImplicitBoxing()
        {
            Console.WriteLine("\n=== Задание 21: Явная и неявная упаковка ===\n");

            int number = 100;

            // Явная упаковка
            object explicitBox = (object)number;
            Console.WriteLine($"Явная упаковка: {explicitBox}");

            // Неявная упаковка
            object implicitBox = number;
            Console.WriteLine($"Неявная упаковка: {implicitBox}");

            // Упаковка при передаче параметра
            ProcessObject(number); // Неявная упаковка
        }

        static void ProcessObject(object obj)
        {
            Console.WriteLine($"Получен object: {obj} (тип: {obj.GetType().Name})");
        }

        // Задание 23: Упаковка при приведении к интерфейсу
        interface IValue { int GetValue(); }

        struct ValueStruct : IValue
        {
            public int Number;
            public int GetValue() => Number;
        }

        static void InterfaceBoxing()
        {
            Console.WriteLine("\n=== Задание 23: Упаковка при приведении к интерфейсу ===\n");

            ValueStruct value = new ValueStruct { Number = 42 };

            // Упаковка при приведении к интерфейсу
            IValue boxedValue = value; // Boxing!
            Console.WriteLine($"Упакованное значение: {boxedValue.GetValue()}");

            // Работа без упаковки через обобщения
            ProcessValue(value); // No boxing
        }

        static void ProcessValue<T>(T value) where T : IValue
        {
            Console.WriteLine($"Без упаковки: {value.GetValue()}");
        }

        // Задание 25: Упаковка в LINQ
        static void LinqBoxingDemo()
        {
            Console.WriteLine("\n=== Задание 25: Упаковка в LINQ ===\n");

            int[] numbers = { 1, 2, 3, 4, 5 };

            // Упаковка в Select (object)
            var boxed = numbers.Select(n => (object)n);
            Console.WriteLine("Упакованные значения:");
            foreach (var item in boxed)
            {
                Console.WriteLine($"{item} ({item.GetType().Name})");
            }

            // Без упаковки
            var unboxed = numbers.Select(n => n * 2);
            Console.WriteLine("\nБез упаковки:");
            foreach (var item in unboxed)
            {
                Console.WriteLine($"{item} ({item.GetType().Name})");
            }
        }

        // Задание 31: Упаковка с dynamic
        static void DynamicBoxing()
        {
            Console.WriteLine("\n=== Задание 31: Dynamic и упаковка ===\n");

            int value = 100;
            dynamic dynamicValue = value; // Упаковка

            Console.WriteLine($"Original: {value} ({value.GetType().Name})");
            Console.WriteLine($"Dynamic: {dynamicValue} ({dynamicValue.GetType().Name})");

            // Изменение типа
            dynamicValue = "Теперь строка";
            Console.WriteLine($"После изменения: {dynamicValue} ({dynamicValue.GetType().Name})");
        }

        // Задание 33: String.Format и упаковка
        static void StringFormatBoxing()
        {
            Console.WriteLine("\n=== Задание 33: String.Format и упаковка ===\n");

            int age = 25;
            double salary = 50000.75;
            DateTime birthDate = new DateTime(1998, 5, 15);

            // Упаковка в String.Format
            string formatted = string.Format(
                "Возраст: {0}, Зарплата: {1:C}, Дата рождения: {2:yyyy-MM-dd}",
                age,      // boxing
                salary,   // boxing  
                birthDate // boxing
            );

            Console.WriteLine($"String.Format: {formatted}");

            // Без упаковки (интерполяция строк)
            string interpolated = $"Возраст: {age}, Зарплата: {salary:C}, Дата рождения: {birthDate:yyyy-MM-dd}";
            Console.WriteLine($"Интерполяция: {interpolated}");
        }

        #endregion

        #region Раздел 3: DateTime и TimeSpan (41-60)

        // Задание 41: Вычисление возраста
        static void CalculateAge()
        {
            Console.WriteLine("\n=== Задание 41: Вычисление возраста ===\n");

            DateTime birthDate = new DateTime(1990, 6, 15);
            DateTime currentDate = DateTime.Now;

            int age = currentDate.Year - birthDate.Year;
            if (currentDate < birthDate.AddYears(age)) age--;

            Console.WriteLine($"Дата рождения: {birthDate:dd.MM.yyyy}");
            Console.WriteLine($"Текущая дата: {currentDate:dd.MM.yyyy}");
            Console.WriteLine($"Возраст: {age} лет");
        }

        // Задание 42: Калькулятор рабочих дней
        static int CalculateWorkingDays(DateTime start, DateTime end)
        {
            int workingDays = 0;
            DateTime current = start;

            while (current <= end)
            {
                if (current.DayOfWeek != DayOfWeek.Saturday && current.DayOfWeek != DayOfWeek.Sunday)
                {
                    workingDays++;
                }
                current = current.AddDays(1);
            }

            return workingDays;
        }

        static void WorkingDaysDemo()
        {
            Console.WriteLine("\n=== Задание 42: Рабочие дни ===\n");

            DateTime start = new DateTime(2024, 1, 1);
            DateTime end = new DateTime(2024, 1, 31);

            int workingDays = CalculateWorkingDays(start, end);
            Console.WriteLine($"С {start:dd.MM.yyyy} по {end:dd.MM.yyyy}");
            Console.WriteLine($"Рабочих дней: {workingDays}");
        }

        // Задание 45: Парсинг DateTime
        static void DateTimeParsing()
        {
            Console.WriteLine("\n=== Задание 45: Парсинг DateTime ===\n");

            string[] dateStrings = {
                "2024-01-15",
                "15.01.2024",
                "01/15/2024",
                "2024-01-15T14:30:00"
            };

            foreach (string dateString in dateStrings)
            {
                if (DateTime.TryParse(dateString, out DateTime result))
                {
                    Console.WriteLine($"'{dateString}' -> {result:dd.MM.yyyy HH:mm:ss}");
                }
                else
                {
                    Console.WriteLine($"Не удалось распарсить: '{dateString}'");
                }
            }
        }

        // Задание 47: TimeSpan операции
        static void TimeSpanOperations()
        {
            Console.WriteLine("\n=== Задание 47: TimeSpan операции ===\n");

            TimeSpan ts1 = new TimeSpan(2, 30, 0); // 2 часа 30 минут
            TimeSpan ts2 = new TimeSpan(1, 45, 0); // 1 час 45 минут

            TimeSpan sum = ts1 + ts2;
            TimeSpan diff = ts1 - ts2;

            Console.WriteLine($"ts1: {ts1}");
            Console.WriteLine($"ts2: {ts2}");
            Console.WriteLine($"Сумма: {sum}");
            Console.WriteLine($"Разница: {diff}");
            Console.WriteLine($"Общее количество минут: {sum.TotalMinutes}");
        }

        // Задание 50: DateRange класс
        class DateRange
        {
            public DateTime Start { get; set; }
            public DateTime End { get; set; }

            public DateRange(DateTime start, DateTime end)
            {
                if (start > end) throw new ArgumentException("Start date must be before end date");
                Start = start;
                End = end;
            }

            public bool Contains(DateTime date) => date >= Start && date <= End;
            public TimeSpan Duration => End - Start;
            public IEnumerable<DateTime> EachDay()
            {
                for (DateTime date = Start; date <= End; date = date.AddDays(1))
                    yield return date;
            }

            public override string ToString() => $"{Start:dd.MM.yyyy} - {End:dd.MM.yyyy}";
        }

        static void DateRangeDemo()
        {
            Console.WriteLine("\n=== Задание 50: DateRange ===\n");

            DateRange range = new DateRange(
                new DateTime(2024, 1, 1),
                new DateTime(2024, 1, 10)
            );

            Console.WriteLine($"Диапазон: {range}");
            Console.WriteLine($"Продолжительность: {range.Duration.Days} дней");
            Console.WriteLine($"Содержит 2024-01-05: {range.Contains(new DateTime(2024, 1, 5))}");
        }

        #endregion

        #region Раздел 4: Ковариантность и контрвариантность (61-80)

        // Иерархия классов для демонстрации вариантности
        class Animal
        {
            public string Name { get; set; }
            public virtual void Speak() => Console.WriteLine("Animal sound");
        }

        class Dog : Animal
        {
            public override void Speak() => Console.WriteLine("Woof!");
        }

        class Cat : Animal
        {
            public override void Speak() => Console.WriteLine("Meow!");
        }

        // Задание 61: Ковариантный интерфейс
        interface IProducer<out T>
        {
            T Produce();
        }

        class AnimalProducer : IProducer<Animal>
        {
            public Animal Produce() => new Animal { Name = "Generic Animal" };
        }

        class DogProducer : IProducer<Dog>
        {
            public Dog Produce() => new Dog { Name = "Buddy" };
        }

        // Задание 62: Контрвариантный интерфейс  
        interface IConsumer<in T>
        {
            void Consume(T item);
        }

        class AnimalConsumer : IConsumer<Animal>
        {
            public void Consume(Animal animal)
            {
                Console.WriteLine($"Consuming animal: {animal.Name}");
                animal.Speak();
            }
        }

        static void VarianceDemo()
        {
            Console.WriteLine("\n=== Задание 61-62: Ковариантность и контрвариантность ===\n");

            // Ковариантность (out)
            IProducer<Dog> dogProducer = new DogProducer();
            IProducer<Animal> animalProducer = dogProducer; // Dog -> Animal (ковариантность)
            Animal animal = animalProducer.Produce();
            animal.Speak();

            // Контрвариантность (in)
            IConsumer<Animal> animalConsumer = new AnimalConsumer();
            IConsumer<Dog> dogConsumer = animalConsumer; // Animal -> Dog (контрвариантность)
            dogConsumer.Consume(new Dog { Name = "Rex" });
        }

        // Задание 65: Ковариантность с IEnumerable
        static void IEnumerableCovariance()
        {
            Console.WriteLine("\n=== Задание 65: IEnumerable ковариантность ===\n");

            List<Dog> dogs = new List<Dog>
            {
                new Dog { Name = "Buddy" },
                new Dog { Name = "Max" }
            };

            // Ковариантность: IEnumerable<Dog> -> IEnumerable<Animal>
            IEnumerable<Animal> animals = dogs;

            foreach (Animal animal in animals)
            {
                Console.WriteLine($"Animal: {animal.Name}");
                animal.Speak();
            }
        }

        // Задание 66: Делегаты с вариантностью
        static void DelegateVariance()
        {
            Console.WriteLine("\n=== Задание 66: Вариантность делегатов ===\n");

            // Ковариантность возвращаемого типа
            Func<Dog> getDog = () => new Dog { Name = "Sparky" };
            Func<Animal> getAnimal = getDog; // Dog -> Animal (ковариантность)

            Animal result = getAnimal();
            Console.WriteLine($"Result: {result.Name}");

            // Контрвариантность параметров
            Action<Animal> actionAnimal = (animal) => animal.Speak();
            Action<Dog> actionDog = actionAnimal; // Animal -> Dog (контрвариантность)

            actionDog(new Dog { Name = "Charlie" });
        }

        // Задание 70: Generic класс с ковариантностью
        interface IContainer<out T>
        {
            T GetItem();
        }

        class Container<T> : IContainer<T>
        {
            private T _item;

            public Container(T item) => _item = item;
            public T GetItem() => _item;
        }

        static void GenericVariance()
        {
            Console.WriteLine("\n=== Задание 70: Generic ковариантность ===\n");

            IContainer<Dog> dogContainer = new Container<Dog>(new Dog { Name = "Rex" });
            IContainer<Animal> animalContainer = dogContainer; // Ковариантность

            Animal animal = animalContainer.GetItem();
            animal.Speak();
        }

        #endregion

        #region Раздел 5: Перечисления (81-100)

        // Задание 81: DaysOfWeek enum
        enum DaysOfWeek
        {
            Monday,
            Tuesday,
            Wednesday,
            Thursday,
            Friday,
            Saturday,
            Sunday
        }

        static bool IsWeekend(DaysOfWeek day) => day == DaysOfWeek.Saturday || day == DaysOfWeek.Sunday;

        static void DaysOfWeekDemo()
        {
            Console.WriteLine("\n=== Задание 81: DaysOfWeek ===\n");

            foreach (DaysOfWeek day in Enum.GetValues(typeof(DaysOfWeek)))
            {
                Console.WriteLine($"{day}: {(IsWeekend(day) ? "Выходной" : "Рабочий")}");
            }
        }

        // Задание 82: Enum с явными значениями
        enum Status
        {
            None = 0,
            Pending = 1,
            Active = 2,
            Inactive = 3,
            Completed = 4
        }

        static void StatusEnumDemo()
        {
            Console.WriteLine("\n=== Задание 82: Status enum ===\n");

            Status currentStatus = Status.Active;
            Console.WriteLine($"Текущий статус: {currentStatus} (значение: {(int)currentStatus})");

            // Преобразование из числа
            if (Enum.TryParse<Status>("2", out Status parsedStatus))
            {
                Console.WriteLine($"Преобразованное значение: {parsedStatus}");
            }
        }

        // Задание 83: Флаговое перечисление
        [Flags]
        enum FilePermissions
        {
            None = 0,
            Read = 1,
            Write = 2,
            Execute = 4,
            Delete = 8,
            ReadWrite = Read | Write,
            FullControl = Read | Write | Execute | Delete
        }

        static void FlagsEnumDemo()
        {
            Console.WriteLine("\n=== Задание 83: Флаговое перечисление ===\n");

            FilePermissions userPermissions = FilePermissions.Read | FilePermissions.Write;
            FilePermissions adminPermissions = FilePermissions.FullControl;

            Console.WriteLine($"Права пользователя: {userPermissions}");
            Console.WriteLine($"Права администратора: {adminPermissions}");

            // Проверка флагов
            Console.WriteLine($"Может читать: {userPermissions.HasFlag(FilePermissions.Read)}");
            Console.WriteLine($"Может выполнять: {userPermissions.HasFlag(FilePermissions.Execute)}");

            // Добавление права
            userPermissions |= FilePermissions.Execute;
            Console.WriteLine($"После добавления Execute: {userPermissions}");

            // Удаление права
            userPermissions &= ~FilePermissions.Write;
            Console.WriteLine($"После удаления Write: {userPermissions}");
        }

        // Задание 85: Enum с описаниями
        enum Color
        {
            [System.ComponentModel.Description("Красный цвет")]
            Red,
            [System.ComponentModel.Description("Зеленый цвет")]
            Green,
            [System.ComponentModel.Description("Синий цвет")]
            Blue
        }

        // Задание 90: Enum с базовым типом byte
        enum SmallEnum : byte
        {
            Value1 = 1,
            Value2 = 2,
            Value3 = 3
        }

        static void SmallEnumDemo()
        {
            Console.WriteLine("\n=== Задание 90: Enum с byte ===\n");

            Console.WriteLine($"Размер SmallEnum: {sizeof(SmallEnum)} байт");
            Console.WriteLine($"Размер обычного enum: {sizeof(DaysOfWeek)} байт");
        }

        // Задание 93: UserRoles флаговое перечисление
        [Flags]
        enum UserRoles
        {
            None = 0,
            Guest = 1,
            User = 2,
            Moderator = 4,
            Admin = 8
        }

        static void UserRolesDemo()
        {
            Console.WriteLine("\n=== Задание 93: UserRoles ===\n");

            UserRoles user = UserRoles.User | UserRoles.Moderator;
            UserRoles admin = UserRoles.Admin | UserRoles.Moderator | UserRoles.User;

            Console.WriteLine($"Роли пользователя: {user}");
            Console.WriteLine($"Роли администратора: {admin}");

            // Подсчет установленных флагов
            int userFlagCount = CountFlags(user);
            int adminFlagCount = CountFlags(admin);

            Console.WriteLine($"Флагов у пользователя: {userFlagCount}");
            Console.WriteLine($"Флагов у администратора: {adminFlagCount}");
        }

        static int CountFlags(Enum flags)
        {
            int count = 0;
            foreach (Enum value in Enum.GetValues(flags.GetType()))
            {
                if (flags.HasFlag(value) && Convert.ToInt32(value) != 0)
                    count++;
            }
            return count;
        }

        #endregion

        static void Main(string[] args)
        {
            Console.WriteLine("🚀 ДЕМОНСТРАЦИЯ КЛЮЧЕВЫХ ЗАДАЧ ПО C#\n");

            // Раздел 1: Упаковка и распаковка
            Console.WriteLine("========== РАЗДЕЛ 1: УПАКОВКА И РАСПАКОВКА ==========");
            BoxingPerformanceDemo();
            SafeUnboxing();
            ArrayListBoxingDemo();
            ListVsArrayListPerformance();
            ProcessParamsObjects(42, 3.14, "Hello", true, DateTime.Now);

            // Раздел 2: Виды упаковки
            Console.WriteLine("\n========== РАЗДЕЛ 2: ВИДЫ УПАКОВКИ ==========");
            ExplicitImplicitBoxing();
            InterfaceBoxing();
            LinqBoxingDemo();
            DynamicBoxing();
            StringFormatBoxing();

            // Раздел 3: DateTime и TimeSpan
            Console.WriteLine("\n========== РАЗДЕЛ 3: DATETIME И TIMESPAN ==========");
            CalculateAge();
            WorkingDaysDemo();
            DateTimeParsing();
            TimeSpanOperations();
            DateRangeDemo();

            // Раздел 4: Ковариантность и контрвариантность
            Console.WriteLine("\n========== РАЗДЕЛ 4: КОВАРИАНТНОСТЬ И КОНТРВАРИАНТНОСТЬ ==========");
            VarianceDemo();
            IEnumerableCovariance();
            DelegateVariance();
            GenericVariance();

            // Раздел 5: Перечисления
            Console.WriteLine("\n========== РАЗДЕЛ 5: ПЕРЕЧИСЛЕНИЯ ==========");
            DaysOfWeekDemo();
            StatusEnumDemo();
            FlagsEnumDemo();
            SmallEnumDemo();
            UserRolesDemo();

            Console.WriteLine("\n🎉 ВСЕ ЗАДАЧИ ВЫПОЛНЕНЫ!");
            Console.WriteLine("Нажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
    }
}