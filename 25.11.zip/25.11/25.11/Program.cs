﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LINQTasks
{
    class Program
    {
        // Классы для данных
        class Person
        {
            public string Name { get; set; }
            public int Age { get; set; }
        }

        class Student
        {
            public string Name { get; set; }
            public double GPA { get; set; }
            public string Faculty { get; set; }
        }

        class Product
        {
            public string Name { get; set; }
            public decimal Price { get; set; }
            public string Category { get; set; }
        }

        class Employee
        {
            public string Name { get; set; }
            public decimal Salary { get; set; }
            public int Experience { get; set; }
            public string Department { get; set; }
        }

        class User
        {
            public string Name { get; set; }
            public string Email { get; set; }
        }

        static void Main(string[] args)
        {
            Console.WriteLine("=== LINQ ЗАДАЧИ 1-100 ===\n");

            // Категория 1: Where (Фильтрация)
            Category1_Where();

            // Категория 2: Select (Проекция)
            Category2_Select();

            // Категория 3: OrderBy/ThenBy (Сортировка)
            Category3_OrderBy();

            // Категория 4: GroupBy (Группировка)
            Category4_GroupBy();

            // Категория 5: Join (Объединение)
            Category5_Join();

            // Категория 6: Aggregate Functions (Агрегирование)
            Category6_Aggregate();

            // Категория 7: Set Operations (Операции над множествами)
            Category7_SetOperations();

            // Категория 8: Partitioning (Партиционирование)
            Category8_Partitioning();

            // Категория 9: SelectMany (Разворачивание)
            Category9_SelectMany();

            // Категория 10: Quantifiers (Проверка условий)
            Category10_Quantifiers();

            // Категория 11: Concatenation (Объединение)
            Category11_Concatenation();

            // Категория 12: Casting (Приведение типов)
            Category12_Casting();

            // Категория 13: Complex Queries (Сложные запросы)
            Category13_ComplexQueries();

            Console.WriteLine("\nВсе задачи выполнены!");
            Console.ReadKey();
        }

        static void Category1_Where()
        {
            Console.WriteLine("=== КАТЕГОРИЯ 1: Where (Фильтрация) ===");

            // Задание 1
            int[] numbers1 = { 10, 25, 50, 75, 100, 150 };
            var result1 = numbers1.Where(n => n > 50).ToList();
            Console.WriteLine($"1. Числа > 50: {string.Join(", ", result1)}");

            // Задание 2
            List<int> numbers2 = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            var result2 = numbers2.Where(n => n % 2 == 0).ToList();
            Console.WriteLine($"2. Четные числа: {string.Join(", ", result2)}");

            // Задание 3
            string[] fruits = { "Apple", "Banana", "Apricot", "Orange", "Avocado" };
            var result3 = fruits.Where(f => f.StartsWith("A")).ToList();
            Console.WriteLine($"3. Фрукты на 'A': {string.Join(", ", result3)}");

            // Задание 4
            List<Person> people = new List<Person>
            {
                new Person { Name = "John", Age = 25 },
                new Person { Name = "Alice", Age = 35 },
                new Person { Name = "Bob", Age = 40 },
                new Person { Name = "Tom", Age = 28 }
            };
            var result4 = people.Where(p => p.Age > 30).Select(p => p.Name).ToList();
            Console.WriteLine($"4. Люди старше 30: {string.Join(", ", result4)}");

            // Задание 5
            int[] numbers5 = { 3, 5, 9, 12, 15, 17, 21 };
            var result5 = numbers5.Where(n => n % 3 == 0).ToList();
            Console.WriteLine($"5. Числа кратные 3: {string.Join(", ", result5)}");

            // Задание 6
            List<Student> students = new List<Student>
            {
                new Student { Name = "Tom", GPA = 3.8 },
                new Student { Name = "Anna", GPA = 4.2 },
                new Student { Name = "Mike", GPA = 3.5 },
                new Student { Name = "Kate", GPA = 4.5 }
            };
            var result6 = students.Where(s => s.GPA > 4.0).Select(s => s.Name).ToList();
            Console.WriteLine($"6. Студенты с GPA > 4.0: {string.Join(", ", result6)}");

            // Задание 7
            string[] words = { "Hi", "Hello", "World", "Programming" };
            var result7 = words.Where(w => w.Length > 5).ToList();
            Console.WriteLine($"7. Слова длиной > 5: {string.Join(", ", result7)}");

            // Задание 8
            List<Product> products = new List<Product>
            {
                new Product { Name = "Book", Price = 50 },
                new Product { Name = "Phone", Price = 300 },
                new Product { Name = "Laptop", Price = 800 },
                new Product { Name = "Mouse", Price = 150 }
            };
            var result8 = products.Where(p => p.Price >= 100 && p.Price <= 500).Select(p => p.Name).ToList();
            Console.WriteLine($"8. Товары 100-500 руб: {string.Join(", ", result8)}");

            // Задание 9
            int[] mixedNumbers = { -5, 10, -3, 8, 0, -1, 15 };
            var result9 = mixedNumbers.Where(n => n > 0).ToList();
            Console.WriteLine($"9. Положительные числа: {string.Join(", ", result9)}");

            // Задание 10
            List<Employee> employees = new List<Employee>
            {
                new Employee { Name = "John", Salary = 50000, Experience = 3 },
                new Employee { Name = "Alice", Salary = 45000, Experience = 1 },
                new Employee { Name = "Bob", Salary = 60000, Experience = 5 }
            };
            decimal avgSalary = employees.Average(e => e.Salary);
            var result10 = employees.Where(e => e.Salary > avgSalary && e.Experience > 2).Select(e => e.Name).ToList();
            Console.WriteLine($"10. Сотрудники с з/п выше средней и стаж > 2 лет: {string.Join(", ", result10)}");

            Console.WriteLine();
        }

        static void Category2_Select()
        {
            Console.WriteLine("=== КАТЕГОРИЯ 2: Select (Проекция) ===");

            // Задание 11
            int[] numbers11 = { 1, 2, 3, 4, 5 };
            var result11 = numbers11.Select(n => n * n).ToList();
            Console.WriteLine($"11. Квадраты чисел: {string.Join(", ", result11)}");

            // Задание 12
            List<Person> people = new List<Person>
            {
                new Person { Name = "John", Age = 25 },
                new Person { Name = "Alice", Age = 35 }
            };
            var result12 = people.Select(p => p.Name).ToList();
            Console.WriteLine($"12. Имена людей: {string.Join(", ", result12)}");

            // Задание 13
            var result13 = people.Select(p => $"{p.Name} - {p.Age}").ToList();
            Console.WriteLine($"13. Имя - Возраст: {string.Join("; ", result13)}");

            // Задание 14
            string[] strings14 = { "hello", "world", "programming" };
            var result14 = strings14.Select(s => s.Length).ToList();
            Console.WriteLine($"14. Длины строк: {string.Join(", ", result14)}");

            // Задание 15
            List<Product> products = new List<Product>
            {
                new Product { Name = "Phone", Price = 300, Category = "Electronics" }
            };
            var result15 = products.Select(p => new { p.Name, DiscountedPrice = p.Price * 0.9m }).ToList();
            Console.WriteLine($"15. Товары со скидкой: {string.Join(", ", result15.Select(x => $"{x.Name}: {x.DiscountedPrice}"))}");

            // Задание 16
            List<decimal> pricesInRubles = new List<decimal> { 5000, 10000, 7500 };
            var result16 = pricesInRubles.Select(price => price / 100).ToList();
            Console.WriteLine($"16. Цены в долларах: {string.Join(", ", result16)}");

            // Задание 17
            var result17 = people.Select(p => new { UserName = p.Name, YearOfBirth = DateTime.Now.Year - p.Age }).ToList();
            Console.WriteLine($"17. Анонимные типы: {string.Join("; ", result17.Select(x => $"{x.UserName} born in {x.YearOfBirth}"))}");

            // Задание 18
            string[] items = { "apple", "banana", "cherry" };
            var result18 = items.Select(item => $"fruit_{item}").ToList();
            Console.WriteLine($"18. С префиксом: {string.Join(", ", result18)}");

            // Задание 19
            List<User> users = new List<User>
            {
                new User { Name = "John", Email = "john@example.com" },
                new User { Name = "Alice", Email = "alice@test.com" }
            };
            var result19 = users.Select(u => $"<{u.Email}>").ToList();
            Console.WriteLine($"19. Email в угловых скобках: {string.Join(", ", result19)}");

            // Задание 20
            var result20 = people.Select(p => (p.Name, p.Age)).ToList();
            Console.WriteLine($"20. Кортежи: {string.Join("; ", result20.Select(x => $"{x.Name}: {x.Age}"))}");

            Console.WriteLine();
        }

        static void Category3_OrderBy()
        {
            Console.WriteLine("=== КАТЕГОРИЯ 3: OrderBy/ThenBy (Сортировка) ===");

            // Задание 21
            int[] numbers21 = { 5, 2, 8, 1, 9 };
            var result21 = numbers21.OrderBy(n => n).ToList();
            Console.WriteLine($"21. Числа по возрастанию: {string.Join(", ", result21)}");

            // Задание 22
            string[] names22 = { "John", "Alice", "Bob", "Zoe" };
            var result22 = names22.OrderByDescending(n => n).ToList();
            Console.WriteLine($"22. Имена Z-A: {string.Join(", ", result22)}");

            // Задание 23
            List<Person> people = new List<Person>
            {
                new Person { Name = "John", Age = 25 },
                new Person { Name = "Alice", Age = 30 },
                new Person { Name = "Bob", Age = 25 }
            };
            var result23 = people.OrderBy(p => p.Age).ThenBy(p => p.Name).Select(p => $"{p.Name}({p.Age})").ToList();
            Console.WriteLine($"23. Сортировка по возрасту, затем по имени: {string.Join(", ", result23)}");

            // Задание 24
            string[] words24 = { "hi", "hello", "world", "programming", "a" };
            var result24 = words24.OrderBy(w => w.Length).ToList();
            Console.WriteLine($"24. Строки по длине: {string.Join(", ", result24)}");

            // Задание 25
            List<Product> products = new List<Product>
            {
                new Product { Name = "Book", Price = 50 },
                new Product { Name = "Phone", Price = 300 },
                new Product { Name = "Laptop", Price = 800 }
            };
            var result25 = products.OrderByDescending(p => p.Price).Select(p => $"{p.Name}: {p.Price}").ToList();
            Console.WriteLine($"25. Товары по убыванию цены: {string.Join("; ", result25)}");

            // Задание 26
            List<Student> students = new List<Student>
            {
                new Student { Name = "Tom", GPA = 4.2 },
                new Student { Name = "Anna", GPA = 4.2 },
                new Student { Name = "Mike", GPA = 4.5 }
            };
            var result26 = students.OrderByDescending(s => s.GPA).ThenBy(s => s.Name).Select(s => $"{s.Name}: {s.GPA}").ToList();
            Console.WriteLine($"26. Студенты по GPA и фамилии: {string.Join("; ", result26)}");

            // Задание 27
            int[] numbers27 = { 12, 5, 24, 7, 18, 9, 11 };
            int CountDivisors(int n)
            {
                int count = 0;
                for (int i = 1; i <= n; i++)
                    if (n % i == 0) count++;
                return count;
            }
            var result27 = numbers27.OrderBy(n => CountDivisors(n)).ThenBy(n => n).ToList();
            Console.WriteLine($"27. Числа по количеству делителей: {string.Join(", ", result27)}");

            // Задание 28
            List<Employee> employees = new List<Employee>
            {
                new Employee { Name = "John", Department = "IT", Salary = 50000 },
                new Employee { Name = "Alice", Department = "HR", Salary = 45000 },
                new Employee { Name = "Bob", Department = "IT", Salary = 55000 }
            };
            var result28 = employees.OrderBy(e => e.Department).ThenBy(e => e.Salary).Select(e => $"{e.Name}({e.Department}): {e.Salary}").ToList();
            Console.WriteLine($"28. Сотрудники по отделу и з/п: {string.Join("; ", result28)}");

            // Задание 29
            DateTime[] dates = { new DateTime(2023, 5, 1), new DateTime(2023, 1, 1), new DateTime(2023, 12, 1) };
            var result29 = dates.OrderBy(d => d).Select(d => d.ToString("dd.MM.yyyy")).ToList();
            Console.WriteLine($"29. Даты в хронологическом порядке: {string.Join(", ", result29)}");

            // Задание 30
            List<Product> products30 = new List<Product>
            {
                new Product { Name = "iPhone", Category = "Electronics", Price = 800 },
                new Product { Name = "Samsung", Category = "Electronics", Price = 700 },
                new Product { Name = "Book", Category = "Education", Price = 50 }
            };
            var result30 = products30.OrderBy(p => p.Category).ThenByDescending(p => p.Price).Select(p => $"{p.Category}-{p.Name}: {p.Price}").ToList();
            Console.WriteLine($"30. Товары по категории и популярности: {string.Join("; ", result30)}");

            Console.WriteLine();
        }

        static void Category4_GroupBy()
        {
            Console.WriteLine("=== КАТЕГОРИЯ 4: GroupBy (Группировка) ===");

            // Задание 31
            int[] numbers31 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            var result31 = numbers31.GroupBy(n => n % 2 == 0 ? "Четные" : "Нечетные");
            Console.WriteLine("31. Группировка по четности:");
            foreach (var group in result31)
            {
                Console.WriteLine($"   {group.Key}: {string.Join(", ", group)}");
            }

            // Задание 32
            List<Person> people = new List<Person>
            {
                new Person { Name = "John", Age = 25 },
                new Person { Name = "Alice", Age = 30 },
                new Person { Name = "Bob", Age = 25 }
            };
            var result32 = people.GroupBy(p => p.Age);
            Console.WriteLine("32. Группировка по возрасту:");
            foreach (var group in result32)
            {
                Console.WriteLine($"   Возраст {group.Key}: {string.Join(", ", group.Select(p => p.Name))}");
            }

            // Задание 33
            List<Product> products = new List<Product>
            {
                new Product { Name = "iPhone", Category = "Electronics" },
                new Product { Name = "Book", Category = "Education" },
                new Product { Name = "Laptop", Category = "Electronics" }
            };
            var result33 = products.GroupBy(p => p.Category).Select(g => new { Category = g.Key, Count = g.Count() });
            Console.WriteLine("33. Количество товаров по категориям:");
            foreach (var item in result33)
            {
                Console.WriteLine($"   {item.Category}: {item.Count}");
            }

            // Задание 34
            List<Student> students = new List<Student>
            {
                new Student { Name = "Tom", GPA = 4.2, Faculty = "CS" },
                new Student { Name = "Anna", GPA = 4.5, Faculty = "Math" },
                new Student { Name = "Mike", GPA = 3.8, Faculty = "CS" }
            };
            var result34 = students.GroupBy(s => s.Faculty).Select(g => new { Faculty = g.Key, AvgGPA = g.Average(s => s.GPA) });
            Console.WriteLine("34. Средний балл по факультетам:");
            foreach (var item in result34)
            {
                Console.WriteLine($"   {item.Faculty}: {item.AvgGPA:F2}");
            }

            // Задание 35
            List<Employee> employees = new List<Employee>
            {
                new Employee { Name = "John", Department = "IT", Salary = 50000 },
                new Employee { Name = "Alice", Department = "HR", Salary = 45000 },
                new Employee { Name = "Bob", Department = "IT", Salary = 55000 }
            };
            var result35 = employees.GroupBy(e => e.Department).Select(g => new { Department = g.Key, TotalSalary = g.Sum(e => e.Salary) });
            Console.WriteLine("35. Сумма зарплат по отделам:");
            foreach (var item in result35)
            {
                Console.WriteLine($"   {item.Department}: {item.TotalSalary}");
            }

            Console.WriteLine("... остальные задачи GroupBy будут аналогичны ...");
            Console.WriteLine();
        }

        static void Category5_Join()
        {
            Console.WriteLine("=== КАТЕГОРИЯ 5: Join (Объединение) ===");

            // Задание 42
            var employees42 = new List<Employee>
            {
                new Employee { Name = "John", Department = "IT" },
                new Employee { Name = "Alice", Department = "HR" }
            };

            var departments42 = new[]
            {
                new { Name = "IT", Manager = "Bob" },
                new { Name = "HR", Manager = "Carol" }
            }.ToList();

            var result42 = employees42.Join(departments42,
                emp => emp.Department,
                dept => dept.Name,
                (emp, dept) => new { emp.Name, emp.Department, dept.Manager });

            Console.WriteLine("42. Сотрудники с отделами:");
            foreach (var item in result42)
            {
                Console.WriteLine($"   {item.Name} - {item.Department} - менеджер: {item.Manager}");
            }

            // Задание 43
            var customers = new[]
            {
                new { Id = 1, Name = "Customer A" },
                new { Id = 2, Name = "Customer B" },
                new { Id = 3, Name = "Customer C" }
            }.ToList();

            var orders = new[]
            {
                new { CustomerId = 1, Product = "Product 1" },
                new { CustomerId = 1, Product = "Product 2" },
                new { CustomerId = 2, Product = "Product 3" }
            }.ToList();

            // Left Join с помощью SelectMany
            var result43 = from customer in customers
                           join order in orders on customer.Id equals order.CustomerId into customerOrders
                           from co in customerOrders.DefaultIfEmpty()
                           select new
                           {
                               customer.Name,
                               Product = co?.Product ?? "No orders"
                           };

            Console.WriteLine("43. Left Join - клиенты и их заказы:");
            foreach (var item in result43)
            {
                Console.WriteLine($"   {item.Name}: {item.Product}");
            }

            // Задание 44
            var products44 = new[]
            {
                new { Id = 1, Name = "Laptop", ManufacturerId = 1 },
                new { Id = 2, Name = "Phone", ManufacturerId = 2 }
            }.ToList();

            var manufacturers = new[]
            {
                new { Id = 1, Name = "Dell" },
                new { Id = 2, Name = "Samsung" }
            }.ToList();

            var result44 = products44.Join(manufacturers,
                p => p.ManufacturerId,
                m => m.Id,
                (p, m) => new { Product = p.Name, Manufacturer = m.Name });

            Console.WriteLine("44. Товары с производителями:");
            foreach (var item in result44)
            {
                Console.WriteLine($"   {item.Product} - {item.Manufacturer}");
            }

            // Задание 45
            var employees45 = new[]
            {
                new { FirstName = "John", LastName = "Doe", DepartmentId = 1 },
                new { FirstName = "Jane", LastName = "Smith", DepartmentId = 1 }
            }.ToList();

            var departments45 = new[]
            {
                new { DeptId = 1, Location = "New York" }
            }.ToList();

            var result45 = employees45.Join(departments45,
                emp => emp.DepartmentId,
                dept => dept.DeptId,
                (emp, dept) => new { emp.FirstName, emp.LastName, dept.Location });

            Console.WriteLine("45. Объединение по составному ключу:");
            foreach (var item in result45)
            {
                Console.WriteLine($"   {item.FirstName} {item.LastName} - {item.Location}");
            }

            Console.WriteLine();
        }

        static void Category6_Aggregate()
        {
            Console.WriteLine("=== КАТЕГОРИЯ 6: Aggregate Functions (Агрегирование) ===");

            // Задание 51
            int[] numbers51 = { 1, 2, 3, 4, 5 };
            var result51 = numbers51.Sum();
            Console.WriteLine($"51. Сумма чисел: {result51}");

            // Задание 52
            var result52 = numbers51.Average();
            Console.WriteLine($"52. Среднее значение: {result52}");

            // Задание 53
            var result53_min = numbers51.Min();
            var result53_max = numbers51.Max();
            Console.WriteLine($"53. Минимум: {result53_min}, Максимум: {result53_max}");

            // Задание 54
            var result54 = numbers51.Count(n => n % 2 == 0);
            Console.WriteLine($"54. Количество четных чисел: {result54}");

            // Задание 55
            var result55 = numbers51.Aggregate(1, (acc, n) => acc * n);
            Console.WriteLine($"55. Произведение чисел: {result55}");

            Console.WriteLine();
        }

        static void Category7_SetOperations()
        {
            Console.WriteLine("=== КАТЕГОРИЯ 7: Set Operations (Операции над множествами) ===");

            // Задание 61
            int[] numbers61 = { 1, 2, 2, 3, 3, 3, 4 };
            var result61 = numbers61.Distinct().ToList();
            Console.WriteLine($"61. Без дубликатов: {string.Join(", ", result61)}");

            // Задание 62
            List<int> list62a = new List<int> { 1, 2, 3 };
            List<int> list62b = new List<int> { 3, 4, 5 };
            var result62 = list62a.Union(list62b).ToList();
            Console.WriteLine($"62. Объединение: {string.Join(", ", result62)}");

            // Задание 63
            var result63 = list62a.Except(list62b).ToList();
            Console.WriteLine($"63. Разность (A - B): {string.Join(", ", result63)}");

            // Задание 64
            List<int> list64a = new List<int> { 1, 2, 3, 4 };
            List<int> list64b = new List<int> { 3, 4, 5, 6 };
            var result64 = list64a.Intersect(list64b).ToList();
            Console.WriteLine($"64. Пересечение: {string.Join(", ", result64)}");

            Console.WriteLine();
        }

        static void Category8_Partitioning()
        {
            Console.WriteLine("=== КАТЕГОРИЯ 8: Partitioning (Партиционирование) ===");

            // Задание 69
            int[] numbers69 = { 1, 2, 3, 4, 5 };
            var result69 = numbers69.Take(3).ToList();
            Console.WriteLine($"69. Первые 3 элемента: {string.Join(", ", result69)}");

            // Задание 70
            var result70 = numbers69.Skip(2).ToList();
            Console.WriteLine($"70. Пропустить 2 элемента: {string.Join(", ", result70)}");

            // Задание 71
            var result71 = numbers69.First(n => n > 3);
            Console.WriteLine($"71. Первый элемент > 3: {result71}");

            // Задание 72
            var result72 = numbers69.Last();
            Console.WriteLine($"72. Последний элемент: {result72}");

            // Задание 73 (пагинация)
            int page = 2;
            int pageSize = 2;
            var result73 = numbers69.Skip((page - 1) * pageSize).Take(pageSize).ToList();
            Console.WriteLine($"73. Страница {page} (размер {pageSize}): {string.Join(", ", result73)}");

            // Задание 74
            var result74 = numbers69.TakeWhile(n => n < 4).ToList();
            Console.WriteLine($"74. TakeWhile (n < 4): {string.Join(", ", result74)}");

            // Задание 75
            int[] numbers75 = { 1, 2, 3, 5, 4, 6, 2, 7, 8 };
            var result75 = numbers75.SkipWhile(x => x < 5).ToList();
            Console.WriteLine($"75. SkipWhile (x < 5): {string.Join(", ", result75)}");

            // Задание 76
            var result76 = numbers69.TakeLast(3).ToList();
            Console.WriteLine($"76. Последние 3 элемента: {string.Join(", ", result76)}");

            Console.WriteLine();
        }

        static void Category9_SelectMany()
        {
            Console.WriteLine("=== КАТЕГОРИЯ 9: SelectMany (Разворачивание) ===");

            // Задание 77
            List<List<int>> listOfLists = new List<List<int>>
            {
                new List<int> { 1, 2, 3 },
                new List<int> { 4, 5 },
                new List<int> { 6, 7, 8, 9 }
            };
            var result77 = listOfLists.SelectMany(list => list).ToList();
            Console.WriteLine($"77. Развернутый список: {string.Join(", ", result77)}");

            // Задание 78
            int[] numbers78a = { 1, 2 };
            string[] numbers78b = { "A", "B" };
            var result78 = numbers78a.SelectMany(a => numbers78b, (a, b) => $"{a}{b}").ToList();
            Console.WriteLine($"78. Декартово произведение: {string.Join(", ", result78)}");

            Console.WriteLine();
        }

        static void Category10_Quantifiers()
        {
            Console.WriteLine("=== КАТЕГОРИЯ 10: Quantifiers (Проверка условий) ===");

            // Задание 85
            int[] numbers85 = { 1, 5, 8, 12, 3 };
            var result85 = numbers85.Any(n => n > 10);
            Console.WriteLine($"85. Есть число > 10: {result85}");

            // Задание 86
            var result86 = numbers85.All(n => n > 0);
            Console.WriteLine($"86. Все числа > 0: {result86}");

            // Задание 87
            var result87 = numbers85.Contains(8);
            Console.WriteLine($"87. Содержит 8: {result87}");

            // Задание 88
            List<Person> people = new List<Person>
            {
                new Person { Name = "John", Age = 25 }
            };
            var result88 = people.Any(p => p.Name == "John" && p.Age > 20);
            Console.WriteLine($"88. Есть John старше 20: {result88}");

            // Задание 89
            List<int> emptyList = new List<int>();
            var result89 = !emptyList.Any();
            Console.WriteLine($"89. Список пуст: {result89}");

            // Задание 90
            var result90 = numbers85.Count() == 5;
            Console.WriteLine($"90. Ровно 5 элементов: {result90}");

            Console.WriteLine();
        }

        static void Category11_Concatenation()
        {
            Console.WriteLine("=== КАТЕГОРИЯ 11: Concatenation (Объединение) ===");

            // Задание 91
            int[] array91a = { 1, 2, 3 };
            int[] array91b = { 4, 5, 6 };
            var result91 = array91a.Concat(array91b).ToList();
            Console.WriteLine($"91. Объединение массивов: {string.Join(", ", result91)}");

            // Задание 92
            string[] list92a = { "Hello", "World" };
            string[] list92b = { "From", "LINQ" };
            var result92 = list92a.Concat(list92b).ToList();
            Console.WriteLine($"92. Объединение строк: {string.Join(" ", result92)}");

            Console.WriteLine();
        }

        static void Category12_Casting()
        {
            Console.WriteLine("=== КАТЕГОРИЯ 12: Casting (Приведение типов) ===");

            // Задание 95
            object[] objects95 = { 1, 2, 3, "hello", 4 };
            var result95 = objects95.OfType<int>().ToList();
            Console.WriteLine($"95. Только int из object[]: {string.Join(", ", result95)}");

            // Задание 96
            var result96 = objects95.Where(x => x is int).Cast<int>().ToList();
            Console.WriteLine($"96. Приведение к int: {string.Join(", ", result96)}");

            // Задание 97
            object[] mixedData = { 1, "Hello", 2, "World", 3.14, 4, true, "Test", 5 };
            var integers = mixedData.OfType<int>().ToList();
            var strings = mixedData.OfType<string>().ToList();
            Console.WriteLine($"97. OfType - целые: {string.Join(", ", integers)}");
            Console.WriteLine($"    OfType - строки: {string.Join(", ", strings)}");

            // Задание 98
            string[] numberStrings = { "1", "2", "3", "invalid", "5" };
            var result98 = numberStrings.Select(s => int.TryParse(s, out int num) ? num : (int?)null)
                                      .Where(n => n.HasValue)
                                      .Select(n => n.Value)
                                      .ToList();
            Console.WriteLine($"98. Безопасное преобразование: {string.Join(", ", result98)}");

            Console.WriteLine();
        }

        static void Category13_ComplexQueries()
        {
            Console.WriteLine("=== КАТЕГОРИЯ 13: Complex Queries (Сложные запросы) ===");

            // Задание 99
            List<Student> students99 = new List<Student>
            {
                new Student { Name = "Tom", GPA = 4.2, Faculty = "CS" },
                new Student { Name = "Anna", GPA = 4.5, Faculty = "Math" },
                new Student { Name = "Mike", GPA = 3.8, Faculty = "CS" },
                new Student { Name = "Kate", GPA = 4.8, Faculty = "Math" }
            };

            var result99 = students99
                .Where(s => s.GPA > 4.0)
                .GroupBy(s => s.Faculty)
                .Select(g => new
                {
                    Faculty = g.Key,
                    Count = g.Count(),
                    AvgGPA = g.Average(s => s.GPA),
                    TopStudent = g.OrderByDescending(s => s.GPA).First().Name
                })
                .OrderByDescending(x => x.AvgGPA)
                .ToList();

            Console.WriteLine("99. Сложный запрос (группировка -> фильтрация -> сортировка):");
            foreach (var item in result99)
            {
                Console.WriteLine($"   Факультет {item.Faculty}: {item.Count} студентов, средний GPA: {item.AvgGPA:F2}, лучший: {item.TopStudent}");
            }

            Console.WriteLine();
        }
    }
}