﻿namespace LINQTasks
{
    internal class ProgramBase
    {
    }
}