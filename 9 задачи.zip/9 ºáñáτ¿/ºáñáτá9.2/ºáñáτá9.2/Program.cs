﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Task1()
    {
        Console.WriteLine("\n=== Задача 1 ===");
        Console.WriteLine("Введите первый массив из 10 целых чисел:");
        int[] arr1 = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
        Console.WriteLine("Введите второй массив из 10 целых чисел:");
        int[] arr2 = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr1.Length != 10 || arr2.Length != 10)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 10 элементов в каждом массиве");
            return;
        }

        int[] newArr = new int[10];
        for (int i = 0; i < 10; i++)
        {
            if (i % 2 == 0) // четные позиции (индексы 0,2,4,6,8)
                newArr[i] = arr1[i * 2 + 1 < arr1.Length ? i * 2 + 1 : arr1.Length - 1]; // нечетные индексы из первого
            else // нечетные позиции (индексы 1,3,5,7,9)
                newArr[i] = arr2[i * 2 < arr2.Length ? i * 2 : arr2.Length - 1]; // четные индексы из второго
        }

        Console.WriteLine($"Первый массив: [{string.Join(", ", arr1)}]");
        Console.WriteLine($"Второй массив: [{string.Join(", ", arr2)}]");
        Console.WriteLine($"Новый массив: [{string.Join(", ", newArr)}]");
    }

    static void Task2()
    {
        Console.WriteLine("\n=== Задача 2 ===");
        Console.WriteLine("Введите 8 двузначных чисел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 8 || arr.Any(x => x < 10 || x > 99))
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 8 двузначных чисел");
            return;
        }

        int[] newArr = arr.Select(x => x % 10).ToArray(); // младшие разряды

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Младшие разряды: [{string.Join(", ", newArr)}]");
    }

    static void Task3()
    {
        Console.WriteLine("\n=== Задача 3 ===");
        Console.WriteLine("Введите 17 двузначных чисел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 17 || arr.Any(x => x < 10 || x > 99))
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 17 двузначных чисел");
            return;
        }

        int sum = arr.Select(x => x / 10 + x % 10).Sum(); // сумма цифр

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Сумма цифр: {sum}");
    }

    static void Task4()
    {
        Console.WriteLine("\n=== Задача 4 ===");
        Console.WriteLine("Введите первый массив из 9 вещественных чисел:");
        double[] arr1 = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();
        Console.WriteLine("Введите второй массив из 7 вещественных чисел:");
        double[] arr2 = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr1.Length != 9 || arr2.Length != 7)
        {
            Console.WriteLine("Ошибка: неверное количество элементов");
            return;
        }

        double[] newArr = arr1.Concat(arr2).OrderBy(x => x).ToArray();

        Console.WriteLine($"Первый массив: [{string.Join(", ", arr1)}]");
        Console.WriteLine($"Второй массив: [{string.Join(", ", arr2)}]");
        Console.WriteLine($"Объединенный отсортированный: [{string.Join(", ", newArr)}]");
    }

    static void Task5()
    {
        Console.WriteLine("\n=== Задача 5 ===");
        Console.WriteLine("Введите массив X из 10 целых чисел:");
        int[] X = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
        Console.WriteLine("Введите массив Y из 10 целых чисел:");
        int[] Y = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (X.Length != 10 || Y.Length != 10)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 10 элементов в каждом массиве");
            return;
        }

        int[] S = X.Intersect(Y).ToArray();

        Console.WriteLine($"Массив X: [{string.Join(", ", X)}]");
        Console.WriteLine($"Массив Y: [{string.Join(", ", Y)}]");
        Console.WriteLine($"Общие элементы: [{string.Join(", ", S)}]");
    }

    static void Task6()
    {
        Console.WriteLine("\n=== Задача 6 ===");
        double[] Y = new double[12];
        for (int i = 0; i < 12; i++)
        {
            Y[i] = i * i - 2 * i + 19.3 * Math.Cos(i);
        }

        double avg = Y.Average();
        double[] newArr = Y.Where(x => x < avg).Concat(Y.Where(x => x >= avg)).ToArray();

        Console.WriteLine($"Исходный массив Y: [{string.Join(", ", Y.Select(x => $"{x:F2}"))}]");
        Console.WriteLine($"Среднее арифметическое: {avg:F2}");
        Console.WriteLine($"Новый массив: [{string.Join(", ", newArr.Select(x => $"{x:F2}"))}]");
    }

    static void Task7()
    {
        Console.WriteLine("\n=== Задача 7 ===");
        Console.WriteLine("Введите 16 вещественных чисел:");
        double[] Z = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (Z.Length != 16)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 16 элементов");
            return;
        }

        double sumEven = Z.Where((x, i) => i % 2 == 0).Sum();
        double sumMultiple3 = Z.Where((x, i) => i % 3 == 0).Sum();
        double difference = sumEven - sumMultiple3;

        Console.WriteLine($"Массив: [{string.Join(", ", Z)}]");
        Console.WriteLine($"Сумма элементов с четными индексами: {sumEven:F2}");
        Console.WriteLine($"Сумма элементов с индексами кратными 3: {sumMultiple3:F2}");
        Console.WriteLine($"Разность: {difference:F2}");
    }

    static void Task8()
    {
        Console.WriteLine("\n=== Задача 8 ===");
        Console.WriteLine("Введите 9 целых чисел:");
        int[] R = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (R.Length != 9)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 9 элементов");
            return;
        }

        var oddPositive = R.Where((x, i) => x > 0 && x % 2 != 0).ToArray();
        if (oddPositive.Length > 0)
        {
            int maxValue = oddPositive.Max();
            int index = Array.IndexOf(R, maxValue);
            Console.WriteLine($"Массив: [{string.Join(", ", R)}]");
            Console.WriteLine($"Наибольший нечетный положительный: {maxValue}");
            Console.WriteLine($"Его индекс: {index}");
        }
        else
        {
            Console.WriteLine("Нет нечетных положительных элементов");
        }
    }

    static void Task9()
    {
        Console.WriteLine("\n=== Задача 9 ===");
        Console.WriteLine("Введите 15 целых чисел:");
        int[] X = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (X.Length != 15)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 15 элементов");
            return;
        }

        double[] Y = new double[15];
        for (int i = 0; i < 15; i++)
        {
            Y[i] = Math.Cos(X[i] * X[i]) + 2.97 * Math.Log(i * i) * Math.Log(i * i);
        }

        double[] combined = X.Select(x => (double)x).Concat(Y).OrderByDescending(x => x).ToArray();

        Console.WriteLine($"Массив X: [{string.Join(", ", X)}]");
        Console.WriteLine($"Массив Y: [{string.Join(", ", Y.Select(x => $"{x:F2}"))}]");
        Console.WriteLine($"Объединенный отсортированный: [{string.Join(", ", combined.Select(x => $"{x:F2}"))}]");
    }

    static void Task10()
    {
        Console.WriteLine("\n=== Задача 10 ===");
        Console.WriteLine("Введите 17 целых чисел:");
        int[] X = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (X.Length != 17)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 17 элементов");
            return;
        }

        double[] Y = new double[17];
        for (int i = 0; i < 17; i++)
        {
            if (Math.Cos(X[i]) > 0)
                Y[i] = Math.Pow(X[i], 3) - 7.5;
            else
                Y[i] = X[i] * X[i] - 5 * Math.Exp(Math.Sin(X[i]));
        }

        Array.Sort(Y); // по возрастанию
        Array.Sort(X, (a, b) => b.CompareTo(a)); // по убыванию

        double[] R = new double[17];
        for (int i = 0; i < 17; i++)
        {
            R[i] = i % 2 == 0 ? X[i] : Y[i];
        }

        Console.WriteLine($"Массив X (по убыванию): [{string.Join(", ", X)}]");
        Console.WriteLine($"Массив Y (по возрастанию): [{string.Join(", ", Y.Select(x => $"{x:F2}"))}]");
        Console.WriteLine($"Массив R: [{string.Join(", ", R.Select(x => $"{x:F2}"))}]");
    }

    static void Task11()
    {
        Console.WriteLine("\n=== Задача 11 ===");
        Console.WriteLine("Введите 9 двузначных чисел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 9 || arr.Any(x => x < 10 || x > 99))
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 9 двузначных чисел");
            return;
        }

        int[] newArr = arr.Select(x => x / 10 + x % 10).ToArray();

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Суммы цифр: [{string.Join(", ", newArr)}]");
    }

    static void Task12()
    {
        Console.WriteLine("\n=== Задача 12 ===");
        Console.WriteLine("Введите 12 вещественных чисел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr.Length != 12)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 12 элементов");
            return;
        }

        double[] sorted = arr.ToArray();
        int swaps = 0;

        // Сортировка пузырьком с подсчетом перестановок
        for (int i = 0; i < sorted.Length - 1; i++)
        {
            for (int j = 0; j < sorted.Length - 1 - i; j++)
            {
                if (sorted[j] < sorted[j + 1])
                {
                    (sorted[j], sorted[j + 1]) = (sorted[j + 1], sorted[j]);
                    swaps++;
                }
            }
        }

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Отсортированный: [{string.Join(", ", sorted)}]");
        Console.WriteLine($"Количество перестановок: {swaps}");
    }

    static void Task13()
    {
        Console.WriteLine("\n=== Задача 13 ===");
        Console.WriteLine("Введите 11 целых чисел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 11)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 11 элементов");
            return;
        }

        int sum = arr.Where(x => x < 0 && x % 2 != 0).Sum();
        int[] newArr = arr.Select(x => x % 3 == 0 ? sum : x).ToArray();

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Сумма нечетных отрицательных: {sum}");
        Console.WriteLine($"Новый массив: [{string.Join(", ", newArr)}]");
    }

    static void Task14()
    {
        Console.WriteLine("\n=== Задача 14 ===");
        Console.WriteLine("Введите 14 вещественных чисел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr.Length != 14)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 14 элементов");
            return;
        }

        double[] newArr = new double[14];
        int swaps = 0;

        // Меняем местами первую и вторую половину
        for (int i = 0; i < 7; i++)
        {
            newArr[i] = arr[i + 7];
            newArr[i + 7] = arr[i];
            swaps++;
        }

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"После замены: [{string.Join(", ", newArr)}]");
        Console.WriteLine($"Количество перестановок: {swaps}");
    }

    static void Task15()
    {
        Console.WriteLine("\n=== Задача 15 ===");
        Console.WriteLine("Введите вещественные числа через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();
        Console.Write("Введите число S: ");
        double S = double.Parse(Console.ReadLine());

        double maxDistance = 0;
        int maxIndex = 0;
        double maxValue = 0;

        for (int i = 0; i < arr.Length; i++)
        {
            double distance = Math.Abs(arr[i] - S);
            if (distance > maxDistance)
            {
                maxDistance = distance;
                maxIndex = i;
                maxValue = arr[i];
            }
        }

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Число S: {S}");
        Console.WriteLine($"Наиболее удаленный элемент: {maxValue}");
        Console.WriteLine($"Его индекс: {maxIndex}");
        Console.WriteLine($"Расстояние: {maxDistance:F2}");
    }

    static void Task16()
    {
        Console.WriteLine("\n=== Задача 16 ===");
        Console.WriteLine("Введите 10 целых чисел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 10)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 10 элементов");
            return;
        }

        int sum = 0, count = 0;
        foreach (int x in arr)
        {
            if (x < 0) break;
            sum += x;
            count++;
        }

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Сумма до первого отрицательного: {sum}");
        Console.WriteLine($"Количество элементов до первого отрицательного: {count}");
    }

    static void Task17()
    {
        Console.WriteLine("\n=== Задача 17 ===");
        Console.WriteLine("Введите числа через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        int localMinCount = 0;
        for (int i = 1; i < arr.Length - 1; i++)
        {
            if (arr[i] < arr[i - 1] && arr[i] < arr[i + 1])
                localMinCount++;
        }

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Количество локальных минимумов: {localMinCount}");
    }

    static void Task18()
    {
        Console.WriteLine("\n=== Задача 18 ===");
        Console.WriteLine("Введите числа через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        int localMaxCount = 0;
        for (int i = 1; i < arr.Length - 1; i++)
        {
            if (arr[i] > arr[i - 1] && arr[i] > arr[i + 1])
                localMaxCount++;
        }

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Количество локальных максимумов: {localMaxCount}");
    }

    static void Task19()
    {
        Console.WriteLine("\n=== Задача 19 ===");
        Console.WriteLine("Введите 15 целых чисел:");
        int[] Z = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (Z.Length != 15)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 15 элементов");
            return;
        }

        int firstNegative = Array.FindIndex(Z, x => x < 0);
        int firstZero = Array.FindIndex(Z, x => x == 0);

        if (firstNegative == -1 || firstZero == -1)
        {
            Console.WriteLine("Нет отрицательного или нулевого элемента");
            return;
        }

        int start = Math.Min(firstNegative, firstZero) + 1;
        int end = Math.Max(firstNegative, firstZero) - 1;
        int sum = 0;

        if (start <= end)
        {
            var between = Z.Skip(start).Take(end - start + 1).ToArray();
            sum = between.Sum();

            Console.WriteLine($"Массив: [{string.Join(", ", Z)}]");
            Console.WriteLine($"Элементы между первым отрицательным и нулевым: [{string.Join(", ", between)}]");
            Console.WriteLine($"Их сумма: {sum}");
        }
        else
        {
            Console.WriteLine("Между элементами нет других элементов");
        }
    }

    static void Task20()
    {
        Console.WriteLine("\n=== Задача 20 ===");
        Console.WriteLine("Введите числа через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        List<string> sequences = new List<string>();
        int start = -1;

        for (int i = 0; i < arr.Length - 1; i++)
        {
            if (arr[i] > arr[i + 1])
            {
                if (start == -1) start = i;
            }
            else if (start != -1)
            {
                if (i - start >= 1) // минимум 2 элемента в последовательности
                {
                    sequences.Add($"[{start}-{i}]");
                }
                start = -1;
            }
        }

        // Проверяем последнюю последовательность
        if (start != -1 && arr.Length - 1 - start >= 1)
        {
            sequences.Add($"[{start}-{arr.Length - 1}]");
        }

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Индексы убывающих последовательностей: {string.Join(", ", sequences)}");
    }

    static void Task21()
    {
        Console.WriteLine("\n=== Задача 21 ===");
        Console.WriteLine("Введите целые числа через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        var counts = arr.GroupBy(x => x).ToDictionary(g => g.Key, g => g.Count());
        int[] newArr = arr.Where(x => counts[x] <= 2).ToArray();

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"После удаления встречающихся >2 раз: [{string.Join(", ", newArr)}]");
    }

    static void Task22()
    {
        Console.WriteLine("\n=== Задача 22 ===");
        Console.WriteLine("Введите 10 целых чисел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 10)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 10 элементов");
            return;
        }

        int[] negatives = arr.Where(x => x <= 0).ToArray();
        int[] positives = arr.Where(x => x > 0).ToArray();
        int[] newArr = negatives.Concat(positives).ToArray();

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Новый массив: [{string.Join(", ", newArr)}]");
    }

    static void Task23()
    {
        Console.WriteLine("\n=== Задача 23 ===");
        Console.WriteLine("Введите 10 целых чисел:");
        int[] X = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (X.Length != 10)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 10 элементов");
            return;
        }

        double[] Y = X.Select(x => x * x + 0.3).ToArray();

        double numerator = 1, denominator = 1;
        for (int i = 0; i < 10; i++)
        {
            if (i % 2 == 0) // четные индексы (0,2,4,6,8)
                denominator *= X[i] * Y[i];
            else // нечетные индексы (1,3,5,7,9)
                numerator *= X[i] * Y[i];
        }

        double P = numerator / denominator;
        double remainder = P % 1;

        Console.WriteLine($"Массив X: [{string.Join(", ", X)}]");
        Console.WriteLine($"Массив Y: [{string.Join(", ", Y.Select(x => $"{x:F2}"))}]");
        Console.WriteLine($"P = {P:F6}");
        Console.WriteLine($"Остаток от деления: {remainder:F6}");
    }

    static void Task24()
    {
        Console.WriteLine("\n=== Задача 24 ===");
        Console.WriteLine("Введите 10 двузначных чисел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 10 || arr.Any(x => x < 10 || x > 99))
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 10 двузначных чисел");
            return;
        }

        int[] newArr = arr.Select(x => Math.Abs(x / 10 - x % 10)).ToArray();

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Разности цифр: [{string.Join(", ", newArr)}]");
    }

    static void Task25()
    {
        Console.WriteLine("\n=== Задача 25 ===");
        Console.WriteLine("Введите 15 целых чисел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 15)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 15 элементов");
            return;
        }

        int[] negatives = arr.Where(x => x < 0).OrderBy(x => x).ToArray();
        int[] positives = arr.Where(x => x > 0).OrderByDescending(x => x).ToArray();
        int[] newArr = negatives.Concat(positives).ToArray();

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Упорядоченный массив: [{string.Join(", ", newArr)}]");
    }

    static void Task26()
    {
        Console.WriteLine("\n=== Задача 26 ===");
        Console.WriteLine("Введите первый массив из 12 вещественных чисел:");
        double[] arr1 = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();
        Console.WriteLine("Введите второй массив из 12 вещественных чисел:");
        double[] arr2 = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr1.Length != 12 || arr2.Length != 12)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 12 элементов в каждом массиве");
            return;
        }

        double[] newArr1 = arr1.Select(x => arr2.Contains(x) ? 0 : x).ToArray();

        Console.WriteLine($"Первый массив: [{string.Join(", ", arr1)}]");
        Console.WriteLine($"Второй массив: [{string.Join(", ", arr2)}]");
        Console.WriteLine($"Первый массив после замены: [{string.Join(", ", newArr1)}]");
    }

    static void Task27()
    {
        Console.WriteLine("\n=== Задача 27 ===");
        Console.WriteLine("Введите целые числа через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        int sequences = 0;
        bool inSequence = false;

        for (int i = 0; i < arr.Length - 1; i++)
        {
            if (arr[i] < arr[i + 1])
            {
                if (!inSequence)
                {
                    sequences++;
                    inSequence = true;
                }
            }
            else
            {
                inSequence = false;
            }
        }

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Количество возрастающих последовательностей: {sequences}");
    }

    static void Task28()
    {
        Console.WriteLine("\n=== Задача 28 ===");
        Console.WriteLine("Введите целые числа через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        int sumEven = arr.Where((x, i) => i % 2 == 0).Sum();
        int sumOdd = arr.Where((x, i) => i % 2 != 0).Sum();

        if (sumOdd != 0)
        {
            int remainder = sumEven % sumOdd;
            Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
            Console.WriteLine($"Сумма четных индексов: {sumEven}, сумма нечетных: {sumOdd}");
            Console.WriteLine($"Остаток от деления: {remainder}");
        }
        else
        {
            Console.WriteLine("Деление на ноль невозможно");
        }
    }

    static void Task29()
    {
        Console.WriteLine("\n=== Задача 29 ===");
        Console.WriteLine("Введите целые числа через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        double avg = arr.Average();
        int countAbove = arr.Count(x => x > avg);
        double percentage = (double)countAbove / arr.Length * 100;

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Среднее арифметическое: {avg:F2}");
        Console.WriteLine($"Элементов выше среднего: {countAbove}");
        Console.WriteLine($"Процентное содержание: {percentage:F2}%");
    }

    static void Task30()
    {
        Console.WriteLine("\n=== Задача 30 ===");
        Console.WriteLine("Введите первый массив вещественных чисел:");
        double[] arr1 = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();
        Console.WriteLine("Введите второй массив вещественных чисел:");
        double[] arr2 = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr1.Length == 0 || arr2.Length == 0)
        {
            Console.WriteLine("Ошибка: массивы не должны быть пустыми");
            return;
        }

        double max1 = arr1.Max();
        double max2 = arr2.Max();
        int idx1 = Array.IndexOf(arr1, max1);
        int idx2 = Array.IndexOf(arr2, max2);

        (arr1[idx1], arr2[idx2]) = (max2, max1);

        Console.WriteLine($"Первый массив после замены: [{string.Join(", ", arr1)}]");
        Console.WriteLine($"Второй массив после замены: [{string.Join(", ", arr2)}]");
        Console.WriteLine($"Максимумы поменялись местами: {max1} <-> {max2}");
    }

    static void Main()
    {
        Dictionary<int, Action> tasks = new Dictionary<int, Action>
        {
            {1, Task1}, {2, Task2}, {3, Task3}, {4, Task4}, {5, Task5},
            {6, Task6}, {7, Task7}, {8, Task8}, {9, Task9}, {10, Task10},
            {11, Task11}, {12, Task12}, {13, Task13}, {14, Task14}, {15, Task15},
            {16, Task16}, {17, Task17}, {18, Task18}, {19, Task19}, {20, Task20},
            {21, Task21}, {22, Task22}, {23, Task23}, {24, Task24}, {25, Task25},
            {26, Task26}, {27, Task27}, {28, Task28}, {29, Task29}, {30, Task30}
        };

        while (true)
        {
            Console.WriteLine("\n" + new string('=', 50));
            Console.WriteLine("ВЫБЕРИТЕ ЗАДАЧУ (1-30)");
            Console.WriteLine("0 - Выход");
            Console.WriteLine(new string('=', 50));

            try
            {
                Console.Write("Ваш выбор: ");
                int choice = int.Parse(Console.ReadLine());

                if (choice == 0)
                {
                    Console.WriteLine("Выход из программы.");
                    break;
                }
                else if (tasks.ContainsKey(choice))
                {
                    tasks[choice]();
                }
                else
                {
                    Console.WriteLine("Неверный выбор. Введите число от 1 до 30.");
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка: введите целое число.");
            }
            catch (Exception e)
            {
                Console.WriteLine($"Произошла ошибка: {e.Message}");
            }
        }
    }
}