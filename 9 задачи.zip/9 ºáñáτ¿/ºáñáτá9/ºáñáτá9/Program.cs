﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Task1()
    {
        Console.WriteLine("\n=== Задача 1 ===");
        Console.WriteLine("Введите 14 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 14)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 14 элементов");
            return;
        }

        int count = arr.Count(x => x % 2 == 0);
        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Количество четных элементов: {count}");
    }

    static void Task2()
    {
        Console.WriteLine("\n=== Задача 2 ===");
        Console.WriteLine("Введите 12 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 12)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 12 элементов");
            return;
        }

        double avg = arr.Average();
        int[] newArr = (int[])arr.Clone();
        newArr[4] = (int)avg;

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Среднее арифметическое: {avg:F2}");
        Console.WriteLine($"Новый массив: [{string.Join(", ", newArr)}]");
    }

    static void Task3()
    {
        Console.WriteLine("\n=== Задача 3 ===");
        Console.WriteLine("Введите 11 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 11)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 11 элементов");
            return;
        }

        double avg = arr.Average();
        int count = arr.Count(x => Math.Abs(x) > avg);

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Среднее арифметическое: {avg:F2}");
        Console.WriteLine($"Количество элементов с |x| > среднего: {count}");
    }

    static void Task4()
    {
        Console.WriteLine("\n=== Задача 4 ===");
        Console.WriteLine("Введите 10 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 10)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 10 элементов");
            return;
        }

        int maxIdx = Array.IndexOf(arr, arr.Max());
        (arr[0], arr[maxIdx]) = (arr[maxIdx], arr[0]);

        Console.WriteLine($"Массив после замены: [{string.Join(", ", arr)}]");
    }

    static void Task5()
    {
        Console.WriteLine("\n=== Задача 5 ===");
        Console.WriteLine("Введите 9 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 9)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 9 элементов");
            return;
        }

        int minIdx = Array.IndexOf(arr, arr.Min());
        int maxIdx = Array.IndexOf(arr, arr.Max());
        (arr[minIdx], arr[maxIdx]) = (arr[maxIdx], arr[minIdx]);

        Console.WriteLine($"Массив после замены: [{string.Join(", ", arr)}]");
    }

    static void Task6()
    {
        Console.WriteLine("\n=== Задача 6 ===");
        Console.WriteLine("Введите 20 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 20)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 20 элементов");
            return;
        }

        int evenCount = arr.Count(x => x % 2 == 0);
        int oddCount = arr.Length - evenCount;

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Четных элементов: {evenCount}");
        Console.WriteLine($"Нечетных элементов: {oddCount}");

        if (evenCount > oddCount)
            Console.WriteLine("Четных элементов больше");
        else if (oddCount > evenCount)
            Console.WriteLine("Нечетных элементов больше");
        else
            Console.WriteLine("Количество четных и нечетных элементов одинаково");
    }

    static void Task7()
    {
        Console.WriteLine("\n=== Задача 7 ===");
        Console.WriteLine("Введите 15 вещественных чисел через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr.Length != 15)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 15 элементов");
            return;
        }

        double first = arr[0];
        int count = arr.Count(x => x > first);

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Первый элемент: {first}");
        Console.WriteLine($"Количество элементов > первого: {count}");
    }

    static void Task8()
    {
        Console.WriteLine("\n=== Задача 8 ===");
        Console.WriteLine("Введите 16 вещественных чисел через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr.Length != 16)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 16 элементов");
            return;
        }

        int minIdx = Array.IndexOf(arr, arr.Min());
        int maxIdx = Array.IndexOf(arr, arr.Max());

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Индекс минимального элемента: {minIdx}");
        Console.WriteLine($"Индекс максимального элемента: {maxIdx}");
    }

    static void Task9()
    {
        Console.WriteLine("\n=== Задача 9 ===");
        Console.WriteLine("Введите 15 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 15)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 15 элементов");
            return;
        }

        double avg = arr.Average();
        double[] newArr = arr.Select(x => x - avg).ToArray();

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Среднее арифметическое: {avg:F2}");
        Console.WriteLine($"Новый массив: [{string.Join(", ", newArr.Select(x => $"{x:F2}"))}]");
    }

    static void Task10()
    {
        Console.WriteLine("\n=== Задача 10 ===");
        Console.WriteLine("Введите 17 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 17)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 17 элементов");
            return;
        }

        var negativeAbs = arr.Where(x => x < 0).Select(x => Math.Abs(x)).ToArray();
        if (negativeAbs.Length > 0)
        {
            double avgNegAbs = negativeAbs.Average();
            int total = arr.Where(x => Math.Abs(x) > avgNegAbs).Sum();

            Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
            Console.WriteLine($"Среднее арифметическое модулей отрицательных: {avgNegAbs:F2}");
            Console.WriteLine($"Сумма элементов с |x| > этого значения: {total}");
        }
        else
        {
            Console.WriteLine("В массиве нет отрицательных элементов");
        }
    }

    static void Task11()
    {
        Console.WriteLine("\n=== Задача 11 ===");
        Console.WriteLine("Введите 14 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 14)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 14 элементов");
            return;
        }

        var evenPositive = arr.Where(x => x > 0 && x % 2 == 0).ToArray();
        int count = evenPositive.Length;
        int total = evenPositive.Sum();

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Количество четных положительных: {count}");
        Console.WriteLine($"Их сумма: {total}");
    }

    static void Task12()
    {
        Console.WriteLine("\n=== Задача 12 ===");
        Console.WriteLine("Введите 12 вещественных чисел через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr.Length != 12)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 12 элементов");
            return;
        }

        double[] sortedArr = arr.OrderByDescending(x => x).ToArray();
        double sumMinMax = arr.Min() + arr.Max();

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Отсортированный по убыванию: [{string.Join(", ", sortedArr)}]");
        Console.WriteLine($"Сумма минимального и максимального: {sumMinMax:F2}");
    }

    static void Task13()
    {
        Console.WriteLine("\n=== Задача 13 ===");
        Console.WriteLine("Введите 15 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 15)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 15 элементов");
            return;
        }

        int minVal = arr.Min(), maxVal = arr.Max();
        int sumVal = minVal + maxVal;
        int diffVal = maxVal - minVal;

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Минимальный: {minVal}, Максимальный: {maxVal}");
        Console.WriteLine($"Сумма: {sumVal}, Разность: {diffVal}");
    }

    static void Task14()
    {
        Console.WriteLine("\n=== Задача 14 ===");
        Console.WriteLine("Введите 17 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 17)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 17 элементов");
            return;
        }

        int oddSum = arr.Where(x => x % 2 != 0).Sum();
        int[] newArr = arr.Select(x => x % 3 == 0 ? oddSum : x).ToArray();

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Сумма нечетных элементов: {oddSum}");
        Console.WriteLine($"Новый массив: [{string.Join(", ", newArr)}]");
    }

    static void Task15()
    {
        Console.WriteLine("\n=== Задача 15 ===");
        Console.WriteLine("Введите 14 вещественных чисел через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr.Length != 14)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 14 элементов");
            return;
        }

        double[] firstPart = arr.Take(7).OrderBy(x => x).ToArray();
        double[] secondPart = arr.Skip(7).OrderByDescending(x => x).ToArray();
        double[] newArr = firstPart.Concat(secondPart).ToArray();

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Новый массив: [{string.Join(", ", newArr)}]");
    }

    static void Task16()
    {
        Console.WriteLine("\n=== Задача 16 ===");
        Console.WriteLine("Введите 12 вещественных чисел через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr.Length != 12)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 12 элементов");
            return;
        }

        int minIdx = Array.IndexOf(arr, arr.Min());
        int maxIdx = Array.IndexOf(arr, arr.Max());

        int start = Math.Min(minIdx, maxIdx);
        int end = Math.Max(minIdx, maxIdx);
        int countBetween = end - start - 1;

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Индекс минимального: {minIdx}, индекс максимального: {maxIdx}");
        Console.WriteLine($"Количество элементов между ними: {countBetween}");
    }

    static void Task17()
    {
        Console.WriteLine("\n=== Задача 17 ===");
        Console.WriteLine("Введите 15 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 15)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 15 элементов");
            return;
        }

        int negativeCount = arr.Count(x => x < 0);
        long positiveProduct = arr.Where(x => x > 0).Aggregate(1L, (acc, x) => acc * x);
        int zeroCount = arr.Count(x => x == 0);

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Количество отрицательных: {negativeCount}");
        Console.WriteLine($"Произведение положительных: {positiveProduct}");
        Console.WriteLine($"Количество нулевых: {zeroCount}");
    }

    static void Task18()
    {
        Console.WriteLine("\n=== Задача 18 ===");
        Console.WriteLine("Введите 12 вещественных чисел через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr.Length != 12)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 12 элементов");
            return;
        }

        double minVal = arr.Min(), maxVal = arr.Max();

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Границы интервала: [{minVal:F2}, {maxVal:F2}]");
    }

    static void Task19()
    {
        Console.WriteLine("\n=== Задача 19 ===");
        Console.WriteLine("Введите 19 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 19)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 19 элементов");
            return;
        }

        int sumBeforeNegative = 0;
        bool foundNegative = false;

        foreach (int x in arr)
        {
            if (x < 0)
            {
                foundNegative = true;
                break;
            }
            sumBeforeNegative += x;
        }

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        if (foundNegative)
            Console.WriteLine($"Сумма элементов до первого отрицательного: {sumBeforeNegative}");
        else
            Console.WriteLine("Отрицательных элементов нет");
    }

    static void Task20()
    {
        Console.WriteLine("\n=== Задача 20 ===");
        Console.WriteLine("Введите 16 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 16)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 16 элементов");
            return;
        }

        int replacements = 0;
        int[] newArr = new int[arr.Length];

        for (int i = 0; i < arr.Length; i++)
        {
            if (arr[i] % 3 == 0)
            {
                newArr[i] = 0;
                replacements++;
            }
            else
            {
                newArr[i] = arr[i];
            }
        }

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Новый массив: [{string.Join(", ", newArr)}]");
        Console.WriteLine($"Количество замен: {replacements}");
    }

    static void Task21()
    {
        Console.WriteLine("\n=== Задача 21 ===");
        Console.WriteLine("Введите 12 вещественных чисел через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr.Length != 12)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 12 элементов");
            return;
        }

        int minIdx = Array.IndexOf(arr, arr.Min());
        arr[minIdx] *= 3;
        (arr[minIdx], arr[^1]) = (arr[^1], arr[minIdx]);

        Console.WriteLine($"Массив после преобразований: [{string.Join(", ", arr)}]");
    }

    static void Task22()
    {
        Console.WriteLine("\n=== Задача 22 ===");
        Console.WriteLine("Введите 15 вещественных чисел через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr.Length != 15)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 15 элементов");
            return;
        }

        double[] reversedArr = arr.Reverse().ToArray();

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Массив в обратном порядке: [{string.Join(", ", reversedArr)}]");
    }

    static void Task23()
    {
        Console.WriteLine("\n=== Задача 23 ===");
        Console.WriteLine("Введите 14 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 14)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 14 элементов");
            return;
        }

        int sumEvenIndex = 0;
        for (int i = 0; i < arr.Length; i += 2)
            sumEvenIndex += arr[i];

        var oddValues = arr.Where(x => x % 2 != 0).ToArray();
        long productOddValue = oddValues.Length > 0 ? oddValues.Aggregate(1L, (acc, x) => acc * x) : 0;

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Сумма элементов с четными индексами: {sumEvenIndex}");
        Console.WriteLine($"Произведение нечетных по значению элементов: {productOddValue}");
    }

    static void Task24()
    {
        Console.WriteLine("\n=== Задача 24 ===");
        Console.WriteLine("Введите 12 вещественных чисел через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr.Length != 12)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 12 элементов");
            return;
        }

        double last = arr[^1];
        var smaller = arr.Take(arr.Length - 1).Where(x => x < last).ToArray();
        int count = smaller.Length;
        double total = smaller.Sum();

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Последний элемент: {last}");
        Console.WriteLine($"Количество элементов меньше последнего: {count}");
        Console.WriteLine($"Их сумма: {total:F2}");
    }

    static void Task25()
    {
        Console.WriteLine("\n=== Задача 25 ===");
        Console.WriteLine("Введите 15 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 15)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 15 элементов");
            return;
        }

        int positiveSum = arr.Where(x => x > 0).Sum();
        int[] newArr = arr.Select(x => x - positiveSum).ToArray();

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Сумма положительных элементов: {positiveSum}");
        Console.WriteLine($"Новый массив: [{string.Join(", ", newArr)}]");
    }

    static void Task26()
    {
        Console.WriteLine("\n=== Задача 26 ===");
        Console.WriteLine("Введите 15 вещественных чисел через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr.Length != 15)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 15 элементов");
            return;
        }

        double positiveProduct = arr.Where(x => x > 0).DefaultIfEmpty(1).Aggregate((acc, x) => acc * x);
        double negativeAbsProduct = arr.Where(x => x < 0).Select(x => Math.Abs(x)).DefaultIfEmpty(1).Aggregate((acc, x) => acc * x);
        double difference = positiveProduct - negativeAbsProduct;

        Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Произведение положительных: {positiveProduct:F2}");
        Console.WriteLine($"Произведение модулей отрицательных: {negativeAbsProduct:F2}");
        Console.WriteLine($"Разность: {difference:F2}");
    }

    static void Task27()
    {
        Console.WriteLine("\n=== Задача 27 ===");
        Console.WriteLine("Введите 19 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 19)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 19 элементов");
            return;
        }

        int maxVal = arr.Max();
        int[] newArr = arr.Select(x => x % 2 == 0 ? maxVal : x).ToArray();

        Console.WriteLine($"Исходный массив: [{string.Join(", ", arr)}]");
        Console.WriteLine($"Максимальное значение: {maxVal}");
        Console.WriteLine($"Новый массив: [{string.Join(", ", newArr)}]");
    }

    static void Task28()
    {
        Console.WriteLine("\n=== Задача 28 ===");
        Console.WriteLine("Введите 17 целых чисел через пробел:");
        int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

        if (arr.Length != 17)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 17 элементов");
            return;
        }

        var positive = arr.Where(x => x > 0).ToArray();
        if (positive.Length > 0)
        {
            double avgPositive = positive.Average();
            var selected = arr.Where(x => Math.Abs(x) > avgPositive).ToArray();
            int count = selected.Length;
            int total = selected.Sum();

            Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
            Console.WriteLine($"Среднее арифметическое положительных: {avgPositive:F2}");
            Console.WriteLine($"Количество элементов с |x| > этого значения: {count}");
            Console.WriteLine($"Их сумма: {total}");
        }
        else
        {
            Console.WriteLine("В массиве нет положительных элементов");
        }
    }

    static void Task29()
    {
        Console.WriteLine("\n=== Задача 29 ===");
        Console.WriteLine("Введите 18 вещественных чисел через пробел:");
        double[] arr = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();

        if (arr.Length != 18)
        {
            Console.WriteLine("Ошибка: нужно ввести ровно 18 элементов");
            return;
        }

        double positiveProduct = arr.Where(x => x > 0).DefaultIfEmpty(1).Aggregate((acc, x) => acc * x);
        double negativeAbsSum = arr.Where(x => x < 0).Select(x => Math.Abs(x)).Sum();

        if (negativeAbsSum != 0)
        {
            double quotient = positiveProduct / negativeAbsSum;
            Console.WriteLine($"Массив: [{string.Join(", ", arr)}]");
            Console.WriteLine($"Произведение положительных: {positiveProduct:F2}");
            Console.WriteLine($"Сумма модулей отрицательных: {negativeAbsSum:F2}");
            Console.WriteLine($"Частное: {quotient:F2}");
        }
        else
        {
            Console.WriteLine("Ошибка: сумма модулей отрицательных равна 0, деление невозможно");
        }
    }

    static void Main()
    {
        Dictionary<int, Action> tasks = new Dictionary<int, Action>
        {
            {1, Task1}, {2, Task2}, {3, Task3}, {4, Task4}, {5, Task5},
            {6, Task6}, {7, Task7}, {8, Task8}, {9, Task9}, {10, Task10},
            {11, Task11}, {12, Task12}, {13, Task13}, {14, Task14}, {15, Task15},
            {16, Task16}, {17, Task17}, {18, Task18}, {19, Task19}, {20, Task20},
            {21, Task21}, {22, Task22}, {23, Task23}, {24, Task24}, {25, Task25},
            {26, Task26}, {27, Task27}, {28, Task28}, {29, Task29}
        };

        while (true)
        {
            Console.WriteLine("\n" + new string('=', 50));
            Console.WriteLine("ВЫБЕРИТЕ ЗАДАЧУ (1-29)");
            Console.WriteLine("0 - Выход");
            Console.WriteLine(new string('=', 50));

            try
            {
                Console.Write("Ваш выбор: ");
                int choice = int.Parse(Console.ReadLine());

                if (choice == 0)
                {
                    Console.WriteLine("Выход из программы.");
                    break;
                }
                else if (tasks.ContainsKey(choice))
                {
                    tasks[choice]();
                }
                else
                {
                    Console.WriteLine("Неверный выбор. Введите число от 1 до 29.");
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка: введите целое число.");
            }
            catch (Exception e)
            {
                Console.WriteLine($"Произошла ошибка: {e.Message}");
            }
        }
    }
}
