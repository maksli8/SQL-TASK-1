﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypedDataSetConsoleApp
{
    // ====================== ЗАДАНИЕ 1: Ручное создание типизированного DataSet ======================
    public class EmployeesDataSet : DataSet
    {
        public EmployeesDataSet()
        {
            Tables.Add(new EmployeeDataTable());
        }

        public EmployeeDataTable Employee => Tables["Employee"] as EmployeeDataTable;

        public class EmployeeDataTable : DataTable
        {
            public EmployeeDataTable() : base("Employee")
            {
                Columns.Add("EmployeeID", typeof(int));
                Columns.Add("FirstName", typeof(string));
                Columns.Add("LastName", typeof(string));
                Columns.Add("Email", typeof(string));
                Columns.Add("Salary", typeof(decimal));
                Columns.Add("HireDate", typeof(DateTime));

                PrimaryKey = new DataColumn[] { Columns["EmployeeID"] };
                Columns["EmployeeID"].AutoIncrement = true;
                Columns["EmployeeID"].AutoIncrementSeed = 1;
            }

            public EmployeeRow this[int idx] => (EmployeeRow)Rows[idx];

            public void AddEmployeeRow(EmployeeRow row) => Rows.Add(row);

            public EmployeeRow NewEmployeeRow() => (EmployeeRow)NewRow();

            protected override Type GetRowType() => typeof(EmployeeRow);

            protected override DataRow NewRowFromBuilder(DataRowBuilder builder) => new EmployeeRow(builder);
        }

        public class EmployeeRow : DataRow
        {
            public EmployeeRow(DataRowBuilder builder) : base(builder) { }

            public int EmployeeID
            {
                get => (int)this["EmployeeID"];
                set => this["EmployeeID"] = value;
            }

            public string FirstName
            {
                get => this["FirstName"] as string;
                set => this["FirstName"] = value;
            }

            public string LastName
            {
                get => this["LastName"] as string;
                set => this["LastName"] = value;
            }

            public string Email
            {
                get => this["Email"] as string;
                set => this["Email"] = value;
            }

            public decimal Salary
            {
                get => (decimal)this["Salary"];
                set => this["Salary"] = value;
            }

            public DateTime HireDate
            {
                get => (DateTime)this["HireDate"];
                set => this["HireDate"] = value;
            }

            public string FullName => $"{FirstName} {LastName}";
        }
    }

    // ====================== ОСНОВНОЙ КЛАСС ПРИЛОЖЕНИЯ ======================
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== ПРАКТИЧЕСКИЕ ЗАДАНИЯ ПО ТИПИЗИРОВАННОМУ DATASET ===");
            Console.WriteLine();

            // Задание 1: Создание простого типизированного DataSet вручную
            Console.WriteLine("ЗАДАНИЕ 1: Ручное создание типизированного DataSet");
            Console.WriteLine(new string('-', 60));
            DemonstrateManualDataSet();

            // Задание 3: Сравнение типизированного и нетипизированного
            Console.WriteLine("\nЗАДАНИЕ 3: Сравнение типизированного и нетипизированного DataSet");
            Console.WriteLine(new string('-', 60));
            DemonstrateComparison();

            // Задание 5: Добавление строк
            Console.WriteLine("\nЗАДАНИЕ 5: Добавление строк в типизированный DataSet");
            Console.WriteLine(new string('-', 60));
            DemonstrateAddingRows();

            // Задание 6: Поиск данных
            Console.WriteLine("\nЗАДАНИЕ 6: Поиск данных в типизированном DataSet");
            Console.WriteLine(new string('-', 60));
            DemonstrateSearch();

            // Задание 7: Редактирование данных
            Console.WriteLine("\nЗАДАНИЕ 7: Редактирование данных в типизированном DataSet");
            Console.WriteLine(new string('-', 60));
            DemonstrateEditing();

            // Задание 8: Удаление данных
            Console.WriteLine("\nЗАДАНИЕ 8: Удаление данных в типизированном DataSet");
            Console.WriteLine(new string('-', 60));
            DemonstrateDeletion();

            // Задание 9: Валидация данных
            Console.WriteLine("\nЗАДАНИЕ 9: Валидация данных в типизированном DataSet");
            Console.WriteLine(new string('-', 60));
            DemonstrateValidation();

            // Задание 26: Сравнение производительности
            Console.WriteLine("\nЗАДАНИЕ 26: Сравнение производительности");
            Console.WriteLine(new string('-', 60));
            DemonstratePerformance();

            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        // ====================== РЕАЛИЗАЦИЯ МЕТОДОВ ДЛЯ ЗАДАНИЙ ======================
        static void DemonstrateManualDataSet()
        {
            try
            {
                var ds = new EmployeesDataSet();
                var table = ds.Employee;

                // Добавление строк разными способами (Задание 5)
                // Способ 1: Создание и добавление
                var row1 = table.NewEmployeeRow();
                row1.FirstName = "Иван";
                row1.LastName = "Петров";
                row1.Email = "ivan.petrov@email.com";
                row1.Salary = 50000;
                row1.HireDate = new DateTime(2020, 1, 15);
                table.AddEmployeeRow(row1);

                // Способ 2: Непосредственное создание
                var row2 = table.NewEmployeeRow();
                row2["FirstName"] = "Мария";
                row2["LastName"] = "Иванова";
                row2["Email"] = "maria.ivanova@email.com";
                row2["Salary"] = 60000;
                row2["HireDate"] = new DateTime(2019, 3, 20);
                table.Rows.Add(row2);

                Console.WriteLine("Создан типизированный DataSet с таблицей Employee:");
                Console.WriteLine($"Количество строк: {table.Rows.Count}");
                Console.WriteLine($"Столбцы: {string.Join(", ", table.Columns.Cast<DataColumn>().Select(c => c.ColumnName))}");
                Console.WriteLine();

                // Демонстрация типизированного доступа
                Console.WriteLine("Демонстрация типизированного доступа:");
                foreach (EmployeesDataSet.EmployeeRow emp in table.Rows)
                {
                    Console.WriteLine($"ID: {emp.EmployeeID}, Имя: {emp.FullName}, Email: {emp.Email}, " +
                                      $"Зарплата: {emp.Salary:C}, Дата найма: {emp.HireDate:dd.MM.yyyy}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }

        static void DemonstrateComparison()
        {
            // Создание типизированного DataSet
            var typedDs = new EmployeesDataSet();
            var typedTable = typedDs.Employee;

            // Создание нетипизированного DataSet
            var untypedDs = new DataSet();
            var untypedTable = new DataTable("Employee");
            untypedTable.Columns.Add("EmployeeID", typeof(int));
            untypedTable.Columns.Add("FirstName", typeof(string));
            untypedTable.Columns.Add("LastName", typeof(string));
            untypedTable.Columns.Add("Email", typeof(string));
            untypedTable.Columns.Add("Salary", typeof(decimal));
            untypedTable.Columns.Add("HireDate", typeof(DateTime));
            untypedDs.Tables.Add(untypedTable);

            // Добавление одинаковых данных
            for (int i = 1; i <= 3; i++)
            {
                // Типизированный доступ
                var typedRow = typedTable.NewEmployeeRow();
                typedRow.FirstName = $"Имя{i}";
                typedRow.LastName = $"Фамилия{i}";
                typedRow.Email = $"email{i}@test.com";
                typedRow.Salary = 40000 + i * 5000;
                typedRow.HireDate = DateTime.Now.AddDays(-i * 100);
                typedTable.AddEmployeeRow(typedRow);

                // Нетипизированный доступ
                var untypedRow = untypedTable.NewRow();
                untypedRow["FirstName"] = $"Имя{i}";
                untypedRow["LastName"] = $"Фамилия{i}";
                untypedRow["Email"] = $"email{i}@test.com";
                untypedRow["Salary"] = 40000 + i * 5000;
                untypedRow["HireDate"] = DateTime.Now.AddDays(-i * 100);
                untypedTable.Rows.Add(untypedRow);
            }

            Console.WriteLine("Сравнение доступа к данным:");
            Console.WriteLine();

            // Доступ с типизацией
            Console.WriteLine("1. Типизированный доступ (безопасность на этапе компиляции):");
            try
            {
                var firstTyped = typedTable[0];
                Console.WriteLine($"   Полное имя: {firstTyped.FullName}");
                Console.WriteLine($"   Зарплата: {firstTyped.Salary:C}");
                // Компилятор проверяет типы:
                // firstTyped.Salary = "не число"; // Ошибка компиляции!
            }
            catch (Exception ex)
            {
                Console.WriteLine($"   Ошибка: {ex.Message}");
            }

            // Доступ без типизации
            Console.WriteLine("\n2. Нетипизированный доступ (ошибки в runtime):");
            try
            {
                var firstUntyped = untypedTable.Rows[0];
                Console.WriteLine($"   Имя: {firstUntyped["FirstName"]}");
                Console.WriteLine($"   Зарплата: {firstUntyped["Salary"]}");

                // Ошибка времени выполнения (неправильное имя столбца)
                // Console.WriteLine($"   Несуществующий столбец: {firstUntyped["FullName"]}");

                // Ошибка типа в runtime
                // firstUntyped["Salary"] = "не число"; // Исключение!
            }
            catch (Exception ex)
            {
                Console.WriteLine($"   Ошибка: {ex.Message}");
            }

            Console.WriteLine("\n3. IntelliSense в типизированном DataSet:");
            Console.WriteLine("   При вводе 'firstTyped.' IDE показывает: EmployeeID, FirstName, LastName, Email...");
            Console.WriteLine("   В нетипизированном: 'firstUntyped[\"\"]' - IDE не знает доступные столбцы");
        }

        static void DemonstrateAddingRows()
        {
            var ds = new EmployeesDataSet();
            var table = ds.Employee;

            Console.WriteLine("Способы добавления строк:");

            // Способ 1: Через метод AddEmployeeRow()
            Console.WriteLine("\n1. Через метод AddEmployeeRow():");
            var row1 = table.NewEmployeeRow();
            row1.FirstName = "Алексей";
            row1.LastName = "Сидоров";
            row1.Email = "alex.sidorov@email.com";
            row1.Salary = 55000;
            row1.HireDate = DateTime.Now.AddMonths(-6);
            table.AddEmployeeRow(row1);
            Console.WriteLine($"   Добавлен: {row1.FullName}");

            // Способ 2: Непосредственное добавление в Rows
            Console.WriteLine("\n2. Непосредственное добавление в Rows:");
            var row2 = table.NewEmployeeRow();
            row2["FirstName"] = "Ольга";
            row2["LastName"] = "Кузнецова";
            row2["Email"] = "olga.kuznetsova@email.com";
            row2["Salary"] = 65000;
            row2["HireDate"] = DateTime.Now.AddMonths(-12);
            table.Rows.Add(row2);
            Console.WriteLine($"   Добавлен: {row2["FirstName"]} {row2["LastName"]}");

            // Способ 3: LoadDataRow
            Console.WriteLine("\n3. Через LoadDataRow:");
            var rowData = new object[] { null, "Дмитрий", "Васильев", "dmitry.vasiliev@email.com", 70000, DateTime.Now.AddMonths(-24) };
            table.LoadDataRow(rowData, false);
            Console.WriteLine($"   Добавлен: Дмитрий Васильев");

            Console.WriteLine($"\nИтого строк в таблице: {table.Rows.Count}");

            // Валидация
            Console.WriteLine("\nВалидация при добавлении:");
            try
            {
                var invalidRow = table.NewEmployeeRow();
                invalidRow.FirstName = "Тест";
                // Пропустим обязательные поля
                // table.AddEmployeeRow(invalidRow); // Вызовет исключение
                Console.WriteLine("   Проверка обязательных полей активна");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"   Ошибка валидации: {ex.Message}");
            }
        }

        static void DemonstrateSearch()
        {
            var ds = new EmployeesDataSet();
            var table = ds.Employee;

            // Заполняем тестовыми данными
            var employees = new[]
            {
                new { First = "Иван", Last = "Петров", Email = "ivan@test.com", Salary = 50000, HireDate = new DateTime(2020, 1, 1) },
                new { First = "Мария", Last = "Иванова", Email = "maria@test.com", Salary = 60000, HireDate = new DateTime(2019, 5, 1) },
                new { First = "Алексей", Last = "Сидоров", Email = "alex@test.com", Salary = 55000, HireDate = new DateTime(2021, 3, 1) },
                new { First = "Ольга", Last = "Петрова", Email = "olga@test.com", Salary = 70000, HireDate = new DateTime(2018, 7, 1) },
                new { First = "Дмитрий", Last = "Васильев", Email = "dmitry@test.com", Salary = 45000, HireDate = new DateTime(2022, 2, 1) }
            };

            foreach (var emp in employees)
            {
                var row = table.NewEmployeeRow();
                row.FirstName = emp.First;
                row.LastName = emp.Last;
                row.Email = emp.Email;
                row.Salary = emp.Salary;
                row.HireDate = emp.HireDate;
                table.AddEmployeeRow(row);
            }

            Console.WriteLine("Методы поиска в типизированном DataSet:");

            // Поиск по первичному ключу (если бы он был установлен)
            Console.WriteLine("\n1. Поиск по индексу:");
            if (table.Rows.Count > 2)
            {
                var employee = table[2]; // Типизированный доступ по индексу
                Console.WriteLine($"   Сотрудник с индексом 2: {employee.FullName}");
            }

            // Использование LINQ для поиска
            Console.WriteLine("\n2. Использование LINQ:");
            var highSalaryEmployees = table.AsEnumerable()
                .Cast<EmployeesDataSet.EmployeeRow>()
                .Where(e => e.Salary > 55000)
                .ToList();

            Console.WriteLine($"   Сотрудники с зарплатой > 55000: {highSalaryEmployees.Count}");
            foreach (var emp in highSalaryEmployees)
            {
                Console.WriteLine($"   - {emp.FullName}: {emp.Salary:C}");
            }

            // Поиск по фамилии
            Console.WriteLine("\n3. Поиск по фамилии (Petrov*):");
            var petrovs = table.AsEnumerable()
                .Cast<EmployeesDataSet.EmployeeRow>()
                .Where(e => e.LastName.StartsWith("Петр"))
                .ToList();

            foreach (var emp in petrovs)
            {
                Console.WriteLine($"   - {emp.FullName}");
            }

            // Сортировка
            Console.WriteLine("\n4. Сортировка по дате найма:");
            var sorted = table.AsEnumerable()
                .Cast<EmployeesDataSet.EmployeeRow>()
                .OrderBy(e => e.HireDate)
                .ToList();

            foreach (var emp in sorted)
            {
                Console.WriteLine($"   - {emp.FullName}: {emp.HireDate:dd.MM.yyyy}");
            }
        }

        static void DemonstrateEditing()
        {
            var ds = new EmployeesDataSet();
            var table = ds.Employee;

            // Создаем тестового сотрудника
            var row = table.NewEmployeeRow();
            row.FirstName = "Иван";
            row.LastName = "Петров";
            row.Email = "ivan.old@email.com";
            row.Salary = 50000;
            row.HireDate = new DateTime(2020, 1, 1);
            table.AddEmployeeRow(row);

            Console.WriteLine("Редактирование данных:");

            // Отслеживание состояния
            Console.WriteLine($"\n1. Состояние строки до изменений: {row.RowState}");

            // Редактирование с типизированным доступом
            Console.WriteLine("\n2. Редактирование свойств:");
            Console.WriteLine($"   До: {row.FullName}, Email: {row.Email}, Зарплата: {row.Salary:C}");

            row.Email = "ivan.new@email.com";
            row.Salary = 55000;
            row.FirstName = "Иван (измененный)";

            Console.WriteLine($"   После: {row.FullName}, Email: {row.Email}, Зарплата: {row.Salary:C}");
            Console.WriteLine($"   Состояние строки после изменений: {row.RowState}");

            // Валидация при редактировании
            Console.WriteLine("\n3. Валидация при редактировании:");
            try
            {
                // Попытка установить неверный тип данных
                // row.Salary = "не число"; // Ошибка компиляции!
                Console.WriteLine("   Типизация предотвращает ошибки несоответствия типов");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"   Ошибка: {ex.Message}");
            }

            // Откат изменений
            Console.WriteLine("\n4. Откат изменений:");
            row.RejectChanges();
            Console.WriteLine($"   После отката: {row.FullName}, Email: {row.Email}, Зарплата: {row.Salary:C}");
            Console.WriteLine($"   Состояние строки: {row.RowState}");
        }

        static void DemonstrateDeletion()
        {
            var ds = new EmployeesDataSet();
            var table = ds.Employee;

            // Заполняем тестовыми данными
            for (int i = 1; i <= 5; i++)
            {
                var row = table.NewEmployeeRow();
                row.FirstName = $"Сотрудник{i}";
                row.LastName = $"Тестовый{i}";
                row.Email = $"employee{i}@test.com";
                row.Salary = 40000 + i * 5000;
                row.HireDate = DateTime.Now.AddMonths(-i * 6);
                table.AddEmployeeRow(row);
            }

            Console.WriteLine("Удаление данных:");

            Console.WriteLine($"\n1. Исходное количество строк: {table.Rows.Count}");

            // Удаление по индексу
            Console.WriteLine("\n2. Удаление строки по индексу (3):");
            var employeeToDelete = table[2];
            Console.WriteLine($"   Удаляемый сотрудник: {employeeToDelete.FullName}");
            employeeToDelete.Delete();

            Console.WriteLine($"   Состояние строки после Delete(): {employeeToDelete.RowState}");
            Console.WriteLine($"   Видимое количество строк: {table.Rows.Count}");

            // Проверка наличия зависимостей (заглушка)
            Console.WriteLine("\n3. Проверка зависимостей перед удалением:");
            Console.WriteLine("   (В реальном приложении здесь была бы проверка внешних ключей)");

            // Массовое удаление
            Console.WriteLine("\n4. Массовое удаление (сотрудники с зарплатой < 50000):");
            var toDelete = table.AsEnumerable()
                .Cast<EmployeesDataSet.EmployeeRow>()
                .Where(e => e.Salary < 50000)
                .ToList();

            Console.WriteLine($"   Найдено для удаления: {toDelete.Count} сотрудников");
            foreach (var emp in toDelete)
            {
                emp.Delete();
            }

            // Принятие изменений
            Console.WriteLine("\n5. Принятие изменений (AcceptChanges):");
            Console.WriteLine($"   Количество строк до AcceptChanges: {table.Rows.Count}");
            ds.AcceptChanges();
            Console.WriteLine($"   Количество строк после AcceptChanges: {table.Rows.Count}");

            // Откат удаления
            Console.WriteLine("\n6. Откат удаления (RejectChanges):");
            Console.WriteLine("   (Для демонстрации нужно сначала сделать изменения)");
        }

        static void DemonstrateValidation()
        {
            var ds = new EmployeesDataSet();
            var table = ds.Employee;

            Console.WriteLine("Валидация данных:");

            // Встроенные ограничения
            Console.WriteLine("\n1. Встроенные ограничения (constraints):");
            table.Columns["Email"].AllowDBNull = false;
            table.Columns["Salary"].DefaultValue = 30000;

            // Добавляем проверку уникальности email
            var uniqueConstraint = new UniqueConstraint("UniqueEmail", table.Columns["Email"], false);
            table.Constraints.Add(uniqueConstraint);

            Console.WriteLine("   Установлены ограничения: NotNull для Email, Unique для Email, Default для Salary");

            // Custom валидация через события
            Console.WriteLine("\n2. Custom валидация через события:");
            table.ColumnChanging += (sender, e) =>
            {
                if (e.Column.ColumnName == "Email" && e.ProposedValue != null)
                {
                    string email = e.ProposedValue.ToString();
                    if (!email.Contains("@"))
                    {
                        throw new ArgumentException("Email должен содержать '@'");
                    }
                }

                if (e.Column.ColumnName == "Salary" && e.ProposedValue != null)
                {
                    decimal salary = Convert.ToDecimal(e.ProposedValue);
                    if (salary < 30000 || salary > 1000000)
                    {
                        throw new ArgumentException("Зарплата должна быть между 30,000 и 1,000,000");
                    }
                }
            };

            table.RowChanging += (sender, e) =>
            {
                var row = e.Row as EmployeesDataSet.EmployeeRow;
                if (row != null && row.HireDate > DateTime.Now)
                {
                    throw new ArgumentException("Дата найма не может быть в будущем");
                }
            };

            // Тестируем валидацию
            Console.WriteLine("\n3. Тестирование валидации:");

            try
            {
                var validRow = table.NewEmployeeRow();
                validRow.FirstName = "Валидный";
                validRow.LastName = "Сотрудник";
                validRow.Email = "valid@email.com";
                validRow.Salary = 50000;
                validRow.HireDate = DateTime.Now.AddMonths(-12);
                table.AddEmployeeRow(validRow);
                Console.WriteLine("   ✓ Валидная строка добавлена успешно");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"   ✗ Ошибка валидации: {ex.Message}");
            }

            try
            {
                var invalidRow = table.NewEmployeeRow();
                invalidRow.FirstName = "Невалидный";
                invalidRow.LastName = "Сотрудник";
                invalidRow.Email = "invalid-email"; // Нет @
                invalidRow.Salary = 50000;
                invalidRow.HireDate = DateTime.Now.AddMonths(-12);
                table.AddEmployeeRow(invalidRow);
                Console.WriteLine("   ✗ Невалидный email должен был вызвать ошибку");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"   ✓ Ошибка валидации перехвачена: {ex.Message}");
            }

            try
            {
                var invalidRow = table.NewEmployeeRow();
                invalidRow.FirstName = "Еще один";
                invalidRow.LastName = "Сотрудник";
                invalidRow.Email = "valid@email.com"; // Дубликат
                invalidRow.Salary = 50000;
                invalidRow.HireDate = DateTime.Now.AddMonths(-12);
                table.AddEmployeeRow(invalidRow);
                Console.WriteLine("   ✗ Дубликат email должен был вызвать ошибку");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"   ✓ Ошибка уникальности перехвачена: {ex.Message}");
            }
        }

        static void DemonstratePerformance()
        {
            Console.WriteLine("Сравнение производительности:");

            int iterations = 100000;
            var stopwatch = new Stopwatch();

            // Типизированный DataSet
            var typedDs = new EmployeesDataSet();
            var typedTable = typedDs.Employee;

            // Нетипизированный DataSet
            var untypedDs = new DataSet();
            var untypedTable = new DataTable("Employee");
            untypedTable.Columns.Add("EmployeeID", typeof(int));
            untypedTable.Columns.Add("FirstName", typeof(string));
            untypedTable.Columns.Add("LastName", typeof(string));
            untypedTable.Columns.Add("Email", typeof(string));
            untypedTable.Columns.Add("Salary", typeof(decimal));
            untypedTable.Columns.Add("HireDate", typeof(DateTime));
            untypedDs.Tables.Add(untypedTable);

            // Заполнение данных
            Console.WriteLine($"\nЗаполнение {iterations} записей:");

            stopwatch.Start();
            for (int i = 0; i < iterations; i++)
            {
                var row = typedTable.NewEmployeeRow();
                row.FirstName = $"Имя{i}";
                row.LastName = $"Фамилия{i}";
                row.Email = $"email{i}@test.com";
                row.Salary = 40000 + i % 1000;
                row.HireDate = DateTime.Now.AddDays(-i);
                typedTable.AddEmployeeRow(row);
            }
            stopwatch.Stop();
            Console.WriteLine($"   Типизированный: {stopwatch.ElapsedMilliseconds} мс");

            stopwatch.Restart();
            for (int i = 0; i < iterations; i++)
            {
                var row = untypedTable.NewRow();
                row["FirstName"] = $"Имя{i}";
                row["LastName"] = $"Фамилия{i}";
                row["Email"] = $"email{i}@test.com";
                row["Salary"] = 40000 + i % 1000;
                row["HireDate"] = DateTime.Now.AddDays(-i);
                untypedTable.Rows.Add(row);
            }
            stopwatch.Stop();
            Console.WriteLine($"   Нетипизированный: {stopwatch.ElapsedMilliseconds} мс");

            // Доступ к данным
            Console.WriteLine($"\nДоступ к {iterations} записям:");

            stopwatch.Restart();
            decimal typedTotal = 0;
            for (int i = 0; i < Math.Min(iterations, typedTable.Rows.Count); i++)
            {
                var row = typedTable[i];
                typedTotal += row.Salary;
            }
            stopwatch.Stop();
            Console.WriteLine($"   Типизированный: {stopwatch.ElapsedMilliseconds} мс");

            stopwatch.Restart();
            decimal untypedTotal = 0;
            for (int i = 0; i < Math.Min(iterations, untypedTable.Rows.Count); i++)
            {
                var row = untypedTable.Rows[i];
                untypedTotal += (decimal)row["Salary"];
            }
            stopwatch.Stop();
            Console.WriteLine($"   Нетипизированный: {stopwatch.ElapsedMilliseconds} мс");

            // Поиск данных
            Console.WriteLine($"\nПоиск среди {iterations} записей:");

            stopwatch.Restart();
            var typedSearch = typedTable.AsEnumerable()
                .Cast<EmployeesDataSet.EmployeeRow>()
                .Where(e => e.Salary > 45000)
                .Count();
            stopwatch.Stop();
            Console.WriteLine($"   Типизированный (LINQ): {stopwatch.ElapsedMilliseconds} мс, найдено: {typedSearch}");

            stopwatch.Restart();
            var untypedSearch = untypedTable.AsEnumerable()
                .Where(e => (decimal)e["Salary"] > 45000)
                .Count();
            stopwatch.Stop();
            Console.WriteLine($"   Нетипизированный (LINQ): {stopwatch.ElapsedMilliseconds} мс, найдено: {untypedSearch}");

            Console.WriteLine("\nВыводы:");
            Console.WriteLine("1. Типизированный DataSet быстрее при доступе к данным");
            Console.WriteLine("2. Типизированный доступ безопаснее (проверка типов на этапе компиляции)");
            Console.WriteLine("3. IntelliSense улучшает производительность разработки");
        }
    }

    // ====================== ДОПОЛНИТЕЛЬНЫЕ КЛАССЫ ДЛЯ СЛОЖНЫХ ЗАДАНИЙ ======================

    // Задание 11: DataSet с несколькими таблицами и отношениями
    public class CompanyDataSet : DataSet
    {
        public CompanyDataSet()
        {
            Tables.Add(new DepartmentsTable());
            Tables.Add(new EmployeesTable());

            // Создаем отношение
            var relation = new DataRelation("DeptEmp",
                Tables["Departments"].Columns["DepartmentID"],
                Tables["Employees"].Columns["DepartmentID"]);
            Relations.Add(relation);
        }

        public DepartmentsTable Departments => Tables["Departments"] as DepartmentsTable;
        public EmployeesTable Employees => Tables["Employees"] as EmployeesTable;

        public class DepartmentsTable : DataTable
        {
            public DepartmentsTable() : base("Departments")
            {
                Columns.Add("DepartmentID", typeof(int));
                Columns.Add("DepartmentName", typeof(string));
                PrimaryKey = new DataColumn[] { Columns["DepartmentID"] };
            }
        }

        public class EmployeesTable : DataTable
        {
            public EmployeesTable() : base("Employees")
            {
                Columns.Add("EmployeeID", typeof(int));
                Columns.Add("FirstName", typeof(string));
                Columns.Add("LastName", typeof(string));
                Columns.Add("DepartmentID", typeof(int));
                PrimaryKey = new DataColumn[] { Columns["EmployeeID"] };
            }
        }
    }

    // Задание 24: DataSet с вычисляемыми полями
    public class OrdersDataSet : DataSet
    {
        public OrdersDataSet()
        {
            var table = new OrdersTable();

            // Добавляем вычисляемые столбцы
            table.Columns.Add("Quantity", typeof(int));
            table.Columns.Add("Price", typeof(decimal));

            // Вычисляемый столбец: Итого = Количество × Цена
            var totalColumn = new DataColumn("Total", typeof(decimal), "Quantity * Price");
            table.Columns.Add(totalColumn);

            // Вычисляемый столбец: Налог = Итого × 0.18
            var taxColumn = new DataColumn("Tax", typeof(decimal), "Total * 0.18");
            table.Columns.Add(taxColumn);

            // Вычисляемый столбец: К оплате = Итого + Налог
            var totalWithTaxColumn = new DataColumn("TotalWithTax", typeof(decimal), "Total + Tax");
            table.Columns.Add(totalWithTaxColumn);

            Tables.Add(table);
        }

        public OrdersTable Orders => Tables["Orders"] as OrdersTable;

        public class OrdersTable : DataTable
        {
            public OrdersTable() : base("Orders")
            {
                Columns.Add("OrderID", typeof(int));
                Columns.Add("ProductName", typeof(string));
                PrimaryKey = new DataColumn[] { Columns["OrderID"] };
            }
        }
    }
}